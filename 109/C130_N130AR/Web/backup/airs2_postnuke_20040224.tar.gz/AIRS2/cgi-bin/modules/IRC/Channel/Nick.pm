# $Id: Nick.pm,v 1.2 2003/01/23 13:38:56 r0d3r1k Exp $
package IRC::Channel::Nick;
use strict;

sub new {
   my $class = shift;
   my $self = bless { }, $class;
   %$self = @_;
   return $self;
}

# Maybe i'll add some functions here, one day...

1;
