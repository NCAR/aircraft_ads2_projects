# phpMyAdmin MySQL-Dump
# version 2.2.2
# http://phpwizard.net/phpMyAdmin/
# http://phpmyadmin.sourceforge.net/ (download page)
#
# Host: localhost
# Tiempo de Generacion: May 30, 2002 at 10:46 PM
# Version del Servidor: 3.23.46
# Version del PHP: 4.1.0
# Base De Datos : `phpbb201`
# --------------------------------------------------------

#
# Estructura de tabla para tabla `phpbb_auth_access`
#

CREATE TABLE phpbb_auth_access (
  group_id mediumint(8) NOT NULL default '0',
  forum_id smallint(5) unsigned NOT NULL default '0',
  auth_view tinyint(1) NOT NULL default '0',
  auth_read tinyint(1) NOT NULL default '0',
  auth_post tinyint(1) NOT NULL default '0',
  auth_reply tinyint(1) NOT NULL default '0',
  auth_edit tinyint(1) NOT NULL default '0',
  auth_delete tinyint(1) NOT NULL default '0',
  auth_sticky tinyint(1) NOT NULL default '0',
  auth_announce tinyint(1) NOT NULL default '0',
  auth_vote tinyint(1) NOT NULL default '0',
  auth_pollcreate tinyint(1) NOT NULL default '0',
  auth_attachments tinyint(1) NOT NULL default '0',
  auth_mod tinyint(1) NOT NULL default '0',
  KEY group_id (group_id),
  KEY forum_id (forum_id)
) TYPE=MyISAM;

#
# Volcar la base de datos para la tabla `phpbb_auth_access`
#

# --------------------------------------------------------

#
# Estructura de tabla para tabla `phpbb_banlist`
#

CREATE TABLE phpbb_banlist (
  ban_id mediumint(8) unsigned NOT NULL auto_increment,
  ban_userid mediumint(8) NOT NULL default '0',
  ban_ip varchar(8) NOT NULL default '',
  ban_email varchar(255) default NULL,
  PRIMARY KEY  (ban_id),
  KEY ban_ip_user_id (ban_ip,ban_userid)
) TYPE=MyISAM;

#
# Volcar la base de datos para la tabla `phpbb_banlist`
#

# --------------------------------------------------------

#
# Estructura de tabla para tabla `phpbb_categories`
#

CREATE TABLE phpbb_categories (
  cat_id mediumint(8) unsigned NOT NULL auto_increment,
  cat_title varchar(100) default NULL,
  cat_order mediumint(8) unsigned NOT NULL default '0',
  PRIMARY KEY  (cat_id),
  KEY cat_order (cat_order)
) TYPE=MyISAM;

#
# Volcar la base de datos para la tabla `phpbb_categories`
#

INSERT INTO phpbb_categories VALUES (1, 'Test category 1', 10);
# --------------------------------------------------------

#
# Estructura de tabla para tabla `phpbb_config`
#

CREATE TABLE phpbb_config (
  config_name varchar(255) NOT NULL default '',
  config_value varchar(255) NOT NULL default '',
  PRIMARY KEY  (config_name)
) TYPE=MyISAM;

#
# Volcar la base de datos para la tabla `phpbb_config`
#

INSERT INTO phpbb_config VALUES ('config_id', '1'),
('board_disable', '0'),
('sitename', 'yourdomain.com'),
('site_desc', 'A _little_ text to describe your forum'),
('cookie_name', 'phpbb2mysql'),
('cookie_path', '/'),
('cookie_domain', 'TEST'),
('cookie_secure', '0'),
('session_length', '3600'),
('allow_html', '0'),
('allow_html_tags', 'b,i,u,pre'),
('allow_bbcode', '1'),
('allow_smilies', '1'),
('allow_sig', '1'),
('allow_namechange', '0'),
('allow_theme_create', '0'),
('allow_avatar_local', '0'),
('allow_avatar_remote', '0'),
('allow_avatar_upload', '0'),
('override_user_style', '0'),
('posts_per_page', '15'),
('topics_per_page', '50'),
('hot_threshold', '25'),
('max_poll_options', '10'),
('max_sig_chars', '255'),
('max_inbox_privmsgs', '50'),
('max_sentbox_privmsgs', '25'),
('max_savebox_privmsgs', '50'),
('board_email_sig', 'Thanks, The Management'),
('board_email', 'none@none.com'),
('smtp_delivery', '0'),
('smtp_host', ''),
('smtp_username', ''),
('smtp_password', ''),
('require_activation', '0'),
('flood_interval', '15'),
('board_email_form', '0'),
('avatar_filesize', '6144'),
('avatar_max_width', '80'),
('avatar_max_height', '80'),
('avatar_path', 'modules/phpBB2/images/avatars'),
('avatar_gallery_path', 'modules/phpBB2/images/avatars/gallery'),
('smilies_path', 'modules/phpBB2/images/smiles'),
('default_style', '1'),
('default_dateformat', 'D M d, Y g:i a'),
('board_timezone', '0'),
('prune_enable', '1'),
('privmsg_disable', '0'),
('gzip_compress', '0'),
('coppa_fax', ''),
('coppa_mail', ''),
('record_online_users', '1'),
('record_online_date', '1022816688'),
('server_name', 'TEST'),
('server_port', '80'),
('script_path', '/modules/phpBB2/'),
('version', '.0.1'),
('board_startdate', '1022816686'),
('default_lang', 'english');
# --------------------------------------------------------

#
# Estructura de tabla para tabla `phpbb_disallow`
#

CREATE TABLE phpbb_disallow (
  disallow_id mediumint(8) unsigned NOT NULL auto_increment,
  disallow_username varchar(25) default NULL,
  PRIMARY KEY  (disallow_id)
) TYPE=MyISAM;

#
# Volcar la base de datos para la tabla `phpbb_disallow`
#

# --------------------------------------------------------

#
# Estructura de tabla para tabla `phpbb_forum_prune`
#

CREATE TABLE phpbb_forum_prune (
  prune_id mediumint(8) unsigned NOT NULL auto_increment,
  forum_id smallint(5) unsigned NOT NULL default '0',
  prune_days tinyint(4) unsigned NOT NULL default '0',
  prune_freq tinyint(4) unsigned NOT NULL default '0',
  PRIMARY KEY  (prune_id),
  KEY forum_id (forum_id)
) TYPE=MyISAM;

#
# Volcar la base de datos para la tabla `phpbb_forum_prune`
#

# --------------------------------------------------------

#
# Estructura de tabla para tabla `phpbb_forums`
#

CREATE TABLE phpbb_forums (
  forum_id smallint(5) unsigned NOT NULL default '0',
  cat_id mediumint(8) unsigned NOT NULL default '0',
  forum_name varchar(150) default NULL,
  forum_desc text,
  forum_status tinyint(4) NOT NULL default '0',
  forum_order mediumint(8) unsigned NOT NULL default '1',
  forum_posts mediumint(8) unsigned NOT NULL default '0',
  forum_topics mediumint(8) unsigned NOT NULL default '0',
  forum_last_post_id mediumint(8) unsigned NOT NULL default '0',
  prune_next int(11) default NULL,
  prune_enable tinyint(1) NOT NULL default '0',
  auth_view tinyint(2) NOT NULL default '0',
  auth_read tinyint(2) NOT NULL default '0',
  auth_post tinyint(2) NOT NULL default '0',
  auth_reply tinyint(2) NOT NULL default '0',
  auth_edit tinyint(2) NOT NULL default '0',
  auth_delete tinyint(2) NOT NULL default '0',
  auth_sticky tinyint(2) NOT NULL default '0',
  auth_announce tinyint(2) NOT NULL default '0',
  auth_vote tinyint(2) NOT NULL default '0',
  auth_pollcreate tinyint(2) NOT NULL default '0',
  auth_attachments tinyint(2) NOT NULL default '0',
  PRIMARY KEY  (forum_id),
  KEY forums_order (forum_order),
  KEY cat_id (cat_id),
  KEY forum_last_post_id (forum_last_post_id)
) TYPE=MyISAM;

#
# Volcar la base de datos para la tabla `phpbb_forums`
#

INSERT INTO phpbb_forums VALUES (1, 1, 'Test Forum 1', 'This is just a test forum.', 0, 10, 1, 1, 1, NULL, 0, 0, 0, 0, 0, 1, 1, 1, 3, 1, 1, 3);
# --------------------------------------------------------

#
# Estructura de tabla para tabla `phpbb_groups`
#

CREATE TABLE phpbb_groups (
  group_id mediumint(8) NOT NULL default '0',
  group_type tinyint(4) NOT NULL default '1',
  group_name varchar(40) NOT NULL default '',
  group_description varchar(255) NOT NULL default '',
  group_moderator mediumint(8) NOT NULL default '0',
  group_single_user tinyint(1) NOT NULL default '1',
  PRIMARY KEY  (group_id),
  KEY group_single_user (group_single_user)
) TYPE=MyISAM;

#
# Volcar la base de datos para la tabla `phpbb_groups`
#

INSERT INTO phpbb_groups VALUES (1, 1, 'Anonymous', 'Personal User', 0, 1);

# --------------------------------------------------------

#
# Estructura de tabla para tabla `phpbb_posts`
#

CREATE TABLE phpbb_posts (
  post_id mediumint(8) unsigned NOT NULL auto_increment,
  topic_id mediumint(8) unsigned NOT NULL default '0',
  forum_id smallint(5) unsigned NOT NULL default '0',
  poster_id mediumint(8) NOT NULL default '0',
  post_time int(11) NOT NULL default '0',
  poster_ip varchar(8) NOT NULL default '',
  post_username varchar(25) default NULL,
  enable_bbcode tinyint(1) NOT NULL default '1',
  enable_html tinyint(1) NOT NULL default '0',
  enable_smilies tinyint(1) NOT NULL default '1',
  enable_sig tinyint(1) NOT NULL default '1',
  post_edit_time int(11) default NULL,
  post_edit_count smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (post_id),
  KEY forum_id (forum_id),
  KEY topic_id (topic_id),
  KEY poster_id (poster_id),
  KEY post_time (post_time)
) TYPE=MyISAM;

#
# Volcar la base de datos para la tabla `phpbb_posts`
#

INSERT INTO phpbb_posts VALUES (1, 1, 1, 2, 972086460, '7F000001', NULL, 1, 0, 1, 1, NULL, 0);
# --------------------------------------------------------

#
# Estructura de tabla para tabla `phpbb_posts_text`
#

CREATE TABLE phpbb_posts_text (
  post_id mediumint(8) unsigned NOT NULL default '0',
  bbcode_uid varchar(10) NOT NULL default '',
  post_subject varchar(60) default NULL,
  post_text text,
  PRIMARY KEY  (post_id)
) TYPE=MyISAM;

#
# Volcar la base de datos para la tabla `phpbb_posts_text`
#

INSERT INTO phpbb_posts_text VALUES (1, '', NULL, 'This is an example post in your phpBB 2 installation. You may delete this post, this topic and even this forum if you like since everything seems to be working!');
# --------------------------------------------------------

#
# Estructura de tabla para tabla `phpbb_privmsgs`
#

CREATE TABLE phpbb_privmsgs (
  privmsgs_id mediumint(8) unsigned NOT NULL auto_increment,
  privmsgs_type tinyint(4) NOT NULL default '0',
  privmsgs_subject varchar(255) NOT NULL default '0',
  privmsgs_from_userid mediumint(8) NOT NULL default '0',
  privmsgs_to_userid mediumint(8) NOT NULL default '0',
  privmsgs_date int(11) NOT NULL default '0',
  privmsgs_ip varchar(8) NOT NULL default '',
  privmsgs_enable_bbcode tinyint(1) NOT NULL default '1',
  privmsgs_enable_html tinyint(1) NOT NULL default '0',
  privmsgs_enable_smilies tinyint(1) NOT NULL default '1',
  privmsgs_attach_sig tinyint(1) NOT NULL default '1',
  PRIMARY KEY  (privmsgs_id),
  KEY privmsgs_from_userid (privmsgs_from_userid),
  KEY privmsgs_to_userid (privmsgs_to_userid)
) TYPE=MyISAM;

#
# Volcar la base de datos para la tabla `phpbb_privmsgs`
#

# --------------------------------------------------------

#
# Estructura de tabla para tabla `phpbb_privmsgs_text`
#

CREATE TABLE phpbb_privmsgs_text (
  privmsgs_text_id mediumint(8) unsigned NOT NULL default '0',
  privmsgs_bbcode_uid varchar(10) NOT NULL default '0',
  privmsgs_text text,
  PRIMARY KEY  (privmsgs_text_id)
) TYPE=MyISAM;

#
# Volcar la base de datos para la tabla `phpbb_privmsgs_text`
#

# --------------------------------------------------------

#
# Estructura de tabla para tabla `phpbb_ranks`
#

CREATE TABLE phpbb_ranks (
  rank_id smallint(5) unsigned NOT NULL auto_increment,
  rank_title varchar(50) NOT NULL default '',
  rank_min mediumint(8) NOT NULL default '0',
  rank_special tinyint(1) default '0',
  rank_image varchar(255) default NULL,
  PRIMARY KEY  (rank_id)
) TYPE=MyISAM;

#
# Volcar la base de datos para la tabla `phpbb_ranks`
#

INSERT INTO phpbb_ranks VALUES (1, 'Site Admin', -1, 1, NULL);
# --------------------------------------------------------

#
# Estructura de tabla para tabla `phpbb_search_results`
#

CREATE TABLE phpbb_search_results (
  search_id int(11) unsigned NOT NULL default '0',
  session_id varchar(32) NOT NULL default '',
  search_array text NOT NULL,
  PRIMARY KEY  (search_id),
  KEY session_id (session_id)
) TYPE=MyISAM;

#
# Volcar la base de datos para la tabla `phpbb_search_results`
#

# --------------------------------------------------------

#
# Estructura de tabla para tabla `phpbb_search_wordlist`
#

CREATE TABLE phpbb_search_wordlist (
  word_text varchar(50) binary NOT NULL default '',
  word_id mediumint(8) unsigned NOT NULL auto_increment,
  word_common tinyint(1) unsigned NOT NULL default '0',
  PRIMARY KEY  (word_text),
  KEY word_id (word_id)
) TYPE=MyISAM;

#
# Volcar la base de datos para la tabla `phpbb_search_wordlist`
#

INSERT INTO phpbb_search_wordlist VALUES ('example', 1, 0),
('post', 2, 0),
('phpbb', 3, 0),
('installation', 4, 0),
('delete', 5, 0),
('topic', 6, 0),
('forum', 7, 0),
('since', 8, 0),
('everything', 9, 0),
('seems', 10, 0),
('working', 11, 0),
('welcome', 12, 0);
# --------------------------------------------------------

#
# Estructura de tabla para tabla `phpbb_search_wordmatch`
#

CREATE TABLE phpbb_search_wordmatch (
  post_id mediumint(8) unsigned NOT NULL default '0',
  word_id mediumint(8) unsigned NOT NULL default '0',
  title_match tinyint(1) NOT NULL default '0',
  KEY word_id (word_id)
) TYPE=MyISAM;

#
# Volcar la base de datos para la tabla `phpbb_search_wordmatch`
#

INSERT INTO phpbb_search_wordmatch VALUES (1, 1, 0),
(1, 2, 0),
(1, 3, 0),
(1, 4, 0),
(1, 5, 0),
(1, 6, 0),
(1, 7, 0),
(1, 8, 0),
(1, 9, 0),
(1, 10, 0),
(1, 11, 0),
(1, 12, 1),
(1, 3, 1);
# --------------------------------------------------------

#
# Estructura de tabla para tabla `phpbb_sessions`
#

CREATE TABLE phpbb_sessions (
  session_id char(32) NOT NULL default '',
  session_user_id mediumint(8) NOT NULL default '0',
  session_start int(11) NOT NULL default '0',
  session_time int(11) NOT NULL default '0',
  session_ip char(8) NOT NULL default '0',
  session_page int(11) NOT NULL default '0',
  session_logged_in tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (session_id),
  KEY session_user_id (session_user_id),
  KEY session_id_ip_user_id (session_id,session_ip,session_user_id)
) TYPE=HEAP;

#
# Volcar la base de datos para la tabla `phpbb_sessions`
#

INSERT INTO phpbb_sessions VALUES ('97d278e2e616a9b5751528588f402110', -1, 1022816688, 1022816688, '7f000001', -1, 0),
('8d9c481af26071477441f199ab9fdbf1', 2, 1022816688, 1022816688, '7f000001', 0, 1),
('911440ce7fa1597d9f4a314f2496b95a', -1, 1022816688, 1022816688, '7f000001', 0, 0),
('931dcd4e3abb3abf0d4f5590c3fbb85a', -1, 1022816688, 1022816688, '7f000001', -1, 0),
('4b767118951245261cbe6282c1105c4d', -1, 1022816692, 1022816692, '7f000001', -1, 0),
('31d4d460855062833f510875762f1d09', 2, 1022816692, 1022816692, '7f000001', 0, 1),
('d97a8e76e0a142043272253dba3b7dc5', -1, 1022816692, 1022816692, '7f000001', 0, 0),
('8632409a5a646588518a234603e55051', -1, 1022816692, 1022816692, '7f000001', -1, 0),
('5abd11238092f041cde6628ea2eb7d21', -1, 1022816696, 1022816696, '7f000001', -1, 0),
('73c3ee1038e0b39dac4fc268cf8b9ad4', 2, 1022816696, 1022816696, '7f000001', 0, 1),
('3cd73e29a039f48e95b35988d40a172e', -1, 1022816696, 1022816696, '7f000001', 0, 0),
('520804ee7dc812511292767dadc810a3', -1, 1022816696, 1022816696, '7f000001', -1, 0),
('ca4bc8d1839bf282616996e0f17515a0', -1, 1022816727, 1022816727, '7f000001', 0, 0);
# --------------------------------------------------------

#
# Estructura de tabla para tabla `phpbb_smilies`
#

CREATE TABLE phpbb_smilies (
  smilies_id smallint(5) unsigned NOT NULL auto_increment,
  code varchar(50) default NULL,
  smile_url varchar(100) default NULL,
  emoticon varchar(75) default NULL,
  PRIMARY KEY  (smilies_id)
) TYPE=MyISAM;

#
# Volcar la base de datos para la tabla `phpbb_smilies`
#

INSERT INTO phpbb_smilies VALUES (1, ':D', 'icon_biggrin.gif', 'Very Happy'),
(2, ':-D', 'icon_biggrin.gif', 'Very Happy'),
(3, ':grin:', 'icon_biggrin.gif', 'Very Happy'),
(4, ':)', 'icon_smile.gif', 'Smile'),
(5, ':-)', 'icon_smile.gif', 'Smile'),
(6, ':smile:', 'icon_smile.gif', 'Smile'),
(7, ':(', 'icon_sad.gif', 'Sad'),
(8, ':-(', 'icon_sad.gif', 'Sad'),
(9, ':sad:', 'icon_sad.gif', 'Sad'),
(10, ':o', 'icon_surprised.gif', 'Surprised'),
(11, ':-o', 'icon_surprised.gif', 'Surprised'),
(12, ':eek:', 'icon_surprised.gif', 'Surprised'),
(13, ':shock:', 'icon_eek.gif', 'Shocked'),
(14, ':?', 'icon_confused.gif', 'Confused'),
(15, ':-?', 'icon_confused.gif', 'Confused'),
(16, ':???:', 'icon_confused.gif', 'Confused'),
(17, '8)', 'icon_cool.gif', 'Cool'),
(18, '8-)', 'icon_cool.gif', 'Cool'),
(19, ':cool:', 'icon_cool.gif', 'Cool'),
(20, ':lol:', 'icon_lol.gif', 'Laughing'),
(21, ':x', 'icon_mad.gif', 'Mad'),
(22, ':-x', 'icon_mad.gif', 'Mad'),
(23, ':mad:', 'icon_mad.gif', 'Mad'),
(24, ':P', 'icon_razz.gif', 'Razz'),
(25, ':-P', 'icon_razz.gif', 'Razz'),
(26, ':razz:', 'icon_razz.gif', 'Razz'),
(27, ':oops:', 'icon_redface.gif', 'Embarassed'),
(28, ':cry:', 'icon_cry.gif', 'Crying or Very sad'),
(29, ':evil:', 'icon_evil.gif', 'Evil or Very Mad'),
(30, ':twisted:', 'icon_twisted.gif', 'Twisted Evil'),
(31, ':roll:', 'icon_rolleyes.gif', 'Rolling Eyes'),
(32, ':wink:', 'icon_wink.gif', 'Wink'),
(33, ';)', 'icon_wink.gif', 'Wink'),
(34, ';-)', 'icon_wink.gif', 'Wink'),
(35, ':!:', 'icon_exclaim.gif', 'Exclamation'),
(36, ':?:', 'icon_question.gif', 'Question'),
(37, ':idea:', 'icon_idea.gif', 'Idea'),
(38, ':arrow:', 'icon_arrow.gif', 'Arrow'),
(39, ':|', 'icon_neutral.gif', 'Neutral'),
(40, ':-|', 'icon_neutral.gif', 'Neutral'),
(41, ':neutral:', 'icon_neutral.gif', 'Neutral'),
(42, ':mrgreen:', 'icon_mrgreen.gif', 'Mr. Green');
# --------------------------------------------------------

#
# Estructura de tabla para tabla `phpbb_themes`
#

CREATE TABLE phpbb_themes (
  themes_id mediumint(8) unsigned NOT NULL auto_increment,
  template_name varchar(30) NOT NULL default '',
  style_name varchar(30) NOT NULL default '',
  head_stylesheet varchar(100) default NULL,
  body_background varchar(100) default NULL,
  body_bgcolor varchar(6) default NULL,
  body_text varchar(6) default NULL,
  body_link varchar(6) default NULL,
  body_vlink varchar(6) default NULL,
  body_alink varchar(6) default NULL,
  body_hlink varchar(6) default NULL,
  tr_color1 varchar(6) default NULL,
  tr_color2 varchar(6) default NULL,
  tr_color3 varchar(6) default NULL,
  tr_class1 varchar(25) default NULL,
  tr_class2 varchar(25) default NULL,
  tr_class3 varchar(25) default NULL,
  th_color1 varchar(6) default NULL,
  th_color2 varchar(6) default NULL,
  th_color3 varchar(6) default NULL,
  th_class1 varchar(25) default NULL,
  th_class2 varchar(25) default NULL,
  th_class3 varchar(25) default NULL,
  td_color1 varchar(6) default NULL,
  td_color2 varchar(6) default NULL,
  td_color3 varchar(6) default NULL,
  td_class1 varchar(25) default NULL,
  td_class2 varchar(25) default NULL,
  td_class3 varchar(25) default NULL,
  fontface1 varchar(50) default NULL,
  fontface2 varchar(50) default NULL,
  fontface3 varchar(50) default NULL,
  fontsize1 tinyint(4) default NULL,
  fontsize2 tinyint(4) default NULL,
  fontsize3 tinyint(4) default NULL,
  fontcolor1 varchar(6) default NULL,
  fontcolor2 varchar(6) default NULL,
  fontcolor3 varchar(6) default NULL,
  span_class1 varchar(25) default NULL,
  span_class2 varchar(25) default NULL,
  span_class3 varchar(25) default NULL,
  img_size_poll smallint(5) unsigned default NULL,
  img_size_privmsg smallint(5) unsigned default NULL,
  PRIMARY KEY  (themes_id)
) TYPE=MyISAM;

#
# Volcar la base de datos para la tabla `phpbb_themes`
#

INSERT INTO phpbb_themes VALUES (1, 'subSilver', 'subSilver', 'subSilver.css', '', 'E5E5E5', '000000', '006699', '5493B4', '', 'DD6900', 'EFEFEF', 'DEE3E7', 'D1D7DC', '', '', '', '98AAB1', '006699', 'FFFFFF', 'cellpic1.gif', 'cellpic3.gif', 'cellpic2.jpg', 'FAFAFA', 'FFFFFF', '', 'row1', 'row2', '', 'Verdana, Arial, Helvetica, sans-serif', 'Trebuchet MS', 'Courier, \'Courier New\', sans-serif', 10, 11, 12, '444444', '006600', 'FFA34F', '', '', '', NULL, NULL);
# --------------------------------------------------------

#
# Estructura de tabla para tabla `phpbb_themes_name`
#

CREATE TABLE phpbb_themes_name (
  themes_id smallint(5) unsigned NOT NULL default '0',
  tr_color1_name char(50) default NULL,
  tr_color2_name char(50) default NULL,
  tr_color3_name char(50) default NULL,
  tr_class1_name char(50) default NULL,
  tr_class2_name char(50) default NULL,
  tr_class3_name char(50) default NULL,
  th_color1_name char(50) default NULL,
  th_color2_name char(50) default NULL,
  th_color3_name char(50) default NULL,
  th_class1_name char(50) default NULL,
  th_class2_name char(50) default NULL,
  th_class3_name char(50) default NULL,
  td_color1_name char(50) default NULL,
  td_color2_name char(50) default NULL,
  td_color3_name char(50) default NULL,
  td_class1_name char(50) default NULL,
  td_class2_name char(50) default NULL,
  td_class3_name char(50) default NULL,
  fontface1_name char(50) default NULL,
  fontface2_name char(50) default NULL,
  fontface3_name char(50) default NULL,
  fontsize1_name char(50) default NULL,
  fontsize2_name char(50) default NULL,
  fontsize3_name char(50) default NULL,
  fontcolor1_name char(50) default NULL,
  fontcolor2_name char(50) default NULL,
  fontcolor3_name char(50) default NULL,
  span_class1_name char(50) default NULL,
  span_class2_name char(50) default NULL,
  span_class3_name char(50) default NULL,
  PRIMARY KEY  (themes_id)
) TYPE=MyISAM;

#
# Volcar la base de datos para la tabla `phpbb_themes_name`
#

INSERT INTO phpbb_themes_name VALUES (1, 'The lightest row colour', 'The medium row color', 'The darkest row colour', '', '', '', 'Border round the whole page', 'Outer table border', 'Inner table border', 'Silver gradient picture', 'Blue gradient picture', 'Fade-out gradient on index', 'Background for quote boxes', 'All white areas', '', 'Background for topic posts', '2nd background for topic posts', '', 'Main fonts', 'Additional topic title font', 'Form fonts', 'Smallest font size', 'Medium font size', 'Normal font size (post body etc)', 'Quote & copyright text', 'Code text colour', 'Main table header text colour', '', '', '');
# --------------------------------------------------------

#
# Estructura de tabla para tabla `phpbb_topics`
#

CREATE TABLE phpbb_topics (
  topic_id mediumint(8) unsigned NOT NULL auto_increment,
  forum_id smallint(8) unsigned NOT NULL default '0',
  topic_title char(60) NOT NULL default '',
  topic_poster mediumint(8) NOT NULL default '0',
  topic_time int(11) NOT NULL default '0',
  topic_views mediumint(8) unsigned NOT NULL default '0',
  topic_replies mediumint(8) unsigned NOT NULL default '0',
  topic_status tinyint(3) NOT NULL default '0',
  topic_vote tinyint(1) NOT NULL default '0',
  topic_type tinyint(3) NOT NULL default '0',
  topic_first_post_id mediumint(8) unsigned NOT NULL default '0',
  topic_last_post_id mediumint(8) unsigned NOT NULL default '0',
  topic_moved_id mediumint(8) unsigned NOT NULL default '0',
  PRIMARY KEY  (topic_id),
  KEY forum_id (forum_id),
  KEY topic_moved_id (topic_moved_id),
  KEY topic_status (topic_status),
  KEY topic_type (topic_type)
) TYPE=MyISAM;

#
# Volcar la base de datos para la tabla `phpbb_topics`
#

INSERT INTO phpbb_topics VALUES (1, 1, 'Welcome to phpBB 2', 2, 972086460, 0, 0, 0, 0, 0, 1, 1, 0);
# --------------------------------------------------------

#
# Estructura de tabla para tabla `phpbb_topics_watch`
#

CREATE TABLE phpbb_topics_watch (
  topic_id mediumint(8) unsigned NOT NULL default '0',
  user_id mediumint(8) NOT NULL default '0',
  notify_status tinyint(1) NOT NULL default '0',
  KEY topic_id (topic_id),
  KEY user_id (user_id),
  KEY notify_status (notify_status)
) TYPE=MyISAM;

#
# Volcar la base de datos para la tabla `phpbb_topics_watch`
#

# --------------------------------------------------------

#
# Estructura de tabla para tabla `phpbb_user_group`
#

CREATE TABLE phpbb_user_group (
  group_id mediumint(8) NOT NULL default '0',
  user_id mediumint(8) NOT NULL default '0',
  user_pending tinyint(1) default NULL,
  KEY group_id (group_id),
  KEY user_id (user_id)
) TYPE=MyISAM;

#
# Volcar la base de datos para la tabla `phpbb_user_group`
#

INSERT INTO phpbb_user_group VALUES (1, -1, 0),
(2, 2, 0);
# --------------------------------------------------------

#
# Estructura de tabla para tabla `phpbb_users`
#

CREATE TABLE phpbb_users (
  user_id mediumint(8) NOT NULL default '0',
  user_active tinyint(1) default '1',
  username varchar(25) NOT NULL default '',
  user_password varchar(32) NOT NULL default '',
  user_session_time int(11) NOT NULL default '0',
  user_session_page smallint(5) NOT NULL default '0',
  user_lastvisit int(11) NOT NULL default '0',
  user_regdate int(11) NOT NULL default '0',
  user_level tinyint(4) default '0',
  user_posts mediumint(8) unsigned NOT NULL default '0',
  user_timezone decimal(4,2) NOT NULL default '0.00',
  user_style tinyint(4) default NULL,
  user_lang varchar(255) default NULL,
  user_dateformat varchar(14) NOT NULL default 'd M Y H:i',
  user_new_privmsg smallint(5) unsigned NOT NULL default '0',
  user_unread_privmsg smallint(5) unsigned NOT NULL default '0',
  user_last_privmsg int(11) NOT NULL default '0',
  user_emailtime int(11) default NULL,
  user_viewemail tinyint(1) default NULL,
  user_attachsig tinyint(1) default NULL,
  user_allowhtml tinyint(1) default '1',
  user_allowbbcode tinyint(1) default '1',
  user_allowsmile tinyint(1) default '1',
  user_allowavatar tinyint(1) NOT NULL default '1',
  user_allow_pm tinyint(1) NOT NULL default '1',
  user_allow_viewonline tinyint(1) NOT NULL default '1',
  user_notify tinyint(1) NOT NULL default '1',
  user_notify_pm tinyint(1) NOT NULL default '1',
  user_popup_pm tinyint(1) NOT NULL default '0',
  user_rank int(11) default '0',
  user_avatar varchar(100) default NULL,
  user_avatar_type tinyint(4) NOT NULL default '0',
  user_email varchar(255) default NULL,
  user_icq varchar(15) default NULL,
  user_website varchar(100) default NULL,
  user_from varchar(100) default NULL,
  user_sig text,
  user_sig_bbcode_uid varchar(10) default NULL,
  user_aim varchar(255) default NULL,
  user_yim varchar(255) default NULL,
  user_msnm varchar(255) default NULL,
  user_occ varchar(100) default NULL,
  user_interests varchar(255) default NULL,
  user_actkey varchar(32) default NULL,
  user_newpasswd varchar(32) default NULL,
  PRIMARY KEY  (user_id),
  KEY user_session_time (user_session_time)
) TYPE=MyISAM;

#
# Volcar la base de datos para la tabla `phpbb_users`
#

INSERT INTO phpbb_users VALUES (-1, 0, 'Anonymous', '', 0, 0, 0, 1022816686, 0, 0, '0.00', NULL, '', '', 0, 0, 0, NULL, 0, 0, 0, 1, 1, 1, 0, 1, 0, 1, 0, NULL, '', 0, '', '', '', '', '', NULL, '', '', '', '', '', '', '');

# --------------------------------------------------------

#
# Estructura de tabla para tabla `phpbb_vote_desc`
#

CREATE TABLE phpbb_vote_desc (
  vote_id mediumint(8) unsigned NOT NULL auto_increment,
  topic_id mediumint(8) unsigned NOT NULL default '0',
  vote_text text NOT NULL,
  vote_start int(11) NOT NULL default '0',
  vote_length int(11) NOT NULL default '0',
  PRIMARY KEY  (vote_id),
  KEY topic_id (topic_id)
) TYPE=MyISAM;

#
# Volcar la base de datos para la tabla `phpbb_vote_desc`
#

# --------------------------------------------------------

#
# Estructura de tabla para tabla `phpbb_vote_results`
#

CREATE TABLE phpbb_vote_results (
  vote_id mediumint(8) unsigned NOT NULL default '0',
  vote_option_id tinyint(4) unsigned NOT NULL default '0',
  vote_option_text varchar(255) NOT NULL default '',
  vote_result int(11) NOT NULL default '0',
  KEY vote_option_id (vote_option_id),
  KEY vote_id (vote_id)
) TYPE=MyISAM;

#
# Volcar la base de datos para la tabla `phpbb_vote_results`
#

# --------------------------------------------------------

#
# Estructura de tabla para tabla `phpbb_vote_voters`
#

CREATE TABLE phpbb_vote_voters (
  vote_id mediumint(8) unsigned NOT NULL default '0',
  vote_user_id mediumint(8) NOT NULL default '0',
  vote_user_ip char(8) NOT NULL default '',
  KEY vote_id (vote_id),
  KEY vote_user_id (vote_user_id),
  KEY vote_user_ip (vote_user_ip)
) TYPE=MyISAM;

#
# Volcar la base de datos para la tabla `phpbb_vote_voters`
#

# --------------------------------------------------------

#
# Estructura de tabla para tabla `phpbb_words`
#

CREATE TABLE phpbb_words (
  word_id mediumint(8) unsigned NOT NULL auto_increment,
  word char(100) NOT NULL default '',
  replacement char(100) NOT NULL default '',
  PRIMARY KEY  (word_id)
) TYPE=MyISAM;

#
# Volcar la base de datos para la tabla `phpbb_words`
#


