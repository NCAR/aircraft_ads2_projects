Please read file "index.html" to see HOW TO USE.
and file "licence-LGPL.txt" to know copyright (GPL) 
Release by Vietdev : http://vietdev.sourceforge.net

Release Date: Sep-26-2002 (R5.0 / R10.0)
Release Date: Oct-05-2002 (R5.1 / R10.1)


Contact : ngo_canh@yahoo.com
or visit our forums by Vietdev


THANK YOU ALL WHO ASKED, RESQUESTED, SUGGESTED ME TO DEVELOP THIS RELEASE !

Xiao Shibin
Taki
Michelangelo
...........