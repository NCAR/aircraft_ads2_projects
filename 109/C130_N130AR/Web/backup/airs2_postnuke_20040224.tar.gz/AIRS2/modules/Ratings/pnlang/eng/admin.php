<?php
// Generated: $d$ by $id$
// ----------------------------------------------------------------------
// POST-NUKE Content Management System
// Copyright (C) 2001 by the Post-Nuke Development Team.
// http://www.postnuke.com/
// ----------------------------------------------------------------------
// Based on:
// PHP-NUKE Web Portal System - http://phpnuke.org/
// Thatware - http://thatware.org/
// ----------------------------------------------------------------------
// LICENSE
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License (GPL)
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// To read the license please visit http://www.gnu.org/copyleft/gpl.html
// ----------------------------------------------------------------------
// Original Author of file: Everyone
// Purpose of file: Translation files
// Translation team: Read credits in /docs/CREDITS.txt
// ----------------------------------------------------------------------
define('_RATINGS','Ratings');
define('_RATINGSDEFAULTSTYLE','Default ratings style');
define('_RATINGSMODIFYCONFIG','Modify configuration');
define('_RATINGSOUTOFFIVE','Number out of five');
define('_RATINGSOUTOFFIVESTARS','Stars out of five');
define('_RATINGSOUTOFTEN','Number out of ten');
define('_RATINGSOUTOFTENSTARS','Stars out of ten');
define('_RATINGSPERCENTAGE','Percentage');
define('_RATINGSSECHIGH','High (user can only vote once)');
define('_RATINGSSECLOW','Low (user can vote multiple times)');
define('_RATINGSSECMEDIUM','Medium (user can vote once per session)');
define('_RATINGSSECURITY','Security against rate rigging');
define('_RATINGSUPDATECONFIG','Update configuration');
?>