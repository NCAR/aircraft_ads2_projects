<?php
// Generated: $d$ by $id$
// ----------------------------------------------------------------------
// POST-NUKE Content Management System
// Copyright (C) 2001 by the Post-Nuke Development Team.
// http://www.postnuke.com/
// ----------------------------------------------------------------------
// Based on:
// PHP-NUKE Web Portal System - http://phpnuke.org/
// Thatware - http://thatware.org/
// ----------------------------------------------------------------------
// LICENSE
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License (GPL)
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// To read the license please visit http://www.gnu.org/copyleft/gpl.html
// ----------------------------------------------------------------------
// Original Author of file: Everyone
// Purpose of file: Translation files
// Translation team: Read credits in /docs/CREDITS.txt
// ----------------------------------------------------------------------
define('_CANCELQUOTEDELETE','Cancel');
define('_QOTDACTION','Action');
define('_QOTDADD','Add');
define('_QOTDADDSUCCESS','Quote Added Successfully.');
define('_QOTDAUTHOR','Author');
define('_QOTDDEL','Delete This Quote?');
define('_QOTDDELETEACTION','Delete');
define('_QOTDDELETED','Quote Deleted.');
define('_QOTDEDITACTION','Edit');
define('_QOTDMODIFY','Modify Quotes');
define('_QOTDNOQUOTES','No Quotes Found.');
define('_QOTDNQ','No quotes found');
define('_QOTDQUOTE','Quote');
define('_QOTDSAVE','Save Modification?');
define('_QOTDSEARCH','Search By Keyword:');
define('_QOTDSEARCHRESULTS','Search Results ...');
define('_QOTDTEXT','Quote Text:');
define('_QOTDTOTAL','Total Quotes in Database: ');
define('_QUOTESNOAUTH','Not Authorized To Access Quotes.');
?>