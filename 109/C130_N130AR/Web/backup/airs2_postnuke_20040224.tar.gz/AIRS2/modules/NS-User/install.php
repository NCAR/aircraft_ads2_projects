<?php
// Install file by Chestnut !
// pncUserHack v1.6
// http://dev.pnconcept.com
// If you try installing the pncUserHack by Chestnut !,
// Chestnut ! recommends you say three times reeeeaally fast :
// "I am a fool, I am a fool, I am a fool..."

if (file_exists("modules/NS-User/lang/".pnConfigGetVar(language)."/global.php")) {
	include("modules/NS-User/lang/".pnConfigGetVar(language)."/global.php");
} else {
	include("modules/NS-User/lang/eng/global.php");
}

function index()
{
	include("header.php");

	OpenTable();
	echo "<center><font class=\"pn-title\">"._UAINSTALLTITLE."</font></center><br>\n";
	echo "<br><br>\n";
	echo "<center>\n"
		."<form action=\"modules.php\" method=\"post\">\n"
		."	<input type=\"hidden\" name=\"op\" value=\"modload\">\n"
		."	<input type=\"hidden\" name=\"name\" value=\"NS-User\">\n"
		."	<input type=\"hidden\" name=\"file\" value=\"install\">\n"
		."	<select name=go>\n"
		."		<option value=\"install\" selected>"._UASELNEWINSTALL."</option>\n"
		."		<option value=\"uninstall\">"._UAUNINSTALLTITLE."</option>\n"
		."	</select>\n"
		."	<input type=\"submit\" value=\""._UAINSTALLBTN."\"></center></form>";

	CloseTable();
	include("footer.php");
}

function install()
{
	include("header.php");
    list($dbconn) = pnDBGetConn();
	$prefix = pnConfigGetVar(prefix);
	$pntable = pnDBGetTables();

	$sql = "DROP TABLE IF EXISTS ".$prefix."_users_modrequest";
	$dbconn->Execute($sql);

	$sql="CREATE TABLE ".$prefix."_users_modrequest (
  			pn_uactr int(11) NOT NULL auto_increment,
  			pn_uid int(11) NOT NULL default '0',
  			pn_name varchar(60) NOT NULL default '',
  			pn_uname varchar(25) NOT NULL default '',
  			pn_email varchar(60) NOT NULL default '',
  			pn_femail varchar(60) NOT NULL default '',
  			pn_url varchar(100) NOT NULL default '',
  			pn_user_avatar varchar(30) default NULL,
  			pn_user_regdate varchar(20) NOT NULL default '',
  			pn_user_icq varchar(15) default NULL,
  			pn_user_occ varchar(100) default NULL,
  			pn_user_from varchar(100) default NULL,
  			pn_user_intrest varchar(150) default NULL,
  			pn_user_sig varchar(255) default NULL,
  			pn_user_viewemail tinyint(2) default NULL,
  			pn_user_theme tinyint(3) default NULL,
  			pn_user_aim varchar(18) default NULL,
  			pn_user_yim varchar(25) default NULL,
  			pn_user_msnm varchar(25) default NULL,
  			pn_pass varchar(40) NOT NULL default '',
  			pn_storynum tinyint(4) NOT NULL default '10',
  			pn_umode varchar(10) NOT NULL default '',
  			pn_uorder tinyint(1) NOT NULL default '0',
  			pn_thold tinyint(1) NOT NULL default '0',
  			pn_noscore tinyint(1) NOT NULL default '0',
  			pn_bio tinytext NOT NULL,
  			pn_ublockon tinyint(1) NOT NULL default '0',
  			pn_ublock tinytext NOT NULL,
  			pn_theme varchar(255) NOT NULL default '',
  			pn_commentmax int(11) NOT NULL default '4096',
  			pn_counter int(11) NOT NULL default '0',
  			pn_timezone_offset float(3,1) NOT NULL default '0.0',
  			pn_uda_vars text NOT NULL,
  			pn_gid int(11) NOT NULL default '0',
  			pn_ppn tinyint(1) NOT NULL default '0',
  			pn_uadd tinyint(1) NOT NULL default '0',
  			pn_udel tinyint(1) NOT NULL default '0',
			pn_reason mediumtext NOT NULL,			
  			PRIMARY KEY  (pn_uactr)
			) TYPE=MyISAM;";

	$dbconn->Execute($sql);

	if (pnConfigGetVar('allowuserdelete')."" == "") pnConfigSetVar('allowuserdelete', 0);
	if (pnConfigGetVar('senddeletemail')."" == "") pnConfigSetVar('senddeletemail', 0);
	if (pnConfigGetVar('sendaddmail')."" == "") pnConfigSetVar('sendaddmail', 0);
	if (pnConfigGetVar('allowuserpass')."" == "") pnConfigSetVar('allowuserpass', 0);
	if (pnConfigGetVar('blkusrreg')."" == "") pnConfigSetVar('blkusrreg', 1);
	if (!pnConfigGetVar('reservedstring')) {
		$reservedstring[] = "fuck";
		$reservedstring[] = "cunt";
		$reservedstring[] = "pussy";
		$reservedstring[] = "cock";
		$reservedstring[] = "cum";
		$reservedstring[] = "clit";
		$reservedstring[] = "bitch";
		$reservedstring[] = "fuk";
		$reservedstring[] = "God";
		$reservedstring[] = "staff";
		$reservedstring[] = "administrator";
		$reservedstring[] = "nazi";
		$reservedstring[] = "nigger";
		$reservedstring[] = "bastard";
		$reservedstring[] = "tabarnak";
		$reservedstring[] = "putain";
		$reservedstring[] = "anonymous";
		$reservedstring[] = "anonyme";
		pnConfigSetVar('reservedstring', $reservedstring);
	}	
	if (pnConfigGetVar('senduserpass')."" == "") pnConfigSetVar('senduserpass', 0);
	if (pnConfigGetVar('pncuaver')."" == "") pnConfigSetVar('pncuaver', 1.6);
	if (pnConfigGetVar('pncuaadvreg')."" == "") pnConfigSetVar('pncuaadvreg', 0);
	if (pnConfigGetVar('pncusrmodreg')."" == "") pnConfigSetVar('pncusrmodreg', 0);
	if (pnConfigGetVar('pnc_mail_modusrwning')."" == "") pnConfigSetVar('pnc_mail_modusrwning', 1);
	if (pnConfigGetVar('pnc_mail_adminwning')."" == "") pnConfigSetVar('pnc_mail_adminwning', 1);
	if (pnConfigGetVar('pnc_mail_usrregok')."" == "") pnConfigSetVar('pnc_mail_usrregok', 1);
	if (pnConfigGetVar('pnc_mail_usrregsorry')."" == "") pnConfigSetVar('pnc_mail_usrregsorry', 1);

	$column = &$pntable['user_data'];
	$sql = "ALTER TABLE $pntable[user_data]
			CHANGE		$column[uda_value]
						$column[uda_value] LONGTEXT NOT NULL ";
	$dbconn->Execute("ALTER TABLE $pntable[user_data] CHANGE pn_uda_value pn_uda_value LONGTEXT NOT NULL ");
   	if($dbconn->ErrorNo()<>0) {
   	    echo $dbconn->ErrorMsg(). "<br>";
	}
	$dbconn->Execute("ALTER TABLE $pntable[user_property] CHANGE pn_prop_validation pn_prop_validation LONGTEXT NOT NULL ");
   	if($dbconn->ErrorNo()<>0) {
   	    echo $dbconn->ErrorMsg(). "<br>";
	}

	$column = &$pntable['user_property_column'];
	$sql = "SELECT	$column[prop_label],
					$column[prop_dtype],
					$column[prop_validation]
			FROM	$pntable[user_property]";
	$result = $dbconn->Execute($sql);

	while(list($prop_label, $prop_dtype, $prop_validation) = $result->fields) {
		$result->MoveNext();
		//echo $prop_label."<br>";
		if ($prop_dtype == _UDCONST_MANDATORY) {
				$dynadefinition['REQUIRED']		= 1;
				$dynadefinition['ADMINONLY']	= 0;
				$dynadefinition['TYPE']			= "TEXT";
				$dynadefinition['LISTOPTION']	= 0;
				$dynadefinition['LISTFILL']		= "";
				$dynadefinition['NOTE']			= "";
				$dynadefinition['VALIDATION']	= "";
				/*break;*/
		} elseif ($prop_dtype == _UDCONST_CORE) {
				switch ($prop_label) {
					case "_TIMEZONEOFFSET":
						$dynadefinition['REQUIRED']		= 0;
						$dynadefinition['ADMINONLY']	= 0;
						$dynadefinition['TYPE']			= "SELECT";
						$dynadefinition['LISTOPTION']	= 0;
						$dynadefinition['LISTFILL']		= "";
						$dynadefinition['NOTE']			= "";
						$dynadefinition['VALIDATION']	= "var: timezoneoffset";
						break;
					case "_YOURAVATAR":
						$dynadefinition['REQUIRED']		= 0;
						$dynadefinition['ADMINONLY']	= 0;
						$dynadefinition['TYPE']			= "SELECT";
						$dynadefinition['LISTOPTION']	= 0;
						$dynadefinition['LISTFILL']		= "";
						$dynadefinition['NOTE']			= "";
						$dynadefinition['VALIDATION']	= "path: images/avatar";
						break;						
					case "_SIGNATURE":
						$dynadefinition['REQUIRED']		= 0;
						$dynadefinition['ADMINONLY']	= 0;
						$dynadefinition['TYPE']			= "TEXTAREA";
						$dynadefinition['LISTOPTION']	= 0;
						$dynadefinition['LISTFILL']		= "";
						$dynadefinition['NOTE']			= "";
						$dynadefinition['VALIDATION']	= "";
						break;
					case "_EXTRAINFO":
						$dynadefinition['REQUIRED']		= 0;
						$dynadefinition['ADMINONLY']	= 0;
						$dynadefinition['TYPE']			= "TEXTAREA";
						$dynadefinition['LISTOPTION']	= 0;
						$dynadefinition['LISTFILL']		= "";
						$dynadefinition['NOTE']			= "";
						$dynadefinition['VALIDATION']	= "";
						break;
					default:
						$dynadefinition['REQUIRED']		= 0;
						$dynadefinition['ADMINONLY']	= 0;
						$dynadefinition['TYPE']			= "TEXT";
						$dynadefinition['LISTOPTION']	= 0;
						$dynadefinition['LISTFILL']		= "";
						$dynadefinition['NOTE']			= "";
						$dynadefinition['VALIDATION']	= "";
						break;
				}
				
		} else {
				$dynadefinition['REQUIRED']		= 0;
				$dynadefinition['ADMINONLY']	= 0;
				$dynadefinition['TYPE']			= "TEXT";
				$dynadefinition['LISTOPTION']	= 0;
				$dynadefinition['LISTFILL']		= "";
				$dynadefinition['NOTE']			= "";
				$dynadefinition['VALIDATION']	= "";
				/*break;*/
		}
		
		$sql = "UPDATE	$pntable[user_property]
				SET		$column[prop_validation] = '".pnVarPrepForStore(serialize($dynadefinition))."'
				WHERE	$column[prop_label] = '".pnVarPrepForStore($prop_label)."'";
		$dbconn->Execute($sql);
    	if($dbconn->ErrorNo()<>0) {
    	    $createerror[] = "Field ".$prop_label." was not updated : ".$dbconn->ErrorMsg(). "<br>";
    	} else {
			$createsuccess[] = "Field ".$prop_label." was updated. ".$dynadefinition['TYPE']."<br>";
		}
	}

	if (is_array($createerror) && !empty($createerror)) {
		OpenTable();
		foreach($createerror as $element) {
			echo pnVarPrepHTMLDisplay($element);
		}
		CloseTable();
	}

	OpenTable();
	echo "<center><font class=\"pn-title\">"._UAINSTALLTITLE."</font></center>\n"
		."<br><br>\n"
		."<center>Table ".pnVarPrepForDisplay($prefix)."_users_modrequest "._UATBLCREATED."<br></center>\n"
		."<center>Table ".pnVarPrepForDisplay($prefix)."_module_vars "._UATBLMVMAJ."<br><br></center>\n"
		."<center><a href=\"admin.php?module=NS-User&op=getConfig\">"._UACFGLINK."</a></center>";
	CloseTable();
	include("footer.php");
}

function uninstall(){
	include("header.php");
    list($dbconn) = pnDBGetConn();
	$pntable = pnDBGetTables();
	
	$prefix = pnConfigGetVar(prefix);

	$x = pnConfigGetVar(allowuserdelete);
	if (($x."") == "") {
		echo _UAWRONGINSTALL;
		return false;
	}
    $column = &$pntable['module_vars_column'];
	$dbconn->Execute("DELETE FROM $pntable[module_vars] WHERE $column[name]='allowuserdelete'");
	
	if (pnConfigGetVar('senddeletemail')."" != "") {
		$dbconn->Execute("DELETE FROM $pntable[module_vars] WHERE $column[name]='senddeletemail'");
	}
	if (pnConfigGetVar('sendaddmail')."" != "") {
		$dbconn->Execute("DELETE FROM $pntable[module_vars] WHERE $column[name]='sendaddmail'");
	}
	if (pnConfigGetVar('allowuserpass')."" != "") {
		$dbconn->Execute("DELETE FROM $pntable[module_vars] WHERE $column[name]='allowuserpass'");
	}
	if (pnConfigGetVar('blkusrreg')."" != "") {
		$dbconn->Execute("DELETE FROM $pntable[module_vars] WHERE $column[name]='blkusrreg'");
	}

	if (pnConfigGetVar('reservedstring')) {
		$dbconn->Execute("DELETE FROM $pntable[module_vars] WHERE $column[name]='reservedstring'");
	}
	if (pnConfigGetVar('senduserpass')."" != "") {
		$dbconn->Execute("DELETE FROM $pntable[module_vars] WHERE $column[name]='senduserpass'");
	}
	if (pnConfigGetVar('pncuaver')."" != "") {
		$dbconn->Execute("DELETE FROM $pntable[module_vars] WHERE $column[name]='pncuaver'");
	}
	if (pnConfigGetVar('pncuaadvreg')."" != "") {
		$dbconn->Execute("DELETE FROM $pntable[module_vars] WHERE $column[name]='pncuaadvreg'");
	}
	if (pnConfigGetVar('pncusrmodreg')."" != "") {
		$dbconn->Execute("DELETE FROM $pntable[module_vars] WHERE $column[name]='pncusrmodreg'");
	}
	if (pnConfigGetVar('pnc_mail_modusrwning')."" != "") {
		$dbconn->Execute("DELETE FROM $pntable[module_vars] WHERE $column[name]='pnc_mail_modusrwning'");
	}
	if (pnConfigGetVar('pnc_mail_adminwning')."" != "") {
		$dbconn->Execute("DELETE FROM $pntable[module_vars] WHERE $column[name]='pnc_mail_adminwning'");
	}
	if (pnConfigGetVar('pnc_mail_usrregok')."" != "") {
		$dbconn->Execute("DELETE FROM $pntable[module_vars] WHERE $column[name]='pnc_mail_usrregok'");
	}
	if (pnConfigGetVar('pnc_mail_usrregsorry')."" != "") {
		$dbconn->Execute("DELETE FROM $pntable[module_vars] WHERE $column[name]='pnc_mail_usrregsorry'");
	}
	
	$sql = "DROP TABLE IF EXISTS ".$prefix."_users_modrequest";
	$dbconn->Execute($sql);

	OpenTable();
	echo "<center><font class=\"pn-title\">"._UAUNINSTALLTITLE."</font></center>";
	echo "<br><br>";
	echo "<center>Tables "._UATBLDROP."<br></center>";
	echo "<center>Table ".pnVarPrepForDisplay($prefix)."_module_vars "._UATBLMVMAJ."<br><br></center>";
	echo "<center><a href=\"admin.php?module=NS-User&op=getConfig\">"._UACFGLINK."</a></center>";
	CloseTable();
	include("footer.php");
}

if (!pnSecAuthAction(0, 'NS-User::', '::', ACCESS_ADMIN)) {
	include("header.php");
	echo _UANOADMININSTALL;
	include("footer.php");
} else {

	switch ($go){
		default:
			index();
			break;

		case install:
			install();
			break;

		case uninstall:
			uninstall();
			break;
	}
}
?>