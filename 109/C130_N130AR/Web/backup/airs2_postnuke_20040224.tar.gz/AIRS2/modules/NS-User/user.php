<?php // File: $Id: user.php,v 1.1.1.1 2003/06/18 19:21:50 fd Exp $ $Name:  $
// ----------------------------------------------------------------------
// POSTNUKE Content Management System
// Copyright (C) 2001 by the PostNuke Development Team.
// http://www.postnuke.com/
// ----------------------------------------------------------------------
// Based on:
// PHP-NUKE Web Portal System - http://phpnuke.org/
// Thatware - http://thatware.org/
// ----------------------------------------------------------------------
// LICENSE
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License (GPL)
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// To read the license please visit http://www.gnu.org/copyleft/gpl.html
// ----------------------------------------------------------------------
// Original Author of file:
// Purpose of file:
// ----------------------------------------------------------------------

$ModName = basename( dirname( __FILE__ ) );
modules_get_language();

function user_user_userinfo()
{
	//global $bgcolor1, $bgcolor2, $bgcolor3;
    list($dbconn) = pnDBGetConn();
    $pntable = pnDBGetTables();

    if (!pnSecAuthAction(0, 'UserInfo::', '::', ACCESS_READ)) {
        return;
    }
    $uname = pnVarCleanFromInput('uname');

    $column = &$pntable['users_column'];
    $sql = "SELECT	$column[femail] 		AS femail,
					$column[name]			AS name,
					$column[url]			AS url,
					$column[bio]			AS bio,
					$column[user_avatar]	AS user_avatar,
					$column[user_icq]		AS user_icq,
					$column[user_aim]		AS user_aim,
					$column[user_yim]		AS user_yim,
					$column[user_msnm]		AS user_msnm,
					$column[user_from]		AS user_from,
					$column[user_occ]		AS user_occ,
					$column[user_intrest]	AS user_intrest,
					$column[user_sig]		AS user_sig,
					$column[uid]			AS pn_uid,
					$column[pass]			AS pass
			FROM	$pntable[users]
			WHERE	$column[uname]='".pnVarPrepForStore($uname)."'";

    $result = $dbconn->Execute($sql);
    $userinfo = $result->GetRowAssoc(false);

	// Aliasing
    $userfield['_USERNAME']['NAME']			= 'uname';
	$userfield['_USERNAME']['LIBEL']		= _USERNAME;
    $userfield['_UREALEMAIL']['NAME']		= 'email';
	$userfield['_UREALEMAIL']['LIBEL']		= _UREALEMAIL;	
    $userfield['_UFAKEMAIL']['NAME']		= 'femail';
	$userfield['_UFAKEMAIL']['LIBEL']		= _MYEMAIL;
    $userfield['_UREALNAME']['NAME']		= _UREALNAME;
	$userfield['_UREALNAME']['LIBEL']		= 'name';
    $userfield['_TIMEZONEOFFSET']['NAME']	= 'timezone_offset';
	$userfield['_TIMEZONEOFFSET']['LIBEL']	= _TIMEZONEOFFSET;
    $userfield['_YOURAVATAR']['NAME']		= 'user_avatar';
	$userfield['_YOURAVATAR']['LIBEL']		= _YOURAVATAR;
    $userfield['_YICQ']['NAME']				= 'user_icq';
	$userfield['_YICQ']['LIBEL']			= _ICQ;
    $userfield['_YAIM']['NAME']				= 'user_aim';
	$userfield['_YAIM']['LIBEL']			= _AIM;
    $userfield['_YYIM']['NAME']				= 'user_yim';
	$userfield['_YYIM']['LIBEL']			= _YIM;
    $userfield['_YMSNM']['NAME']			= 'user_msnm';
	$userfield['_YMSNM']['LIBEL']			= _MSNM;
    $userfield['_YLOCATION']['NAME']		= 'user_from';
	$userfield['_YLOCATION']['LIBEL']		= _LOCATION;
    $userfield['_YOCCUPATION']['NAME']		= 'user_occ';
	$userfield['_YOCCUPATION']['LIBEL']		= _OCCUPATION;
    $userfield['_YINTERESTS']['NAME']		= 'user_intrest';
	$userfield['_YINTERESTS']['LIBEL']		= _INTERESTS;
    $userfield['_SIGNATURE']['NAME']		= 'user_sig';
	$userfield['_SIGNATURE']['LIBEL']		= _SIGNATURE;
    $userfield['_EXTRAINFO']['NAME']		= 'bio';
	$userfield['_EXTRAINFO']['LIBEL']		= _EXTRAINFO;
    $userfield['_YOURHOMEPAGE']['NAME']		= 'url';
	$userfield['_YOURHOMEPAGE']['LIBEL']	= _MYHOMEPAGE;
	
	$userlist = pnUserGetVars($userinfo['pn_uid']);
	$counter = 0;
	
	$fieldlist2 = getfieldlist();
	$fieldlist = $fieldlist2;

	include 'header.php';

	while(list($key, $val) = each($fieldlist2)) {
		if ($userfield[$val['FIELD']]['LIBEL']."" == "") {
			$userfield[$val['FIELD']]['NAME'] = $val['FIELD'];
			$userfield[$val['FIELD']]['LIBEL'] = $val['LIBEL'];
		}
		
		$uservalue = $userlist[$userfield[$val['FIELD']]['NAME']];
		
		//simplifying variables
		$adminonly = $val['VALIDATION']['ADMINONLY'];
		if (is_admin()) {
			$adminview = 1;
		} else {
			$adminview = 0;
		}
		$libel = $userfield[$val['FIELD']]['LIBEL'];
		$field = $val['FIELD'];
		$validation = $val['VALIDATION'];
		$validation['NAME'] = $field;

		if ($adminview == 1) {
			$showit = 1;
		}
		if ($adminview == 0 && $adminonly == '0') {
			$showit = 1;
		} elseif ($adminview == 0 && $adminonly == '1') {
			$showit = 0;
		}
		
		if ($showit == 1 && $uservalue."" != "" && $uservalue != 'http://') {
			if ($field == "_YOURAVATAR") {
				$showavatar = "<img src=images/avatar/".$uservalue." border=0>";
			} elseif ($field == "_TIMEZONEOFFSET") {
				$showme .= "";
			} else {
				$showme .= "<tr bgcolor=\"".$GLOBALS['bgcolor1']."\">\n<td height=\"30\" bgcolor=\"".$GLOBALS['bgcolor3']."\" width=\"35%\">\n";
			}
			if ($field == "_SIGNATURE") {
				$showme .= "&nbsp;<b>".$libel."</b></td>";
				$showme .= "<td align=\"center\">\n";
				$showme .= "<table><tr><td>".pnVarPrepHTMLDisplay(getfieldDynamicDisplay($validation, nl2br($uservalue)))."</td></tr></table>";
				$showme .= "</td>\n</tr>";
				$counter++;
			} elseif ($field == "_UFAKEMAIL") {
				$showme .= "&nbsp;<b>".$libel."</b></td>\n<td>&nbsp;<a href=mailto:".$uservalue.">".getfieldDynamicDisplay($validation, $uservalue)."</a>";
				$showme .= "</td>\n</tr>\n";
				$counter++;
			
			} elseif ($field == "_YOURHOMEPAGE") {
				if (!eregi("^http://[\-\.0-9a-z]+",$uservalue)) {
				    $uservalue = "http://".$uservalue;
			    }
				$showme .= "&nbsp;<b>".$libel."</b></td>\n<td>&nbsp;<a href=\"".$uservalue."\" target=\"_blank\">".getfieldDynamicDisplay($validation, $uservalue)."</a>";
				$showme .= "</td>\n</tr>\n";
				$counter++;
			} elseif ($field == "_YICQ") {
				$showme .= "&nbsp;<b>".$libel."</b></td>\n";
				$showme .= "<td>&nbsp;<a href=\"http://web.icq.com/wwp?Uin=".pnVarPrepForDisplay($uservalue)."\" target=\"_blank\"><img src=\"http://web.icq.com/whitepages/online?icq=".pnVarPrepForDisplay($uservalue)."&img=5\" border=0></a> <a href=\"http://web.icq.com/wwp?Uin=".pnVarPrepForDisplay($uservalue)."\" target=\"_blank\">".getfieldDynamicDisplay($validation, $uservalue)."</a>";
				$showme .= "</td>\n</tr>";
				$counter++;
			} elseif ($field == "_YAIM") {
				$showme .= "&nbsp;<b>".$libel."</b></td>\n";
				$showme .= "<td>&nbsp;<a href=\"aim:goim?screenname=" . pnVarPrepForDisplay($uservalue)."&message=Hi+".pnVarPrepForDisplay($uservalue).".+Are+you+there?\"><img src=\"images/global/aim.gif\" border=\"0\" Alt=\"\"></a> <a href=\"aim:goim?screenname=" . pnVarPrepForDisplay($uservalue)."&message=Hi+".pnVarPrepForDisplay($uservalue).".+Are+you+there?\">".getfieldDynamicDisplay($validation, $uservalue)."</a>";
				$showme .= "</td>\n</tr>";
				$counter++;
			} elseif ($field == "_YYIM") {
				$showme .= "&nbsp;<b>".$libel."</b></td>\n";
				$showme .= "<td>&nbsp;<a href=\"http://edit.yahoo.com/config/send_webmesg?.target=".pnVarPrepForDisplay($uservalue)."&.src=pg\"><img src=\"images/global/yim.gif\" border=\"0\" Alt=\"\"></a> <a href=\"http://edit.yahoo.com/config/send_webmesg?.target=".pnVarPrepForDisplay($uservalue)."&.src=pg\">".getfieldDynamicDisplay($validation, $uservalue)."</a>";
				$showme .= "</td>\n</tr>";
				$counter++;
			} elseif ($field == "_YMSNM") {
				$showme .= "&nbsp;<b>".$libel."</b></td>\n";
				$showme .= "<td>&nbsp;<a href=\"user.php?op=userinfo&amp;uname=".pnVarPrepForDisplay($uname)."\"><img src=\"images/global/msnm.gif\" border=\"0\" Alt=\"\"></a> <a href=\"user.php?op=userinfo&amp;uname=".pnVarPrepForDisplay($uname)."\">".getfieldDynamicDisplay($validation, $uservalue)."</a>";
				$showme .= "</td>\n</tr>";
				$counter++;
			} elseif ($field == "_YOURAVATAR") {
			} elseif ($field == "_TIMEZONEOFFSET") {
			} else {
				if ($validation['TYPE'] == "SELECT" && $validation['LISTOPTION'] == 1) $uservalue = unserialize($uservalue);
				$showme .= "&nbsp;<b>".$libel."</b></td>\n<td>&nbsp;".pnVarPrepHTMLDisplay(getfieldDynamicDisplay($validation, $uservalue));
				$showme .= "</td>\n</tr>";
				$counter++;
			}
		}
	}

	OpenTable();
	echo "<center>\n";
	echo "<font class=\"pn-title\">&nbsp;"._UAPROFILEPAGE."<br>".pnVarPrepForDisplay($userlist['uname'])."</font>";
	echo "<br><br>".$showavatar."<br><br>";
	if(pnModAvailable('Messages')) {
		echo "[ <a class=\"pn-normal\" href=\"modules.php?op=modload&amp;name=Messages&amp;file=replypmsg&amp;send=1&amp;uname=$uname\">"._USENDPRIVATEMSG." ".pnVarPrepForDisplay($uname)."</a> ]<br><br>\n";
	}
	echo "<table width=\"85%\" border=0 cellspacing=\"1\" bgcolor=\"".$GLOBALS['bgcolor2']."\">\n";

	echo $showme;

	echo "<tr><td height=1></td></tr>\n";
	echo "<tr bgcolor=\"".$GLOBALS['bgcolor3']."\"><td align=center colspan=2>\n";

	echo "<table width=\"97%\">\n";
	echo "<tr>\n";
	echo "<td width=\"60%\" valign=top><br>\n";

    user_main_last10com($uname);
    echo "<br></td><td valign=top><br>";
    user_main_last10submit($uname);

	echo "<br></td></tr></table>\n";

	echo "</td><tr>\n";

	echo "</table>";
	echo "</center>\n";	

	CloseTable();

    include("footer.php");
}

/*Added by Chestnut !*/
function user_deleteself($uname)
{
    OpenTable();
    echo "<font class=\"pn-title\">"._UADELUSER." : ".pnVarPrepForDisplay($uname)."</font><br>";

	echo ""._UADELUSERHOW."<br>";
	echo "<form method=\"post\" action=\"user.php\">";	
	echo _UADELMYACC;
	echo "<input type=\"hidden\" name=\"op\" value=\"selfdeleteuser\">";
	echo "<input type=\"submit\" value=\""._OK."\" class=\"pn-normal\" style=\"text-align:center\">";
	
	echo "</form>";
    CloseTable();
}
/*End !*/

function user_user_login() {
    list($uname,
         $pass,
         $url,
         $rememberme) = pnVarCleanFromInput('uname',
                                   			'pass',
                                   			'url',
                                   			'rememberme');

    if (!isset($rememberme)) {
        $rememberme = '';
    }
    access_user_login($uname, $pass, $url, $rememberme);
}

 function user_user_getlogin()
{
        include 'header.php';

// Check if stop var is numeric
if ((isset($GLOBALS['stop']) && !empty($GLOBALS['stop']) && !is_numeric($GLOBALS['stop'])))
{
        include 'header.php';
        OpenTable();
        echo _MODARGSERROR;
        CloseTable();
        include 'footer.php';
}
//End of check
      OpenTable();
       if ($GLOBALS['stop']) {
            echo "<center><font class=\"pn-title\">"._LOGININCOR."</font></center>\n";
        } else {
            echo "<center><font class=\"pn-title\">"._USERREGLOGIN."</font>\n"
                ."</center><br><font class=\"pn-title\">";

            echo ""._SELECTOPTION."<br><br>"
                ."<a href=\"user.php?op=loginscreen&amp;module=NS-User\">"._LOGINSITE."</a><br><br>";

    // age will not be checked, if $pnconfig['minage'] is set to 0 in config.php
        if (pnConfigGetVar('minage') == 0) {
              echo "<a href=\"user.php?op=register&amp;module=NS-NewUser\">"._REGISTER."</a><br><br>";
        } else {
            echo "<a href=\"user.php?op=check_age&amp;module=NS-NewUser\">"._REGISTER."</a><br><br>";
        }

            echo "<a href=\"user.php?op=lostpassscreen&amp;module=NS-LostPassword\">"._RETRIEVEPASS."</a><br></font>";

        }

        CloseTable();

        include ("footer.php");
 }

function user_main_last10com($uname)
{
    list($dbconn) = pnDBGetConn();
    $pntable = pnDBGetTables();
    $column1 = &$pntable['comments_column'];
    $column2 = &$pntable['stories_column'];

    /*
     *  Fetch active laguage
     */
    if (pnConfigGetVar('multilingual') == 1) {
        $querylang = "AND (".$column2['alanguage']."='".pnVarPrepForStore(pnUserGetLang())."' OR "
                           .$column2['alanguage']."='') ";
    } else {
        $querylang = '';
    }

    /*
     *  Build up SQL
     */
    $query = "SELECT ".$column1['tid'].", "
                      .$column1['sid'].", "
                      .$column1['subject']." "
            ."FROM ".$pntable['comments'].", "
                    .$pntable['stories']." "
            ."WHERE (".$column1['name']."='".pnVarPrepForStore($uname)."' AND "
                    .$column1['sid']."=".$column2['sid'].") "
                    .$querylang
            ."ORDER BY ".$column1['sid']." DESC";

    /*
     *  Make limited select
     */
    $result = $dbconn->SelectLimit($query, 10, 0);

    /*
     *  Do output
     */
    //OpenTable();
    echo "<font class=\"pn-title\">"._LAST10COMMENTS." ".pnVarPrepForDisplay($uname).":</font><br>";

    while(list($tid, $sid, $subject) = $result->fields) {

        $result->MoveNext();
        echo "<li><a class=\"pn-normal\" href=\"modules.php?op=modload&amp;name=News&amp;file=article&amp;thold=-1&amp;mode=flat&amp;order=0&amp;sid=$sid#$tid\">".pnVarPrepForDisplay($subject)."</a><br>";
    }
    //CloseTable();
}

function user_main_last10submit($uname)
{
    $pntable = pnDBGetTables();
    list($dbconn) = pnDBGetConn();
    $column = &$pntable['stories_column'];

    /*
     *  Fetch active laguage
     */
    if (pnConfigGetVar('multilingual') == 1) {
        $querylang = "AND (".$column['alanguage']."='".pnVarPrepForStore(pnUserGetLang())."' OR "
                           .$column['alanguage']."='') ";
    } else {
        $querylang = '';
    }

    /*
     *  Build up SQL
     */
    $query = "SELECT ".$column['sid'].", "
                      .$column['title']." "
            ."FROM ".$pntable['stories']." "
            ."WHERE ".$column['informant']."='".pnVarPrepForStore($uname)."' "
                    .$querylang
            ."ORDER BY ".$column['sid']." DESC";

    /*
     *  Make limited select
     */
    $result = $dbconn->SelectLimit($query, 10, 0);

    /*
     *  Do output
     */
    //OpenTable();
    echo "<font class=\"pn-title\">"._LAST10SUBMISSIONS." ".pnVarPrepForDisplay($uname).":</font><br>";
    while(list($sid, $title) = $result->fields) {

        $result->MoveNext();
        If (!$title)  {
            $title = '- no Title -' ;
        }
        echo "<li><a class=\"pn-normal\" href=\"modules.php?op=modload&name=News&file=article&sid=$sid\">" . pnVarPrepForDisplay($title) . "</a><br>";
    }
    //CloseTable();
}

// View main user page
// ====================
function user_user_main($var)
{
    include 'header.php';
    user_menu_draw();

    if (pnUserLoggedIn()) {
        $uname = pnUserGetVar('uname');
		OpenTable();
		echo "<center><table width=\"97%\" cellpadding=1>\n";
		echo "<tr>\n";
		echo "<td width=\"50%\" align=center valign=top><br>\n";

		echo "<table><tr><td>";
    	user_main_last10com($uname);
		echo "</td></tr></table>";
		
    	echo "<br></td><td align=center valign=top><br>";
		echo "<table><tr><td>";
    	user_main_last10submit($uname);
		echo "</td></tr></table>";

		echo "<br></td></tr></table></center>\n";
		CloseTable();
    	/*Added by Chestnut !*/
		if (pnConfigGetvar('allowuserdelete')=="1") {
			if (pnUserGetVar('uname')==$uname) {
				user_deleteself($uname);
			}
		}
        include 'footer.php';
    } // ?else
}

function user_user_loginscreen()
{
    include 'header.php';
    OpenTable();
    echo "<form action=\"user.php\" method=\"post\">\n"
        ."<font class=\"pn-title\">"._USERLOGIN."</font><br><br>\n"
        ."<table border=\"0\"><tr><td>\n"
        ."<font class=\"pn-normal\">"._NICKNAME.": </font></td><td><input type=\"text\" name=\"uname\" size=\"26\" maxlength=\"25\"></td></tr>\n"
        ."<tr><td><font class=\"pn-normal\">"._PASSWORD.": </font></td><td><input type=\"password\" name=\"pass\" size=\"21\" maxlength=\"20\"></td></tr>\n";
        if (pnConfigGetVar('seclevel') != 'High') {
            echo "<tr><td><font class=\"pn-normal\">"._REMEMBERME.": </font></td><td><input type=\"checkbox\" name=\"rememberme\"></td></tr>\n";
        }
        echo "</table>\n"
        ."<input type=\"hidden\" name=\"url\" value=\"".getenv("HTTP_REFERER")."\">\n";
        user_submit('NS-User','login',_LOGIN);
    echo "</form>\n";
    CloseTable();

    include 'footer.php';
}

function user_user_logout($var)
{
    pnUserLogOut();

    redirect_index(_YOUARELOGGEDOUT);
}



///////////////////////
function getfieldlist()
{
	
	list($dbconn) = pnDBGetConn();
    $pntable = pnDBGetTables();
	$propcolumn = &$pntable['user_property_column'];
	$propresult = $dbconn->Execute("SELECT		$propcolumn[prop_label],
												$propcolumn[prop_validation]
									FROM		$pntable[user_property]
									WHERE		$propcolumn[prop_dtype]!='-1'
									AND			$propcolumn[prop_weight]!='0'
									ORDER BY	$propcolumn[prop_weight]");
	if (!$propresult->EOF) {
		$fieldrequired = array();
		while(list($prop_label, $prop_validation) = $propresult->fields) {
	       	$propresult->MoveNext();
			$prop_validation = unserialize($prop_validation);
			$prop_label_text = "";
		    $eval_cmd = "\$prop_label_text = $prop_label;";
		    @eval($eval_cmd);    
			if (empty($prop_label_text)) {
				$prop_label_text = $prop_label;
			}
			$fieldlist[$prop_label]['FIELD'] = $prop_label;
			$fieldlist[$prop_label]['LIBEL'] = $prop_label_text;
			$fieldlist[$prop_label]['VALIDATION'] = $prop_validation;
		}
	}

	return $fieldlist;

}
?>