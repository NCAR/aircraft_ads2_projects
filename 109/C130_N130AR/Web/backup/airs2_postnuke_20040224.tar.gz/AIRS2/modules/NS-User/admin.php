<?php
// File: $Id: admin.php,v 1.3 2003/06/19 00:02:38 fd Exp $ $Name:  $
// ----------------------------------------------------------------------
// POST-NUKE Content Management System
// Copyright (C) 2001 by the PostNuke Development Team.
// http://www.postnuke.com/
// ----------------------------------------------------------------------
// Based on:
// PHP-NUKE Web Portal System - http://phpnuke.org/
// Thatware - http://thatware.org/
// ----------------------------------------------------------------------
// LICENSE
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License (GPL)
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// To read the license please visit http://www.gnu.org/copyleft/gpl.html
// ----------------------------------------------------------------------
// Original Author of file:
// Purpose of file:
// ----------------------------------------------------------------------

if (!eregi("admin.php", $PHP_SELF)) {
    die ("Access Denied");
}

modules_get_language();
modules_get_manual();
include 'modules/NS-User/tools.php';
include 'modules/NS-User/password.php';

if (!pnSecAuthAction(0, 'Users::', '::', ACCESS_ADMIN)) {
    include 'header.php';
    echo _MODIFYUSERSNOAUTH;
    include 'footer.php';
}

/**
 * Users Functions
 */

function displayUsers() {

    include("header.php");
    GraphicAdmin();
    OpenTable();
    echo "<center><font class=\"pn-title\"><b><a href=\"admin.php?module=NS-User&op=main\">"._USERADMIN."</a></b></font></center>";
    CloseTable();

    if (!pnSecAuthAction(0, 'Users::', '::', ACCESS_EDIT)) {
        echo _MODIFYUSERSNOAUTH;
        include 'footer.php';
        return;
    }
    /*Added by Chestnut 13/02/2003 16h39*/
    //Delete User Request
    list($dbconn) = pnDBGetConn();
    $pntable = pnDBGetTables();
	$uatable = $pntable['users_modrequest'];
	$uacolumn = &$pntable[users_modrequest_column];
    if (pnSecAuthAction(0, 'Users::', '::', ACCESS_DELETE)) {
        $result = $dbconn->Execute("SELECT count(*) FROM ".$uatable['users_modrequest']." WHERE $uacolumn[udel]='1'");
        list($delreq) = $result->fields;
        if ($delreq != 0) {
            OpenTable();
            echo "<center><font class=\"pn-title\"><b>"._UADELWAIT."</b></font><br><br>\n";
            echo "<center><a href=\"admin.php?module=".$GLOBALS['module']."&op=ListDelRequest\">"._UADELWAITLST." ( ".pnVarPrepForDisplay($delreq)." )</a></center><br>\n";
            CloseTable();
        }
    }
	// Moderate List
    if (pnSecAuthAction(0, 'Users::', '::', ACCESS_ADD)) {
        $result = $dbconn->Execute("SELECT count(*) FROM ".$uatable['users_modrequest']." WHERE $uacolumn[uadd]='1'");
        list($addreq) = $result->fields;
        if ($addreq != 0) {
            OpenTable();
            echo "<center><font class=\"pn-title\"><b>"._UAADDWAIT."</b></font><br><br>\n";
            echo "<center><a href=\"admin.php?module=".$GLOBALS['module']."&op=ListUAddRequest\">"._UAADDWAITLST." ( ".pnVarPrepForDisplay($addreq)." )</a></center><br>\n";
            CloseTable();
        }
    }
    /*End*/
	
    // Edit current user
    if (pnSecAuthAction(0, 'Users::', '::', ACCESS_EDIT)) {
        $column = &$pntable['users_column'];
        $result = $dbconn->Execute("SELECT 		$column[uid], $column[uname]
							        FROM		$pntable[users]
                                    WHERE		$column[uid]!='1'
                                    ORDER BY	$column[uname]");
        OpenTable();
        echo "<center><font class=\"pn-title\"><b>"._EDITUSER."</b></font><br><br>"
        	."<form method=\"post\" action=\"admin.php\">\n";
        echo "<select name=\"chng_uid\">";
	    while(list($uid, $uname) = $result->fields) {
	        $result->MoveNext();
	        echo "<option value=\"$uid\">$uname</option>\n";
        }
        echo "</select>&nbsp;&nbsp;"
	        ."<select name=\"op\">\n"
	        ."<option value=\"modifyUser\">"._MODIFY."</option>\n"
	        ."<option value=\"delUser\">"._DELETE."</option></select>\n"
	        ."<input type=\"hidden\" name=\"module\" value=\"".$GLOBALS['module']."\">\n"
			."<input type=\"hidden\" name=\"authid\" value=\"" . pnSecGenAuthKey() . "\">\n"
	        ."<input type=\"submit\" value=\""._OK."\"></form></center>\n";
        CloseTable();
    }

    // Add new user
    if (pnSecAuthAction(0, 'Users::', '::', ACCESS_ADD)) {
        OpenTable();
        echo "<center><font class=\"pn-title\"><b>"._ADDUSER."</b></font><br><br>\n"
        	."<form action=\"admin.php\" method=\"post\">\n"
        	."<table border=\"0\" width=\"100%\">\n"
            ."<tr><td width=\"150\"><font class=\"pn-norma\">"._NICKNAME."</font></td>\n"
            ."<td><input type=\"text\" name=\"add_uname\" size=\"30\" maxlength=\"25\"> <font class=\"pn-sub\">"._REQUIRED."</font></td></tr>\n"
            ."<tr><td><font class=\"pn-normal\">"._EMAIL."</font></td>\n"
            ."<td><input type=\"text\" name=\"add_email\" size=\"30\" maxlength=\"60\"> <font class=\"pn-sub\">"._REQUIRED."</font></td></tr>\n"
            ."<tr><td><font class=\"pn_normal\">"._PASSWORD."</font></td>\n"
            ."<td><input type=\"password\" name=\"add_pass\" size=\"30\" maxlength=\"12\"> <font class=\"pn-sub\">"._REQUIRED."</font></td></tr>\n";

		// Adding the Required fields to the Add User function - Search Sign %%@ get required fields @%%
		$requiredfields = getfieldrequired();
		if (!empty($requiredfields) && is_array($requiredfields)) {
			echo "<tr><td colspan=2> -- </td></tr>\n";
			while(list($key, $val) = each($requiredfields)) {

				$namefield = $val['FIELD'];
				$isrequired = $val['VALIDATION']['REQUIRED'];
				$fieldvalid = $val['VALIDATION'];
				$fieldlibel = $val['LIBEL'];

				echo "<tr><td><font class=\"pn-normal\">\n".pnVarPrepForDisplay($fieldlibel)."</font></td>\n";
				echo "<td>\n";
				switch ($namefield) {
					case "_TIMEZONEOFFSET":
	                	global $tzinfo;
	                    echo "<table><tr><td><select name=\"dynafield['".$val['FIELD']."']\" class=\"pn-normal\">";
	                    foreach ($tzinfo as $tzindex => $tzdata) {
		                    echo "\n<option value=\"$tzindex\">";
	                        echo $tzdata;
	                        echo "</option>";
	                    }
	                    echo "</select></td></tr></table>\n";
						break;
					case "_YOURAVATAR":
                        echo "<table><tr><td><select name=\"dynafield['".$namefield."']\" class=\"pn-normal\">";
                        $handle = opendir('./images/avatar');
                        while ($file = readdir($handle)) {
                            $filelist[] = $file;
                        }
                        asort($filelist);
                        while (list ($key, $file) = each ($filelist)) {
                            ereg(".gif|.jpg",$file);
                            if ($file != "." && $file != "..") {
                                echo "<option value=\"$file\">$file</option>";
                           }
                        }
                        echo "</select>&nbsp;&nbsp;";
                        echo "<script language=\"JavaScript\">
						<!--
						function OpenAvatarWindow(theURL,winName,features) { //v2.0
						  window.open(theURL,winName,features);
						}
						//-->
						</script>[ <a onClick=\"OpenAvatarWindow('avatar.php','Avatars','scrollbars=yes,width=450,height=400')\">"._UAAVATARLIST."</a> ]</td></tr></table>";
						break;
					default:
						$fieldvalid['NAME'] = $namefield;
						echo getfieldHTMLDef($fieldvalid, $dynavalue='');
						break;
				}
				//echo " <font class=\"pn-sub\">"._REQUIRED."</font>\n";
				echo "</td></tr>\n";
			}
		}

		echo "<tr><td colspan=2> -- </td></tr>\n"
			//."<input type=\"hidden\" name=\"add_avatar\" value=\"blank.gif\">\n"
            ."<input type=\"hidden\" name=\"module\" value=\"NS-User\">\n"
            ."<input type=\"hidden\" name=\"op\" value=\"addUser\">\n"
	    	."<input type=\"hidden\" name=\"authid\" value=\"" . pnSecGenAuthKey() . "\">\n"
            ."<tr><td colspan=\"2\"><input type=\"submit\" value=\""._ADDUSERBUT."\"></form></td></tr>\n"
            ."</table>\n";
        CloseTable();
    }
// Access User Settings
    if (pnSecAuthAction(0, 'Users::', '::', ACCESS_ADD)) {
        OpenTable();
        echo "<center><font class=\"pn-title\"><b>"._USERCONF."</b></font></center><br><br>";
        echo "<center><a href=\"admin.php?module=".$GLOBALS['module']."&amp;op=getConfig\">"._USERCONF."</a></center>";
        echo "<center><a href=\"admin.php?module=".$GLOBALS['module']."&amp;op=getDynamic\">"._DYNAMICDATA."</a></center>";
        CloseTable();
        include("footer.php");
    }
}

function modifyUser($chng_user)
{
    list($dbconn) = pnDBGetConn();
    $pntable = pnDBGetTables();

    include("header.php");
    GraphicAdmin();

    OpenTable();
    echo "<center><font class=\"pn-title\"><b><a href=\"admin.php?module=NS-User&op=main\">"._USERADMIN."</a></b></font></center>";
    CloseTable();

	OpenTable();
	
	$userinfo = pnUserGetVars($chng_user);
	
	// Aliasing
    $userinfo['_UREALEMAIL'] = $userinfo['email'];
    $userinfo['_UFAKEMAIL'] = $userinfo['femail'];
    $userinfo['_UREALNAME'] = $userinfo['name'];
    $userinfo['_TIMEZONEOFFSET'] = $userinfo['timezone_offset'];
    //$userinfo['email'] = $userinfo['uname'];
    $userinfo['_YOURAVATAR'] = $userinfo['user_avatar'];
    $userinfo['_YICQ'] = $userinfo['user_icq'];
    $userinfo['_YAIM'] = $userinfo['user_aim'];
    $userinfo['_YYIM'] = $userinfo['user_yim'];
    $userinfo['_YMSNM'] = $userinfo['user_msnm'];
    $userinfo['_YLOCATION'] = $userinfo['user_from'];
    $userinfo['_YOCCUPATION'] = $userinfo['user_occ'];
    $userinfo['_YINTERESTS'] = $userinfo['user_intrest'];
    $userinfo['_SIGNATURE'] = $userinfo['user_sig'];
    $userinfo['_EXTRAINFO'] = $userinfo['bio'];
    $userinfo['_YOURHOMEPAGE'] = $userinfo['url'];
	
	$fieldlist = getfieldlist();

   	echo "<center><font class=\"pn-title\"><b>"._USERUPDATE.": <i>" . pnVarPrepForDisplay(stripslashes($chng_user)) . "</i></b></font></center>"
   	    ."<form name=\"Register\" action=\"admin.php\" method=\"post\">"
   	    ."<table border=\"0\">"
   	    ."<tr><td>"._USERID."</td>"
   	    ."<td><table><tr><td>\n<b>".pnVarPrepForDisplay($chng_user)."</b></td></tr></table></td></tr>"
   	    ."<tr><td>"._NICKNAME."</td>"
		."<td><table><tr><td>\n<input type=text name=\"chng_uname\" value=\"".$userinfo['uname']."\" size=40> ( <b>"._REQUIREDSTAR."</b> )</td></tr></table></td></tr>\n"
        ."<tr><td><font class=\"pn-normal\">"._EMAIL."</font></td>\n"
        ."<td><table><tr><td>\n<input type=\"text\" name=\"chng_email\" value=\"".$userinfo['email']."\" size=\"40\" maxlength=\"60\"> ( <b>"._REQUIREDSTAR."</b> )</font></td></tr></table></td></tr>\n";

	while(list($key, $val) = each($fieldlist)) {


		//Simplifying
		$namefield = $val['FIELD'];
		$isrequired = $val['VALIDATION']['REQUIRED'];
		$fieldvalid = $val['VALIDATION'];
		$fieldlibel = $val['LIBEL'];

		echo "<tr><td>".$fieldlibel."</td><td>\n";
		switch ($namefield) {
			case "_TIMEZONEOFFSET":
               	global $tzinfo;
                echo "<table><tr><td>\n<select name=\"dynafield[".$namefield."]\" class=\"pn-normal\">";
                foreach ($tzinfo as $tzindex => $tzdata) {
					if ($userinfo[$namefield] == $tzindex) {
						$selected = 'selected';
					} else {
						$selected = '';
					}
	                echo "\n<option value=\"$tzindex\" $selected>";
                    echo $tzdata;
                    echo "</option>";
                }
                echo "</select>\n";
				if ($isrequired == 1) {
					echo " ( <b>"._REQUIREDSTAR."</b> )";
				}
				echo "</td></tr></table>\n";
				break;
			case "_YOURAVATAR":
	            echo "<table><tr><td>\n<select name=\"user_avatar\" onChange=\"showimage()\" class=\"pn-normal\">";
                $handle = opendir('./images/avatar');
                while ($file = readdir($handle)) {
	                $filelist[] = $file;
                }
                asort($filelist);
                while (list ($key, $file) = each ($filelist)) {
	                ereg(".gif|.jpg",$file);
                    if ($file != "." && $file != "..") {
						if ($userinfo[$namefield] == $file) {
							$selected = 'selected';
						} else {
							$selected = '';
						}
	                    echo "<option value=\"$file\" $selected>$file</option>";
                    }
				}
                echo "</select>&nbsp;&nbsp;<img src=\"images/avatar/" . pnVarPrepForDisplay($userinfo[$namefield]) . "\" name=\"avatar\" width=\"32\" height=\"32\" alt=\"\" align=\"top\">&nbsp;&nbsp;";
                echo "<script language=\"JavaScript\">
				<!--
				function OpenAvatarWindow(theURL,winName,features) { //v2.0
				window.open(theURL,winName,features);
				}
				//-->
				</script>[ <a onClick=\"OpenAvatarWindow('avatar.php','Avatars','scrollbars=yes,width=450,height=400')\">avatar list</a> ]";
				if ($isrequired == 1) {
					echo " ( <b>"._REQUIREDSTAR."</b> )";
				}
				echo "</td></tr></table>\n";
				break;
			default:
				$fieldvalid['NAME'] = $namefield;
				if ($fieldvalid['TYPE'] == "SELECT" && $fieldvalid['LISTOPTION'] == 1) $userinfo[$namefield] = unserialize($userinfo[$namefield]);
				echo getfieldHTMLDef($fieldvalid, $userinfo[$namefield]);
				//echo "<input type=\"text\" name=\"reqdynadata['".$namefield."']\" size=\"30\" maxlength=\"60\">\n";
				break;
		}
		
		echo "</td></tr>";
	}
    echo "<input type=\"hidden\" name=\"module\" value=\"NS-User\">"
	    ."<input type=\"hidden\" name=\"op\" value=\"updateUser\">"
		."<input type=\"hidden\" name=\"chng_uid\" value=\"$chng_user\">"
		."<input type=\"hidden\" name=\"authid\" value=\"" . pnSecGenAuthKey() . "\">"
   	    ."<tr><td>"._PASSWORD."</td>"
   	    ."<td><table><tr><td>\n<input type=\"password\" name=\"chng_pass\" size=\"15\" maxlength=\"12\">\n</td></tr></table>\n</td></tr>"
   	    ."<tr><td>"._RETYPEPASSWD."</td>"
   	    ."<td><table><tr><td>\n<input type=\"password\" name=\"chng_pass2\" size=\"15\" maxlength=\"12\"> <font class=\"pn-sub\">"._FORCHANGES."</font>\n</td></tr></table>\n</td></tr>"
   	    ."<tr><td><input type=\"submit\" value=\""._SAVECHANGES."\"></form></td></tr>"
   	    ."</table>";

   	CloseTable();
    include("footer.php");
}

function updateUser()
{
    if (!pnSecConfirmAuthKey()) {
        include 'header.php';
        echo _BADAUTHKEY;
        include 'footer.php';
        exit;
    }

    list(	$chng_uid,
         	$chng_uname,
			$chng_email,
			$user_avatar,
         	$chng_pass,
         	$chng_pass2) = pnVarCleanFromInput(	'chng_uid',
												'chng_uname',
												'chng_email',
												'user_avatar',
												'chng_pass',
												'chng_pass2');
	$dynafield = pncVarCleanFromInput('dynafield');
	

	// Aliasing
    $storefield['_UREALEMAIL']['NAME'] = 'email';
    $storefield['_UFAKEMAIL']['NAME'] = 'femail';
    $storefield['_UREALNAME']['NAME'] = 'name';
    $storefield['_TIMEZONEOFFSET']['NAME'] = 'timezone_offset';
    $storefield['_YOURAVATAR']['NAME'] = 'user_avatar';
    $storefield['_YICQ']['NAME'] = 'user_icq';
    $storefield['_YAIM']['NAME'] = 'user_aim';
    $storefield['_YYIM']['NAME'] = 'user_yim';
    $storefield['_YMSNM']['NAME'] = 'user_msnm';
    $storefield['_YLOCATION']['NAME'] = 'user_from';
    $storefield['_YOCCUPATION']['NAME'] = 'user_occ';
    $storefield['_YINTERESTS']['NAME'] = 'user_intrest';
    $storefield['_SIGNATURE']['NAME'] = 'user_sig';
    $storefield['_EXTRAINFO']['NAME'] = 'bio';
    $storefield['_YOURHOMEPAGE']['NAME'] = 'url';
	
	$storecontent = $dynafield;
	if (is_array($storecontent) && !empty($storecontent)) {
		while(list($fieldname, $fieldvalue) = each($storecontent)) {
			if (!isset($storefield[$fieldname]['NAME'])) {
				$newdynafield[$fieldname]['VALUE'] = $fieldvalue;
				$newdynafield[$fieldname]['NAME'] = $fieldname;
			} else {
				$storefield[$fieldname]['VALUE'] = $fieldvalue;
				//$storefield[$fieldname]['NAME'] = $fieldname;
			}
		}
	}
	$storefield['_YOURAVATAR']['VALUE'] = $user_avatar;
	$storefield['_UREALEMAIL']['VALUE'] = $chng_email;
	
    list($dbconn) = pnDBGetConn();
    $pntable = pnDBGetTables();

    $column = &$pntable['users_column'];
    $result = $dbconn->Execute("SELECT $column[uname], $column[pass]
                                FROM $pntable[users]
                                WHERE $column[uid] = " . pnVarPrepForStore($chng_uid)."");


    if(!isset($chng_user_viewemail)) {
        $chng_user_viewemail = 0;
    }

    if(!$result->EOF) {
        list($old_uname, $old_pass) = $result->fields;
    } else {
        include 'header.php';
        echo _USERNOEXIST;
        include 'footer.php';
        return;
    }
    if (!pnSecAuthAction(0, 'Users::', $old_uname."::".$chng_uid, ACCESS_EDIT)) {
        include 'header.php';
        echo _MODIFYUSERSEDITNOAUTH;
        include 'footer.php';
        return;
    }

    // Bug #507260 - space in username
    // 2002-01-27: hdonner
    if ((!$chng_uname) || !(ereg("^[[:print:]]+",$chng_uname) && !ereg("[[:space:]]",$chng_uname))) {

        include("header.php");
        GraphicAdmin();
        OpenTable();
        echo "<center><font class=\"pn-title\"><b>"._USERADMIN."</b></font></center>";
        CloseTable();

        OpenTable();
        echo "<center>"._ERRORINVNICK."<br><br>"
            .""._GOBACK."</center>";
        CloseTable();
        include("footer.php");
        exit;
    }

	$chng_url = $storefield['_YOURHOMEPAGE']['VALUE'];
    if ($chng_url != "")
    {
        $url_array = explode(":", $chng_url);
        if ($url_array[0] != "http")
        {
            include("header.php");
            GraphicAdmin();
            OpenTable();
            echo "<center><font class=\"pn-title\"><b>"._USERADMIN."</b></font></center>";
            CloseTable();

            OpenTable();
            echo "<center>"._ERRORINVURL."<br><br>"
                .""._GOBACK."</center>";
            CloseTable();
            include("footer.php");
            exit;
        }
    }

    $tmp = 0;
    if ($chng_pass2 != "") {
        if($chng_pass != $chng_pass2) {
            include 'header.php';
            GraphicAdmin();
            OpenTable();
            echo "<center><font class=\"pn-title\"><b>"._USERADMIN."</b></font></center>";
            CloseTable();

            OpenTable();
            echo "<center>"._PASSWDNOMATCH."<br><br>"
                .""._GOBACK."</center>";
            CloseTable();
            include("footer.php");
            exit;
        }
        $tmp = 1;
    }
	
	$fieldrequired = getfieldrequired();
	$checkrequired = $fieldrequired;
	$error = false;
	
	if (is_array($checkrequired) && !empty($checkrequired)) {
		while(list($key, $val) = each($checkrequired)) {
			if ($storefield[$val['FIELD']]['NAME']."" != "" && $storefield[$val['FIELD']]['VALUE']."" == "") {
				$error = true;
				$errortype = "Store";
			}
			if (isset($newdynafield[$val['FIELD']]['NAME']) && $newdynafield[$val['FIELD']]['VALUE']."" == "") {
				$error = true;
				$errortype = "Dyna";
			}
			if ($error == true) {
				include 'header.php';
	            OpenTable();
	            echo "<center>".EMPTYREQUIRED." = ".$errortype."<br>"
					."".$storefield[$val['FIELD']]['NAME']." = ".$storefield[$val['FIELD']]['VALUE']."<br>"
	                .""._GOBACK."</center>";
	            CloseTable();
	            include("footer.php");
	            return;
			}
		}
	}
	
	if ($tmp == 1) {
		$cpass = md5($chng_pass);
	} else {
		$cpass = $old_pass;
	}
	$sql = "UPDATE $pntable[users]
            SET		$column[uname]										='".pnVarPrepForStore($chng_uname)."',
					".$column[$storefield['_UREALEMAIL']['NAME']]."		='".pnVarPrepForStore($storefield['_UREALEMAIL']['VALUE'])."',
					".$column[$storefield['_UFAKEMAIL']['NAME']]."		='".pnVarPrepForStore($storefield['_UFAKEMAIL']['VALUE'])."',
					".$column[$storefield['_UREALNAME']['NAME']]."		='".pnVarPrepForStore($storefield['_UREALNAME']['VALUE'])."',
					".$column[$storefield['_YOURAVATAR']['NAME']]."		='".pnVarPrepForStore($storefield['_YOURAVATAR']['VALUE'])."',
					".$column[$storefield['_YICQ']['NAME']]."			='".pnVarPrepForStore($storefield['_YICQ']['VALUE'])."',
					".$column[$storefield['_YAIM']['NAME']]."			='".pnVarPrepForStore($storefield['_YAIM']['VALUE'])."',
					".$column[$storefield['_YYIM']['NAME']]."			='".pnVarPrepForStore($storefield['_YYIM']['VALUE'])."',
					".$column[$storefield['_YMSNM']['NAME']]."			='".pnVarPrepForStore($storefield['_YMSNM']['VALUE'])."',
					".$column[$storefield['_TIMEZONEOFFSET']['NAME']]."	='".pnVarPrepForStore($storefield['_TIMEZONEOFFSET']['VALUE'])."',
					".$column[$storefield['_YLOCATION']['NAME']]."		='".pnVarPrepForStore($storefield['_YLOCATION']['VALUE'])."',
					".$column[$storefield['_YINTERESTS']['NAME']]."		='".pnVarPrepForStore($storefield['_YINTERESTS']['VALUE'])."',
					".$column[$storefield['_SIGNATURE']['NAME']]."		='".pnVarPrepForStore($storefield['_SIGNATURE']['VALUE'])."',
					".$column[$storefield['_EXTRAINFO']['NAME']]."		='".pnVarPrepForStore($storefield['_EXTRAINFO']['VALUE'])."',
					".$column[$storefield['_YOURHOMEPAGE']['NAME']]."	='".pnVarPrepForStore($storefield['_YOURHOMEPAGE']['VALUE'])."',
					$column[pass]='".pnVarPrepForStore($cpass)."'
					WHERE 	$column[uid]='".pnVarPrepForStore($chng_uid)."'";
    $result = $dbconn->Execute($sql);
    if($dbconn->ErrorNo()<>0) {
	    echo $dbconn->ErrorMsg();
    }
	
	$dynarequired = getdynamiclist();
	if (is_array($dynarequired) && !empty($dynarequired)) {
		while(list($key, $val) = each($dynarequired)) {
			$inputfield = $val['FIELD'];
			$inputvalue = $newdynafield[$inputfield]['VALUE'];
			if (is_array($inputvalue)) {
				$inputvalue = serialize($inputvalue);
			}
			pncAdminUserSetVar($inputfield, $inputvalue, $chng_uid);
		}
	}

	pnRedirect("admin.php");
}

function deleteUser($chng_uid)
{
   list($dbconn) = pnDBGetConn();
   $pntable = pnDBGetTables();

   $authid = pnSecGenAuthKey();

   include("header.php");
   GraphicAdmin();
   OpenTable();
   echo "<center><font class=\"pn-title\"><b><a href=\"admin.php?module=NS-User&op=main\">"._USERADMIN."</a></b></font></center>";
   CloseTable();

   OpenTable();
   echo "<center><font class=\"pn-title\"><b>"._DELETEUSER."</b></font><br><br>";

   $column = &$pntable['users_column'];
   // Someone got uname and uid the wrong way around in the form.
   // This needs to be sorted one day to avoid further confusion
   $result = $dbconn->Execute("SELECT $column[uname], $column[uid]
           FROM $pntable[users]
           WHERE ($column[uid] = '$chng_uid') OR ($column[uname] = '$chng_uid')");

   if(!$result->EOF) {
       list($uname, $uid) = $result->fields;
   } else {
     echo _USERNOEXIST;
     CloseTable();
     include 'footer.php';
     exit;
   }
   if (!pnSecAuthAction(0, 'Users::', "$uname::$chng_uid", ACCESS_DELETE)) {
      echo _MODIFYUSERSDELNOAUTH;
      CloseTable();
      include 'footer.php';
      exit;
   }
   
   $userinfo = pnUserGetVars($chng_uid);
   echo ""._SURE2DELETE." " . pnVarPrepForDisplay($userinfo['uname']) . " ( " . pnVarPrepForDisplay(stripslashes($chng_uid)) . " ) ?<br><br>\n\n"
       ."[ <a href=\"admin.php?module=NS-User&amp;op=delUserConf&amp;del_uid=$uid&amp;authid=$authid\">"._YES.""
       ."</a> | <a href=\"admin.php?module=NS-User&amp;op=mod_users\">"._NO."</a> ]</center>";
   CloseTable();
   include("footer.php");
}

function deleteUserConfirm($del_uid)
{

    if (!pnSecConfirmAuthKey()) {
        include 'header.php';
        echo _BADAUTHKEY;
        include 'footer.php';
        exit;
    }
    list($dbconn) = pnDBGetConn();
    $pntable = pnDBGetTables();

    $column = &$pntable['users_column'];

    $result = $dbconn->Execute("SELECT $column[uname]
         FROM $pntable[users]
         WHERE $column[uid] = \"$del_uid\"");

    if(!$result->EOF) {
       list($uname) = $result->fields;
    } else {
      include 'header.php';
      echo _USERNOEXIST;
      include 'footer.php';
      exit;
    }
    if (!pnSecAuthAction(0, 'Users::', "$uname::$del_uid", ACCESS_DELETE)) {
       include 'header.php';
       echo _MODIFYUSERSDELNOAUTH;
       include 'footer.php';
       exit;
    }
    $column = &$pntable['user_perms_column'];
    $dbconn->Execute("DELETE FROM $pntable[user_perms]
                            WHERE $column[uid]='$del_uid'");
    if($dbconn->ErrorNo()<>0) {
       echo $dbconn->ErrorMsg();
       error_log("DB Error: " . $dbconn->ErrorMsg());
    }
    $column = &$pntable['group_membership_column'];
    $dbconn->Execute("DELETE FROM $pntable[group_membership]
                            WHERE $column[uid]='$del_uid'");
    if($dbconn->ErrorNo()<>0) {
       echo $dbconn->ErrorMsg();
       error_log("DB Error: " . $dbconn->ErrorMsg());
    }
    $column = &$pntable['users_column'];
    $dbconn->Execute("DELETE FROM $pntable[users]
                            WHERE $column[uid]='$del_uid'");
    if($dbconn->ErrorNo()<>0) {
       echo $dbconn->ErrorMsg();
       error_log("DB Error: " . $dbconn->ErrorMsg());
    }
    $column = &$pntable['user_data_column'];
    $dbconn->Execute("DELETE FROM $pntable[user_data]
                            WHERE $column[uda_uid]='$del_uid'");
    if($dbconn->ErrorNo()<>0) {
       echo $dbconn->ErrorMsg();
       error_log("DB Error: " . $dbconn->ErrorMsg());
    }
    pnRedirect("admin.php");

}

function addUser($var)
{
    if (!pnSecConfirmAuthKey()) {
        include 'header.php';
        echo _BADAUTHKEY;
        include 'footer.php';
        exit;
    }
    list($dbconn) = pnDBGetConn();
    $pntable = pnDBGetTables();

    if (!pnSecAuthAction(0, 'Users::', $var['add_uname']."::", ACCESS_ADD)) {
       include 'header.php';
       echo _MODIFYUSERSADDNOAUTH;
       include 'footer.php';
       exit;
    }

    $add_pass = md5($var['add_pass']);
    if (!($var['add_uname'] && $var['add_email'] && $var['add_pass'])) { // && $var['dynafield'])) {
       include("header.php");
       GraphicAdmin();
       OpenTable();
       echo "<center><font class=\"pn-title\"><b><a href=\"admin.php?module=NS-User&op=main\">"._USERADMIN."</a></b></font></center>";
       CloseTable();

       OpenTable();
       echo "<center><b>"._NEEDTOCOMPLETE."</b><br><br>"
       .""._GOBACK."";
       CloseTable();
       include("footer.php");
       return;
    }

    $stop = userCheck($var);
    if (!isset($stop)) {

    if (empty($var['add_user_viewemail'])) {
       $var['add_user_viewemail'] = 0;
    } else {
		$var['add_user_viewemail'] = 1;
	}
    $Default_Theme = pnConfigGetVar('Default_Theme');
    $commentlimit = pnConfigGetVar('commentlimit');
    $storynum = pnConfigGetVar('storyhome');
	
	if (!empty($var['dynafield']) && is_array($var['dynafield'])) $reqdynadata = $var['dynafield'];
	if (isset($reqdynadata['_TIMEZONEOFFSET'][0])) {
		$timezoneoffset = $reqdynadata['_TIMEZONEOFFSET'][0];
	} else {
	    $timezoneoffset = pnConfigGetVar('timezone_offset');
	}
	if (isset($reqdynadata['_YOURAVATAR'][0])) {
		$add_avatar = $reqdynadata['_YOURAVATAR'][0];
	} else {
	    $add_avatar = 'blank.gif';
	}
    $user_regdate = time();
    $column = &$pntable['users_column'];
	$existinguser = $dbconn->Execute("SELECT $column[uname] FROM $pntable[users] WHERE $column[uname]='".$var['add_uname']."'");
	if (!$existinguser->EOF) {
		include 'header.php';
		echo "<div align=center><font class=\"pn-title\">"._USEREXIST
			." <a href=\"admin.php?module=NS-User&op=modifyUser&chng_uid=$var[add_uname] \">(".pnVarPrepForDisplay($var['add_uname']).") "
			."</a></font></div><br>";
		echo "<a href=\"admin.php?module=NS-User&op=main\">"._ADDUSER."</a>";
		include 'footer.php';
	} else {
		$uid = $dbconn->GenId($pntable['users']);
		$sql = "INSERT INTO $pntable[users] ($column[uid], $column[name],
						 $column[uname], $column[email], $column[femail], $column[url],
						 $column[user_regdate], $column[user_icq], $column[user_aim],
						 $column[user_yim], $column[user_msnm], $column[user_from],
						 $column[user_occ], $column[user_intrest], $column[user_viewemail],
						 $column[user_avatar], $column[user_sig], $column[pass], $column[timezone_offset])
						 values (".pnVarPrepForStore($uid).",'','".$var['add_uname']."','".$var['add_email']."','',
						 '','".pnVarPrepForStore($user_regdate)."','','','','','','','','".$var['add_user_viewemail']."','".pnVarPrepForStore($add_avatar)."',
						 '','".pnVarPrepForStore($add_pass)."','".pnVarPrepForStore($timezoneoffset)."')";
		$result = $dbconn->Execute($sql);
		if($dbconn->ErrorNo()<>0) {
		   echo $dbconn->ErrorNo() . ": " . $dbconn->ErrorMsg() . "<br>";
		   error_log("DB Error: " . $dbconn->ErrorMsg());
		   return;
		}

		// Add user to group
		// get the generated id
		$uid = $dbconn->PO_Insert_ID($pntable['users'],$column['uid']);
		$column = &$pntable['groups_column'];
		$result = $dbconn->Execute("SELECT $column[gid] FROM $pntable[groups] WHERE $column[name]='".pnConfigGetVar('defaultgroup')."'");

		if($dbconn->ErrorNo()<>0) {
		    echo $dbconn->ErrorNo(). "Get default group: ".$dbconn->ErrorMsg(). "<br>";
		    error_log ($dbconn->ErrorNo(). "Get default group: ".$dbconn->ErrorMsg(). "<br>");
		    return;
		}
		
		if (!$result->EOF) {
		  list($gid) = $result->fields;
		  $result->Close();
		  $column = &$pntable['group_membership_column'];
		  $result = $dbconn->Execute("INSERT INTO $pntable[group_membership] ($column[gid], $column[uid]) VALUES (".pnVarPrepForStore($gid).", ".pnVarPrepForStore($uid).")");

		  if($dbconn->ErrorNo()<>0) {
			 echo $dbconn->ErrorNo(). "Add to default group: ".$dbconn->ErrorMsg(). "<br>";
			 error_log ($dbconn->ErrorNo(). "Add to default group: ".$dbconn->ErrorMsg(). "<br>");
			 return;
		  }
		}
		
		// Add Dynamic Data
		if (!empty($var['dynafield']) && is_array($var['dynafield'])) {
			$fieldrequired = getfieldrequired();
			if (is_array($fieldrequired) && !empty($fieldrequired)) {
				while(list($key, $val) = each($fieldrequired)) {
					$field = $val['FIELD'];
					$newvar = $var['dynafield'];
					//while(list($nkey, $nvar) = each($newvar)) {
						pncAdminUserSetVar($field, $newvar[$field], $uid);
					//}
				}
			}
		}

		include 'header.php';
		echo "<div align=center><font class=\"pn-title\">"
			."<a href=\"admin.php?module=NS-User&op=modifyUser&chng_uid=$uid\">".pnVarPrepForDisplay(stripslashes($var['add_uname']))." ("
			._USERID." $uid)</A> "._ADDED."</div></font><br>";
		echo "<a href=\"admin.php?module=NS-User&op=main\">"._ADDUSER."</a>";
		include 'footer.php';
	}
    } else {
    	include 'header.php';
		echo "$stop";
		include 'footer.php';
    }
}

function user_admin_getConfig() {

    include ("header.php");

    // prepare vars
    $sel_usergraphic['0'] = '';
    $sel_usergraphic['1'] = '';
    $sel_usergraphic[pnConfigGetVar('usergraphic')] = ' checked';
    $sel_minpass['3'] = '';
    $sel_minpass['5'] = '';
    $sel_minpass['8'] = '';
    $sel_minpass['10'] = '';
    $sel_minpass[pnConfigGetVar('minpass')] = ' selected';
    /*Added by Chestnut ! 22/05/2002*/
    $sel_theme_change['0'] = '';
    $sel_theme_change['1'] = '';
    $sel_theme_change[pnConfigGetVar('theme_change')] = ' checked';
    $sel_sendaddmail['0'] = '';
    $sel_sendaddmail['1'] = '';
    $sel_sendaddmail[pnConfigGetVar('sendaddmail')] = ' checked';
    $sel_allowuserpass['0'] = '';
    $sel_allowuserpass['1'] = '';
    $sel_allowuserpass[pnConfigGetVar('allowuserpass')] = ' checked';
    $sel_senduserpass['0'] = '';
    $sel_senduserpass['1'] = '';
    $sel_senduserpass[pnConfigGetVar('senduserpass')] = ' checked';
    $sel_allowuserdelete['0'] = '';
    $sel_allowuserdelete['1'] = '';
    $sel_allowuserdelete[pnConfigGetVar('allowuserdelete')] = ' checked';
    $sel_senddeletemail['0'] = '';
    $sel_senddeletemail['1'] = '';
    $sel_senddeletemail[pnConfigGetVar('senddeletemail')] = ' checked';
    $sel_blkusrreg['0'] = '';
    $sel_blkusrreg['1'] = '';
    $sel_blkusrreg[pnConfigGetVar('blkusrreg')] = ' checked';
    //pncUA v1.2
    $sel_pncuaadvreg['0'] = '';
    $sel_pncuaadvreg['1'] = '';
    $sel_pncuaadvreg[pnConfigGetVar('pncuaadvreg')] = ' checked';
    //pncUA v1.5
    $sel_pncusrmodreg['0'] = '';
    $sel_pncusrmodreg['1'] = '';
    $sel_pncusrmodreg[pnConfigGetVar('pncusrmodreg')] = ' checked';
    $sel_pnc_mail_modusrwning['0'] = '';
    $sel_pnc_mail_modusrwning['1'] = '';
    $sel_pnc_mail_modusrwning[pnConfigGetVar('pnc_mail_modusrwning')] = ' checked';
    $sel_pnc_mail_adminwning['0'] = '';
    $sel_pnc_mail_adminwning['1'] = '';
    $sel_pnc_mail_adminwning[pnConfigGetVar('pnc_mail_adminwning')] = ' checked';
    $sel_pnc_mail_usrregok['0'] = '';
    $sel_pnc_mail_usrregok['1'] = '';
    $sel_pnc_mail_usrregok[pnConfigGetVar('pnc_mail_usrregok')] = ' checked';
    $sel_pnc_mail_usrregsorry['0'] = '';
    $sel_pnc_mail_usrregsorry['1'] = '';
    $sel_pnc_mail_usrregsorry[pnConfigGetVar('pnc_mail_usrregsorry')] = ' checked';


    GraphicAdmin();
    OpenTable();
    print '<center><font size="3" class="pn-title">'._USERCONF.'</b></font></center><br>'
          .'<form action="admin.php" method="post">'
        .'<table border="0"><tr><td class="pn-normal">'
        ._MINAGE."</td><td class=\"pn-normal\"><input type=\"text\" name=\"xminage\" value=\"".pnConfigGetVar('minage')."\" size=\"2\" maxlength=\"2\" class=\"pn-normal\" /> "._MINAGEDESCR."\n"
        .'</td></tr><tr><td class="pn-normal">'
        ._USERPATH."</td><td><input type=\"text\" name=\"xuserimg\" value=\"".pnConfigGetVar('userimg')."\" size=\"50\" class=\"pn-normal\">"
        .'</td></tr><tr><td class="pn-normal">'
        ._USERGRAPHIC.'</td><td class="pn-normal">'
        ."<input type=\"radio\" name=\"xusergraphic\" value=\"1\" class=\"pn-normal\"".$sel_usergraphic['1'].">"._YES.' &nbsp;'
        ."<input type=\"radio\" name=\"xusergraphic\" value=\"0\" class=\"pn-normal\"".$sel_usergraphic['0'].">"._NO
        .'</td></tr><tr><td class="pn-normal">'
        ._PASSWDLEN.'</td><td>'
        .'<select name="xminpass" size"1" class="pn-normal">'
        ."<option value=\"3\"".$sel_minpass['3'].">3</option>\n"
        ."<option value=\"5\"".$sel_minpass['5'].">5</option>\n"
        ."<option value=\"8\"".$sel_minpass['8'].">8</option>\n"
        ."<option value=\"10\"".$sel_minpass['10'].">10</option>\n"
        .'</select>'
        .'</td></tr></table>'
        ."<input type=\"hidden\" name=\"module\" value=\"".$GLOBALS['module']."\">"
        ."<input type=\"hidden\" name=\"op\" value=\"setConfig\">"
	."<input type=\"hidden\" name=\"authid\" value=\"" . pnSecGenAuthKey() . "\">"
        ."<input type=\"submit\" value=\""._SUBMIT."\">"
        ."</form>";
    CloseTable();

###########################################################################
# Changements par Chestnut !
###########################################################################
    OpenTable();

	echo '<center><font size="3" class="pn-title">'._UACONFADDON.'</b></font></center><br>'
		.'<form action="admin.php" method="post">';

    echo '<center><font size="3" class="pn-title">'._UAMODREGADDON.'</b></font></center><br>';
    echo '<table width=640 border="0" cellspacing="4">';
    echo '<tr><td class="pn-normal" width=60%>'
		.''._UAUSRMODREG.' :</td><td class="pn-normal">'
        ."<input type=\"radio\" name=\"ypncusrmodreg\" value=\"1\" class=\"pn-normal\"$sel_pncusrmodreg[1]>"._YES.' &nbsp;'
        ."<input type=\"radio\" name=\"ypncusrmodreg\" value=\"0\" class=\"pn-normal\"$sel_pncusrmodreg[0]>"._NO
        .'</td></tr>';
    echo "</table><br>";
	echo '<hr>';
    echo "<table width=640 border=\"0\" cellspacing=\"4\">";
    
    list($dbconn) = pnDBGetConn();
    $pntable = pnDBGetTables();
    $column = &$pntable['groups_column'];
    $result = $dbconn->Execute("SELECT 		$column[name]
    	                        FROM 		$pntable[groups]
                                ORDER BY 	$column[name]");
    $oldgroup = pnConfigGetVar('defaultgroup');
    echo '<tr><td class="pn-normal" width=60%>'._DEFAULTGROUP.' : </td><td class="pn-normal"><select name="ydefaultgroup">';

    while(list($gname) = $result->fields) {
    	$result->MoveNext();
        if ($gname==$oldgroup) {
    	    echo '<option value="'.pnVarPrepForDisplay($gname).'" selected>'.pnVarPrepForDisplay($gname).'</option>';
        } else {
            echo '<option value="'.pnVarPrepForDisplay($gname).'">'.pnVarPrepForDisplay($gname).'</option>';
        }
    }
    echo '</select> -- <a href=admin.php?module=NS-Groups&op=main>Groupe</a></td></tr>';
    echo '<tr><td class="pn-normal">'
        .''._THEMECHANGE.' : </td><td class="pn-normal">'
        ."<input type=\"radio\" name=\"ytheme_change\" value=\"0\" class=\"pn-normal\"$sel_theme_change[0]>"._YES.' &nbsp;'
        ."<input type=\"radio\" name=\"ytheme_change\" value=\"1\" class=\"pn-normal\"$sel_theme_change[1]>"._NO
        .'</td></tr>';
    echo '</tr><tr><td class="pn-normal">'
        .''._UAALLOWUPASS.' :</td><td class="pn-normal">'
        ."<input type=\"radio\" name=\"yallowuserpass\" value=\"1\" class=\"pn-normal\"$sel_allowuserpass[1]>"._YES.' &nbsp;'
        ."<input type=\"radio\" name=\"yallowuserpass\" value=\"0\" class=\"pn-normal\"$sel_allowuserpass[0]>"._NO
        .'</td></tr>';
    echo '</tr><tr><td class="pn-normal">'
        .''._UAALLOWUSERDEL.' :</td><td class="pn-normal">'
        ."<input type=\"radio\" name=\"yallowuserdelete\" value=\"1\" class=\"pn-normal\"$sel_allowuserdelete[1]>"._YES.' &nbsp;'
        ."<input type=\"radio\" name=\"yallowuserdelete\" value=\"0\" class=\"pn-normal\"$sel_allowuserdelete[0]>"._NO
        .'</td></tr>';
    echo '</tr><tr><td class="pn-normal">'
        .''._UABLKUSRREG.' :</td><td class="pn-normal">'
        ."<input type=\"radio\" name=\"yblkusrreg\" value=\"1\" class=\"pn-normal\"$sel_blkusrreg[1]>"._YES.' &nbsp;'
        ."<input type=\"radio\" name=\"yblkusrreg\" value=\"0\" class=\"pn-normal\"$sel_blkusrreg[0]>"._NO
        .'</td></tr>';
    echo '</tr><tr><td class="pn-normal">'
        .''._UAADVREG.' :</td><td class="pn-normal">'
        ."<input type=\"radio\" name=\"ypncuaadvreg\" value=\"1\" class=\"pn-normal\"$sel_pncuaadvreg[1]>"._YES.' &nbsp;'
        ."<input type=\"radio\" name=\"ypncuaadvreg\" value=\"0\" class=\"pn-normal\"$sel_pncuaadvreg[0]>"._NO
        .'</td></tr>';
    echo "</table><br>"
        ."<input type=\"submit\" value=\""._SAVECHANGES."\" class=\"pn-normal\" style=\"text-align:center\">";
    CloseTable();                
//MAIL
	OpenTable();
	echo '<center><font size="3" class="pn-title">Configuration MAIL ADD-On</b></font></center><br>'
		.'<form action="admin.php" method="post">';

    echo "<table width=640 border=\"0\" cellspacing=\"4\">";
    echo '<tr><td class="pn-normal" width=60%>'
        .''._UASENDADDMAIL.' :</td><td class="pn-normal">'
        ."<input type=\"radio\" name=\"ysendaddmail\" value=\"1\" class=\"pn-normal\"$sel_sendaddmail[1]>"._YES.' &nbsp;'
        ."<input type=\"radio\" name=\"ysendaddmail\" value=\"0\" class=\"pn-normal\"$sel_sendaddmail[0]>"._NO
        .'</td></tr>';
    echo '</tr><tr><td class="pn-normal">'
        .''._UASENDUPASS.' :</td><td class="pn-normal">'
        ."<input type=\"radio\" name=\"ysenduserpass\" value=\"1\" class=\"pn-normal\"$sel_senduserpass[1]>"._YES.' &nbsp;'
        ."<input type=\"radio\" name=\"ysenduserpass\" value=\"0\" class=\"pn-normal\"$sel_senduserpass[0]>"._NO
        .'</td></tr>';
    echo '</tr><tr><td class="pn-normal">'
        .''._UASENDDELETEMAIL.' :</td><td class="pn-normal">'
         ."<input type=\"radio\" name=\"ysenddeletemail\" value=\"1\" class=\"pn-normal\"$sel_senddeletemail[1]>"._YES.' &nbsp;'
        ."<input type=\"radio\" name=\"ysenddeletemail\" value=\"0\" class=\"pn-normal\"$sel_senddeletemail[0]>"._NO
        .'</td></tr>';
	echo "</table><br>";
   
	echo '<hr>';
// Moderation
	echo '<center><font size="3" class="pn-title">"._UAMODERATIONMODE."</b></font></center><br>';
    echo "<table width=640 border=\"0\" cellspacing=\"4\">";
    echo '<tr><td class="pn-normal" width=60%>'
        .''._UAUSRMAILNEWMODREQ.'</td><td class="pn-normal">'
        ."<input type=\"radio\" name=\"ypnc_mail_modusrwning\" value=\"1\" class=\"pn-normal\"$sel_pnc_mail_modusrwning[1]>"._YES.' &nbsp;'
        ."<input type=\"radio\" name=\"ypnc_mail_modusrwning\" value=\"0\" class=\"pn-normal\"$sel_pnc_mail_modusrwning[0]>"._NO
        .'</td></tr>';
    echo '</tr><tr><td class="pn-normal">'
        .''._UAADMMAILNEWMODREQ.'</td><td class="pn-normal">'
        ."<input type=\"radio\" name=\"ypnc_mail_adminwning\" value=\"1\" class=\"pn-normal\"$sel_pnc_mail_adminwning[1]>"._YES.' &nbsp;'
        ."<input type=\"radio\" name=\"ypnc_mail_adminwning\" value=\"0\" class=\"pn-normal\"$sel_pnc_mail_adminwning[0]>"._NO
        .'</td></tr>';
    echo '</tr><tr><td class="pn-normal">'
        .''._UAUSRMAILREQUESTOK.'</td><td class="pn-normal">'
        ."<input type=\"radio\" name=\"ypnc_mail_usrregok\" value=\"1\" class=\"pn-normal\"$sel_pnc_mail_usrregok[1]>"._YES.' &nbsp;'
        ."<input type=\"radio\" name=\"ypnc_mail_usrregok\" value=\"0\" class=\"pn-normal\"$sel_pnc_mail_usrregok[0]>"._NO
        .'</td></tr>';
    echo '</tr><tr><td class="pn-normal">'
        .''._UAUSRMAILREQUESTNO.'</td><td class="pn-normal">'
        ."<input type=\"radio\" name=\"ypnc_mail_usrregsorry\" value=\"1\" class=\"pn-normal\"$sel_pnc_mail_usrregsorry[1]>"._YES.' &nbsp;'
        ."<input type=\"radio\" name=\"ypnc_mail_usrregsorry\" value=\"0\" class=\"pn-normal\"$sel_pnc_mail_usrregsorry[0]>"._NO
        .'</td></tr>';
	echo "</table><br>";
	
	
	
    echo "<input type=\"hidden\" name=\"module\" value=\"".$GLOBALS['module']."\">"
        ."<input type=\"hidden\" name=\"op\" value=\"setConfig_AddOn\">"
        ."<input type=\"hidden\" name=\"authid\" value=\"" . pnSecGenAuthKey() . "\">"
        ."<input type=\"submit\" value=\""._SAVECHANGES."\" class=\"pn-normal\" style=\"text-align:center\">"
        ."</form>";
	
	CloseTable();
	
    OpenTable();
    echo "<center><font size=\"3\" class=\"pn-title\">"._UASTRCENSADDON."</b></font><br>"
        ."<form action=\"admin.php\" method=\"post\">"
        ."<table border=\"0\" width=\"100%\"><tr><td class=\"pn-normal\" align=\"center\">"
        .""._UALSTSTRCENS."</td></tr></table>";
    echo "<table border=\"2\" width=\"50%\">";
    echo "<tr><th>"._UASTRCENS."</th>"
        ."<th>"._UASTRCENSDEL."</th>"
        ."</tr>";

    $rsvstr = pnConfigGetVar('reservedstring');
	sort($rsvstr);
    foreach($rsvstr as $element) {
        echo '<tr>';
        echo '<td align="center"><input type="text" size="50" name="z' . pnVarPrepForDisplay($element) .'" value=' . pnVarPrepForDisplay($element) . '></td>';
        echo '<td align="center"><input type="checkbox" name="strallowdel' . pnVarPrepForDisplay($element) . 'tag"></td>';
        echo '</tr>';
    }
    echo "<tr><td colspan=\"2\">"._UANEWSTRCENS." : "
        ."<input type=\"text\" size=\"50\" name=\"newstr\" value=\"\" size=\"25\">"
        ."</td></tr>";
    echo "</table><br>";
    echo "<input type=\"hidden\" name=\"module\" value=\"".$GLOBALS['module']."\">"
        ."<input type=\"hidden\" name=\"op\" value=\"setCensorList_AddOn\">"
        ."<input type=\"hidden\" name=\"authid\" value=\"" . pnSecGenAuthKey() . "\">"
        ."<table border=\"0\" width=\"50%\"><tr><td align=\"center\"><input type=\"submit\" value=\""._SAVECHANGES."\" class=\"pn-normal\" style=\"text-align:center\"></form></td></tr></table></center>";
    CloseTable();

    include ("footer.php");
}

function user_admin_setCensorList_AddOn($var)
{
    if (!pnSecConfirmAuthKey()) {
        include 'header.php';
        echo _BADAUTHKEY;
        include 'footer.php';
        exit;
    }

    $newvar = array();
    while (list ($key, $val) = each ($var)) {
    	if ((substr($key, 0, 1) == 'z') && ($val!='')) {
    	    $tagval = pnVarCleanFromInput('strallowdel'.$val.'tag');
            if (!$tagval) {
                $newvar[]=$val;
            }
        } elseif (($key == 'newstr') && ($val!='')) {
            $newvar[]=$val;
        }
    }
    pnConfigSetVar('reservedstring', $newvar);
    pnRedirect('admin.php?module=NS-User&op=getConfig');
}

function user_admin_setConfig_AddOn($var)
{
    if (!pnSecConfirmAuthKey()) {
        include 'header.php';
        echo _BADAUTHKEY;
        include 'footer.php';
        exit;
    }
        
    // Escape some characters in these variables.
    // hehe, I like doing this, much cleaner :-)
    $fixvars = array();

    // todo: make FixConfigQuotes global / replace with other function
    foreach ($fixvars as $v) {
    // $var[$v] = FixConfigQuotes($var[$v]);
    }

    // Set any numerical variables that havn't been set, to 0. i.e. paranoia check :-)
    $fixvars = array();

    // all variables starting with y are the config vars.
    foreach ($fixvars as $v) {
        if (empty($var[$v])) {
            $var[$v] = 0;
        }
    }

    // all variables starting with y are the config vars.
    while (list ($key, $val) = each ($var)) {
        if (substr($key, 0, 1) == 'y') {
            pnConfigSetVar(substr($key, 1), $val);
        }
    }
    //pnRedirect('admin.php');
    pnRedirect('admin.php?module=NS-User&op=getConfig');
}
##########################################################################
# Fin des changements !
##########################################################################

function user_dynamic_data()
{
    list($dbconn) = pnDBGetConn();
    $pntable = pnDBGetTables();

   $currentlangfile = 'language/' . pnVarPrepForOS(pnUserGetLang()) . '/user.php';
   $defaultlangfile = 'language/' . pnVarPrepForOS(pnConfigGetVar('language')) . '/user.php';
   if (file_exists($currentlangfile)) {
       include $currentlangfile;
   } elseif (file_exists($defaultlangfile)) {
       include $defaultlangfile;
   }

    include ("header.php");
    GraphicAdmin();

    OpenTable();
    echo "<center><font class=\"pn-title\"><b><a href=\"admin.php?module=NS-User&op=main\">"._USERADMIN."</a></b></font></center>";
    CloseTable();

    // This section displays the dynamic fields
    // and the order in which they are displayed
	OpenTable();
	echo "<center><font size=\"3\" class=\"pn-title\">"._DYNAMICDATA."</b></font></center><br>\n"
    	."<table class=\"pn-normal\" border=\"1\" width=\"100%\">\n"
    	."<tr>\n"
    	."<th>"._FIELDACTIVE."</th>\n"
    	."<th colspan=\"2\">"._FIELDLABEL."</th>\n"
    	."<th>"._FIELDWEIGHT."</th>\n"
    	."<th>"._FIELDTYPE."</th>\n"
    	."<th>"._FIELDLENGTH."</th>\n"
    	."<th>"._DELETE."</th>\n"
    	."<th>"._FIELDVALIDATION."</th>\n"
    	."</tr>\n";

    $column = &$pntable['user_property_column'];
    $result = $dbconn->Execute("SELECT $column[prop_id], $column[prop_label],$column[prop_dtype],
                              $column[prop_length], $column[prop_weight], $column[prop_validation]
                              FROM $pntable[user_property] ORDER BY $column[prop_weight]");
    if($dbconn->ErrorNo()<>0) {
       echo $dbconn->ErrorNo(). "List User Properties: ".$dbconn->ErrorMsg(). "<br>";
       error_log ($dbconn->ErrorNo(). "List User Properties: ".$dbconn->ErrorMsg(). "<br>");
       return;
    }
    $active_count = 0;
    $true_count = 0;
    $total_count = $result->PO_RecordCount();
    $prop_weight = 0;
    while(list($prop_id,$prop_label,$prop_dtype,$prop_length,$prop_weight,$prop_validation) = $result->fields) {
        $result->MoveNext();

        $true_count++;
        if ($prop_weight<>0) {
            $active_count++;
            $next_prop_weight = $active_count + 1;
        }

		$prop_validation = unserialize($prop_validation);
		
        $eval_cmd = "\$prop_label_text=$prop_label;";
        @eval($eval_cmd);

        // display the proper icom and link to enable or disable the field
        switch (TRUE) {
            // Mandatory Images can't be disabled
            case ($prop_dtype == _UDCONST_MANDATORY):
                $img_cmd = '<img src="images/global/green_dot.gif" border=0 ALT="'._REQUIREDSTAR.'">';
                break;
            case ($prop_weight <> 0):
                $img_cmd = "<a href=admin.php?module=".$GLOBALS['module']."&amp;op=deactivate_property&amp;property=$prop_id&amp;weight=$prop_weight>"
                .'<img src="images/global/green_dot.gif" border=0 ALT="'._FIELD_DEACTIVATE.'">'
                .'</a>';
                break;
            default:
                $img_cmd = "<a href=admin.php?module=".$GLOBALS['module']."&amp;op=activate_property&amp;property=$prop_id&amp;weight=$prop_weight>"
                .'<img src="images/global/red_dot.gif" border=0 ALT="'._FIELD_ACTIVATE.'">'
                .'</a>';
        }

        switch ($prop_dtype) {
            case _UDCONST_MANDATORY:
                $data_type_text = _UDT_MANDATORY;
                $data_length_text = _FIELD_NA;
				$prop_required_text = _FIELD_NA;
                break;
            case _UDCONST_CORE:
                $data_type_text = _UDT_CORE;
                $data_length_text = _FIELD_NA;
                if ($prop_weight==0) {
                	$prop_required_text = _FIELD_NA;
                } elseif ($prop_validation['REQUIRED'] == 1) {
                	$prop_required_text = '<b>'._REQUIREDSTAR.'</b>';
                } else {
                	$prop_required_text = _UANO;
                }
                break;
            case _UDCONST_STRING:
                $data_type_text = _UDT_STRING;
                $data_length_text = $prop_length;
                if ($prop_weight==0) {
                    $prop_required_text = _FIELD_NA;
                } elseif ($prop_validation['REQUIRED'] == 1) {
                    $prop_required_text = '<b>'._REQUIREDSTAR.'</b>';
                } else {
                    $prop_required_text = _UANO;
                }
                break;
            case _UDCONST_TEXT:
                $data_type_text = _UDT_TEXT;
                $data_length_text = _FIELD_NA;
                if ($prop_weight==0) {
                    $prop_required_text = _FIELD_NA;
                } elseif ($prop_validation['REQUIRED'] == 1) {
                    $prop_required_text = '<b>'._REQUIREDSTAR.'</b>';
                } else {
                    $prop_required_text = _UANO;
                }
				break;
            case _UDCONST_FLOAT:
                $data_type_text = _UDT_FLOAT;
                $data_length_text = _FIELD_NA;
                if ($prop_weight==0) {
                    $prop_required_text = _FIELD_NA;
                } elseif ($prop_validation['REQUIRED'] == 1) {
                    $prop_required_text = '<b>'._REQUIREDSTAR.'</b>';
                } else {
                    $prop_required_text = _UANO;
                }
				break;
            case _UDCONST_INTEGER:
                $data_type_text = _UDT_INTEGER;
                $data_length_text = _FIELD_NA;
                if ($prop_weight==0) {
                    $prop_required_text = _FIELD_NA;
                } elseif ($prop_validation['REQUIRED'] == 1) {
                    $prop_required_text = '<b>'._REQUIREDSTAR.'</b>';
                } else {
                    $prop_required_text = _UANO;
                }
				break;
            default:
                $data_length_text = "";
                $data_type_text = "";
                $prop_required_text = "";
        }

        switch (TRUE) {
            case ($active_count == 0):
                $arrows = "&nbsp";
                break;
            case ($active_count == 1):
                $arrows = "<a href=admin.php?module=".$GLOBALS['module']."&amp;op=increase_weight&amp;property=$prop_id&amp;weight=$prop_weight>"
                .'<img src=images/global/down.gif border=0>'
                .'</a>';
                break;
            case ($true_count == $total_count):
                $arrows = "<a href=admin.php?module=".$GLOBALS['module']."&amp;op=decrease_weight&amp;property=$prop_id&amp;weight=$prop_weight>"
                .'<img src=images/global/up.gif border=0>'
                .'</a>';
                break;
            default:
                $arrows = '<img src=images/global/up.gif>&nbsp;<img src=images/global/down.gif>';
                $arrows = "<a href=admin.php?module=".$GLOBALS['module']."&amp;op=decrease_weight&amp;property=$prop_id&amp;weight=$prop_weight>"
                .'<img src=images/global/up.gif border=0>'
                .'</a>&nbsp;'
                ."<a href=admin.php?module=".$GLOBALS['module']."&amp;op=increase_weight&amp;property=$prop_id&amp;weight=$prop_weight>"
                .'<img src=images/global/down.gif border=0>'
                .'</a>';

        }

        if (($prop_dtype == _UDCONST_MANDATORY) || ($prop_dtype == _UDCONST_CORE)) {
            $del_text = _FIELD_NA;
        } else {
            $del_text = "<a href=admin.php?module=".$GLOBALS['module']."&amp;op=delete_property&amp;property=$prop_id>"
            ._DELETE
            .'</a>';
        }
        if ($prop_required_text != _FIELD_NA) {
	        $prop_required_text = "<a href=admin.php?module=".$GLOBALS['module']."&amp;op=required_change&amp;prop_id=".pnVarPrepForDisplay($prop_id).">".$prop_required_text."</a>";
			$prop_required_text .= " - ";
			$prop_required_text .= "<a href=admin.php?module=".$GLOBALS['module']."&amp;op=editdynafield&amp;prop_id=".$prop_id.">"._UAEDITDYNAFIELD."</a>\n";
        }
//        .'<img src=\'images/global/green_dot.gif\'>'
        print '<tr><td width=\'5%\' align=\'center\'>'
        ."$img_cmd"
        .'</td>'
        .'<td width=\'12%\'>'.$prop_label.'</td>'
        .'<td width=\'12%\'>'.$prop_label_text.'</td>'
        .'<td width=\'10%\' align=\'center\'>'.$arrows.'</td>'
        .'<td width=\'10%\' align=\'center\'>'.$data_type_text.'</td>'
        .'<td width=\'20%\' align=\'center\'>'.$data_length_text.'</td>'
        .'<td width=\'10%\' align=\'center\'>'.$del_text.'</td>'
//        .'<td width=\'5%\' align=\'center\'>'.$prop_validation.'</td>'
        .'<td align=\'center\'>'.$prop_required_text.'</td>'
//        .'<td width=\'15%\' align=\'center\'>'._FIELD_NA.'</td>'
        .'</tr>';
    }
    print '</table>';
	CloseTable();

    print "<br>";

	OpenTable();

	print '<center><font size="3" class="pn-title">'._ADDFIELD.'</b></font></center><br>'
    .'<form action="admin.php" method="post">'
    .'<table class=\'pn-normal\'>'
    .'<tr>'
    .'<th align=\'left\'>'._FIELDLABEL.':</th>'
    .'<td>'
    .'<input type="text" name="label" value="" size="20" maxlength="20" class="pn-normal" />'
    .'&nbsp;'._ADDINSTRUCTIONS
    .'</td>'
    .'</tr>'
    .'<tr>'
    .'<th align=\'left\'>'._FIELDTYPE.':</th>'
    .'<td>'
    .'<select name="dtype" class="pn-normal">'
    .'<option value="'._UDCONST_STRING.'">'._UDT_STRING.'</option>' . "\n"
    .'<option value="'._UDCONST_TEXT.'">'._UDT_TEXT.'</option>' . "\n"
    .'<option value="'._UDCONST_FLOAT.'">'._UDT_FLOAT.'</option>' . "\n"
    .'<option value="'._UDCONST_INTEGER.'">'._UDT_INTEGER.'</option>' . "\n"
    .'</select>'
    .'</td>'
    .'</tr>'
    .'<tr>'
    .'<th align=\'left\'>'._FIELDLENGTH.':</th>'
    .'<td>'
    .'<input type="text" name="prop_len" value="" size="3" maxlength="3" class="pn-normal" />'
    .'&nbsp;'._STRING_INSTRUCTIONS
    .'</td>'
    .'</tr>'
    .'<tr><td></td><td>'
    ."<input type=\"hidden\" name=\"module\" value=\"".$GLOBALS['module']."\">"
    ."<input type=\"hidden\" name=\"op\" value=\"addDynamic\">"
    ."<input type=\"submit\" value=\""._SUBMIT."\">"
    .'</td></tr>'
    .'</table>'
    .'<input type="hidden" name="prop_weight" value="'.$next_prop_weight.'">'
    .'<input type="hidden" name="validation" value="">'
    ."<input type=\"hidden\" name=\"authid\" value=\"" . pnSecGenAuthKey() . "\">"
    .'<input type="hidden" name="op" value="add_property">'
    .'</form>';
    CloseTable();
    include ("footer.php");
}

function add_property()
{
    if (!pnSecConfirmAuthKey()) {
        include 'header.php';
        echo _BADAUTHKEY;
        include 'footer.php';
        exit;
    }
    global $label, $dtype, $prop_weight, $validation, $prop_len;

    addVar($label, $dtype, $prop_weight, $validation, $prop_len );
    pnRedirect("admin.php?module=NS-User&op=getDynamic");
}

function delete_property_confirm($var) {
//    print_r($var);
    removeVar($var['label']);
//    pnRedirect("admin.php?module=NS-User&op=getDynamic");

}

function delete_property($var)
{
   list($dbconn) = pnDBGetConn();
   $pntable = pnDBGetTables();

   include("header.php");

   GraphicAdmin();
   OpenTable();
   echo "<center><font class=\"pn-title\"><b><a href=\"admin.php?module=NS-User&op=main\">"._USERADMIN."</a></b></font></center>";
   CloseTable();

   OpenTable();
   echo "<center><font class=\"pn-title\"><b>"._DELETEFIELD."</b></font><br><br>";

   $column = &$pntable['user_property_column'];

   $result = $dbconn->Execute("SELECT $column[prop_id], $column[prop_label], $column[prop_weight]
           FROM $pntable[user_property]
           WHERE $column[prop_id] = '$var[property]'");

   if(!$result->EOF) {
       list($pid, $plabel, $pweight) = $result->fields;
   } else {
     echo _FIELD_NOEXIST;
     CloseTable();
     include 'footer.php';
     exit;
   }
   if ($pweight != 0) {
      echo _FIELD_DEACTIVATE;
      //CloseTable();
      //include 'footer.php';
      //exit;
   }
   if (!pnSecAuthAction(0, 'Users::', '::', ACCESS_ADMIN)) {
      echo _MODIFYUSERSDELNOAUTH;
      CloseTable();
      include 'footer.php';
      exit;
   }
   echo ""._FIELD_DEL_SURE." ".pnVarPrepForDisplay($plabel)."?<br><br>"
   ."[ <a href=\"admin.php?module=".$GLOBALS['module']."&amp;op=delPropConf&amp;label=".$plabel."\">"._YES
   ."</a> | <a href=\"admin.php?module=".$GLOBALS['module']."&amp;op=getDynamic\">"._NO."</a> ]</center>";
   CloseTable();
   include("footer.php");
}

/**
 * add a user variable to the database
 * @access public
 * @author Gregor J. Rothfuss
 * @since 1.22 - 2002/02/01
 * @param name the name of the variable
 * @param type the type of the variable
 * @param weight the weight of the variable for display
 * @param validation the name of the validation function to apply
 * @param length the length of the variable for text fields
 * @returns bool
 * @return true on success, false on failure
 */
function addVar($name, $type, $weight, $validation, $length=0)
{
    list($dbconn) = pnDBGetConn();
    $pntable = pnDBGetTables();

    $propertiestable = $pntable['user_property'];
    $columns = &$pntable['user_property_column'];

    // Prevent bogus entries
    if (empty($name) || ($name == 'uid') || ($name == 'email') ||
    ($name == 'password') || ($name == 'uname')) {
        return false;
    }

    // Don't want duplicates either
    $query = "SELECT $columns[prop_label] from $propertiestable
              WHERE $columns[prop_label] = '" . pnVarPrepForStore($name) ."'";
    $result = $dbconn->Execute($query);

    if ($result->PO_RecordCount() != 0) {
        return false;
    }

    // datatype checks
    if (($type != _UDCONST_STRING) && ($type != _UDCONST_TEXT)
        && ($type != _UDCONST_FLOAT) && ($type != _UDCONST_INTEGER)) {
        return false;
    }

    // further checks
    if (($type == _UDCONST_STRING) && (!is_numeric($length) || ($length <=0))) {
        return false;
    }

    if (!is_numeric($weight)) {
        return false;
    }

    $query = "INSERT INTO $propertiestable
                  ($columns[prop_label],
                   $columns[prop_dtype],
                   $columns[prop_length],
                   $columns[prop_weight],
                   $columns[prop_validation])
                  VALUES ('".pnVarPrepForStore($name)."',
                          '".pnVarPrepForStore($type)."',
                          '".pnVarPrepForStore($length)."',
                          '".pnVarPrepForStore($weight)."',
                          '".pnVarPrepForStore($validation)."')";
    $dbconn->Execute($query);

    if($dbconn->ErrorNo() != 0) {
      return false;
    }

    return true;
}

/**
 * remove a user variable from the database
 * @access public
 * @author Gregor J. Rothfuss
 * @since 1.22 - 2002/02/01
 * @param name the name of the variable
 * @returns bool
 * @return true on success, false on failure
 */
function removeVar($name)
{
    list($dbconn) = pnDBGetConn();
    $pntable = pnDBGetTables();

    $propertiestable = $pntable['user_property'];
    $datatable = $pntable['user_data'];
    $propcolumns = &$pntable['user_property_column'];
    $datacolumns = &$pntable['userdata_column'];

    // Prevent deletion of core fields (duh)
    if (empty($name) || ($name == 'uid') || ($name == 'email') ||
    ($name == 'password') || ($name == 'uname')) {
        return false;
    }

    // get property id for cascading delete later
    $query = "SELECT $propcolumns[prop_id] from $propertiestable
              WHERE $propcolumns[prop_label] = '" . pnVarPrepForStore($name) ."'";
    $result = $dbconn->Execute($query);

    if ($result->PO_RecordCount() == 0) {
        return false;
    }

    list ($id) = $result->fields;


    // Remove variable from properties
    $query = "DELETE from $propertiestable
              WHERE $propcolumns[prop_label] = '" . pnVarPrepForStore($name) ."'";
    $dbconn->Execute($query);

    if($dbconn->ErrorNo() != 0) {
      return false;
    }

    // Remove variable from user data
    $query = "DELETE from $datatable
              WHERE $datacolumns[uda_propid] = '" . pnVarPrepForStore($id) ."'";
    $dbconn->Execute($query);

    // Temp Fix for deleting a label with no data.  Will fix after release.
    //if($dbconn->ErrorNo() != 0) {
    //  return false;
    //}

    pnRedirect("admin.php?module=NS-User&op=getDynamic");
}

function increase_weight($var)
{
    list($dbconn) = pnDBGetConn();
    $pntable = pnDBGetTables();

    if (!empty($var['property']) && !empty($var['weight'])) {
        $new_weight = $var['weight'] + 1;
        $column = &$pntable['user_property_column'];
        $result = $dbconn->Execute("UPDATE $pntable[user_property] SET $column[prop_weight]=".pnVarPrepForStore($new_weight)."
                                    WHERE $column[prop_id]='".$var['property']."' AND $column[prop_weight]='".$var['weight']."'");
        if($dbconn->ErrorNo()<>0) {
           echo $dbconn->ErrorNo(). "Increase Weight 1".$dbconn->ErrorMsg(). "<br>";
           error_log ($dbconn->ErrorNo(). "Increase Weight 1: ".$dbconn->ErrorMsg(). "<br>");
           return;
        }

        $result = $dbconn->Execute("UPDATE $pntable[user_property] SET $column[prop_weight]=".$var['weight']."
                                    WHERE $column[prop_id]<>'".$var['property']."' AND $column[prop_weight]='".pnVarPrepForStore($new_weight)."'");
        if($dbconn->ErrorNo()<>0) {
           echo $dbconn->ErrorNo(). "Increase Weight 2".$dbconn->ErrorMsg(). "<br>";
           error_log ($dbconn->ErrorNo(). "Increase Weight 2: ".$dbconn->ErrorMsg(). "<br>");
           return;
        }
    }
    pnRedirect("admin.php?module=NS-User&op=getDynamic");
}

function decrease_weight($var)
{
    list($dbconn) = pnDBGetConn();
    $pntable = pnDBGetTables();

    if (!empty($var['property']) && !empty($var['weight'])) {
        $new_weight = $var['weight'] - 1;
        $column = &$pntable['user_property_column'];
        $result = $dbconn->Execute("UPDATE $pntable[user_property] SET $column[prop_weight]=".pnVarPrepForStore($new_weight)."
                                    WHERE $column[prop_id]='".$var['property']."' AND $column[prop_weight]='".$var['weight']."'");
        if($dbconn->ErrorNo()<>0) {
           echo $dbconn->ErrorNo(). "Decrease Weight 1".$dbconn->ErrorMsg(). "<br>";
           error_log ($dbconn->ErrorNo(). "Decrease Weight 1: ".$dbconn->ErrorMsg(). "<br>");
           return;
        }

        $result = $dbconn->Execute("UPDATE $pntable[user_property] SET $column[prop_weight]=".$var['weight']."
                                    WHERE $column[prop_id]<>'".$var['property']."' AND $column[prop_weight]='".pnVarPrepForStore($new_weight)."'");
        if($dbconn->ErrorNo()<>0) {
           echo $dbconn->ErrorNo(). "Decrease Weight 2".$dbconn->ErrorMsg(). "<br>";
           error_log ($dbconn->ErrorNo(). "Decrease Weight 2: ".$dbconn->ErrorMsg(). "<br>");
           return;
        }
    }
    pnRedirect("admin.php?module=NS-User&op=getDynamic");
}

function activate_property ($var)
{
    list($dbconn) = pnDBGetConn();
    $pntable = pnDBGetTables();

    if (!empty($var['property'])) {
        $max_weight = 0;
        $column = &$pntable['user_property_column'];
        $result = $dbconn->Execute("SELECT MAX($column[prop_weight]) max_weight FROM $pntable[user_property]");

        if(!$result->EOF) {
            list($max_weight) = $result->fields;
        }
        $max_weight++;
        $result = $dbconn->Execute("UPDATE $pntable[user_property] SET $column[prop_weight]=".pnVarPrepForStore($max_weight)."
                                    WHERE $column[prop_id]='".$var['property']."'");
        if($dbconn->ErrorNo()<>0) {
           echo $dbconn->ErrorNo(). "Activate User Property 1".$dbconn->ErrorMsg(). "<br>";
           error_log ($dbconn->ErrorNo(). "Activate User Property 1: ".$dbconn->ErrorMsg(). "<br>");
           return;
        }
    }
    pnRedirect("admin.php?module=NS-User&op=getDynamic");
}

// deactive a user property
function deactivate_property($var)
{
    list($dbconn) = pnDBGetConn();
    $pntable = pnDBGetTables();

    if (!empty($var['property'])) {

        $column = &$pntable['user_property_column'];

        $result = $dbconn->Execute("UPDATE $pntable[user_property] SET $column[prop_weight]=0
                                    WHERE $column[prop_id]='".$var['property']."'");
        if($dbconn->ErrorNo()<>0) {
           echo $dbconn->ErrorNo(). "Deactivate User Property 1".$dbconn->ErrorMsg(). "<br>";
           error_log ($dbconn->ErrorNo(). "Deactivate User Property 1: ".$dbconn->ErrorMsg(). "<br>");
           return;
        }
        $result = $dbconn->Execute("UPDATE $pntable[user_property] SET $column[prop_weight]=$column[prop_weight]-1
                                    WHERE $column[prop_weight]>'".$var['weight']."'");

        if($dbconn->ErrorNo()<>0) {
           echo $dbconn->ErrorNo(). "Deactivate User Property 2: ".$dbconn->ErrorMsg(). "<br>";
           error_log ($dbconn->ErrorNo(). "Deactivate User Property 2: ".$dbconn->ErrorMsg(). "<br>");
           return;
        }
    }
    pnRedirect("admin.php?module=NS-User&op=getDynamic");
}

function userCheck($var)
{
   
    list($dbconn) = pnDBGetConn();
    $pntable = pnDBGetTables();

    $uname = $var['add_uname'];
    $email = $var['add_email'];

    $res = pnVarValidate($email, 'email');
    if($res == false) {
        $stop = "<center><font class=\"pn-title\">"._ERRORINVEMAIL."</center></font><br>";
    }
    
    // Here we test the uname. Any value is possible but space.
    // On special character sets you might configure the server.
    // (was bug #455288)
    if ((!$uname) || !(ereg("^[[:print:]]+",$uname) && !ereg("[[:space:]]",$uname))) {
    /*if ((!$uname) || ($uname=="") || (ereg("[^a-zA-Z0-9_-]",$uname))) {*/
        $stop = "<center><font class=\"pn-title\">"._ERRORINVNICK."</center></font><br>";
    }
    if (strlen($uname) > 25) {
        $stop = "<center><font class=\"pn-title\">"._NICK2LONG."</center></font>";
    }
    if (preg_match('/((root)|(adm)|(linux)|(webmaster)|(admin)|(god)|(administrator)|(administrador)|(nobody)|(anonymous)|(anonimo)|
(an��imo)|(operator))/iAD',$uname)) {
        $stop = "<center><font class=\"pn-title\">"._NAMERESERVED."</center></font>";
    }
	/*Added by Chestnut ! 17/02/2003 - Took from [class007]*/
	$vtest = pnConfigGetVar('reservedstring');
	if (!empty($vtest) && is_array($vtest)) {
        $count = count($vtest);
        $pregcondition = "/((";
        for ($i = 0;$i < $count;$i++) {
            if ($i != $count-1) {
                $pregcondition .= $vtest[$i] . ")|(";
            } else {
                $pregcondition .= $vtest[$i] . "))/iAD";
            } 
        } 
        if (preg_match($pregcondition, $uname)) {
            $stop = "<center><font class=\"pn-title\">" . _NAMERESERVED . "</center></font>";
        } 
	}
    if (strrpos($uname,' ') > 0) {
        $stop = "<center><font class=\"pn-title\">"._NICKNOSPACES."</center></font>";
    }
    $column = &$pntable['users_column'];
    $existinguser = $dbconn->Execute("SELECT $column[uname] FROM $pntable[users] WHERE $column[uname]='".pnVarPrepForStore($uname)."'");
    if (!$existinguser->EOF) {
        $stop = "<center><font class=\"pn-title\">"._NICKTAKEN."</center></font><br>";
    }
    $existinguser->Close();
    $existinguser = $dbconn->Execute("SELECT $column[email] FROM $pntable[users] WHERE $column[email]='".pnVarPrepForStore($email)."'");
    if (!$existinguser->EOF) {
        $stop = "<center><font class=\"pn-title\">"._EMAILREGISTERED."</center></font><br>";
    }

	/*Added by Chestnut 19/10/2002 pncUserHack v1.5 pn0.721*/
/*	if ($var['moderateaction']!="1") {
		$column = &$pntable['users_modrequest_column'];
	   	$existinguser = $dbconn->Execute("	SELECT	$column[uname]
											FROM	$pntable[users_modrequest] WHERE $column[uname]='".pnVarPrepForStore($uname)."'
											AND		$column[uadd]=1");
	    if (!$existinguser->EOF) {
			$stop = "<center><font class=\"pn-title\">Utilisateur d�j� en Attente !</center></font><br>";
			//$existinguser->Close();
	    }
	    $existinguser = $dbconn->Execute("	SELECT	$column[email]
											FROM	$pntable[users_modrequest]
											WHERE	$column[email]='".pnVarPrepForStore($email)."'
											AND		$column[uadd]=1");
	    if (!$existinguser->EOF) {
	        $stop = "<center><font class=\"pn-title\">Utilisateur d�j� en Attente !</center></font><br>";
			//$existinguser->Close();
	    }
	}
*/
	if (!empty($var['dynafield']) && is_array($var['dynafield'])) {
		$fieldrequired = getfieldrequired();
		if (is_array($fieldrequired) && !empty($fieldrequired)) {
			while(list($key, $val) = each($fieldrequired)) {
				$field = $val['FIELD'];
				$newvar = $var['dynafield'];
				while(list($nkey, $nvar) = each($newvar)) {
					if ($field == $key && $nvar."" == "") {
						$stop = "<center><font class=\"pn-title\">MISSING FIELDS ".$field." - To add to lang file</font></center><br>\n";
					}
				}
			}
		}
	}
    //$existinguser->Close();

    return($stop);

}

function user_admin_setConfig($var)
{
    if (!pnSecConfirmAuthKey()) {
        include 'header.php';
        echo _BADAUTHKEY;
        include 'footer.php';
        exit;
    }
    // Escape some characters in these variables.
    // hehe, I like doing this, much cleaner :-)
    $fixvars = array();

    // todo: make FixConfigQuotes global / replace with other function
    foreach ($fixvars as $v) {
	// $var[$v] = FixConfigQuotes($var[$v]);
    }

    // Set any numerical variables that havn't been set, to 0. i.e. paranoia check :-)
    $fixvars = array();

    foreach ($fixvars as $v) {
        if (empty($var[$v])) {
            $var[$v] = 0;
        }
    }

    // all variables starting with x are the config vars.
    while (list ($key, $val) = each ($var)) {
        if (substr($key, 0, 1) == 'x') {
            pnConfigSetVar(substr($key, 1), $val);
        }
    }
    pnRedirect('admin.php');
}




##########################################################
// Added by Chestnut ! - 20030213 17h51 (pncUserHack v1.6)
// Check the required fields and return an array to the
// Add_user Form - Search Sign %%@ function get required fields @%%

function getfieldrequired()
{
	
	list($dbconn) = pnDBGetConn();
    $pntable = pnDBGetTables();
	$propcolumn = &$pntable['user_property_column'];
	$propresult = $dbconn->Execute("SELECT		$propcolumn[prop_label], $propcolumn[prop_validation]
									FROM		$pntable[user_property]
									WHERE		$propcolumn[prop_dtype]!='-1'
									AND			$propcolumn[prop_weight]!='0'
									ORDER BY	$propcolumn[prop_weight]");
	if (!$propresult->EOF) {
		$fieldrequired = array();
		while(list($prop_label, $prop_validation) = $propresult->fields) {
	       	$propresult->MoveNext();
			$prop_validation = unserialize($prop_validation);
	       	if ($prop_validation['REQUIRED'] == 1) {
				$prop_label_text = "";
		       	$eval_cmd = "\$prop_label_text = $prop_label;";
		       	@eval($eval_cmd);    
		       	if (empty($prop_label_text)) {
			   	    $prop_label_text = $prop_label;
		       	}
				$fieldrequired[$prop_label]['FIELD'] = $prop_label;
				$fieldrequired[$prop_label]['LIBEL'] = $prop_label_text;
				$fieldrequired[$prop_label]['VALIDATION'] = $prop_validation;
			}
		}
	}

	return $fieldrequired;

}

function getfieldlist()
{
	
	list($dbconn) = pnDBGetConn();
    $pntable = pnDBGetTables();
	$propcolumn = &$pntable['user_property_column'];
	$propresult = $dbconn->Execute("SELECT		$propcolumn[prop_label], $propcolumn[prop_validation]
									FROM		$pntable[user_property]
									WHERE		$propcolumn[prop_dtype]!='-1'
									AND			$propcolumn[prop_weight]!='0'
									ORDER BY	$propcolumn[prop_weight]");
	if (!$propresult->EOF) {
		$fieldrequired = array();
		while(list($prop_label, $prop_validation) = $propresult->fields) {
	       	$propresult->MoveNext();
			$prop_validation = unserialize($prop_validation);
	       	//if ($prop_validation['REQUIRED'] == 1) {
				$prop_label_text = "";
		       	$eval_cmd = "\$prop_label_text = $prop_label;";
		       	@eval($eval_cmd);    
		       	if (empty($prop_label_text)) {
			   	    $prop_label_text = $prop_label;
		       	}
				$fieldrequired[$prop_label]['FIELD'] = $prop_label;
				$fieldrequired[$prop_label]['LIBEL'] = $prop_label_text;
				$fieldrequired[$prop_label]['VALIDATION'] = $prop_validation;
			//}
		}
	}

	return $fieldrequired;

}

function getdynamiclist()
{
	
	list($dbconn) = pnDBGetConn();
    $pntable = pnDBGetTables();
	$propcolumn = &$pntable['user_property_column'];
	$propresult = $dbconn->Execute("SELECT		$propcolumn[prop_label], $propcolumn[prop_validation]
									FROM		$pntable[user_property]
									WHERE		$propcolumn[prop_dtype]='1'
									AND			$propcolumn[prop_weight]!='0'
									ORDER BY	$propcolumn[prop_weight]");
	if (!$propresult->EOF) {
		$fieldrequired = array();
		while(list($prop_label, $prop_validation) = $propresult->fields) {
	       	$propresult->MoveNext();
			$prop_validation = unserialize($prop_validation);
	       	//if ($prop_validation['REQUIRED'] == 1) {
				$prop_label_text = "";
		       	$eval_cmd = "\$prop_label_text = $prop_label;";
		       	@eval($eval_cmd);    
		       	if (empty($prop_label_text)) {
			   	    $prop_label_text = $prop_label;
		       	}
				$fieldrequired[$prop_label]['FIELD'] = $prop_label;
				$fieldrequired[$prop_label]['LIBEL'] = $prop_label_text;
				$fieldrequired[$prop_label]['VALIDATION'] = $prop_validation;
			//}
		}
	}

	return $fieldrequired;

}

function pncGetFieldType()
{

	$listtype[] = "TEXT";
	$listtype[] = "TEXTAREA";
	$listtype[] = "CHECKBOX";
	$listtype[] = "RADIO";
	$listtype[] = "SELECT";
	
	return $listtype;

}
	

##########################################################
// Added by Chestnut ! - 20030214 13h41 (pncUserHack v1.6)
// Register the User Information, Difference with the
// original is that it checks if the field is in the
// normal table or in the dynamic data table and register
// the value to the right place.

function pncAdminUserSetVar($name, $value, $uid)
{
	global $psnconfirm;
    list($dbconn) = pnDBGetConn();
    $pntable = pnDBGetTables();

    if (empty($name)) {
	//	$psnconfirm = 'Name empty';
        $fncreturn = false;
    }

	if (	$name != "_UREALNAME"
		&&	$name != "_UFAKEMAIL"
		&&	$name != "_YOURHOMEPAGE"
		&&	$name != "_TIMEZONEOFFSET"
		&&	$name != "_YOURAVATAR"
		&&	$name != "_YICQ"
		&&	$name != "_YAIM"
		&&	$name != "_YYIM"
		&&	$name != "_YMSNM"
		&&	$name != "_YLOCATION"
		&&	$name != "_YOCCUPATION"
		&&	$name != "_YINTERESTS"
		&&	$name != "_SIGNATURE"
		&&	$name != "_EXTRAINFO") {
	
		$isdynamic = 1;

	} else {

		$isdynamic = 0;
		$fieldname['_UREALNAME'] = "name";
		$fieldname['_UFAKEMAIL'] = "uname";
		$fieldname['_YOURHOMEPAGE'] = "url";
		$fieldname['_TIMEZONEOFFSET'] = "timezone_offset";
		$fieldname['_YOURAVATAR'] = "user_avatar";
		$fieldname['_YICQ'] = "user_icq";
		$fieldname['_YAIM'] = "user_aim";
		$fieldname['_YYIM'] = "user_yim";
		$fieldname['_YMSNM'] = "user_msnm";
		$fieldname['_YLOCATION'] = "user_from";
		$fieldname['_YOCCUPATION'] = "user_occ";
		$fieldname['_YINTERESTS'] = "user_intrest";
		$fieldname['_SIGNATURE'] = "user_sig";
		$fieldname['_EXTRAINFO'] = "bio";

	}

	if ($isdynamic == 1) {
		
		$propertiestable = $pntable['user_property'];
	    $datatable = $pntable['user_data'];
	    $propcolumns = &$pntable['user_property_column'];
	    $datacolumns = &$pntable['user_data_column'];

    // Confirm that this is a known value
	    $query = "SELECT	$propcolumns[prop_id],
	                    	$propcolumns[prop_dtype]
	              FROM		$propertiestable
	              WHERE 	$propcolumns[prop_label] = '" . pnVarPrepForStore($name) ."'";
	    $result = $dbconn->Execute($query);

	    if ($result->EOF) {
			$psnconfirm ='Confirm that this is a known value';
	        $fncreturn = false;
	    }

	    list ($id, $type) = $result->fields;
	    // check for existence of the variable in user data
	    $query = "SELECT	$datacolumns[uda_id]
	              FROM		$datatable
	              WHERE		$datacolumns[uda_propid] = '" . pnVarPrepForStore($id) ."'
	              AND		$datacolumns[uda_uid] = '" . pnVarPrepForStore($uid) ."'";
	    $result = $dbconn->Execute($query);

	    // jgm - this won't work in databases that care about typing
	    // but this should get fixed when we move to the dynamic user
	    // variables setup
	    // TODO: do some checking with $type to maybe do conditional sql

	    if ($result->EOF) {
	    // record does not exist
			if (is_array($value)) $value = serialize($value);
		    $query = "INSERT INTO $datatable
					($datacolumns[uda_propid],
					$datacolumns[uda_uid],
	                $datacolumns[uda_value])
	                VALUES ('".pnVarPrepForStore($id)."',
	                        '".pnVarPrepForStore($uid)."',
	                        '".pnVarPrepForStore($value)."')";
			$dbconn->Execute($query);

	        if($dbconn->ErrorNo() != 0) {
				$psnconfirm ='record does not exist, inscription capout';
		        $fncreturn = false;
	        }

		} else {
		    // existing record
		    $query = "UPDATE $datatable
	                  SET $datacolumns[uda_value] = '" . pnVarPrepForStore($value) . "'
	                  WHERE $datacolumns[uda_propid] = '" . pnVarPrepForStore($id) ."'
					  AND $datacolumns[uda_uid] = '" . pnVarPrepForStore($uid) ."'";
	        $dbconn->Execute($query);

	        if($dbconn->ErrorNo() != 0) {
				$psnconfirm ='existait d�j�';
		        $fncreturn = false;
	        }
	    }
	
	} else {
		// Non dynamic
		$usertable = $pntable['users'];
	    $usercolumn = $pntable['users_column'];
		
		$query = "	UPDATE	$usertable
					SET		".$usercolumn[$fieldname[$name]]." = '" . pnVarPrepForStore($value) . "'
					WHERE	$usercolumn[uid] = '" . pnVarPrepForStore($uid) ."'";
		$dbconn->Execute($query);
		
		if ($dbconn->ErrorNo() != 0) {
			$fncreturn = false;
		}
	}
	
    return $fncreturn;
}

##########################################################
// Added by Chestnut ! - 20030214 13h41 (pncUserHack v1.6)
// Change the field validation to make it required or
// not.
// To be change in the future for the advance dynamic
// creation page.

function required_propchange($prop_id) {
//If value is 1, change it to 0, else change it to 1

	
    list($dbconn) = pnDBGetConn();
    $pntable = pnDBGetTables();
    $propertiestable = $pntable['user_property'];
	$columns = &$pntable['user_property_column'];

	$sql = "SELECT	$columns[prop_validation]
			FROM	$propertiestable
			WHERE	$columns[prop_id]='".pnVarPrepForStore($prop_id)."'";
	$validresult = $dbconn->Execute($sql);

    if($dbconn->ErrorNo()<>0) {
        echo $dbconn->ErrorNo(). "Change Required Property ".$dbconn->ErrorMsg(). "<br>";
        return;
    }

	list($validdef) = $validresult->fields;

	$validdef = unserialize($validdef);
	if ($validdef['REQUIRED'] == '1') {
	    $validdef['REQUIRED'] = '0';
    } else {
	    $validdef['REQUIRED'] = '1';
    }

        
    $result = $dbconn->Execute("UPDATE $propertiestable
								SET pn_prop_validation='".pnVarPrepForStore(serialize($validdef))."'
                                WHERE $columns[prop_id]='".pnVarPrepForStore($prop_id)."'");
    if($dbconn->ErrorNo()<>0) {
        echo $dbconn->ErrorNo(). "Change Required Property ".$dbconn->ErrorMsg(). "<br>";
        error_log ($dbconn->ErrorNo(). "Change Required Property : ".$dbconn->ErrorMsg(). "<br>");
        return;
    }
    pnRedirect("admin.php?module=NS-User&op=getDynamic");

}

##########################################################
// Added by Chestnut ! - 20030214 13h41 (pncUserHack v1.6)
// Fetching the HTML to display the dynamic field.
//

function getfieldHTMLDef($dynafield, $dynavalue) {

	if (!isset($dynavalue)) {
		$dynavalue = "";
	}

	switch($dynafield['TYPE']) {
		case "TEXT":
			$varaffiche = "<table><tr><td>\n";
			$varaffiche .= "<input type=text name=\"dynafield[".$dynafield['NAME']."]\" value=\"".$dynavalue."\" size=\"40\">\n";
			$varaffiche .= "</td><td>\n";
			if ($dynafield['REQUIRED'] == 1) $varaffiche .= " ( <b>"._REQUIREDSTAR."</b> )";
			if ($dynafield['ADMINONLY'] == 1) $varaffiche .= "<br><b>"._FORYOUREYESONLY."</b>";
			if ($dynafield['NOTE']."" != "") $varaffiche .= "<br>".nl2br($dynafield['NOTE']);
			$varaffiche .= "</td></tr></table>";
			$varaffiche .= "\n";
			break;
		case "TEXTAREA":
			$varaffiche = "<table><tr><td>\n";
			$varaffiche .= "<textarea cols=50 rows=10 name=\"dynafield[".$dynafield['NAME']."]\">".$dynavalue."</textarea>\n";
			$varaffiche .= "</td><td>\n";
			if ($dynafield['REQUIRED'] == 1) $varaffiche .= " ( <b>"._REQUIREDSTAR."</b> )";
			if ($dynafield['ADMINONLY'] == 1) $varaffiche .= "<br><b>"._FORYOUREYESONLY."</b>";
			if ($dynafield['NOTE']."" != "") $varaffiche .= "<br>".nl2br($dynafield['NOTE']);
			$varaffiche .= "</td></tr></table>";
			$varaffiche .= "\n";
			break;
		case "CHECKBOX":
			$varaffiche = "<table><tr><td>\n";
			$varaffiche .= "<input type=\"CHECKBOX\" name=\"dynafield[".$dynafield['NAME']."]\">&nbsp;".$dynavalue."&nbsp;";
			$varaffiche .= "</td><td>\n";
			if ($dynafield['REQUIRED'] == 1) $varaffiche .= " ( <b>"._REQUIREDSTAR."</b> )";
			if ($dynafield['ADMINONLY'] == 1) $varaffiche .= "<br><b>"._FORYOUREYESONLY."</b>";
			if ($dynafield['NOTE']."" != "") $varaffiche .= "<br>".nl2br($dynafield['NOTE']);
			$varaffiche .= "</td></tr></table>";
			$varaffiche .= "\n";
			break;
		case "RADIO":
			$listfill = explode('@@',$dynafield['LISTFILL']);
			$count = count($listfill);
			$compteur = 1;
			$varaffiche = "";
			$varaffiche .= "<table><tr><td>\n";
			while(list($key,$val) = each($listfill)) {
				if ($dynavalue == $compteur) {
					$checked = "checked";
				} else {
					$checked = "";
				}
				if ($val != "") {
					$varaffiche .= "<input type=RADIO name=\"dynafield[".$dynafield['NAME']."]\" value=\"".$compteur."\" $checked> ".$val."<br>\n";
					$compteur++;
				}
				//$compteur++;
			}
			$varaffiche .= "</td><td>\n";
			if ($dynafield['REQUIRED'] == 1) $varaffiche .= " ( <b>"._REQUIREDSTAR."</b> )";
			if ($dynafield['ADMINONLY'] == 1) $varaffiche .= "<br><b>"._FORYOUREYESONLY."</b>";
			if ($dynafield['NOTE']."" != "") $varaffiche .= "<br>".nl2br($dynafield['NOTE']);
			$varaffiche .= "</td></tr></table>";
			$varaffiche .= "\n";
			break;
		case "SELECT":
            $listfill = explode('@@',$dynafield['LISTFILL']);
            $count = count($listfill);
            $compteur = 1;
            if ($dynafield['LISTOPTION']==1) {
                $multiple = " multiple";
                $size = "size=\"5\"";
            } else {
                $multiple = "";
                $size = "size=\"1\"";
            }

            $varaffiche = "<table><tr><td>\n";
            if ($multiple."" != "") {
                $varaffiche .= "<SELECT NAME=\"dynafield[".$dynafield['NAME']."][]\"".$multiple." ".$size.">\n";
            } else {
                $varaffiche .= "<SELECT NAME=\"dynafield[".$dynafield['NAME']."]\" ".$size.">\n";
            }
            
            if ($multiple."" == "") $varaffiche .= "<option value=\"\"".$selected."></option>\n";
            
            $getdyna = $dynavalue;
            $parselist = $listfill;
            while(list($key,$val) = each($listfill)) {
                if ($dynafield['LISTOPTION'] == 1) {
                    if ($val."" != "") {
                        $getdyna = $dynavalue;
                        $check = $key;
                        if (!empty($getdyna) && is_array($getdyna)) {
							//$getdyna = unserialize($getdyna);
                            $cherche = array_search($check, $getdyna);
                            if ($cherche !== null && $cherche !== false) {
                                $selected = " selected";
                                $varaffiche .= "<option value=\"".$compteur."\"".$selected.">".$val."</option>\n";
                            } else {
                                $selected = "";
                                $varaffiche .= "<option value=\"".$compteur."\"".$selected.">".$val."</option>\n";
                            }
                        } else {
                            $selected = "";
                            $varaffiche .= "<option value=\"".$compteur."\"".$selected.">".$val."</option>\n";
                        }
                        $compteur++;
                    }
                } else {
					if ($val."" != "") {
					    if ($dynavalue == $compteur) {
                        	$selected = " selected";
	                    } else {
	                        $selected = "";
	                    }
	                    $varaffiche .= "<option value=\"".$compteur."\"".$selected.">".$val."</option>\n";
	                    $compteur++;
					}
                }
            }
            $varaffiche .= "</select>";
            $varaffiche .= "</td><td>\n";
            if ($dynafield['REQUIRED'] == 1) $varaffiche .= " ( <b>"._REQUIREDSTAR."</b> )";
            if ($dynafield['ADMINONLY'] == 1) $varaffiche .= " <b>"._FORYOUREYESONLY."</b>";
            if ($dynafield['NOTE']."" != "") $varaffiche .= ""._UANOTE."".nl2br($dynafield['NOTE']);
            $varaffiche .= "</td></tr></table>";
            $varaffiche .= "\n";
            break;
		default:
			$varaffiche = "<table><tr><td>\n";
			$varaffiche .= "<input type=text name=\"dynafield[".$dynafield['NAME']."]\" value=\"".$dynavalue."\" size=\"40\">\n";
			$varaffiche .= "</td><td>\n";
			if ($dynafield['REQUIRED'] == 1) $varaffiche .= " ( <b>"._REQUIREDSTAR."</b> )";
			if ($dynafield['ADMINONLY'] == 1) $varaffiche .= "<br><b>"._FORYOUREYESONLY."</b>";
			if ($dynafield['NOTE']."" != "") $varaffiche .= "<br>"._UANOTE."".nl2br($dynafield['NOTE']);
			$varaffiche .= "</td></tr></table>";
			$varaffiche .= "\n";
			break;
	}

	return $varaffiche;
}

function editdynafield($prop_id)
{
	include 'header.php';
    GraphicAdmin();
    OpenTable();
    echo "<center><font class=\"pn-title\"><b><a href=\"admin.php?module=NS-User&op=main\">"._USERADMIN."</a></b></font></center>";
    CloseTable();
	
    list($dbconn) = pnDBGetConn();
    $pntable = pnDBGetTables();
	$column = &$pntable['user_property_column'];
	
	$sql = "SELECT	$column[prop_label], $column[prop_validation]
			FROM	$pntable[user_property]
			WHERE	$column[prop_id]='".pnVarPrepForStore($prop_id)."'";
	$result = $dbconn->Execute($sql);
	if($dbconn->ErrorNo()<>0) {
   	    echo $dbconn->ErrorMsg(). "<br>";
	}
	list($prop_label, $prop_validation) = $result->fields;
	
	$prop_validation = unserialize($prop_validation);
	
	OpenTable();
	echo "<center>"._UACURRENTDYNACONFIG."</center>\n<br><br>\n";

	echo "<form action=\"admin.php\" method=\"post\"><center><table>\n<tr>\n";
	$prop_label_text = "";
	$eval_cmd = "\$prop_label_text = $prop_label;";
	@eval($eval_cmd);    
	if (empty($prop_label_text)) {
		$prop_label_text = $prop_label;
	}
	echo "<td>\n<b>".$prop_label."</b>\n</td>\n<td>".$prop_label_text."</td>\n";
	
	echo "</tr>\n<tr><td colspan=2>&nbsp;</td>\n";
	
	echo "</tr>\n<tr><td>\n"._UAEDITREQUIRED."</td>\n<td>";

	echo "<select name=\"changeto_required\">";
	if ($prop_validation['REQUIRED'] == 1) {
		$selected = "selected";
	} else {
		$selected = "";
	}
	echo "<option value=\"1\" $selected>"._YES."</option>\n";
	if ($prop_validation['REQUIRED'] == 0) {
		$selected = "selected";
	} else {
		$selected = "";
	}
	echo "<option value=\"0\" $selected>"._NO."</option>\n";
	echo "</select>\n";

	echo "</td></tr>\n<tr><td>\n"._UAEDITFORYOUREYESONLY."</td>\n<td>";

	echo "<select name=\"changeto_adminonly\">";
	if ($prop_validation['ADMINONLY'] == 1) {
		$selected = "selected";
	} else {
		$selected = "";
	}
	echo "<option value=\"1\" $selected>"._YES."</option>\n";
	if ($prop_validation['ADMINONLY'] == 0) {
		$selected = "selected";
	} else {
		$selected = "";
	}
	echo "<option value=\"0\" $selected>"._NO."</option>\n";
	echo "</select>\n";
	echo "</td></tr>\n<tr><td>\n";

	echo _UAEDITFIELDTYPE."\n</td>\n<td>";

	$listtype = pncGetFieldType();
	
	echo "<select name=\"changeto_type\">\n";
	foreach ($listtype as $type) {
		if ($type == $prop_validation['TYPE']) {
			$selected = "selected";
		} else {
			$selected = "";
		}
		echo "<option value\"".pnVarPrepForDisplay($type)."\" $selected>".pnVarPrepForDisplay($type)."</option>\n";
	}
	echo "</select>\n";
	
	echo "</td></tr>\n<tr><td>\n"._UAEDITMULTIPLE."</td>\n<td>";

	echo "<select name=\"changeto_multiple\">";
	if ($prop_validation['LISTOPTION'] == 1) {
		$selected = "selected";
	} else {
		$selected = "";
	}
	echo "<option value=\"1\" $selected>"._YES."</option>\n";
	if ($prop_validation['LISTOPTION'] == 0) {
		$selected = "selected";
	} else {
		$selected = "";
	}
	echo "<option value=\"0\" $selected>"._NO."</option>\n</td></tr>\n<tr><td>\n";

	echo "List Content :<br>\n"._UAEDITLISTOPTION."<b>@@</b></td>\n<td>";
	echo "<textarea cols=50 rows=5 name=\"changeto_listfill\">".pnVarPrepForDisplay($prop_validation['LISTFILL'])."</textarea>\n</td></tr>\n";
	
	echo "<tr><td>\n"._UAEDITNOTE."</td>\n<td>";
	echo "<textarea cols=50 wrap=\"virtual\" rows=5 name=\"changeto_note\">".pnVarPrepForDisplay($prop_validation['NOTE'])."</textarea>\n";	
	
	echo "</td></tr>\n<tr><td>\n"._UAEDITVALIDATION."</td>\n<td>";
	echo "<textarea cols=50 rows=2 name=\"changeto_validation\">".pnVarPrepForDisplay($prop_validation['VALIDATION'])."</textarea>\n";

	echo "</td></tr>\n";
	echo "</table></center>\n";

	echo "<input type=\"hidden\" name=\"prop_id\" value=\"".pnVarPrepForDisplay($prop_id)."\">"
    	."<input type=\"hidden\" name=\"module\" value=\"NS-User\">"
        ."<input type=\"hidden\" name=\"op\" value=\"pncEditSaveField\">"
		."<input type=\"hidden\" name=\"authid\" value=\"" . pnSecGenAuthKey() . "\">";
	
	echo "<br><br>\n"
		."<center>\n"
		."<input type=\"submit\" value=\""._UAEDITSUBMIT."\">\n"
		."</center>\n"
		."</form>\n";
	
	CloseTable();

	OpenTable();
	echo "<center>\n"._UAEDITPREVIEW."\n<br><br>\n";

	$prop_validation['NAME'] = $prop_label;
	$affiche = getfieldHTMLDef($prop_validation, $dynavalue="");

	echo "<form>\n";
	echo $affiche;
	echo "</form>\n";
	
	echo "</center>\n";
	CloseTable();
	
	echo "<center><a href=\"admin.php?module=".$GLOBALS['module']."&op=getDynamic\">"._UAEDITBACKTODYNAPAGE."</a></center>\n";
	echo "<br><br>\n";
	
	include 'footer.php';
}

function pncEditSaveField($var)
{
	list(	$prop_id,
			$changeto_required,
			$changeto_adminonly,
			$changeto_type,
			$changeto_multiple,
			$changeto_listoption,
			$changeto_listfill,
			$changeto_note,
			$changeto_validation) = pnVarCleanFromInput('prop_id',
														'changeto_required',
														'changeto_adminonly',
														'changeto_type',
														'changeto_multiple',
														'changeto_listoption',
														'changeto_listfill',
														'changeto_note',
														'changeto_validation');
	
	$newproperty['REQUIRED'] = $changeto_required;
	$newproperty['ADMINONLY'] = $changeto_adminonly;
	$newproperty['TYPE'] = $changeto_type;
	$newproperty['LISTOPTION'] = $changeto_multiple;
	$newproperty['LISTFILL'] = $changeto_listfill;
	$newproperty['NOTE'] = $changeto_note;
	$newproperty['VALIDATION'] = $changeto_validation;

    list($dbconn) = pnDBGetConn();
    $pntable = pnDBGetTables();
	$column = &$pntable['user_property_column'];
	$sql = "UPDATE	$pntable[user_property]
			SET		$column[prop_validation] = '".pnVarPrepForStore(serialize($newproperty))."'
			WHERE	$column[prop_id] = '".pnVarPrepForStore($prop_id)."'";
	$dbconn->Execute($sql);
	if($dbconn->ErrorNo()<>0) {
   	    echo $dbconn->ErrorMsg(). "<br>";
	} else {
		pnredirect('admin.php?module=NS-User&op=editdynafield&prop_id='.$prop_id);
	}

}

function CreateFieldDef() {

	include 'header.php';
    GraphicAdmin();
    OpenTable();
    echo "<center><font class=\"pn-title\"><b><a href=\"admin.php?module=NS-User&op=main\">"._USERADMIN."</a></b></font></center>";
    CloseTable();
	
    list($dbconn) = pnDBGetConn();
    $pntable = pnDBGetTables();
	$column = &$pntable['user_property_column'];
	
	$sql = "SELECT	$column[prop_label], $column[prop_dtype], $column[prop_validation]
			FROM	$pntable[user_property]";
	$result = $dbconn->Execute($sql);

	while(list($prop_label, $prop_dtype, $prop_validation) = $result->fields) {
		$result->MoveNext();
		//echo $prop_label."<br>";
		if ($prop_dtype == _UDCONST_MANDATORY) {
				$dynadefinition['REQUIRED']		= 1;
				$dynadefinition['ADMINONLY']	= 0;
				$dynadefinition['TYPE']			= "TEXT";
				$dynadefinition['LISTOPTION']	= 0;
				$dynadefinition['LISTFILL']		= "";
				$dynadefinition['NOTE']			= "";
				$dynadefinition['VALIDATION']	= "";
				/*break;*/
		} elseif ($prop_dtype == _UDCONST_CORE) {
				switch ($prop_label) {
					case "_TIMEZONEOFFSET":
						$dynadefinition['REQUIRED']		= 0;
						$dynadefinition['ADMINONLY']	= 0;
						$dynadefinition['TYPE']			= "SELECT";
						$dynadefinition['LISTOPTION']	= 0;
						$dynadefinition['LISTFILL']		= "";
						$dynadefinition['NOTE']			= "";
						$dynadefinition['VALIDATION']	= "var: timezoneoffset";
						break;
					case "_YOURAVATAR":
						$dynadefinition['REQUIRED']		= 0;
						$dynadefinition['ADMINONLY']	= 0;
						$dynadefinition['TYPE']			= "SELECT";
						$dynadefinition['LISTOPTION']	= 0;
						$dynadefinition['LISTFILL']		= "";
						$dynadefinition['NOTE']			= "";
						$dynadefinition['VALIDATION']	= "path: images/avatar";
						break;						
					case "_SIGNATURE":
						$dynadefinition['REQUIRED']		= 0;
						$dynadefinition['ADMINONLY']	= 0;
						$dynadefinition['TYPE']			= "TEXTAREA";
						$dynadefinition['LISTOPTION']	= 0;
						$dynadefinition['LISTFILL']		= "";
						$dynadefinition['NOTE']			= "";
						$dynadefinition['VALIDATION']	= "";
						break;
					case "_EXTRAINFO":
						$dynadefinition['REQUIRED']		= 0;
						$dynadefinition['ADMINONLY']	= 0;
						$dynadefinition['TYPE']			= "TEXTAREA";
						$dynadefinition['LISTOPTION']	= 0;
						$dynadefinition['LISTFILL']		= "";
						$dynadefinition['NOTE']			= "";
						$dynadefinition['VALIDATION']	= "";
						break;
					default:
						$dynadefinition['REQUIRED']		= 0;
						$dynadefinition['ADMINONLY']	= 0;
						$dynadefinition['TYPE']			= "TEXT";
						$dynadefinition['LISTOPTION']	= 0;
						$dynadefinition['LISTFILL']		= "";
						$dynadefinition['NOTE']			= "";
						$dynadefinition['VALIDATION']	= "";
						break;
				}
				
		} else {
				$dynadefinition['REQUIRED']		= 0;
				$dynadefinition['ADMINONLY']	= 0;
				$dynadefinition['TYPE']			= "TEXT";
				$dynadefinition['LISTOPTION']	= 0;
				$dynadefinition['LISTFILL']		= "";
				$dynadefinition['NOTE']			= "";
				$dynadefinition['VALIDATION']	= "";
				/*break;*/
		}
		
		//$dynadefinition = serialize($dynadefinition);

		$sql = "UPDATE	$pntable[user_property]
				SET		$column[prop_validation] = '".pnVarPrepForStore(serialize($dynadefinition))."'
				WHERE	$column[prop_label] = '".pnVarPrepForStore($prop_label)."'";
		$dbconn->Execute($sql);
    	if($dbconn->ErrorNo()<>0) {
    	    $createerror[] = "Field ".$prop_label." was not updated : ".$dbconn->ErrorMsg(). "<br>";
    	} else {
			$createsuccess[] = "Field ".$prop_label." was updated. ".$dynadefinition['TYPE']."<br>";
		}
	}
	
	
	OpenTable();
	if (is_array($createsuccess) && !empty($createsuccess)) {
		foreach($createsuccess as $element) {
			echo pnVarPrepHTMLDisplay($element);
		}
	}
	CloseTable();
	
	if (is_array($createerror) && !empty($createerror)) {
		OpenTable();
		foreach($createerror as $element) {
			echo pnVarPrepHTMLDisplay($element);
		}
		CloseTable();
	}
	
	OpenTable();
	
	$sql = "SELECT	$column[prop_label], $column[prop_validation]
			FROM	$pntable[user_property]";
	$result = $dbconn->Execute($sql);
	if($dbconn->ErrorNo()<>0) {
   	    echo $dbconn->ErrorMsg(). "<br>";
	}
	while(list($fieldname, $entry) = $result->fields) {
		$result->MoveNext();
		
		echo pnVarPrepForDisplay($fieldname)." : ";
		$entry = unserialize($entry);
		if (is_array($entry) && !empty($entry)) {
			echo "----->".$entry['TYPE']." - ".$entry['REQUIRED']."<br>";
		} else {
			echo "----->".$entry['TYPE']." - ".$entry['REQUIRED']."<br>";
		}
	}
	
	CloseTable();
	
	include 'footer.php';

}

// Main function End of file
function user_admin_main($var)
{
	switch($var['op']) {
	    case "modifyUser":
	        modifyUser($var['chng_uid']);
            break;

        case "updateUser":
            updateUser($var);
            break;

        case "delUser":
            deleteUser($var['chng_uid']);
            break;

        case "delUserConf":
            deleteUserConfirm($var['del_uid']);
            break;

        case "addUser":
            addUser($var);
            break;

        case "getConfig":
            user_admin_getConfig();
            break;

        case "setConfig":
            user_admin_setConfig($var);
            break;

        case "getDynamic":
            user_dynamic_data();
            break;

        case "add_property":
            add_property();
            break;

        case "delete_property":
            delete_property($var);
            break;

        case "delPropConf":
            delete_property_confirm($var);
            break;

        case "deactivate_property":
            deactivate_property ($var);
            break;

        case "activate_property":
            activate_property ($var);
            break;

        case "increase_weight":
            increase_weight ($var);
            break;

        case "decrease_weight":
            decrease_weight ($var);
            break;

######################################
        //pncUserHack v1.5
        case "required_change":
	        required_propchange($var['prop_id']);
	        break;

		case "editdynafield":
			editdynafield($var['prop_id']);
			break;

		case "pncEditSaveField":
			pncEditSaveField($var);
			break;
		
	    case "ListUAddRequest":
			include 'modules/NS-User/moderate.php';
		    user_admin_addRequest($var['show']);
		    break;

	    case "ModUAddUser":
			include 'modules/NS-User/moderate.php';
		    user_admin_modadduser();
		    break;

		case "delModConfRequest":
			include 'modules/NS-User/moderate.php';
			deleteModRequest($var['chng_uid']);
			break;
			
		case "delModRequestConfOK":
			include 'modules/NS-User/moderate.php';
			deleteModConfRequestOK($var['del_uid']);
			break;

        case "ListDelRequest":
			include 'modules/NS-User/moderate.php';
	        user_admin_delRequest();
	        break;

        case "IgnoreDelRequest":
			include 'modules/NS-User/moderate.php';
	        user_admin_ignoredelrequest();
	        break;

        case "delUserRequest":
			include 'modules/NS-User/moderate.php';
        	user_admin_deleteUserRequest();
        	break;

	    case "delUserConfRequest":
			include 'modules/NS-User/moderate.php';
	        deleteUserConfirmRequest();
	        break;

		// Fonction D�finition des champs
		case "CreateFieldDef":
			CreateFieldDef();
			break;
		/*End !*/  
######################################


        default:
            displayUsers();
            break;
	}
}

?>