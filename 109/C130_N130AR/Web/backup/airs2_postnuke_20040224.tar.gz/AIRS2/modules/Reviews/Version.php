<?php // $Id: Version.php,v 1.2 2002/10/21 20:33:39 larsneo Exp $ $Name:  $

$modversion['name'] = 'Reviews';
$modversion['version'] = '1.0';
$modversion['description'] = 'Reviews System Module';
$modversion['credits'] = 'docs/credits.txt';
$modversion['help'] = 'docs/install.txt';
$modversion['changelog'] = 'docs/changelog.txt';
$modversion['license'] = 'docs/license.txt';
$modversion['official'] = 1;
$modversion['author'] = 'Jeff Lambert';
$modversion['contact'] = 'http://www.qchc.com';
$modversion['admin'] = 0;
$modversion['securityschema'] = array('Reviews::' => 'Review name::Review ID');

?>