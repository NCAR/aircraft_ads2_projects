<?php
// Generated: $d$ by $id$
// ----------------------------------------------------------------------
// POST-NUKE Content Management System
// Copyright (C) 2001 by the Post-Nuke Development Team.
// http://www.postnuke.com/
// ----------------------------------------------------------------------
// Based on:
// PHP-NUKE Web Portal System - http://phpnuke.org/
// Thatware - http://thatware.org/
// ----------------------------------------------------------------------
// LICENSE
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License (GPL)
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// To read the license please visit http://www.gnu.org/copyleft/gpl.html
// ----------------------------------------------------------------------
// Original Author of file: Everyone
// Purpose of file: Translation files
// Translation team: Read credits in /docs/CREDITS.txt
// ----------------------------------------------------------------------
$minage = pnConfigGetVar('minage');
define('_2CHANGEINFO','to change your info');
define('_ALLOWEMAILVIEW','Allow other users to view my e-mail address');
define('_ANDCONNECTOR','and');
define('_ASREG1','Post comments with your username');
define('_ASREG2','Send news with your username');
define('_ASREG3','Have a personal box on the homepage');
define('_ASREG4','Select how many news items to show on the homepage');
define('_ASREG5','Customize the comments');
define('_ASREG6','Select different themes');
define('_ASREG7','and lots of other cool stuff...');
define('_ASREGUSER','As a registered user you can:');
define('_CONSENT','(By clicking on the above link you certify that you are either<br>'.$minage.' or over, or that you have parental consent to register here.)');
define('_COOKIEWARNING','NOTICE: Account preferences are cookie based.');
define('_ERRORMUSTAGREE','To use this site, you must agree to our Terms of Service and Privacy Policy! Please go back and check the box to agree.');
define('_FINISH','Finish');
define('_FOLLOWINGMEM','The following is the member information:');
define('_HERE','here');
define('_MUSTBE','You must be '.$minage.' or over, or have parental permission to register here.');
define('_OVER13','I am '.$minage.' or over or I have parental consent');
define('_PASSWILLSEND','(Password will be sent to the e-mail address you enter)');
define('_PRIVACYPOLICY','Privacy Policy');
define('_REGISTERNOW','Register now! It\'s free!');
define('_REGISTRATION','registration area.');
define('_REGISTRATIONAGREEMENT','I agree to be bound by this website\'s');
define('_REGNEWUSER','New user registration');
define('_RETURN','to return to the main page.');
define('_SORRY','Sorry.');
define('_TERMSOFUSE','Terms of Use');
define('_TOREGISTER','to register an account at');
define('_UNDER13','I am under '.$minage.' and do not have parental consent.');
define('_UNICKNAME','-Username:');
define('_UPASSWORD','-Password:');
define('_USERPASS4','Password for');
define('_WEDONTGIVE','We won\'t sell/give others your personal info.');
define('_YOUAREREGISTERED','You are now registered. You should receive your password at the e-mail account you provided.');
define('_YOURPASSIS','Your password is:');
define('_YOUUSEDEMAIL','You or someone else has used your e-mail account');


//Added by Chestnut !
define('_UAREGNOACTIVE','Account registration is not active for the moment !');
define('_UAREGBEBACK','It\'ll be back soon !');
define('_UAUPASS','Password : ');
define('_UAUPASSCONFIRM','ReType : ');
define('_UAORCENS','Or Censored !');
define('_UAPASSTOOSHORT','Password too short. Limit is set at');
define('_UAPASSTOOSHORT2','caracters !');
define('_UAPASSDIFF','Passwords are different ! Watch the syntax !');
define('_UAADMMAILNEWOBJ','subscribed to');
define('_UAADMMAILNEWSBJ','New Member on');
define('_UACYA','See You Soon !');
// pncUserHack v1.2
define('_UASUBPSNREG','Subscribe to '.pnConfigGetVar(sitename).'\'s NewsLetter');
define('_UASUBPSNOK','Succefully subscribed to '.pnConfigGetVar(sitename).'\'s NewsLetter');
define('_UASUBPSNNO','Registration to the '.pnConfigGetVar(sitename).'\'s NewsLatter failed.');
//CyberOto for the pncUserHack
define('_UAREALNAME','Real Name');
define('_UALOCATION','<br>Example: San Fransico, Ca');
define('_UAREMARK','NOTE');
define('_UAREMARKTEXT','Fields with <b>*</b> are required !');
//pncUserHack v1.5 19/10/2002
define('_UAALLREADYASK','You made a subscription request.');
define('_UAREQFIELDSEMPTY','Required Fields empty !!!');
define('_UAMAILMODREG1','Your subscription request on');
define('_UAMAILMODREG2','is saved.');
define('_UAMAILMODREGSBJ1','Subscription Request for');
define('_UAMAILADMINMODREG1','Someone wants to register on');
define('_UAMAILADMINMODREG2','Username :');
define('_UAMAILADMINMODREG3','Email :');
define('_UAMAILADMINMODSBJ','Subscription request by ');
define('_UAMODREQSAVED','Your request has been saved !<br><br>We will verify your request as soon as possible.<br><br>Goodbye !');

define('_UAMAILADMINNUSRREG0','New Subscription on');
define('_UAMAILADMINNUSRREG1','Someone registered on');
define('_UAMAILADMINNUSRREG2','Username :');
define('_UAMAILADMINNUSRREG3','Email :');

define('_FIELD_REQUIRED','*');

define('_UAAVATARLIST','Avatar List');
?>