<?php
// Generated: $d$ by $id$
// ----------------------------------------------------------------------
// POST-NUKE Content Management System
// Copyright (C) 2001 by the Post-Nuke Development Team.
// http://www.postnuke.com/
// ----------------------------------------------------------------------
// Based on:
// PHP-NUKE Web Portal System - http://phpnuke.org/
// Thatware - http://thatware.org/
// ----------------------------------------------------------------------
// LICENSE
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License (GPL)
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// To read the license please visit http://www.gnu.org/copyleft/gpl.html
// ----------------------------------------------------------------------
// Original Author of file: Everyone
// Purpose of file: Translation files
// Translation team: Read credits in /docs/CREDITS.txt
// ----------------------------------------------------------------------
define('_CONSIDERED','considered the following article interesting and wanted to send it to you.');
define('_EMAILWRONG','Friend\'s email address is invalid');
define('_FDATE','Date:');
define('_FFRIENDEMAIL','Your friend\'s e-mail:');
define('_FFRIENDNAME','Your friend\'s name:');
define('_FREFERENCE','The reference to our site has been sent to');
define('_FSITENAME','Site name:');
define('_FSITEURL','Site URL:');
define('_FTOPIC','Topic:');
define('_FYOUREMAIL','Your e-mail:');
define('_FYOURNAME','Your name:');
define('_HASSENT','Has been sent to');
define('_INTERESTING','Interesting article on');
define('_INTSENT','interesting and wanted to send it to you.');
define('_INTSITE','Interesting site:');
define('_NAMETOOLONG','Friend\'s name is too long');
define('_OURSITE','considered our site');
define('_RECOMMEND','Recommend this site to a friend');
define('_RECOMMENDUSNOAUTH','Not authorised to recommend others');
define('_SEND','Send');
define('_THANKS','Thanks!');
define('_THANKSREC','Thanks for recommending us!');
define('_TOAFRIEND','to a specified friend:');
define('_YOUCANREAD','You can read interesting articles on');
define('_YOURFRIEND','Your friend');
define('_YOUSENDSTORY','You will send the story');
?>