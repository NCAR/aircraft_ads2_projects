<?php
define('_HEADCREDITDESC','Description');
define('_HEADCREDITDISPNAME','Module name');
define('_CREDITSNOMODS','No modules available');
define('_CREDITSNOAUTH','Not authorised to access Modules module');
define('_CREDITSBACK','Back to main Credits page');
define('_CREDITSNOEXIST','That document doesn\'t exist');
define('_CREDITSFOR','for');
define('_CREDITSVERSION','version');
define('_HEADCREDITVERSION','Version');
define('_HEADCREDITAUTHOR','Author');
define('_HEADCREDITDOCS','Documentation');
define('_CREDITSCREDITS','Credits');
define('_CREDITSHELP','Help');
define('_CREDITSLICENSE','License');
define('_CREDITSCHANGELOG','Change Log');
define('_CREDITSTITLE','Credits & License Information');
define('_CREDITSPOSTNUKE','This web site is powered by <a href="http://www.postnuke.com">PostNuke</a>, an open source GPL licensed content management system.');
define('_CREDITSMODULES','Installed Modules');
define('_CREDITSREADPNCR','Read PostNuke Credits');
define('_CREDITSREADPNHP','Read PostNuke Help');
define('_CREDITSREADPNLIC','Read PostNuke License');
?>
