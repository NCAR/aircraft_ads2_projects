<?php // $Id: Version.php,v 1.1.1.1 2002/09/15 22:26:15 root Exp $ $Name:  $

$modversion['name'] = 'Search';
$modversion['version'] = '1.0';
$modversion['description'] = 'Search reviews/users/stories/faqs';
$modversion['credits'] = 'docs/credits.txt';
$modversion['help'] = 'docs/install.txt';
$modversion['changelog'] = 'docs/changelog.txt';
$modversion['license'] = 'docs/license.txt';
$modversion['official'] = 1;
$modversion['author'] = 'Patrick Kellum';
$modversion['contact'] = 'http://www.ctarl-ctarl.com';
$modversion['admin'] = 0;

?>