<?php
$modversion['name'] = 'Modules Administration';
$modversion['version'] = '2.0';
$modversion['description'] = 'Enable/disable modules, view install/docs/credits.';
$modversion['credits'] = '';
$modversion['help'] = '';
$modversion['changelog'] = '';
$modversion['license'] = '';
$modversion['official'] = 1;
$modversion['author'] = 'Jim McDonald';
$modversion['contact'] = '';
$modversion['admin'] = 1;
$modversion['securityschema'] = array('Modules::' => '::');
?>