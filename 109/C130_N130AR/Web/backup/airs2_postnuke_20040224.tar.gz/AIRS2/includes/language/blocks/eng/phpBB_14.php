<?php // File: $Id: phpBB_14.php,v 1.20 2002/04/26 07:20:06 larsneo Exp $ $Name:  $
/************************************************************************
 * phpBB_14 - The Post-Nuke Module                                      *
 * ==============================                                       *
 *                                                                      *
 * Copyright (c) 2001, 2002 by the PN_phpBB14  Module Development Team  *
 * http://postnuke.pwp.ru/                                              *
 ************************************************************************
 * Modified version of: *
 ************************************************************************
 * phpBB version 1.4                                                    *
 * begin                : Wed July 19 2000                              *
 * copyright            : (C) 2001 The phpBB Group                      *
 * email                : support@phpbb.com                             *
 ************************************************************************
 * License *
 ************************************************************************
 * This program is free software; you can redistribute it and/or modify *
 * it under the terms of the GNU General Public License as published by *
 * the Free Software Foundation; either version 2 of the License, or    *
 * (at your option) any later version.                                  *
 *                                                                      *
 * This program is distributed in the hope that it will be useful,      *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of       *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        *
 * GNU General Public License for more details.                         *
 *                                                                      *
 * You should have received a copy of the GNU General Public License    *
 * along with this program; if not, write to the Free Software          *
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 *
 * USA                                                                  *
 ************************************************************************/ 

define('_RESULTS',"Results");
define('_PHPBB_SEARCHINCLUDE_AUTHOR',"Author");
define('_PHPBB_SEARCHINCLUDE_BYDATE',"by date");
define('_PHPBB_SEARCHINCLUDE_BYTITLE',"by title");
define('_PHPBB_SEARCHINCLUDE_BYFORUM',"by forum");
define('_PHPBB_SEARCHINCLUDE_DATE',"Date");
define('_PHPBB_SEARCHINCLUDE_FORUM',"Category and forum");
define('_PHPBB_SEARCHINCLUDE_NEWWIN',"Show in new window");
define('_PHPBB_SEARCHINCLUDE_NOENTRIES',"No messages in forums found");
define('_PHPBB_SEARCHINCLUDE_ORDER',"Order");
define('_PHPBB_SEARCHINCLUDE_REPLIES',"Replies");
define('_PHPBB_SEARCHINCLUDE_RESULTS',"Forums");
define('_PHPBB_SEARCHINCLUDE_TITLE',"Search forums");
define('_PHPBB_SEARCHINCLUDE_VIEWS',"Views");

?>