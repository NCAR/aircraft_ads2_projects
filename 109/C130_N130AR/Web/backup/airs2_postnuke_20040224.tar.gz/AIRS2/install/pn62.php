<?php
// File: $Id: pn62.php,v 1.1.1.1 2002/09/15 22:26:15 root Exp $ $Name:  $
/* Cat Title increased */
mysql_query("ALTER TABLE ".$prefix."_stories_cat MODIFY title varchar(40) NOT NULL DEFAULT ''");

/* Referers Addition */
mysql_query("ALTER TABLE ".$prefix."_referer ADD COLUMN frequency INT(15) AFTER url");

/* Update for the Authors Permissions */
mysql_query("ALTER TABLE ".$prefix."_authors ADD COLUMN radminblocks tinyint(2) DEFAULT '0' NOT NULL AFTER radminreviews");

/* Update for the AutoLink Mod */
mysql_query("CREATE TABLE ".$prefix."_autolinks (
lid int(11) NOT NULL auto_increment,
keyword varchar(100) NOT NULL,
title varchar(100) NOT NULL,
url varchar(200) NOT NULL,
comment varchar(200),
PRIMARY KEY (lid),
UNIQUE keyword (keyword)
)");

/* Update stories for the comments selection */
mysql_query("ALTER TABLE ".$prefix."_stories ADD withcomm int(1) DEFAULT '0' NOT NULL AFTER alanguage");
mysql_query("ALTER TABLE ".$prefix."_autonews ADD withcomm int(1) DEFAULT '0' NOT NULL AFTER alanguage");

mysql_query("ALTER TABLE ".$prefix."_queue ADD arcd INT (1) DEFAULT '0' NOT NULL AFTER uid");
mysql_query("ALTER TABLE ".$prefix."_users ADD timezone_offset float(3,1) DEFAULT '0.0' NOT NULL");

?>