<?php
// File: $Id: phpnuke54.php,v 1.3 2002/11/01 12:37:01 magicx Exp $ $Name:  $
####################### BEGIN THE UPDATE #######################################

// Users Table Alteration to add forums support

mysql_query("ALTER TABLE $user_prefix"._users." DROP user_posts");
mysql_query("ALTER TABLE $user_prefix"._users." DROP user_attachsig");
mysql_query("ALTER TABLE $user_prefix"._users." DROP user_rank");
mysql_query("ALTER TABLE $user_prefix"._users." DROP user_level");

// Author's Table Alteration

mysql_query("ALTER TABLE $prefix"._authors." DROP radminforum");
mysql_query("ALTER TABLE $prefix"._authors." DROP radmincontent");
mysql_query("ALTER TABLE $prefix"._authors." DROP radminency");

/* Update stories for the comments selection */
mysql_query("ALTER TABLE ".$prefix."_stories ADD withcomm int(1) DEFAULT '0' NOT NULL AFTER alanguage");
mysql_query("ALTER TABLE ".$prefix."_stories ADD pn_format_type int(1) UNSIGNED DEFAULT '0' NOT NULL AFTER withcomm");
mysql_query("ALTER TABLE ".$prefix."_autonews ADD withcomm int(1) DEFAULT '0' NOT NULL AFTER alanguage");

mysql_query("ALTER TABLE ".$prefix."_queue ADD arcd INT (1) DEFAULT '0' NOT NULL AFTER uid");
mysql_query("ALTER TABLE ".$prefix."_users ADD timezone_offset float(3,1) DEFAULT '0.0' NOT NULL");

// Links Table Alteration
mysql_query("ALTER TABLE $prefix"._links_categories." DROP parentid");

echo "phpBB Tables intact.";


?>