<?php
/************************************************************************/
/* NukeCalendar v1.1.0                                                  */
/* ===================                                                  */
/*  PHP-Nuke Calendar Module for PHP-Nuke v5.5  (http://phpnuke.org)    */
/*  Copyright (c) 2002 by Andi (info@shiba-design.de)                   */
/*  http://www.shiba-design.de                                          */
/* -------------------------------------------------------------------- */
/* Nuke Calendar is based on EventCalendar 2.0                          */
/*  Copyright (c) 2001 Originally by Rob Sutton                         */
/*  http://smart.xnettech.net (Nuke Site)                               */
/*  Development continued by Aleks A.-Lessmann                          */
/* Prefix and minor bugfixes by fsz dESIGN & maaX dESIGN                */
/*  http://www.fsz-design.de  http://www.maax-design.de                 */
/* Included some ideas and changes by:                                  */
/*  flobee, bulli-frank, kicks, kochloeffel, Matthias "E.Z." E.         */
/* -------------------------------------------------------------------- */
/* This program is free software. You can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation; either version 2 or a newer version.   */
/************************************************************************/

####### description of event dots color #######
define("_CALdotcolorgreen","gr�n"); 				// desription of the green dot
define("_CALdotcolorred","rot");      				// desription of the red dot 
define("_CALdotcolorblue","blau";      				// desription of the blue dot
define("_CALdotcolorwhite","weiss"); 				// desription of the white dot
define("_CALdotcoloryellow","gelb");     			// desription of the yellow dot
define("_CALdotcolorpurple","");  				// desription of the purple dot
define("_CALdotcolorbrown","");  				// desription of the brown dot
define("_CALdotcolorcyan","");  				// desription of the cyan dot

####### locale time-format variables #######
define("_CALSHORTDATEFORMAT","%d.%m.%y");	// local short date format string 
define("_CALLONGDATEFORMAT","%A, %d. %B %Y");	// local long date format string
define("_CALMONTHDATEFORMAT","%B %Y");		// local month format string
define("_CALINTERNATIONALDATES",1);    		// 0 = mm/dd/yyyy, 1 = dd/mm/yyyy
define("_CALTIME24HOUR",1);  			// 1 = 24 hour time... 0 = AM/PM time
define("_CALLOCALE","de_DE");			// local date format for e.g. Linux/Unix		// modified by Matthias E.
#define("_CALLOCALE","ger");   			// local date format for e.g. Windows System!!		// modified by Matthias E.
define("_CALTIMEFORMAT","%H:%M Uhr");		// local time format string				// modified by Matthias E.
define("_CALWEEKBEGINN",1);  			// the First Day in the Week: 0 = Sunday, 1 = Monday

####### main texts #######
define("_CALDOTCOLORALL","Alle&nbsp;Termine");     // desription of all Events (no colordot)
define("_CALSEND","Absenden");
define("_CALSUBMITEVENT", "Neuen Termin eintragen");
define("_CALSUBMITNAME", "Terminkalender Eintragsformular");
define("_CALNAME", "Termin-Kalender");
define("_CALPREVIEW", "Terminvorschau");
define("_CALOK", "Termin �bermitteln");
define("_CALEVENTDATETEXT", "Termindatum");
define("_CALSUBSENT", "Ihr Kalendereintrag ist eingegangen");
define("_CALTHANKSSUB", "Vielen Dank f�r Ihre Einsendung!");
define("_CALSUBTEXT", "In den n�chsten Stunden wird Ihr Eintrag gepr�ft und gegebenenfalls ver�ffentlicht.");
define("_CALSUBTEXTADMIN", "Ihr Eintrag wurde sofort ver�ffentlicht.");
define("_CALWEHAVESUB", "Im Augenblick haben wir");
define("_CALWAITING", "Einsendungen, die darauf warten ver�ffentlicht zu werden.");
define("_CALEVENTDATEPREVIEW", "Termindatum");
define("_CALCHECKSTORY", "Bitte �berpr�fen Sie Text, Links, etc. BEVOR Sie Ihren Termin senden!");
define("_CALYOURNAME", "Ihr Name");
define("_CALLOGOUT", "Logout");
define("_CALSUBTITLE", "Betreff");
define("_CALTOPIC", "Thema");
define("_CALSELECTTOPIC", "Thema ausw�hlen");
define("_CALARTICLETEXT", "Beschreibung");
define("_CALHTMLISFINE", "HTML ist erlaubt, bitte &uuml;berpr&uuml;fen Sie aber unbedingt die Tags!");
define("_CALNEWSUBPREVIEW", "Terminvorschlag: Vorschau");
define("_CALSTORYLOOK", "Ihr Eintrag wird in etwa SO aussehen:");
define("_CALBEDESCRIPTIVE", "Beschreiben Sie bitte kurz und pr�zise!");
define("_CALSUBPREVIEW", "Vor der �bertragung m&uuml;ssen Sie zun�chst die Vorschau ansehen");
define("_CALALLOWEDHTML", "Erlaubtes HTML");
define("_CALSUBMISSIONSADMIN", "Terminkalender Administration");
define("_CALNEWSUBMISSIONS", "Neue Terminvorschl�ge");
define("_CALNOSUBJECT", "ein Betreff fehlt!");
define("_CALNOSUBMISSIONS", "Keine neuen Terminvorschl�ge vorhanden!");
define("_CALDELETE", "L�schen");
define("_CALNAMEFIELD", "Name");
define("_CALDELETESTORY", "Termin l�schen");
define("_CALPREVIEWSTORY", "Terminvorschau");
define("_CALPOSTSTORY", "Termin ver�ffentlichen");
define("_CALSUBMITADVICE1", "F�llen Sie bitte das folgende Formular aus.");
define("_CALSUBMITADVICE2", "Wir m�chten Sie darauf hinweisen, dass nicht alle Termine ver�ffentlicht werden.<br>Eventuell nehmen wir uns die Freiheit Ihren Termin zu �berarbeiten.");
define("_CALPOSTEDBY","Ver�ffentlicht von");
define("_CALPOSTEDON","am");
define("_CALACCEPTEDBY"," und genehmigt von");
define("_CALVIEWEVENT","KalenderTermin");
define("_CALPREVIOUS","Vorherige");
define("_CALNEXT","N�chste");
define("_CALSTARTTIME","Startzeit");
define("_CALENDTIME","Ende");
define("_CALALLDAYEVENT","ganzt&auml;gig");
define("_CALTIMEIGNORED","Start- und Endzeit werden ignoriert.");
define("_CALENDDATETEXT","Enddatum");
define("_CALENDDATEPREVIEW","Enddatum");
#define("_CALBARCOLORTEXT","Bitte w&auml;hlen Sie eine Kategorie f�r den Termin aus");
define("_CALBARCOLORTEXT","Kategorie");
define("_CALLOGIN","Login");
define("_CALNO","Nein");
define("_CALYES","Ja");
define("_CALREMOVETEST","Sind Sie sicher, dass Sie diesen Termin entfernen m�chtesn?");
define("_CALNOTAUTHORIZED1","Sie sind nicht berechtigt, diesen Eintrag zu &auml;ndern, oder zu entfernen!");
define("_CALNOTAUTHORIZED2","F�r Fragen konsultieren Sie bitte den Systemadministrator");
define("_CALNOTAUTHORIZED3","Sorry, aber Sie sind nicht berechtigt, Eintr&auml;ge zu ver&auml;ndern oder zu l&ouml;schen!");
define("_CALTODAY","Heute");
define("_CALLISTDESCRIPTION1","�bersicht der n�chsten");
define("_CALLISTDESCRIPTION2","Termine");
define("_CALLISTSTART","ab");
define("_CALLISTRANGE","bis");
define("_CALHEADAPPOINTM","Termine");
define("_CALDAYEVENTS","Ereignisse");
define("_CALDAYMORNING","Morgens");
define("_CALDAYEVENING","am Abend");
define("_CALMORE","weitere Termine");
define("_CAL1EVENT","Termin");
define("_CAL2EVENT","Termine");
define("_CAL0EVENTS", "Es sind keine Termine f&uuml;r diese Bedingung vorhanden");
define("_CAL0EVENTSBLOCK", "Sorry, zur Zeit haben wir keine aktuellen Termine zur Verf&uuml;gung.");
define("_CALNOTODAYEVENTS","Keine Termine f&uuml;r Heute.");
define("_CALADDASARTICLE","Artikel");
define("_CALADDASARTICLE2","Einen News-Artikel von diesem Termin erstellen.");

###### EMAIL NOTIFICATION ###### // whole block added by Matthias Ehrmann
define("_CALADMINNOTIFICATIONTITLE","Hey admin, ein neuer Kalendereintrag wartet auf Freigabe");
define("_CALADMINNOTIFICATIONSUBJECT","Neuer Kalendereintrag");		
define("_CALEVENTNEW","Neuer Termin");				
define("_CALEVENTCHANGED","Termin ge�ndert");	
define("_CALEVENTCHANGEDNEWDATA","Neue Termindaten:");
define("_CALEVENTREMOVED","Termin gel�scht");			
define("_CALEVENTREMOVEDDATAWAS","Termindaten waren:"); 
define("_CALUNSUBSCRIBE","Keine weiteren Benachrichtigungen ? Einfach auf der homepage abschalten:");

####### LINKS ########
define("_CALEVENTLINK","Termin eintragen");		// modified by Matthias E.
define("_CALAPPTLINK","Termin eintragen");		// modified by Matthias E.
define("_CALTASKLINK","Neue Aufgabe eintragen");
define("_CALDAYLINK","Tagesansicht");
define("_CALMONTHLINK","Monatsansicht");
define("_CALYEARLINK","Jahresansicht");
define("_CALJUMPTOTEXT","Zur folgenden Terminkalenderansicht wechseln");	// modified by Matthias E.
define("_CALJUMPBUTTON","Wechseln!");
define("_CALLISTLINK","n�chste Termine");

####### MONTHS ########
define("_CALJAN","Januar");
define("_CALFEB","Februar");
define("_CALMAR","M�rz");
define("_CALAPR","April");
define("_CALMAY","Mai");
define("_CALJUN","Juni");
define("_CALJUL","Juli");
define("_CALAUG","August");
define("_CALSEP","September");
define("_CALOCT","Oktober");
define("_CALNOV","November");
define("_CALDEC","Dezember");

####### DAYS OF THE WEEK ########
define("_CALFIRSTDAY","Mo");
define("_CALSECONDDAY","Di");
define("_CALTHIRDDAY","Mi");
define("_CALFOURTHDAY","Do");
define("_CALFIFTHDAY","Fr");
define("_CALSIXTHDAY","Sa");
define("_CALSEVENTHDAY","So");
define("_CALLONGFIRSTDAY","Montag");
define("_CALLONGSECONDDAY","Dienstag");
define("_CALLONGTHIRDDAY","Mittwoch");
define("_CALLONGFOURTHDAY","Donnerstag");
define("_CALLONGFIFTHDAY","Freitag");
define("_CALLONGSIXTHDAY","Samstag");
define("_CALLONGSEVENTHDAY","Sonntag");

####### FIELD VALIDATION STRINGS ########	// modified by Matthias E. (removed german XML entities like &ouml;)
define("_CALVALIDERRORMSG","Es sind Fehler aufgetreten bei dem Versuch den Eintrag zu best�tigen!");
define("_CALVALIDFIXMSG","Bitte diese Fehler VOR der Vorschau oder �bertragung �ndern.");
define("_CALVALIDSUBJECT","Das Feld 'Betreff' ist zwingend notwendig.");
define("_CALVALIDENDDATE","Das 'Enddatum' hat einen ung�ltigen Eintrag.");
define("_CALVALIDEVENTDATE","Das 'Termindatum' hat einen ung�ltigen Eintrag.");
define("_CALVALIDDATES","Das 'Enddatum' muss nach oder gleich dem 'Termindatum' liegen.");
define("_CALVALIDTIMES","Das 'Enddatum' muss nach dem 'Startdatum' liegen'.");
define("_CALVALIDTOPIC", "Es muss ein Thema ausgew�hlt werden.");

?>