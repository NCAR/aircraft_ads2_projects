main()
{
	int	i, j;

	for (i = 0; i < 1000; ++i)
		{
		for (j = 0; j < 49; ++j)
			printf("1.0\n");

		printf("2.0\n");
		}

}
