/*
-------------------------------------------------------------------------
OBJECT NAME:	template.c

FULL NAME:	

ENTRY POINTS:	xletorq()

STATIC FNS:	none

DESCRIPTION:	

INPUT:		

OUTPUT:		

REFERENCES:	none

REFERENCED BY:	rec_decode.c

COPYRIGHT:	University Corporation for Atmospheric Research, 1995
-------------------------------------------------------------------------
*/

#include "nimbus.h"
#include "amlib.h"


/* -------------------------------------------------------------------- */
void xletorq(RAWTBL *varp, void *input, NR_TYPE *output)
{




}	/* END XLETORQ */

/* END ETORQ.C */
