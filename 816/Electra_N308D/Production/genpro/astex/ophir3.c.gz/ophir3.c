/*  	Ophir 3 radiometer                      */
#include <math.h>
#include <header.h>
#include <decode.h>
#include <digitalraw.h>

#define h               6.626176e-34            /* Planck's const, J-s */
#define k               1.380662e-23            /* Boltzman's const, J/K */
#define lam             4.25e-6                 /* Wavelength, um */
#define TZERO           273.16
#define c               2.99792458e8            /* Speed of light, m/s */
#define PI              3.14159

extern float MAXCNT;	/* values set in /home/local/winds/proj/nnn/defaults */
extern float THERM_BIAS;
extern float THERM_RZ;
extern float THERM_COEFF;
extern float DFLT_GAIN;
extern float DFLT_OFFSET;

extern float A1;
extern float A2;

double  planck_rad();
double  planck_t();
double  therm();

extern short int *indata;
extern unsigned short int *bitdata;
extern struct Indata *inptr;

struct Oph3_blk *oph;

static float otdetc,odsigc,obbcr,ogainf,odetof;
float oat;

double  gain, gain_factor, bbrad, av_detofset,
        av_detdc, av_bbctem, av_bbhtem,
        av_bbcsig, av_bbhsig;
double  sum_bbctem, sum_bbhtem, sum_detofset,
        sum_bbcsig, sum_bbhsig, sum_detdc;
double  bbctem_k, bbcrad, bbhtem_k, bbhrad, detdc_v;

int 	nbbc, nbbh, nofset;
unsigned int convert;
int sbb;
float detdc,detem,bbctem,detsig;
float idetsig,idetem;

void soat(out,rawdata,derivedata,varp,iogain,iobbcod,iodetdc,iotsnt,iotbnch,iotdet,iotbbc,iotbbf,iosmotr,iodetsg,iotbox)
float	*out,*rawdata,*derivedata;
VATBL	*varp;	/* Variable Pointer	*/
int 	*iogain,*iobbcod,*iodetdc,*iotsnt,*iotbnch,*iotdet,*iotbbc,*iotbbf,*iosmotr,*iodetsg,*iotbox;
{
float temp;

sbb = rawdata[*iobbcod-1]/256;
rawdata[*iobbcod-1] = sbb;
temp = rawdata[*iodetdc-1];
	if(temp < 0.) temp += 65536.0;
	detdc = (-5.0+temp*10.0/MAXCNT);
	rawdata[*iodetdc-1] = detdc;
temp = rawdata[*iotsnt-1];
	if(temp < 0.) {
		temp += 65536.0;
		std(&temp,&temp,rawdata,&inptr[*iotsnt-1].order,&inptr[*iotsnt-1].cof);
		rawdata[*iotsnt-1] = temp;
		}
temp = rawdata[*iotbnch-1];
        if(temp < 0.) {
                temp += 65536.0;
                std(&temp,&temp,rawdata,&inptr[*iotbnch-1].order,&inptr[*iotbnch-1].cof);           
                rawdata[*iotbnch-1] = temp;
                }
idetem = rawdata[*iotdet-1];
	if(idetem<0.) {
		idetem += 65536.0;
                rawdata[*iotdet-1] = idetem;
		}
temp = rawdata[*iotbbc-1];
        if(temp < 0.) {
                temp += 65536.0;
                std(&temp,&temp,rawdata,&inptr[*iotbbc-1].order,&inptr[*iotbbc-1].cof);
                rawdata[*iotbbc-1] = temp;
                }
bbctem = temp;
temp = rawdata[*iotbbf-1];
        if(temp < 0.) {
                temp += 65536.0;
                std(&temp,&temp,rawdata,&inptr[*iotbbf-1].order,&inptr[*iotbbf-1].cof);
                rawdata[*iotbbf-1] = temp;
                }
temp = rawdata[*iosmotr-1];
        if(temp<0.) {
                temp += 65536.0;
                rawdata[*iosmotr-1] = temp;
                }
idetsig = rawdata[*iodetsg-1];
        if(idetsig<0.) {
		idetsig += 65536.0;
                rawdata[*iodetsg-1] = idetsig;
                }

      if(sbb=='z') {                   /* Null record */
        sum_bbctem=sum_bbhtem=0.0;
        sum_bbcsig=sum_bbhsig=0.0;
        sum_detdc=0.0;
        sum_detofset+=(double) idetsig;
        nofset++;
        av_detofset=sum_detofset/(double) nofset;
      }

      if(sbb=='c') {                  /* BB cooling calibration */
        sum_detofset=0.0;
        nofset=0;
        sum_bbctem+=(double) bbctem;
        sum_bbcsig+=(double) idetsig;
        sum_detdc+=(double) detdc;
        nbbc++;
        av_bbctem=sum_bbctem/(double) nbbc;
        av_bbcsig=sum_bbcsig/(double) nbbc;
        bbctem_k=av_bbctem;
        bbcrad=planck_rad(bbctem_k);
      }

      if(sbb=='h') {                   /* BB heating calibration */
        sum_detofset=0.0;
        nofset=0;
        sum_bbhtem+=(double) bbctem;
        sum_bbhsig+=(double) idetsig;
        sum_detdc+=(double) detdc;
        nbbh++;
        av_bbhtem=sum_bbhtem/(double) nbbh;
        bbhtem_k=av_bbhtem;
        bbhrad=planck_rad(bbhtem_k);
        av_detdc=sum_detdc/((double) nbbc+(double) nbbh);
        av_bbhsig=sum_bbhsig/(double) nbbh;
        gain=-fabs((bbhrad-bbcrad)/((av_bbhsig-av_bbcsig)*10.0/MAXCNT));
        detdc_v=(-5.0+av_detdc*10.0/MAXCNT);
        gain_factor=gain*detdc_v*detdc_v;
      }

      if(sbb=='b') {                   /* Normal record with no BB cooling */

/*  Calculates parameters in eng units  */
  detem=therm((double) idetem);
  detsig=((double) idetsig - DFLT_OFFSET)*10.0/MAXCNT;
  bbcrad=planck_rad((double)bbctem);
/* calc_airtem = OphirAirTem = oat */
  oat = detsig*A1 + A2 + bbcrad;
   
  if(oat>0.0) 
	oat=planck_t((double)oat);
    else 
	oat=TZERO;

        sum_bbctem=sum_bbhtem=0.0;
        sum_bbcsig=sum_bbhsig=0.0;
   }
*out = oat - 273.16;
}


/*  planck_rad - returns hemishperical black body radiance  */
/*    in W/cm^2/um  */
double planck_rad(tk)
double tk;
{
  double rad;
  rad=(2.0*h*c*c*PI)/(pow(lam,5.0)*(exp(h*c/lam/k/tk)-1.0));
  rad=rad*1.0e-10;
  return(rad);
}

/*  planck_t - Returns temp in K from rad in W/cm^2/um  */
double planck_t(rad)
double rad;
{
  double t;
  t=h*c/(lam*k*log(2.0*h*c*c*PI/(rad*1.0e10)/pow(lam,5.0)+1.0));
  return(t);
}

/*  therm - Temp of detector thermistor deg K  */
double therm(counts)
double counts;
{
  double tc,rt,v;
  v=(-5.0+counts/MAXCNT*10.0)/(1.0+50.0/18.2);
  if(v>-THERM_BIAS/21.0)
    rt=200.0/(1.0/(1.0/21.0+v/THERM_BIAS)-1.0);
  else
    rt=1.0;
  tc=1.0/(TZERO-50.0)-log(rt/THERM_RZ)/THERM_COEFF;
  tc=1.0/tc;
  return(tc);
}


void sotdetc(out)
float *out;
{
*out = detem;
}
void sodsigc(out)
float *out;
{
*out = detsig;
}
void sobbcr(out)
float *out;
{
*out = bbcrad;
}
void sogainf(out)
float *out;
{
*out = gain_factor;
}
void sodetof(out)
float *out;
{
*out = av_detofset;
}

/*
Raw variable names      Names in this software
 
ogain                   szg             (gain)
obbcod                  sbb             (black body code)
odetdc                  detdc
otsnt                   sntem           (snout temperature)
otbnch                  bntem           (optical bench temperature)
otdet                   idetem          (detector temperature)
otbbc                   bbctem          (BBC temperature)
otbbf                   bbftem          (BBF temperature)
osmotr                  motor           (motor speed)
otbox                   boxtem          (box temperature)
odetsg                  idetsig         (detector raw signal)
 
computed output values
 
odsigc                  detsig          (corrected detector signal)
otdetc                  detem           (corrected detector temperature)
obbcr                   bbcrad
ogainf                  gain_factor
odetof                  av_detofset
oat                     oat             (computed air temperature)
*/
