<?php
/************************************************************************/
/* SPChat  (Multi Room Web based Chat System)                           */
/* Language file for german language                                    */
/* for phpNUKE Version 5.5 and above (http://www.phpnuke.org)           */
/* and Postnuke Version 7.2.2 and above                 */
/* ==================================================================== */
/* By Frank Wallacher (frank@saarport.net) (c) 2002-2003                */
/* http://www.saarport.net                                              */
/* ==================================================================== */
/* Based on:                                                            */
/* PHPNukeWebChat v2.0                                                  */
/* ===================                                                  */
/* Authors:                                                 */
/*                                  */
/* Frank Wallacher <frank@saarport.dyndns.org                       */
/* Web: http://www.saarport.net                                         */
/*                                  */
/* Oliver Gading   <oliver@gading.de>                   */
/* Web: http://nuke-modules.gading.de                   */
/*                                  */
/* ==================================================================== */
/* This program is free software. You can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation; either version 2 of the License.       */
/************************************************************************/

if (eregi("block-SPChat.php",$PHP_SELF)) {
    Header("Location: index.php");
    die();
}

global $cookie, $prefix, $currentlang;
$GLOBALS['spchat']['ModDir'] = "SPChat";
$basepath   = "modules/".$GLOBALS['spchat']['ModDir'];

if(file_exists("$basepath/language/lang-".$currentlang.".php")) {
    include("$basepath/language/lang-".$currentlang.".php");
} else {
    include("$basepath/language/lang-$language.php");
}

define('_SPCHAT_PHPNUKE_BLOCK_RUNNING','yes');
include_once('modules/'.$GLOBALS['spchat']['ModDir'].'/inc/init.inc.php');
include_once(_SPCHAT_INCLUDEPATH.'inc/user.inc.php');

spchat_user_cleanup_tables_timeouts();
#print "<pre>"; print_r(spchat_user_get_rooms()); print "</pre>";

if(file_exists("./includes/adodb/adodb.inc.php")) {
    include_once('includes/adodb/adodb.inc.php');
    $title = "Chatblock";
        $content  = '<table width="95%" align="center" cellpadding="1">';
        $content .= '<tr width="100%" align="center">';
        $content .= '<td class="content" width="100%">'._ROOM_NAME.'</td><td class="content" width="100%">'._ONLINE.'</td>';
      
    
        $spchat_user = $GLOBALS['prefix'] . '_spchat_user';
    $pntable['spchat_user'] = $spchat_user;
    $pntable['spchat_user_column'] =
                   array('uid'      => $spchat_user . '.uid',
                         'name'     => $spchat_user . '.name',
                         'last'     => $spchat_user . '.last',
                         'rid'      => $spchat_user . '.rid',
                         'ip'       => $spchat_user . '.ip',
                         'kicked'       => $spchat_user . '.kicked',
                         'gid'      => $spchat_user . '.gid',
                         'usercol'      => $spchat_user . '.usercol',
                         'useragent'    => $spchat_user . '.useragent',
                         'usesounds'    => $spchat_user . '.usesounds',
                         'msglastcheck' => $spchat_user . '.msglastcheck');

    $spchat_room = $GLOBALS['prefix'] . '_spchat_room';
    $pntable['spchat_room'] = $spchat_room;
    $pntable['spchat_room_column'] =
                      array('rid'       => $spchat_room . '.rid',
                            'name'      => $spchat_room . '.name',
                            'descript'  => $spchat_room . '.descript',
                            'typ'       => $spchat_room . '.typ',
                            'pass'      => $spchat_room . '.pass',
                            'orig'      => $spchat_room . '.orig',
                            'stamp'     => $spchat_room . '.stamp');                                                        

    $spchat_room_table = $pntable['spchat_room'];
    $spchat_room_column = &$pntable['spchat_room_column'];
    $spchat_user_table = $pntable['spchat_user'];
    $spchat_user_column = &$pntable['spchat_user_column'];
        
        // Connect to the database
    $dbconn = &ADONewConnection($GLOBALS['dbtype']);
    $dbconn->Connect($GLOBALS['dbhost'],$GLOBALS['dbuname'],$GLOBALS['dbpass'],$GLOBALS['dbname']);         
 
        $sql = "SELECT $spchat_room_column[rid],
                $spchat_room_column[name],
                $spchat_room_column[typ],
     count($spchat_user_column[rid]) 
         as users from $spchat_room_table 
         left join $spchat_user_table
         on $spchat_user_column[rid] = $spchat_room_column[rid]
         group by $spchat_room_column[typ], $spchat_room_column[name]
        ";
    
    // $dbconn->debug = true;         
    $result = $dbconn->Execute($sql);
        if($result === false) { print 'DB-Error! Install SPChat Package first!'; }
        if($result -> EOF) { 
            $content .= '<td>'.NO_ROOMS.'</td>'; 
        } else {
            for(;!$result->EOF;$result->MoveNext()) {
                    $data = $result->fields;
                        $content .= '</tr><tr width="100%">';
                        if($data[typ] == "P") {
                            $content .= '<td bgcolor="'.$GLOBALS[bgcolor1].'" class="content" width="100%"><img src="modules/'.$GLOBALS['spchat']['ModDir'].'/images/pass.gif" alt="'._PRIVAT.'" align="middle">&nbsp;<a href="modules.php?op=modload&name='.$GLOBALS['spchat']['ModDir'].'&file=index&roomid='.$data[rid].'">'.$data[name].'</a></td><td bgcolor="'.$GLOBALS[bgcolor1].'" class="content" width="100%" align="center">'.$data[users].'</td>';
                        } else {
                            $content .= '<td bgcolor="'.$GLOBALS[bgcolor1].'" class="content" width="100%"><a href="modules.php?op=modload&name='.$GLOBALS['spchat']['ModDir'].'&file=index&roomid='.$data[rid].'">'.$data[name].'</a></td><td bgcolor="'.$GLOBALS[bgcolor1].'" class="content" width="100%" align="center">'.$data[users].'</td>';
                        }
                    $content .= '</tr><td></td>';
                }
            $result->Close();
        }
        
        $content .= '</tr>';
        $content .= '</table>';
        $content .= '<br>';
        $content .= '<center>[ <a href="modules.php?name='.$GLOBALS['spchat']['ModDir'].'">SPChat</a> ]</center>';
} else {
    $content = "No Adodb found - install SPChat before installing the block";
}

?>
