<?php
// $Id: Version.php,v 1.1.1.1 2002/09/15 22:26:15 root Exp $
$modversion['name'] = 'Groups Adminstration';
$modversion['version'] = '0.1';
$modversion['description'] = 'Modify groups';
$modversion['credits'] = 'docs/credits.txt';
$modversion['help'] = 'docs/help.txt';
$modversion['changelog'] = 'docs/changelog.txt';
$modversion['license'] = 'docs/license.txt';
$modversion['official'] = 1;
$modversion['author'] = 'Jim McDonald';
$modversion['contact'] = 'http://www.mcdee.net/';
$modversion['admin'] = 1;
$modversion['securityschema'] = array('Groups::' => 'Group Name::Group ID');
?>