<?php //$Id: Version.php,v 1.3 2002/10/24 19:05:13 larsneo Exp $ $Name: HEAD $

$modversion['name'] = 'Members_List';
$modversion['version'] = '1.1';
$modversion['description'] = 'Members Listing Module';
$modversion['credits'] = 'docs/credits.txt';
$modversion['help'] = 'docs/install.txt';
$modversion['changelog'] = 'docs/changelog.txt';
$modversion['license'] = 'docs/license.txt';
$modversion['official'] = 1;
$modversion['author'] = 'Francisco Burzi';
$modversion['contact'] = 'http://www.phpnuke.org';
$modversion['admin'] = 0;
$modversion['securityschema'] = array('Members_List::' => '::');

?>