<?php
$modversion['name'] = '';
$modversion['version'] = '1.0';
$modversion['description'] = 'Old PostNuke admin compatibility';
$modversion['credits'] = '';
$modversion['help'] = '';
$modversion['changelog'] = '';
$modversion['license'] = '';
$modversion['official'] = 1;
$modversion['author'] = 'Pascal Riva';
$modversion['contact'] = 'http://www.e-riva.org';
$modversion['admin'] = 1;
$modversion['securityschema'] = ''
?>