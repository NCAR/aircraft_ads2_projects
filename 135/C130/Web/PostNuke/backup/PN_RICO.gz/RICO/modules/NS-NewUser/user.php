<?php
// File: $Id: user.php,v 1.40 2004/06/17 07:07:13 r3ap3r Exp $ $Name: HEAD $
// ----------------------------------------------------------------------
// PostNuke Content Management System
// Copyright (C) 2001 by the PostNuke Development Team.
// http://www.postnuke.com/
// ----------------------------------------------------------------------
// Based on:
// PHP-NUKE Web Portal System - http://phpnuke.org/
// Thatware - http://thatware.org/
// ----------------------------------------------------------------------
// LICENSE

// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License (GPL)
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.

// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.

// To read the license please visit http://www.gnu.org/copyleft/gpl.html
// ----------------------------------------------------------------------
// Original Author of this file:
// Purpose of this file:  new user routines
// ----------------------------------------------------------------------
// Added calls to pnVarCleanFromInput since it's more secure than using $var[]. - Skooter

if (!defined('LOADED_AS_MODULE')) {
	die ('You can\'t access this file directly...');
}

$ModName = 'NS-NewUser';
modules_get_language();

function newuser_user_underage()
{
    include 'header.php';

    OpenTable();
    echo "<span class=\"pn-title\">" . _SORRY . "</span>";
    echo "<br /><br />\n" . "<span class=\"pn-normal\">" . _MUSTBE . "<br />" . "<br />" . _CLICK . "<a href=\"index.php\">" . _HERE . "</a> " . _RETURN . "</span><br />\n";
    CloseTable();
    include 'footer.php';
}

function newuser_user_check_age($var)
{
    $sitename = pnConfigGetVar('sitename');
    // new by class007
    include 'header.php';
    if (!pnConfigGetVar('reg_allowreg')) {
        echo "<strong>"._REGISTERDISABLED."<br />"._REASONS."</strong><br />&nbsp;&nbsp;&nbsp;&nbsp;" . pnVarPrepForDisplay(pnConfigGetVar('reg_noregreasons')) . "<br /><br />";
        include 'footer.php';
        return false;
    }

    OpenTable();
    echo "<div style=\"text-align:center\">" . "<span class=\"pn-title\">" . _WELCOMETO . " " . pnVarPrepForDisplay($sitename) . " " 
	. _REGISTRATION . "</span>" . "<br /><br />\n" . "<span class=\"pn-normal\">" . _MUSTBE . "</span><br />\n" 
	. "<a href=\"user.php?op=register&amp;module=NS-NewUser\">" . "" . _OVER13 . "" . "</a><br /><br />" 
	. "<span class=\"pn-normal\">" . _CONSENT . "</span><br /><br />\n" . "<a href=\"user.php?op=underage&amp;module=NS-NewUser\">" 
	. "" . _UNDER13 . "</a><br />\n" . "</div>\n";
 //   echo "<div style=\"text-align:center\">" . "<span class=\"pn-title\">" . _WELCOMETO . " " . pnVarPrepForDisplay($sitename) . " " . _REGISTRATION . "</span>" . "<br /><br />\n" . "<span class=\"pn-normal\">" . _MUSTBE . " $minage " . _MUSTBE . "</span><br />\n" . "<a href=\"user.php?op=register&amp;module=NS-NewUser\">" . "" . _OVER13a . " $minage " . _OVER13b . "" . "</a><br /><br />" . "<span class=\"pn-normal\">" . _CONSENT1 . " $minage " . _CONSENT2 . "</span><br /><br />\n" . "<a href=\"user.php?op=underage&amp;module=NS-NewUser\">" . "" . _UNDER13a . " $minage " . _UNDER13b . "" . "</a><br />\n" . "</span></div>\n";

    CloseTable();
    include 'footer.php';
}

function newuser_user_register()
{
    $system = pnConfigGetVar('system');
    $size = 35;

    include 'header.php';
    // new by class007
    if (!pnConfigGetVar('reg_allowreg')) {
		echo "<strong>" . _REGISTERDISABLED . "<br />" . _REASONS . "</strong><br />&nbsp;&nbsp;&nbsp;&nbsp;" . pnVarPrepForDisplay(pnConfigGetVar('reg_noregreasons')) . "<br /><br />";
        include 'footer.php';
        return false;
    }

    OpenTable();
	echo "<span class=\"pn-title\">" . _REGNEWUSER . "</span><br /><br />\n"
		."<span class=\"pn-title\">" . _REGISTERNOW . "</span><br />\n"
		."<span class=\"pn-normal\">" ._WEDONTGIVE . "</span>\n";
	CloseTable();
	
	OpenTable();
	echo "<form name=\"Register\" action=\"user.php\" method=\"post\"><div>\n"
		."<table cellpadding=\"5\" cellspacing=\"0\" border=\"0\">\n"
		. "<tr>\n"
		. "<td style=\"width:25%\" align=\"right\"><span class=\"pn-normal\"><strong><label for=\"uname_new_user\">" . _NICKNAME . "</label></strong></span></td>\n"
		. "<td style=\"width:75%\"><input type=\"text\" name=\"uname\" id=\"uname_new_user\" size=\"$size\" maxlength=\"25\" tabindex=\"0\" /></td>\n"
		. "</tr>\n";

		// new by class007. echo password area if admin do not want to verify email.
	if (!pnConfigGetVar('reg_verifyemail')) {
		echo "<tr>\n"
			."<td align=\"right\"><span class=\"pn-normal\"><strong><label for=\"pass_new_user\">" . _PASSWORD . "</label></strong></span></td>\n"
			."<td><input type=\"password\" name=\"pass\" id=\"pass_new_user\" size=\"$size\" maxlength=\"20\" tabindex=\"0\" /></td>"
			."</tr>\n"
			."<tr>\n"
			."<td align=\"right\"><span class=\"pn-normal\"><strong><label for=\"vpass_new_user\">" . _PASSWDAGAIN . "</label></strong></span></td>\n"
			."<td><input type=\"password\" name=\"vpass\" id=\"vpass_new_user\" size=\"$size\" maxlength=\"20\" tabindex=\"0\" /></td>\n"
			."</tr>\n";
	}

	echo "<tr>\n"
		."<td align=\"right\"><span class=\"pn-normal\"><strong><label for=\"email_new_user\">" . _EMAIL . "</label></strong></span></td>\n"
		."<td><input type=\"text\" name=\"email\" id=\"email_new_user\" size=\"$size\" maxlength=\"60\" tabindex=\"0\" /></td>\n"
		."</tr>\n"
		."<tr>\n"
		."<td align=\"right\"><span class=\"pn-normal\"><strong><label for=\"vemail_new_user\">" . _EMAILAGAIN . "</label></strong></span></td>\n"
		."<td><input type=\"text\" name=\"vemail\" id=\"vemail_new_user\" size=\"$size\" maxlength=\"60\" tabindex=\"0\" /></td>\n"
		."</tr>\n";

	// edit by class007
	if (pnConfigGetVar('reg_verifyemail')) {
		echo "<tr>\n"
			."<td style=\"width:75\">&nbsp;</td>\n"
			."<td><span class=\"pn-normal\"><strong>" . _PASSWILLSEND . "</strong></span></td>\n"
			."</tr>\n";
	}

	echo "<tr>\n"
		."<td align=\"right\"><span class=\"pn-normal\"><strong>" . _OPTION . "</strong></span></td>\n"
		."<td><input type=\"checkbox\" name=\"user_viewemail\" id=\"user_viewemail_new_user\" value=\"1\" tabindex=\"0\" /><span class=\"pn-normal\"><label for=\"user_viewemail_new_user\">" . _ALLOWEMAILVIEW . "</label></span></td>"
		."</tr>\n";

	// Check for legal module
	if (pnModAvailable("legal")) {
		echo "<tr>\n"
			."<td style=\"width:75\" align=\"right\"><span class=\"pn-normal\">&nbsp;</span></td>\n"
			."<td><input type=\"checkbox\" name=\"agreetoterms\" id=\"agreetoterms_new_user\" value=\"1\" tabindex=\"0\" /><span class=\"pn-normal\"><label for=\"agreetoterms_new_user\">" . _REGISTRATIONAGREEMENT . " <a href=\"modules.php?op=modload&amp;name=legal&amp;file=index\">" . _TERMSOFUSE . "</a> " . _ANDCONNECTOR . " <a href=\"modules.php?op=modload&amp;name=legal&amp;file=privacy\">" . _PRIVACYPOLICY . "</a></label>.</span></td>"
			."</tr>\n";
	}

	echo "<tr>\n"
		."<td align=\"right\">&nbsp;</td>\n"
		."<td>\n"
		."<input type=\"hidden\" name=\"module\" value=\"NS-NewUser\" />\n"
		."<input type=\"hidden\" name=\"op\" value=\"finishnewuser\" />\n"
		."<input type=\"submit\" value=\"" . _NEWUSER . "\" />\n" 
		."</td>\n"
		."</tr>\n";

	echo "<tr>\n"
		."<td>&nbsp;</td>\n"
		."<td><span class=\"pn-normal\">" . _COOKIEWARNING . "</span></td>\n"
		."</tr>\n";

	if (pnConfigGetVar('reg_optitems')) {
		echo "<tr>"
			."<td>&nbsp;</td>"
			."<td><span class=\"pn-normal\"><strong>" . _ASREGUSER . "</strong></span><br />\n"
			."<span class=\"pn-normal\">" 
			."<br />- " . _ASREG1
			."<br />- " . _ASREG2
			."<br />- " . _ASREG3
			."<br />- " . _ASREG4
			."<br />- " . _ASREG5
			."<br />- " . _ASREG6
			."<br />- " . _ASREG7
			."</span></td>"
			."</tr>\n";

		echo "<tr>"
			."<td>&nbsp;</td>"
			."<td><span class=\"pn-normal\"><strong>" . _OPTIONALITEMS . "</strong></span></td>"
			."</tr>\n" . "";
			// Display optional items to register
		optionalitems();
	}
	echo "</table>\n";
	echo "</div></form>\n";
	CloseTable();
	include 'footer.php';
}

function userCheck($uname, $email, $agreetoterms)
{
    $dbconn =& pnDBGetConn(true);
    $pntable =& pnDBGetTables();

    $stop = '';
    $res = pnVarValidate($email, 'email');
    if ($res == false) {
        $stop = "<div style=\"text-align:center\"><span class=\"pn-title\">" . _ERRORINVEMAIL . "</div></span><br />";
    }
    // Check for legal module
    if (pnModAvailable("legal")) {
        // If legal var agreetoterms checkbox not checked, value is 0 and results in error
        if ($agreetoterms == 0) {
            $stop = "<div style=\"text-align:center\"><span class=\"pn-title\">" . _ERRORMUSTAGREE . "</div></span><br />";
        }
    }
    // By this test (without on printable characters) it should be possible to have
    // eg. Chinese characters on the username. (hinrich, 2002-07-03, reported by class 007

    if ((!$uname) || !(/**
                 * preg_match("/^[[:print:]]+/",$uname) &&
                 */!preg_match("/[[:space:]]/", $uname))) {
        // Here we test the uname. Any value is possible but space.
        // On special character sets you might configure the server.
        // (was bug #455288)
        // if ((!$uname) || !(ereg("^[[:print:]]+",$uname) && !ereg("[[:space:]]",$uname))) {
        /**
         * if ((!$uname) || ($uname=="") || (ereg("[^a-zA-Z0-9_-]",$uname))) {
         */

        $stop = "<div style=\"text-align:center\"><span class=\"pn-title\">" . _ERRORINVNICK . "</div></span><br />";
    }
    if (strlen($uname) > 25) {
        $stop = "<div style=\"text-align:center\"><span class=\"pn-title\">" . _NICK2LONG . "</div></span>";
    }
    // Illegal Usernames [class007]
    $reg_illegalusername = trim(pnConfigGetVar('reg_Illegalusername'));
    if (!empty($reg_illegalusername)) {
        $usernames = explode(" ", $reg_illegalusername);
        $count = count($usernames);
        $pregcondition = "/((";
        for ($i = 0;$i < $count;$i++) {
            if ($i != $count-1) {
                $pregcondition .= $usernames[$i] . ")|(";
            } else {
                $pregcondition .= $usernames[$i] . "))/iAD";
            }
        }
        // die ($pregcondition);
        if (preg_match($pregcondition, $uname)) {
            $stop = "<div style=\"text-align:center\"><span class=\"pn-title\">" . _NAMERESERVED . "</div></span>";
        }
    }
    if (strrpos($uname, ' ') > 0) {
        $stop = "<div style=\"text-align:center\"><span class=\"pn-title\">" . _NICKNOSPACES . "</div></span>";
    }
    $column = &$pntable['users_column'];
    $existinguser =& $dbconn->Execute("SELECT $column[uname] FROM $pntable[users] WHERE $column[uname]='" . pnVarPrepForStore($uname) . "'");
    if (!$existinguser->EOF) {
        $stop = "<div style=\"text-align:center\"><span class=\"pn-title\">" . _NICKTAKEN . "</div></span><br />";
    }
    $existinguser->Close();
    $existinguser =& $dbconn->Execute("SELECT $column[email] FROM $pntable[users] WHERE $column[email]='" . pnVarPrepForStore($email) . "'");
    // new by class007
    if (pnConfigGetVar('reg_uniemail')) {
        if (!$existinguser->EOF) {
            $existinguser =& $dbconn->Execute("SELECT $column[email] FROM $pntable[users] WHERE $column[email]='" . pnVarPrepForStore($email) . "'");
            $stop = "<div style=\"text-align:center\"><span class=\"pn-title\">" . _EMAILREGISTERED . "</div></span><br />";
            $existinguser->Close();
        }
    }
    return($stop);
}

/**
 * We do not need this function. [class007]
 * function newuser_user_confirmNewUser($var)
 * {
 * list($uname,$user_viewemail,$email,$agreetoterms) =
 * pnVarCleanFromInput('uname','user_viewemail','email','agreetoterms');
 *
 * include 'header.php';
 *
 * $uname = filter_text($uname);
 *
 * if(isset($user_viewemail) && $user_viewemail == 1) {
 * $user_viewemail = "1";
 * $femail = $email;
 * } else {
 * $user_viewemail = "0";
 * $femail = "-";
 * }
 * if(empty($agreetoterms)) {
 * $agreetoterms = '0';
 * }
 * //Removed if since there is not error checkin in this function it's not necessary.
 * // Audits are completed in the finishnewuser function below. - skooter
 * //if (!$stop) {
 * OpenTable();
 * echo "<span class=\"pn-normal\">"._USERNAME.": ".pnVarPrepForDisplay($uname)."<br />"
 * .""._EMAIL.": ".pnVarPrepForDisplay($email)."<br /></span><br /><br />\n";
 * echo ""._GOBACK."";
 * echo "<form action=\"user.php\" method=\"post\">"
 * ."<input type=\"hidden\" name=\"uname\" value=\"$uname\">"
 * ."<input type=\"hidden\" name=\"email\" value=\"$email\">"
 * ."<input type=\"hidden\" name=\"agreetoterms\" value=\"$agreetoterms\">"
 * ."<input type=\"hidden\" name=\"user_viewemail\" value=\"$user_viewemail\">"
 * ."<input type=\"hidden\" name=\"op\" value=\"finishnewuser\">"
 * ."<input type=\"hidden\" name=\"module\" value=\"NS-NewUser\">"
 * ."<input type=\"submit\" value=\""._FINISH."\"></form>";
 * CloseTable();
 * //} else {
 * //    OpenTable();
 * //    echo "<div style=\"text-align:center\"><span class=\"pn-title\">Registration Error!</span><br /><br />";
 * //    echo "<span class=\"pn-normal\">$stop<br />"._GOBACK."</span></div>";
 * //    CloseTable();
 * //}
 * include 'footer.php';
 * }
 */

function newuser_user_finishnewuser($var)
{
    $dbconn =& pnDBGetConn(true);
    $pntable =& pnDBGetTables();

    list($name,
        $agreetoterms,
        $email,
        $femail,
        $vemail,
        $url,
        $pass,
        $vpass,
        $bio,
        $uname,
        $user_avatar,
        $user_icq,
        $user_occ,
        $user_from,
        $user_intrest,
        $user_sig,
        $user_aim,
        $user_yim,
        $user_msnm,
        $user_viewemail,
        $timezoneoffset,
        $dynadata) = pnVarCleanFromInput('name',
        'agreetoterms',
        'email',
        'femail',
        'vemail',
        'url',
        'pass',
        'vpass',
        'bio',
        'uname',
        'user_avatar',
        'user_icq',
        'user_occ',
        'user_from',
        'user_intrest',
        'user_sig',
        'user_aim',
        'user_yim',
        'user_msnm',
        'user_viewemail',
        'timezoneoffset',
        'dynadata');

    $system = pnConfigGetVar('system');
    $adminmail = pnConfigGetVar('adminmail');
    $sitename = pnConfigGetVar('sitename');
    $siteurl = pnGetBaseURL();
    $Default_Theme = pnConfigGetVar('Default_Theme');
    $commentlimit = pnConfigGetVar('commentlimit');
    $storynum = pnConfigGetVar('storyhome');
    if (!pnConfigGetVar('reg_optitems')) {
            // if we don't show optional items
            // we should set the timezone based on site settings
            $timezoneoffset = pnConfigGetVar('timezone_offset');
    }
    $minpass = pnConfigGetVar('minpass'); //by class007

    include 'header.php';
    $stop = userCheck($uname, $email, $agreetoterms);
    // add vpass and vemail check. by class007
    // TODO: remove it to userCheck() [class007]
    if ((isset($pass)) && ("$pass" != "$vpass")) {
        $stop = "<div style=\"text-align:center\"><span class=\"pn-title\">" . _PASSDIFFERENT . "</div></span><br /><br /><br /><br />";
    } elseif (($pass != "") && (strlen($pass) < $minpass)) {
        $stop = "<div style=\"text-align:center\"><span class=\"pn-title\">" . _YOURPASSMUSTBE . " $minpass " . _CHARLONG . "</div></span><br /><br /><br /><br />";
    } elseif (empty($pass) && !pnConfigGetVar('reg_verifyemail')) {
        $stop = "<div style=\"text-align:center\"><span class=\"pn-title\">" . _PASSWDNEEDED . "</div></span><br /><br /><br /><br />";
    } elseif ("$email" != "$vemail") {
        $stop = "<div style=\"text-align:center\"><span class=\"pn-title\">" . _EMAILSDIFF . "</div></span><br /><br /><br /><br />";
    }
    $user_regdate = time();
    if (empty($user_avatar)) $user_avatar = 'blank.gif';
    if (empty($stop)) {
        if (pnConfigGetVar('reg_verifyemail')) {
            $makepass = makepass();
            $cryptpass = md5($makepass);
        } else {
            $makepass = $pass; // for welcome email. [class007]
            $cryptpass = md5($pass);
        }
		
		// some additional checks
		if (!empty($femail)) {
			$femail = preg_replace('/[^a-zA-Z0-9_@.-]/', '', $femail);
		} 
		if (!empty($url)) {
			if (!eregi("^http://[\-\.0-9a-z]+", $url)) {
				$url = "http://" . $url;
			} 
			$url = preg_replace('/[^a-zA-Z0-9_@.&#?;:\/-]/', '', $url);
		}
		// end of additional checks
		 
        $uid = $dbconn->GenId($pntable['users']);
        $column = &$pntable['users_column'];
        $result =& $dbconn->Execute("INSERT INTO $pntable[users] ($column[name], $column[uname], $column[email],
                           $column[femail], $column[url], $column[user_avatar], $column[user_regdate], $column[user_icq],
                           $column[user_occ], $column[user_from], $column[user_intrest], $column[user_sig],
                           $column[user_viewemail], $column[user_theme], $column[user_aim], $column[user_yim],
                           $column[user_msnm], $column[pass], $column[storynum], $column[umode], $column[uorder],
                           $column[thold], $column[noscore], $column[bio], $column[ublockon], $column[ublock],
                           $column[theme], $column[commentmax], $column[counter], $column[timezone_offset])
                           VALUES ('" . pnVarPrepForStore($name) . "','" . pnVarPrepForStore($uname) . "',
                           '" . pnVarPrepForStore($email) . "','" . pnVarPrepForStore($femail) . "',
                           '" . pnVarPrepForStore($url) . "','" . pnVarPrepForStore($user_avatar) . "',
                           '" . pnVarPrepForStore($user_regdate) . "','" . pnVarPrepForStore($user_icq) . "',
                           '" . pnVarPrepForStore($user_occ) . "','" . pnVarPrepForStore($user_from) . "',
                           '" . pnVarPrepForStore($user_intrest) . "','" . pnVarPrepForStore($user_sig) . "',
                           '" . pnVarPrepForStore($user_viewemail) . "','',
                           '" . pnVarPrepForStore($user_aim) . "','" . pnVarPrepForStore($user_yim) . "',
                           '" . pnVarPrepForStore($user_msnm) . "','" . pnVarPrepForStore($cryptpass) . "',
                           '" . pnVarPrepForStore($storynum) . "','',0,0,0,'" . pnVarPrepForStore($bio) . "',0,'','',
                           '" . pnVarPrepForStore($commentlimit) . "', '0', '" . pnVarPrepForStore($timezoneoffset) . "')");
        // insert dynadata [class007]
        if (!empty($dynadata) && is_array($dynadata)) {
            while (list($key, $val) = each($dynadata)) {
                pnUserSetVar($key, $val);
            }
        }

        if ($dbconn->ErrorNo() <> 0) {
            echo $dbconn->ErrorNo() . ": " . $dbconn->ErrorMsg() . "<br />";
            error_log ($dbconn->ErrorNo() . ": " . $dbconn->ErrorMsg() . "<br />");
        } else {
            // get the generated id
            $uid = $dbconn->PO_Insert_ID($pntable['users'], $column['uid']);

			// Let any hooks know that we have created a new item
			pnModCallHooks('item', 'create', $uid, 'uid');

            // Add user to group
            $column = &$pntable['groups_column'];
            $result =& $dbconn->Execute("SELECT $column[gid]
                                      FROM $pntable[groups]
                                      WHERE $column[name]='" . pnConfigGetVar('defaultgroup') . "'");
            if ($dbconn->ErrorNo() <> 0) {
                echo $dbconn->ErrorNo() . _GETGROUP . $dbconn->ErrorMsg() . "<br />";
                error_log ($dbconn->ErrorNo() . _GETGROUP . $dbconn->ErrorMsg() . "<br />");
            } else {
                if (!$result->EOF) {
                    list($gid) = $result->fields;
                    $result->Close();
                    $column = &$pntable['group_membership_column'];
                    $result =& $dbconn->Execute("INSERT INTO $pntable[group_membership] ($column[gid], $column[uid])
                                              VALUES (" . pnVarPrepForStore($gid) . ", " . pnVarPrepForStore($uid) . ")");
                    if ($dbconn->ErrorNo() <> 0) {
                        echo $dbconn->ErrorNo() . _CREATEGROUP . $dbconn->ErrorMsg() . "<br />";
                        error_log ($dbconn->ErrorNo() . _CREATEGROUP . $dbconn->ErrorMsg() . "<br />");
                    }
                }
                $message = "" . _WELCOMETO . " $sitename ($siteurl)!\n\n" . _YOUUSEDEMAIL . " ($email) " . _TOREGISTER . " $sitename. " . _FOLLOWINGMEM . "\n\n" . _UNICKNAME . " $uname\n" . _UPASSWORD . " $makepass";
                $subject = "" . _USERPASS4 . " $uname" . _USERPASS42 . "";
                $from = "$adminmail";
                /**
                 * if ($system == 1) {
                 * echo "<table align=\"center\"><tr><td><span class=\"pn-normal\">"._YOURPASSIS." <strong>$makepass</strong></span><br />";
                 * echo "<a class=\"pn-normal\" href=\"user.php?module=NS-User&op=login&uname=$uname&pass=$makepass&url=user.php\">"._LOGIN."</a><span class=\"pn-normal\"> "._2CHANGEINFO."</span></td></tr></table>";
                 * } else {
                 */
                // 11-09-01 eugeniobaldi not compliant with PHP < 4.0.5
                // pnMail($email, $subject, $message, "From: $from\nX-Mailer: PHP/" . phpversion(), "-f$from");
                // if (pnConfigGetVar('reg_verifyemail')) {
                pnMail($email, $subject, $message, "From: $from\nX-Mailer: PHP/" . phpversion(), 0);
                // }
                if (pnConfigGetVar('reg_notifyemail') != "") {
                    $email2 = pnConfigGetVar('reg_notifyemail');
                    $subject2 = _NOTIFYEMAILSUB;
                    $message2 = _NOTIFYEMAILCONT1 . "$uname" . _NOTIFYEMAILCONT2;
                    pnMail($email2, $subject2, $message2, "From: $from\nX-Mailer: PHP/" . phpversion(), 0);
                }

                OpenTable();
                echo "<span class=\"pn-normal\">" . _YOUAREREGISTERED . "</span>";
                CloseTable();
            }
        }
    } else {
        echo "$stop";
    }
    include 'footer.php';
}

function optionalitems() {
     $size = 35;
     $dbconn =& pnDBGetConn(true);
     $pntable =& pnDBGetTables();

     //OpenTable();
     $propertytable = $pntable['user_property'];
     $propertycolumn = &$pntable['user_property_column'];

     $sql = "select " . $propertycolumn['prop_id'] . " AS prop_id, " . $propertycolumn['prop_label'] . " AS prop_label, " . $propertycolumn['prop_dtype'] . " AS prop_dtype, " . $propertycolumn['prop_length'] . " AS prop_length, " . $propertycolumn['prop_weight'] . " AS prop_weight, " . $propertycolumn['prop_validation'] . " AS prop_validation " . "FROM " . $propertytable . " " . "WHERE " . $propertycolumn['prop_weight'] . "!=0 ORDER BY " . $propertycolumn['prop_weight'];

     $result =& $dbconn->Execute($sql);

     $core_fields = array();
     //echo "<table cellpadding=\"0\" border=\"0\" class=\"pn-normal\">";
     while (!$result->EOF) {
         list($prop_id, $prop_label, $prop_dtype, $prop_length, $prop_weight, $prop_validation) = $result->fields;
         $result->MoveNext();
         // do not display email & fakeemail & password
         if ($prop_label != "_UREALEMAIL" && $prop_label != "_PASSWORD") {
             $prop_label_text = "";
             $eval_cmd = "\$prop_label_text=$prop_label;";
             @eval($eval_cmd);
             if (empty($prop_label_text)) {
                 $prop_label_text = $prop_label;
             }

             echo "<tr><td valign=\"top\" align=\"right\">" . $prop_label_text . ":</td>" . "<td valign=\"top\" class=\"pn-normal\">";
             switch ($prop_dtype) {
                 case _UDCONST_MANDATORY;
                 case _UDCONST_CORE;
                     $core_fields[] = $prop_label;
                     switch ($prop_label) {
                         case "_UREALNAME":
                             echo "<input type=\"text\" name=\"name\" value=\"" . pnVarPrepForDisplay(pnUserGetVar('name')) . "\" size=\"$size\" maxlength=\"60\" />";
                             break;
                         case "_UREALEMAIL":
                             // echo "<input type=\"text\" name=\"email\" value=\"" . pnVarPrepForDisplay(pnUserGetVar('email')) . "\" size=\"$size\" maxlength=\"60\">"
                             // ."&nbsp;"._REQUIRED."&nbsp;"._EMAILNOTPUBLIC."</td>";
                             break;
                         case "_UFAKEMAIL":
                             echo "<input type=\"text\" name=\"femail\" value=\"" . pnVarPrepForDisplay(pnUserGetVar('femail')) . "\" size=\"$size\" maxlength=\"60\" />";
                             break;
                         case "_YOURHOMEPAGE":
                             echo "<input type=\"text\" name=\"url\" value=\"" . pnVarPrepForDisplay(pnUserGetVar('url')) . "\" size=\"$size\" maxlength=\"100\" />";
                             break;
                         case "_TIMEZONEOFFSET":
                             $tzoffset = pnConfigGetVar('timezone_offset');
                             global $tzinfo;
                             echo "<select name=\"timezoneoffset\" class=\"pn-normal\">";
                             foreach ($tzinfo as $tzindex => $tzdata) {
                                 echo "\n<option value=\"$tzindex\"";
                                 if ($tzoffset == $tzindex) {
                                     echo 'selected="selected"';
                                 }
                                 echo ">";
                                 echo pnVarPrepHTMLDisplay($tzdata);
                                 echo "</option>";
                             }
                             echo "</select>";
                             break;
                         case "_YOURAVATAR":
                             $user_avatar = pnUserGetVar('user_avatar');
                             echo "<select name=\"user_avatar\" onchange=\"showimage()\" class=\"pn-normal\">";
                             $handle = opendir('images/avatar');
                             while ($file = readdir($handle)) {
                                 $filelist[] = $file;
                             }
                             asort($filelist);
                             while (list ($key, $file) = each ($filelist)) {
                                 ereg(".gif|.jpg", $file);
                                 if ($file != "." && $file != ".." && $file != "CVS" && $file != "index.html") {
                                                                         echo "<option value=\"$file\"";
                                         if ($file == "blank.gif") {
                                         echo 'selected="selected"';
                                         }
                                         echo ">$file</option>";
                                 }
                             }
                             echo "</select>&nbsp;&nbsp;<img src=\"images/avatar/blank.gif\" name=\"avatar\" style=\"width:32\" height=\"32\" alt=\"\" />";
                             break;
                         case "_YICQ":
                             echo "<input type=\"text\" name=\"user_icq\" value=\"" . pnVarPrepForDisplay(pnUserGetVar('user_icq')) . "\" size=\"$size\" maxlength=\"100\" />";
                             break;
                         case "_YAIM":
                             echo "<input type=\"text\" name=\"user_aim\" value=\"" . pnVarPrepForDisplay(pnUserGetVar('user_aim')) . "\" size=\"$size\" maxlength=\"100\" />";
                             break;
                         case "_YYIM":
                             echo "<input type=\"text\" name=\"user_yim\" value=\"" . pnVarPrepForDisplay(pnUserGetVar('user_yim')) . "\" size=\"$size\" maxlength=\"100\" />";
                             break;
                         case "_YMSNM":
                             echo "<input type=\"text\" name=\"user_msnm\" value=\"" . pnVarPrepForDisplay(pnUserGetVar('user_msnm')) . "\" size=\"$size\" maxlength=\"100\" />";
                             break;
                         case "_YLOCATION":
                             echo "<input type=\"text\" name=\"user_from\" value=\"" . pnVarPrepForDisplay(pnUserGetVar('user_from')) . "\" size=\"$size\" maxlength=\"100\" />";
                             break;
                         case "_YOCCUPATION":
                             echo "<input type=\"text\" name=\"user_occ\" value=\"" . pnVarPrepForDisplay(pnUserGetVar('user_occ')) . "\" size=\"$size\" maxlength=\"100\" />";
                             break;
                         case "_YINTERESTS":
                             echo "<input type=\"text\" name=\"user_intrest\" value=\"" . pnVarPrepForDisplay(pnUserGetVar('user_intrest')) . "\" size=\"$size\" maxlength=\"100\" />";
                             break;
                         case "_SIGNATURE":
                             echo "<textarea cols=\"80\" rows=\"10\" name=\"user_sig\" class=\"pn-normal\">" . pnVarPrepForDisplay(pnUserGetVar('user_sig')) . "</textarea>" . "<br /><span class=\"pn-normal\">" . _OPTIONAL . "" . "&nbsp;" . _255CHARMAX . "<br />" . "" . _ALLOWEDHTML . "<br />";
                             $AllowableHTML = pnConfigGetVar('AllowableHTML');
                             while (list($key, $access,) = each($AllowableHTML)) {
                                 if ($access > 0) echo " &lt;" . $key . "&gt;";
                             }
                             echo "</span>";
                             break;
                         case "_EXTRAINFO":
                             echo "<textarea cols=\"80\" rows=\"10\" name=\"bio\" class=\"pn-normal\">" . pnVarPrepForDisplay(pnUserGetVar('bio')) . "</textarea>" . "&nbsp;<br /><span class=\"pn-normal\">" . _CANKNOWABOUT . "</span>";
                             break;

                         case "_PASSWORD":
                             // echo "<input type=\"password\" name=\"pass\" size=\"10\" maxlength=\"20\">&nbsp;&nbsp;<input type=\"password\" name=\"vpass\" size=\"10\" maxlength=\"20\">"
                             // ."&nbsp;<span class=\"pn-normal\">"._TYPENEWPASSWORD."</span>";
                             break;
                         default:
                             echo "Undefined $prop_id, $prop_label, $prop_dtype, $prop_length, $prop_weight, $prop_validation";
                     }
                     break;

                 case _UDCONST_STRING:
                     if (empty($prop_length)) $prop_length = 30;
                     echo "<input type=\"text\" name=\"dynadata[$prop_label]\" value=\"" . pnVarPrepForDisplay(pnUserGetVar($prop_label)) . "\" size=\"$size\" maxlength=\"$prop_length\" />";
                     break;

                 case _UDCONST_TEXT:
                     echo "<textarea wrap=\"virtual\" cols=\"80\" rows=\"10\" name=\"dynadata[$prop_label]\" class=\"pn-normal\">" . pnVarPrepForDisplay(pnUserGetVar($prop_label)) . "</textarea>";
                     break;

                 case _UDCONST_FLOAT:
                 case _UDCONST_INTEGER:
                     echo "<input type=\"text\" name=\"dynadata[$prop_label]\" value=\"" . pnVarPrepForDisplay(pnUserGetVar($prop_label)) . "\" size=\"$size\" maxlength=\"100\" />";
                     break;
             }
             echo "</td></tr>";
         }
     }
     //echo "</table>";

     //CloseTable();
}
?>
