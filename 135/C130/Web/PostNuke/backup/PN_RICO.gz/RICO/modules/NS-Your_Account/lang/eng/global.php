<?php
// Generated: $d$ by $id$
// ----------------------------------------------------------------------
// PostNuke Content Management System
// Copyright (C) 2001 by The PostNuke Development Team.
// http://www.postnuke.com/
// ----------------------------------------------------------------------
// Based on:
// PHP-NUKE Web Portal System - http://phpnuke.org/
// Thatware - http://thatware.org/
// ----------------------------------------------------------------------
// LICENSE
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License (GPL)
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU General Public License for more details.
//
// To read the license please visit http://www.gnu.org/copyleft/gpl.html
// ----------------------------------------------------------------------
// Original Author of file: Everyone
// Purpose of file: Translation files
// Translation team: Read credits in /docs/CREDITS.txt
// ----------------------------------------------------------------------
define('_255CHARMAX','(255 characters max. Enter your desired signature, with HTML tags if wanted)');
define('_ACTIVATEPERSONAL','Enable your personal menu block');
define('_CANKNOWABOUT','(255 characters max. Enter any information you would like other users to know about you)');
define('_CHANGEHOME','Edit your home page');
define('_CHANGEYOURINFO','Edit your information');
define('_CHARLONG','characters long');
define('_CHECKTHISOPTION','(If you enable this option, the following text will display on your personal home page)');
define('_EMAILNOTPUBLIC','(This e-mail address will not be public but is required. It will be used to send you your password if you lose it)');
define('_EMAILPUBLIC','(This e-mail address will be public. Type what you\'d like. It\'s spamproof)');
define('_HOMECONFIG','Home page configuration');
define('_MAX127','(max. 127):');
define('_NEWSINHOME','Number of stories on the home page');
define('_PASSDIFFERENT','Sorry! You did not enter the same  password in each password field. Please enter the same password twice (this is for verification).');
define('_PERSONALINFO','Personal information');
define('_SELECTTHEME','Select a theme');
define('_SELECTTHETHEME','Select theme');
define('_THEMESELECTION','Theme selection');
define('_THEMETEXT1','The site theme you choose will change the visual presentation of the whole site for you when you are logged-in.');
define('_THEMETEXT2','The theme you choose will only apply for your visits.');
define('_THEMETEXT3','Each user can view the site with a different theme applied.');
define('_TYPENEWPASSWORD','(Please enter a new password twice, for verification, in order change it)');
define('_YOUCANUSEHTML','(Tip: you can use HTML code to include links to web pages on this site or another site)');
define('_YOURPASSMUSTBE','Sorry! Your password must be at least');
?>