<?php
// File: $Id: dl-viewdownload.php,v 1.27 2004/08/22 18:51:57 larsneo Exp $ $Name: HEAD $
// ----------------------------------------------------------------------
// PostNuke Content Management System
// Copyright (C) 2001 by the PostNuke Development Team.
// http://www.postnuke.com/
// ----------------------------------------------------------------------
// Based on:
// PHP-NUKE Web Portal System - http://phpnuke.org/
// Thatware - http://thatware.org/
// ----------------------------------------------------------------------
// LICENSE
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License (GPL)
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// To read the license please visit http://www.gnu.org/copyleft/gpl.html
// ----------------------------------------------------------------------
// Original Author of file: Francisco Burzi
// Purpose of file:
// ----------------------------------------------------------------------

/**
 * viewdownload
 */
function viewdownload($cid, $min, $orderby, $show) {
	list($cid, $min, $orderby, $show) = pnVarCleanFromInput('cid', 'min', 'orderby', 'show');

    include("header.php");

    if ((!isset($cid) || !is_numeric($cid))){
        echo _MODARGSERROR;
		include('footer.php');
        return false;
    }

    $dbconn =& pnDBGetConn(true);
    $pntable =& pnDBGetTables();

    $perpage = pnConfigGetVar('perpage');

    $cattitle = downloads_CatNameFromCID($cid);
    if (!pnSecAuthAction(0, 'Downloads::Category', "$cattitle::$cid", ACCESS_READ)) {
        echo _DOWNLOADSACCESSNOAUTH;
        include 'footer.php';
        return;
    }

    if (!isset($min) || !is_numeric($min)) $min=0;
    if (!isset($max) || !is_numeric($max)) $max=$min+$perpage;
    if(isset($orderby)) {
        $orderby = convertorderbyin($orderby);
    } else {
        $orderby = $pntable['downloads_downloads_column']['title'] . ' ASC';
    }
    if ($show!="") {
        $perpage = $show;
    } else {
        $show=$perpage;
    }
    menu(1);

    OpenTable();
    $result =& $dbconn->Execute("SELECT ".$pntable['downloads_categories_column']['title'].
                            " FROM ".$pntable['downloads_categories'].
                            " WHERE ".$pntable['downloads_categories_column']['cid']."='".(int)pnVarPrepForStore($cid)."'");

    list($title) = $result->fields;
    echo "<div style=\"text-align:center\"><span class=\"pn-title\">"._CATEGORY.": ".pnVarPrepForDisplay($title)."</span></div><br />";
    $carrytitle = $title;
    $column = &$pntable['downloads_subcategories_column'];
	$sorderby = $pntable['downloads_subcategories_column']['title']. ' ASC';
    $subresult =& $dbconn->Execute("SELECT $column[sid], $column[title]
                               FROM $pntable[downloads_subcategories]
                               WHERE $column[cid]='".(int)pnVarPrepForStore($cid).
					           "' ORDER BY ".$sorderby);
    if (!$subresult->EOF) {
        echo "<div style=\"text-align:center\"><span class=\"pn-sub\">"._DLALSOAVAILABLE." ".pnVarPrepForDisplay($title)." "._SUBCATEGORIES.":</span><br /><br />";
        $scount = 0;

        $downloadscolumn = &$pntable['downloads_downloads_column'];
        $downloadstable = $pntable['downloads_downloads'];

        while(list($sid, $title) = $subresult->fields) {

	    if (downloads_authsubcat($cid, $sid, ACCESS_READ)) {
                $result2 =& $dbconn->Execute("SELECT count(*)
                                             FROM $downloadstable
                                             WHERE $downloadscolumn[sid]='".(int)pnVarPrepForStore($sid)."'");

                list($numrows) = $result2->fields;
		echo "<img src=\"modules/".$GLOBALS['ModName']."/images/icon_folder.gif\" alt=\"\" width=\"15\" height=\"13\" />&nbsp;&nbsp;"
		. "<a class=\"pn-normal\" href=\"".$GLOBALS['modurl']."&amp;req=viewsdownload&amp;sid=$sid\">"
		.pnVarPrepForDisplay($title)."</a> <span class=\"pn-normal\">(".pnVarPrepForDisplay($numrows).")</span>";
		subcategorynewlinkgraphic($sid);
		echo "&nbsp;&nbsp;&nbsp;";
                $scount++;
                if ($scount==3) {
                    echo "<br />";
                    $scount = 0;
                }
            }
            $subresult->MoveNext();
        }
        echo "</div><br />";
    }
    //echo "<hr />";
    $orderbyTrans = convertorderbytrans($orderby);
    echo "<div style=\"text-align:center\"><span class=\"pn-sub\">"._SORTDOWNLOADSBY.": "
        .""._TITLE." ( <a class=\"pn-normal\" href=\"".$GLOBALS['modurl']."&amp;req=viewdownload&amp;cid=$cid&amp;orderby=titleA\">+</a> | <a class=\"pn-normal\" href=\"".$GLOBALS['modurl']."&amp;req=viewdownload&amp;cid=$cid&amp;orderby=titleD\">-</a> ) "
        .""._DATE." ( <a class=\"pn-normal\" href=\"".$GLOBALS['modurl']."&amp;req=viewdownload&amp;cid=$cid&amp;orderby=dateA\">+</a> | <a class=\"pn-normal\" href=\"".$GLOBALS['modurl']."&amp;req=viewdownload&amp;cid=$cid&amp;orderby=dateD\">-</a> ) "
        .""._RATING." ( <a class=\"pn-normal\" href=\"".$GLOBALS['modurl']."&amp;req=viewdownload&amp;cid=$cid&amp;orderby=ratingA\">+</a> | <a class=\"pn-normal\" href=\"".$GLOBALS['modurl']."&amp;req=viewdownload&amp;cid=$cid&amp;orderby=ratingD\">-</a> ) "
        .""._POPULARITY." ( <a class=\"pn-normal\" href=\"".$GLOBALS['modurl']."&amp;req=viewdownload&amp;cid=$cid&amp;orderby=hitsA\">+</a> | <a href=\"".$GLOBALS['modurl']."&amp;req=viewdownload&amp;cid=$cid&amp;orderby=hitsD\">-</a> )"
        ."<br />"._RESSORTED.":$orderbyTrans</span></div><br /><br />";
    $column = &$pntable['downloads_downloads_column'];
    $sql = "SELECT $column[lid], $column[url], $column[title],
                   $column[description], $column[date], $column[hits],
                   $column[downloadratingsummary], $column[totalvotes],
                   $column[totalcomments], $column[filesize],
                   $column[version], $column[homepage]
            FROM $pntable[downloads_downloads]
            WHERE $column[cid]='".pnVarPrepForStore($cid)."'
            AND $column[sid]=0 ORDER BY $orderby";

    $result =& $dbconn->SelectLimit($sql,$perpage,$min);

    $fullcountresult =& $dbconn->Execute("SELECT $column[lid], $column[title],
                                              $column[description], $column[date],
                                              $column[hits], $column[downloadratingsummary],
                                              $column[totalvotes], $column[totalcomments]
                                       FROM $pntable[downloads_downloads]
                                       WHERE $column[cid]='".(int)pnVarPrepForStore($cid)."' AND $column[sid]=0");
    $totalselecteddownloads = $fullcountresult->PO_RecordCount();

    echo "<span class=\"pn-normal\">";

    while(list($lid, $url, $title, $description, $time, $hits, $downloadratingsummary, $totalvotes, $totalcomments, $filesize, $version, $homepage)=$result->fields) {
        $result->MoveNext();
		# Fixes layout of the description in downloads annoying without this - Neo
		$description = nl2br($description);
	    downloads_outputitem ($lid, $url, $title, $description, $time, $hits, $downloadratingsummary, $totalvotes, $totalcomments, $filesize, $version, $homepage, $GLOBALS['modurl'], $GLOBALS['ModName']);
    }

    echo "</span>";

	$orderbyPager = convertorderbypager($orderby);
    downloads_outputpagelinks($cid, $GLOBALS['modurl'], $orderbyPager, $totalselecteddownloads, $perpage, $min, $max, $show, "viewdownload", "cid");

    CloseTable();
    include("footer.php");
}

function viewsdownload($sid, $min, $orderby, $show)
{
	list($sid, $min, $orderby, $show) = pnVarCleanFromInput('sid', 'min', 'orderby', 'show');

    include("header.php");

    if ( (!isset($sid) || !is_numeric($sid)) ){
        echo _MODARGSERROR;
		include('footer.php');
        return false;
    }

    $dbconn =& pnDBGetConn(true);
    $pntable =& pnDBGetTables();

    menu(1);

    $perpage = pnConfigGetVar('perpage');

    $column = &$pntable['downloads_subcategories_column'];
    $result =& $dbconn->Execute("SELECT $column[cid], $column[title]
                              FROM $pntable[downloads_subcategories]
                              WHERE $column[sid]='".(int)pnVarPrepForStore($sid)."'");
    list($cid, $stitle) = $result->fields;

    $column = &$pntable['downloads_categories_column'];
    $result2 =& $dbconn->Execute("SELECT $column[cid], $column[title]
                               FROM $pntable[downloads_categories]
                               WHERE $column[cid]='".(int)pnVarPrepForStore($cid)."'");
    list($cid, $title) = $result2->fields;

// DJD - Fix - Auth used to be called with Cat name instead of SubCat Name 04/06/2002

    if (downloads_authsubcat($cid, $sid, "ACCESS_READ")) {
        echo _DOWNLOADSACCESSNOAUTH;
        include 'footer.php';
        return;
    }

    if (!isset($min)) $min=0;
    if (!isset($max)) $max=$min+$perpage;
    if(isset($orderby)) {
        $orderby = convertorderbyin($orderby);
    } else {
        $orderby = convertorderbyin("titleA");
    }
    if ($show != "") {
        $perpage = $show;
    } else {
        $show = $perpage;
    }

    OpenTable();

    echo "<br /><div style=\"text-align:center\"><span class=\"pn-title\"><a class=\"pn-normal\" href=\"".$GLOBALS['modurl']."\">"._MAIN."</a> / <a class=\"pn-normal\" href=\"".$GLOBALS['modurl']."&amp;req=viewdownload&amp;cid=$cid\">".pnVarPrepForDisplay($title)."</a> / ".pnVarPrepForDisplay($stitle)."</span><br />";
    $orderbyTrans = convertorderbytrans($orderby);

    echo "<br /><span class=\"pn-sub\">"._SORTDOWNLOADSBY.": "
    .""._TITLE." ( <a class=\"pn-normal\" href=\"".$GLOBALS['modurl']."&amp;req=viewsdownload&amp;sid=$sid&amp;orderby=titleA\">+</a> | <a href=\"".$GLOBALS['modurl']."&amp;req=viewsdownload&amp;sid=$sid&amp;orderby=titleD\">-</a> )"
    ." "._DATE." ( <a class=\"pn-normal\" href=\"".$GLOBALS['modurl']."&amp;req=viewsdownload&amp;sid=$sid&amp;orderby=dateA\">+</a> | <a href=\"".$GLOBALS['modurl']."&amp;req=viewsdownload&amp;sid=$sid&amp;orderby=dateD\">-</a> )"
    ." "._RATING." ( <a class=\"pn-normal\" href=\"".$GLOBALS['modurl']."&amp;req=viewsdownload&amp;sid=$sid&amp;orderby=ratingA\">+</a> | <a href=\"".$GLOBALS['modurl']."&amp;req=viewsdownload&amp;sid=$sid&amp;orderby=ratingD\">-</a> )"
    ." "._POPULARITY." ( <a class=\"pn-normal\" href=\"".$GLOBALS['modurl']."&amp;req=viewsdownload&amp;sid=$sid&amp;orderby=hitsA\">+</a> | <a href=\"".$GLOBALS['modurl']."&amp;req=viewsdownload&amp;sid=$sid&amp;orderby=hitsD\">-</a> )"
    ."<br />"._RESSORTED.": $orderbyTrans</span></div><br /><br />";

    $column = &$pntable['downloads_downloads_column'];
    $sql = "SELECT $column[lid], $column[url], $column[title],
                   $column[description], $column[date], $column[hits],
                   $column[downloadratingsummary], $column[totalvotes],
                   $column[totalcomments], $column[filesize],
                   $column[version], $column[homepage]
            FROM $pntable[downloads_downloads]
            WHERE $column[sid]='".(int)pnVarPrepForStore($sid)."'
            ORDER BY $orderby";

    $result =& $dbconn->SelectLimit($sql,$perpage,$min);
//
// Temporary Fixed       eugeniobaldi 01/07/11
//                            ORDER BY  {$column[$orderby]} LIMIT $min,$perpage");
    $fullcountresult =& $dbconn->Execute("SELECT $column[lid], $column[title],
                                              $column[description], $column[date],
                                              $column[hits], $column[downloadratingsummary],
                                              $column[totalvotes], $column[totalcomments]
                                       FROM $pntable[downloads_downloads]
                                       WHERE $column[sid]='".(int)pnVarPrepForStore($sid)."'");

    $totalselecteddownloads = $fullcountresult->PO_RecordCount();

    echo "<span class=\"pn-normal\">";

    while(list($lid, $url, $title, $description, $time, $hits, $downloadratingsummary, $totalvotes, $totalcomments, $filesize, $version, $homepage) = $result->fields) {
        $result->MoveNext();
		$description = nl2br($description);		
		downloads_outputitem ($lid, $url, $title, $description, $time, $hits, $downloadratingsummary, $totalvotes, $totalcomments, $filesize, $version, $homepage, $GLOBALS['modurl'], $GLOBALS['ModName']);
    }

    echo "</span>";

	$orderbyPager = convertorderbypager($orderby);
    downloads_outputpagelinks($sid, $GLOBALS['modurl'], $orderbyPager, $totalselecteddownloads, $perpage, $min, $max, $show, "viewsdownload", "sid");

    CloseTable();
    include 'footer.php';
}
?>