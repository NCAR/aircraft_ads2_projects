<?php
// $Id: pnversion.php,v 1.1.1.1 2002/09/15 22:26:15 root Exp $
$modversion['name'] = 'Blocks administration';
$modversion['version'] = '2.0';
$modversion['description'] = 'Administration of side and centre blocks';
$modversion['credits'] = '';
$modversion['help'] = '';
$modversion['changelog'] = '';
$modversion['license'] = '';
$modversion['official'] = 1;
$modversion['author'] = 'Jim McDonald';
$modversion['contact'] = 'http://www.mcdee.net/';
$modversion['admin'] = 1;
$modversion['securityschema'] = array('Blocks::' => 'Block key:Block title:Block ID');

?>