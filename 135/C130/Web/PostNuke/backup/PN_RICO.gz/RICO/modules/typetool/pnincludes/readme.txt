Please read file "index.html" to see HOW TO USE.
and file "licence-LGPL.txt" to know copyright (GPL) 
Release by Vietdev : http://vietdev.sourceforge.net

Release Date: Sep-26-2002 (R5.0 / R10.0)
Release Date: Oct-05-2002 (R5.1 / R10.1)
Release Date: Oct-20-2002 (R5.5 / R10.5)
Release Date: Oct-31-2002 (R6.0 / R11.0)
Release Date: Mar-16-2003 (R7.0 / R12.0)  (work with Mozilla 1.30)
Release Date: Mai-25-2003 (R7.5 / R12.5)  (tool in Mozilla version)
Release Date: Januar-07-2004 (R8.0 / R14.0)  (insert image, link, separate CSS, languages files)
Release Date: Mar-15-2004 (R9.0)  (editable fontlist, textstyle in languages files)


Contact : ngo_canh@yahoo.com
or visit our forums by Vietdev


THANK YOU ALL WHO ASKED, RESQUESTED, SUGGESTED ME TO DEVELOP THESE SCRIPTS !

Xiao Shibin : where is redo ?
Taki : external stylesheet
Michelangelo: special textarea name "xxxx[iiii]"
Pirl : click on editor to begin editing, error if field hat type "file".
Davetheslave : install error
wickedbob : editor's content not empty, although nothing to see
cdouglas : how to enter newline 
unisoft anstalt : how to enter newline with return button
webmaster at portalzine.de : right click option
Cats : unicode
eddieajau: pre tags
Nam (64vn) : security by upload scripts
larsneo : problem with IE for Mac
frankblack : insert files from upload directory
-uk- : content error by mozilla
and all who have writed questions or requests or suggesions.......
