<?php
// File: $Id: admin.php,v 1.17 2004/05/02 18:02:37 markwest Exp $
// ----------------------------------------------------------------------
// POSTNUKE Content Management System
// Copyright (C) 2001 by the PostNuke Development Team.
// http://www.postnuke.com/
// ----------------------------------------------------------------------
// Based on:
// PHP-NUKE Web Portal System - http://phpnuke.org/
// Thatware - http://thatware.org/
// ----------------------------------------------------------------------
// LICENSE
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License (GPL)
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// To read the license please visit http://www.gnu.org/copyleft/gpl.html
// ----------------------------------------------------------------------
// Original Author of file: Jim McDonald
// Purpose of file:  Group administration
// ----------------------------------------------------------------------

if (!eregi('admin.php', $_SERVER['PHP_SELF'])) { die ('Access Denied'); }

modules_get_language();
modules_get_manual();

/*
 * viewGroups - view groups
 * Takes no parameters
 *
 */
function viewGroups()
{
   $module = pnVarCleanFromInput('module');

    $dbconn =& pnDBGetConn(true);
    $pntable =& pnDBGetTables();

    $grouptable = $pntable['groups'];
    $groupcolumn = &$pntable['groups_column'];

    include("header.php");
    GraphicAdmin();

    // Heading
    OpenTable();
    echo "<div style=\"text-align:center\"><span class=\"pn-title\"><strong>"._GROUPADMIN."</strong></span><br />";

    if (!pnSecAuthAction(0, 'Groups::', '::', ACCESS_EDIT)) {
        echo _GROUPSNOAUTH;
        include 'footer.php';
        return;
    }

    // Options
    if (pnSecAuthAction(0, 'Groups::', '::', ACCESS_ADD)) {
        echo '<br />
              <table border="0" width="100%">
              <tr>
              <td>
              <div style="text-align:center">
                  <a class="pn-title" href="admin.php?module='.$module.'&amp;op=secnewgroup">'._ADDGROUP.'</a>
              </div>
              </td>
              </tr>
              </table>
              <br />';
    }

    // Get and display current groups
    $query = "SELECT $groupcolumn[gid],
                     $groupcolumn[name]
              FROM $grouptable
              ORDER BY $groupcolumn[name]";
    $result =& $dbconn->Execute($query);
    if (!$result->EOF) {
        echo "<table border=\"5\">".
             "<tr class=\"pn-title\">".
             "<td><div style=\"text-align:center\"><span class=\"pn-normal\">"._GROUPNAME."</span></div></td>".
             "<td>&nbsp;</td>".
             "</tr>";

        while(list($gid, $name) = $result->fields) {
            echo '<tr>';
            if (pnSecAuthAction(0, 'Groups::', "$name::$gid", ACCESS_EDIT)) {
                 echo "<td><a href=\"admin.php?module=".$module."&amp;op=secviewgroup&amp;gid=$gid\">".pnVarPrepForDisplay($name)."</a></td>";
                 if (pnSecAuthAction(0, 'Groups::', "$name::$gid", ACCESS_DELETE)) {
                     echo "<td>"
                     ."<form action=\"admin.php\" method=\"post\"><div>"
                     ."<input type=\"hidden\" name=\"module\" value=\"".$module."\" />"
                     ."<input type=\"hidden\" name=\"op\" value=\"secdeletegroup\" />"
                     ."<input type=\"hidden\" name=\"gid\" value=\"$gid\" />"
                     .'<input type="hidden" name="authid" value="' . pnSecGenAuthKey() . '" />'
                     .'<input type="submit" value="'._DELETE.'" />'
                     .'</div></form></td>';
                 } else {
                     echo "<td>&nbsp;</td>";
                 }
            }
            echo "</tr>";
            $result->MoveNext();
        }
        echo "</table></div>";

    }

    CloseTable();
    include("footer.php");
}

/*
 * viewGroup - view a group
 * Takes one parameter:
 * - the gid
 */
function viewGroup()
{
    $gid = pnVarCleanFromInput('gid');
    $module = pnVarCleanFromInput('module');

    $dbconn =& pnDBGetConn(true);
    $pntable =& pnDBGetTables();

    $grouptable = $pntable['groups'];
    $groupcolumn = &$pntable['groups_column'];
    $groupmembershiptable = $pntable['group_membership'];
    $groupmembershipcolumn = &$pntable['group_membership_column'];
    $usertable = $pntable['users'];
    $usercolumn = &$pntable['users_column'];

    include("header.php");
    GraphicAdmin();

    // Get details on current group
    $query = "SELECT $groupcolumn[name]
              FROM $grouptable
              WHERE $groupcolumn[gid]='".(int)pnVarPrepForStore($gid)."'";
    $result =& $dbconn->Execute($query);
    if ($result->EOF) {
        die("No such group ID $gid");
    }

    list($gname) = $result->fields;
    $result->Close();

    // Heading
    OpenTable();
    echo "<div style=\"text-align:center\"><a href=\"admin.php?module=".$module."&amp;op=secviewgroups\" class=\"pn-title\"><strong>"
    ._GROUPADMIN."</strong></a><span class=\"pn-title\"><strong>: ".pnVarPrepForDisplay($gname)."</strong></span></div>";

    if (!pnSecAuthAction(0, 'Groups::', "$gname::$gid", ACCESS_EDIT)) {
        echo _GROUPSNOAUTH;
        CloseTable();
        include 'footer.php';
        return;
    }

    // Group options
    echo "<br />".
         "<table border=\"0\" width=\"100%\">".
         "<tr>";
    if (pnSecAuthAction(0, 'Groups::', "$gname::$gid", ACCESS_EDIT)) {
        echo "<td><div style=\"text-align:center\"><a href=\"admin.php?module=".$module."&amp;op=secselectuserforgroup&amp;gid=$gid\"><span class=\"pn-title\">"
        ._ADDUSERTOGROUP."</span></a></div></td>".
         "<td><div style=\"text-align:center\"><a href=\"admin.php?module=".$module."&amp;op=secmodifygroup&amp;gid=$gid\"><span class=\"pn-title\">"
         ._MODIFYGROUP."</span></a></div></td>";
/*        if (pnSecAuthAction(0, 'Groups::', "$gname::$gid", ACCESS_DELETE)) {
            echo "<td><a href=\"admin.php?module=".$module."&amp;op=secdeletegroup&amp;gid=$gid&amp;ok=0\"><div style=\"text-align:center\"><span class=\"pn-title\">"
            ._DELETEGROUP."</span></div></a></td>";
        }
*/
    }
    echo "</tr>".
         "</table>".
         "<br />";


    // Get users in this group
    $query = "SELECT $groupmembershipcolumn[uid]
              FROM $groupmembershiptable
              WHERE $groupmembershipcolumn[gid]='".(int)pnVarPrepForStore($gid)."'";
    $result =& $dbconn->Execute($query);
    if (!$result->EOF) {
        for(;list($uid) = $result->fields;$result->MoveNext() ) {
            $uids[] = $uid;
        }
        $result->Close();
        $uidlist=implode(",", $uids);

        // Get names of users
        $query = "SELECT $usercolumn[uname],
                         $usercolumn[uid]
                  FROM $usertable
                  WHERE $usercolumn[uid] IN ($uidlist)
                  ORDER BY $usercolumn[uname]";
        $result =& $dbconn->Execute($query);

        echo "<div style=\"text-align:center\"><strong><span class=\"pn-normal\">"._USERSINGROUP."</span></strong><br />".
             "<table border=\"1\">".
             "<tr>".
             "<td><div style=\"text-align:center\"><span class=\"pn-normal\">"._USERNAME."</span></div></td>".
             "<td>&nbsp;</td>".
             "</tr>";

        while(list($uname, $uid) = $result->fields) {
            echo "<tr>".
                 "<td>".pnVarPrepForDisplay($uname)."</td>";
            if (pnSecAuthAction(0, 'Groups::', "$gname::$gid", ACCESS_DELETE)) {
                echo "<td><a href=\"admin.php?module=".$module."&amp;op=secdeleteuserfromgroup&amp;uid=$uid&amp;gid=$gid\">"
                ._DELETE."</a></td>";
            } else {
                echo "<td>&nbsp;</td>";
            }
            echo "</tr>";
            $result->MoveNext();
        }
        $result->Close();
        echo "</table></div><br />";
    } else {
        echo "<div style=\"text-align:center\"><strong><span class=\"pn-normal\">"._NOONEINGROUP."</span></strong></div>";
    }

    CloseTable();
    include("footer.php");

}

/*
 * newGroup - create a new group
 * Takes no parameters
 */
function newGroup()
{
    $module = pnVarCleanFromInput('module');
    include("header.php");
    GraphicAdmin();

    // Heading
    OpenTable();
    echo "<div style=\"text-align:center\"><a href=\"admin.php?module=".$module."&amp;op=secviewgroups\" class=\"pn-title\"><strong>"
    ._GROUPADMIN."</strong></a></div>";
    echo "<br />";

    if (!pnSecAuthAction(0, 'Groups::', '::', ACCESS_ADD)) {
        echo _GROUPSADDNOAUTH;
        CloseTable();
        include 'footer.php';
        return;
    }

    echo "<form action=\"admin.php\" method=\"post\"><div>"
         ."<input type=\"hidden\" name=\"module\" value=\"".$module."\" />"
         ."<input type=\"hidden\" name=\"op\" value=\"secaddgroup\" />"
		 ."<span class=\"pn-normal\"><input type=\"hidden\" name=\"authid\" value=\"" . pnSecGenAuthKey() . "\" />"
         ._GROUPNAME. ": <input type=\"text\" name=\"gname\" />"
         ."<input type=\"submit\" value=\""._NEWGROUP."\" />"
         ."</span></div></form>";

    CloseTable();
    include("footer.php");
}

/*
 * addGroup - add a group
 * Takes one parameter:
 * - the group name
 */
function addGroup()
{
    $gname = pnVarCleanFromInput('gname');
    $module = pnVarCleanFromInput('module');

    if (!pnSecConfirmAuthKey()) {
        include 'header.php';
        echo _BADAUTHKEY;
        include 'footer.php';
        exit;
    }
    $dbconn =& pnDBGetConn(true);
    $pntable =& pnDBGetTables();

    if (!pnSecAuthAction(0, 'Groups::', "$gname::", ACCESS_ADD)) {
        include 'header.php';
        GraphicAdmin();
        OpenTable();
        echo _GROUPSADDNOAUTH;
        CloseTable();
        include 'footer.php';
        return;
    }

	if ($gname == '') {
        include 'header.php';
        echo _MODARGSERROR;
        include 'footer.php';
        exit;
	}
    $grouptable = $pntable['groups'];
    $groupcolumn = &$pntable['groups_column'];

    // Confirm that this group does not already exist
    $query = "SELECT COUNT(*) FROM $grouptable
              WHERE $groupcolumn[name] = '".pnVarPrepForStore($gname)."'";

    $result =& $dbconn->Execute($query);

    list($count) = $result->fields;
    $result->Close();
    if ($count == 1) {
        include("header.php");
        GraphicAdmin();
        OpenTable();
        echo "<div style=\"text-align:center\"><a href=\"admin.php?module=".$module."&amp;op=secviewgroups\" class=\"pn-title\"><strong>"
        ._GROUPADMIN."</strong></a>:<span class=\"pn-normal\"> ".pnVarPrepForDisplay($gname)."</span></div>";
        echo "<br />";
        echo _GROUPALREADYEXISTS;
    } else {
        $nextId = $dbconn->GenId($grouptable);
        $query = "INSERT INTO $grouptable
                  VALUES ($nextId, \"$gname\")";

        $dbconn->Execute($query);
		// Let any hooks know that we have created a new link
		pnModCallHooks('item', 'create', $nextId, 'gid');

        pnRedirect('admin.php?module='.$module.'&op=secviewgroups');
    }
}

/*
 * deleteGroup - delete a group
 * Takes two parameters:
 * - the group ID
 * - confirmation
 */
function deleteGroup()
{
    $module = pnVarCleanFromInput('module');
    list($gid,
	 $ok) = pnVarCleanFromInput('gid',
				    'ok');

    if(!isset($ok)) {
	$ok = 0;
    }

    if (!pnSecConfirmAuthKey()) {
        include 'header.php';
        echo _BADAUTHKEY;
        include 'footer.php';
        exit;
    }
    $dbconn =& pnDBGetConn(true);
    $pntable =& pnDBGetTables();

    $groupstable = $pntable['groups'];
    $groupscolumn = &$pntable['groups_column'];
    // Get details on current group
    $query = "SELECT $groupscolumn[name]
              FROM $groupstable
              WHERE $groupscolumn[gid]='".(int)pnVarPrepForStore($gid)."'";
    $result =& $dbconn->Execute($query);
    if ($result->EOF) {
        die("No such group ID $gid");
    }

    list($gname) = $result->fields;
    $result->Close();

    if (!pnSecAuthAction(0, 'Groups::', "$gname::$gid", ACCESS_DELETE)) {
        include 'header.php';
        GraphicAdmin();
        OpenTable();
        echo "<div style=\"text-align:center\"><a href=\"admin.php?module=".$module."&amp;op=secviewgroups\" class=\"pn-title\"><strong>"
        ._GROUPADMIN."</strong></a><span class=\"pn-normal\">: ".pnVarPrepForDisplay($gname)."</span></div>";
        CloseTable();
        echo _GROUPSDELNOAUTH;
        include 'footer.php';
        return;
    }

    if ($ok != 1) {
        include("header.php");
        GraphicAdmin();

        // Heading
        OpenTable();
        echo "<div style=\"text-align:center\"><a href=\"admin.php?module=".$module."&amp;op=secviewgroups\" class=\"pn-title\"><strong>"
        ._GROUPADMIN."</strong></a><span class=\"pn-normal\">: ".pnVarPrepForDisplay($gname)."</span></div>";
        echo "<br />
              <div style=\"text-align:center\">".
              _DELETEGROUPSURE.
             "<form action=\"admin.php\" method=\"post\"><div>
              <input type=\"hidden\" name=\"module\" value=\"".$module."\" />
              <input type=\"hidden\" name=\"op\" value=\"secdeletegroup\" />
              <input type=\"hidden\" name=\"ok\" value=\"1\" />
              <input type=\"hidden\" name=\"gid\" value=\"$gid\" />
		      <input type=\"hidden\" name=\"authid\" value=\"" . pnSecGenAuthKey() . "\" />
              <input type=\"submit\" value=\""._YES."\" />
			  </div>
              </form>
              <br />
              <a href=\"admin.php?module=".$module."&amp;op=secviewgroups\">".
              _NO.
             "</a>
              </div>";

        CloseTable();
        include("footer.php");
    } else {
        $groupmembershiptable = $pntable['group_membership'];
        $groupmembershipcolumn = &$pntable['group_membership_column'];
        $grouppermstable = $pntable['group_perms'];
        $grouppermscolumn = &$pntable['group_perms_column'];
        $groupstable = $pntable['groups'];
        $groupscolumn = &$pntable['groups_column'];

        // Delete permissions for the group
        $query = "DELETE FROM $grouppermstable
                  WHERE $grouppermscolumn[gid]='".pnVarPrepForStore($gid)."'";
        $dbconn->Execute($query);

        // Delete membership of the group
        $query = "DELETE FROM $groupmembershiptable
                  WHERE $groupmembershipcolumn[gid]='".pnVarPrepForStore($gid)."'";
        $dbconn->Execute($query);

        // Delete the group itself
        $query = "DELETE FROM $groupstable
                  WHERE $groupscolumn[gid]='".pnVarPrepForStore($gid)."'";
        $dbconn->Execute($query);

		// Let any hooks know that we have deleted an item
		pnModCallHooks('item', 'delete', $gid, '');

        pnRedirect('admin.php?module='.$module.'&op=secviewgroups');
    }
}

/*
 * selectUserForGroup - select a user to add to
 *                      a group
 * Takes one parameter:
 * - the group ID
 */
function selectUserForGroup()
{
    $module = pnVarCleanFromInput('module');
    $gid = pnVarCleanFromInput('gid');

    $dbconn =& pnDBGetConn(true);
    $pntable =& pnDBGetTables();

    $grouptable = $pntable['groups'];
    $groupcolumn = &$pntable['groups_column'];
    $groupmembershiptable = $pntable['group_membership'];
    $groupmembershipcolumn = &$pntable['group_membership_column'];
    $usertable = $pntable['users'];
    $usercolumn = &$pntable['users_column'];

    include("header.php");
    GraphicAdmin();

    // Get details on current group
    $query = "SELECT $groupcolumn[name]
              FROM $grouptable
              WHERE $groupcolumn[gid]='".(int)pnVarPrepForStore($gid)."'";
    $result =& $dbconn->Execute($query);
    if ($result->EOF) {
        die("No such group ID $gid");
    }

    list($gname) = $result->fields;
    $result->Close();

    // Heading
    OpenTable();
    echo "<div style=\"text-align:center\"><a href=\"admin.php?module=".$module."&amp;op=secviewgroups\" class=\"pn-title\"><strong>"
    ._GROUPADMIN."</strong></a><span class=\"pn-title\"><strong><span class=\"pn-normal\">: ".pnVarPrepForDisplay($gname)."</span></strong></span></div>";
    echo "<br />";

    if (!pnSecAuthAction(0, 'Groups::', "$gname::$gid", ACCESS_EDIT)) {
        CloseTable();
        echo _GROUPSEDITNOAUTH;
        include 'footer.php';
        return;
    }

    // Get list of users already in this group
    $query = "SELECT $groupmembershipcolumn[uid]
              FROM $groupmembershiptable
              WHERE $groupmembershipcolumn[gid]='".(int)pnVarPrepForStore($gid)."'";
    $result =& $dbconn->Execute($query);
    $uids = array();
    while(list($uid) = $result->fields) {
        $uids[] = $uid;
        $result->MoveNext();
    }
    $uidlist = implode(",", $uids);
    $result->Close();

    // Get list of eligible users
    $query = "SELECT $usercolumn[uid],
                     $usercolumn[uname]
              FROM $usertable";
    if (!empty($uidlist)) {
        $query .= " WHERE $usercolumn[uid] NOT IN ($uidlist)";
    }
    $query .= " ORDER BY $usercolumn[uname]";
    $result =& $dbconn->Execute($query);
    if (!$result->EOF) {
        echo "<br />"
             ."<form action=\"admin.php\" method=\"post\"><div>"
             ._USERTOADD.": "
             ."<input type=\"hidden\" name=\"module\" value=\"".$module."\" />"
             ."<input type=\"hidden\" name=\"op\" value=\"secaddusertogroup\" />"
	     	 ."<input type=\"hidden\" name=\"authid\" value=\"" . pnSecGenAuthKey() . "\" />"
             ."<input type=\"hidden\" name=\"gid\" value=\"$gid\" />"
             ."<select name=\"uid\">";

        while(list($uid, $uname) = $result->fields) {
            echo "<option value=\"$uid\">".pnVarPrepForDisplay($uname)."</option>";
            $result->MoveNext();
        }
       echo "</select>".
            " <input type=\"submit\" value=\""._CONFIRM."\" />".
			"</div>".
            "</form>";
    } else {
        echo "<strong>All users are currently in this group</strong>";
    }
    $result->Close();

    CloseTable();
    include("footer.php");
}

/*
 * addUserToGroup - add a user to a group
 * Takes two parameters:
 * - the user ID
 * - the group ID
 */
function addUserToGroup()
{
    $module = pnVarCleanFromInput('module');
    list($uid,
	 $gid) = pnVarCleanFromInput('uid',
				     'gid');

    if (!pnSecConfirmAuthKey()) {
        include 'header.php';
        echo _BADAUTHKEY;
        include 'footer.php';
        exit;
    }
    $dbconn =& pnDBGetConn(true);
    $pntable =& pnDBGetTables();

    // Get details on current group
    $groupstable = $pntable['groups'];
    $groupscolumn = &$pntable['groups_column'];
    $query = "SELECT $groupscolumn[name]
              FROM $groupstable
              WHERE $groupscolumn[gid]='".(int)pnVarPrepForStore($gid)."'";
    $result =& $dbconn->Execute($query);
    if ($result->EOF) {
        die("No such group ID $gid");
    }

    list($gname) = $result->fields;
    $result->Close();

    if (!pnSecAuthAction(0, 'Groups::', "$gname::$gid", ACCESS_EDIT)) {
        include 'header.php';
        GraphicAdmin();
        OpenTable();
        echo "<div style=\"text-align:center\"><a href=\"admin.php?module=".$module."&amp;op=secviewgroups\" class=\"pn-title\"><strong>"
        ._GROUPADMIN."</strong></a><span class=\"pn-normal\">: ".pnVarPrepForDisplay($gname)."</span></div>";
        CloseTable();
        echo _GROUPSEDITNOAUTH;
        include 'footer.php';
        return;
    }

    $groupmembershiptable = $pntable['group_membership'];
    $groupmembershipcolumn = &$pntable['group_membership_column'];

    $query = "INSERT INTO $groupmembershiptable
              ($groupmembershipcolumn[uid],
               $groupmembershipcolumn[gid])
              VALUES (".(int)pnVarPrepForStore($uid).", ".(int)pnVarPrepForStore($gid).")";
    $dbconn->Execute($query);

    pnredirect('admin.php?module='.$module.'&op=secviewgroup&gid='.$gid);
}

/*
 * deleteUserFromGroup - delete a user from a group
 * Takes two parameters:
 * - the user ID
 * - the group ID
 */
function deleteUserFromGroup()
{
    $module = pnVarCleanFromInput('module');
    list($uid,
	 $gid) = pnVarCleanFromInput('uid',
				     'gid');

    $dbconn =& pnDBGetConn(true);
    $pntable =& pnDBGetTables();

    // Get details on current group
    $groupstable = $pntable['groups'];
    $groupscolumn = &$pntable['groups_column'];
    $query = "SELECT $groupscolumn[name]
              FROM $groupstable
              WHERE $groupscolumn[gid]='".(int)pnVarPrepForStore($gid)."'";
    $result =& $dbconn->Execute($query);
    if ($result->EOF) {
        die("No such group ID $gid");
    }

    list($gname) = $result->fields;
    $result->Close();

    if (!pnSecAuthAction(0, 'Groups::', "$gname::$gid", ACCESS_EDIT)) {
        include 'header.php';
        GraphicAdmin();
        OpenTable();
        echo "<div style=\"text-align:center\"><a href=\"admin.php?module=".$module."&amp;op=secviewgroups\" class=\"pn-title\"><strong>"
        ._GROUPADMIN."</strong></a><span class=\"pn-normal\">: ".pnVarPrepForStore($gname)."</span></div>";
        CloseTable();
        echo _GROUPSEDITNOAUTH;
        include 'footer.php';
        return;
    }

    $groupmembershiptable = $pntable['group_membership'];
    $groupmembershipcolumn = &$pntable['group_membership_column'];

    $query = "DELETE FROM $groupmembershiptable
              WHERE $groupmembershipcolumn[uid]='".pnVarPrepForStore($uid)."'
                AND $groupmembershipcolumn[gid]='".pnVarPrepForStore($gid)."'";
    $dbconn->Execute($query);

    pnRedirect('admin.php?module='.$module.'&op=secviewgroup&gid='.$gid);
}

/*
 * modifyGroup - modify group details
 * Takes one parameter:
 * - the group ID
 */
function modifyGroup()
{
    $module = pnVarCleanFromInput('module');
    $gid = pnVarCleanFromInput('gid');

    $dbconn =& pnDBGetConn(true);
    $pntable =& pnDBGetTables();

    $groupstable = $pntable['groups'];
    $groupscolumn = &$pntable['groups_column'];

    include("header.php");
    GraphicAdmin();

    $query = "SELECT $groupscolumn[name]
              FROM $groupstable
              WHERE $groupscolumn[gid]='".(int)pnVarPrepForStore($gid)."'";
    $result =& $dbconn->Execute($query);
    if ($result->EOF) {
        die("No such group ID $gid");
    }

    list($gname) = $result->fields;
    $result->Close();

    // Heading
    OpenTable();
    echo "<div style=\"text-align:center\"><a href=\"admin.php?module=".$module."&amp;op=secviewgroups\" class=\"pn-title\"><strong>"
    ._GROUPADMIN."</strong></FONT></a><span class=\"pn-normal\">: ".pnVarPrepForDisplay($gname)."</span></div>";
    echo "<br />";

    if (!pnSecAuthAction(0, 'Groups::', "$gname::$gid", ACCESS_EDIT)) {
        CloseTable();
        echo _GROUPSEDITNOAUTH;
        include 'footer.php';
        return;
    }

    echo "<form action=\"admin.php\" method=\"post\"><div>"
         ."<input type=\"hidden\" name=\"module\" value=\"".$module."\" />"
         ."<input type=\"hidden\" name=\"op\" value=\"secrenamegroup\" />"
         ."<input type=\"hidden\" name=\"gid\" value=\"$gid\" />"
		 ."<input type=\"hidden\" name=\"authid\" value=\"" . pnSecGenAuthKey() . "\" />"
         ._GROUPNAME. ": <input type=\"text\" name=\"gname\" value=\"$gname\" /><p>"
         ."<input type=\"submit\" value=\""._RENAMEGROUP."\" />"
         ."</div></form>";

    if (pnSecAuthAction(0, 'Groups::', "$gname::$gid", ACCESS_DELETE)) {
        echo "<form action=\"admin.php\" method=\"post\"><div>"
            ."<input type=\"hidden\" name=\"module\" value=\"".$module."\" />"
            ."<input type=\"hidden\" name=\"op\" value=\"secdeletegroup\" />"
            ."<input type=\"hidden\" name=\"gid\" value=\"$gid\" />"
            .'<input type="hidden" name="authid" value="' . pnSecGenAuthKey() . '" />'
            .'<input type="submit" value="'._DELETE.'" />'
            .'</div></form>';
    } else {
       echo "<td>&nbsp;</td>";
    }
    CloseTable();
    include("footer.php");
}

/*
 * renameGroup - rename group
 * Takes two parameters:
 * - the group ID
 * - the new group name
 */
function renameGroup()
{
    $module = pnVarCleanFromInput('module');
    list($gid,
	 $gname) = pnVarCleanFromInput('gid',
				       'gname');

    if (!pnSecConfirmAuthKey()) {
        include 'header.php';
        echo _BADAUTHKEY;
        include 'footer.php';
        exit;
    }
    $dbconn =& pnDBGetConn(true);
    $pntable =& pnDBGetTables();

    $groupstable = $pntable['groups'];
    $groupscolumn = &$pntable['groups_column'];

    // Get details on current group
    $query = "SELECT $groupscolumn[name]
              FROM $groupstable
              WHERE $groupscolumn[gid]='".(int)pnVarPrepForStore($gid)."'";
    $result =& $dbconn->Execute($query);
    if ($result->EOF) {
        die("No such group ID $gid");
    }

    list($oldgname) = $result->fields;
    $result->Close();

    if (!pnSecAuthAction(0, 'Groups::', "$oldgname::$gid", ACCESS_EDIT)) {
        include 'header.php';
        GraphicAdmin();
        OpenTable();
        echo "<div style=\"text-align:center\"><a href=\"admin.php?module=".$module."&amp;op=secviewgroups\" class=\"pn-title\"><strong>"
        ._GROUPADMIN."</strong></a><span class=\"pn-normal\">: ".pnVarPrepForDisplay($gname)."</span></div>";
        CloseTable();
        echo _GROUPSEDITNOAUTH;
        include 'footer.php';
        return;
    }

    $query = "UPDATE $groupstable
              SET $groupscolumn[name]=\"$gname\"
              WHERE $groupscolumn[gid]='".(int)pnVarPrepForStore($gid)."'";
    $dbconn->Execute($query);

    pnRedirect('admin.php?module='.$module.'&op=secviewgroup&gid='.$gid);
}


function groups_admin_main($var)
{
   $op = pnVarCleanFromInput('op');
   extract($var);

   if (!pnSecAuthAction(0, 'Groups::', '::', ACCESS_EDIT)) {
       include 'header.php';
       echo _GROUPSNOAUTH;
       include 'footer.php';
   } else {
       switch($op) {

        case "secviewgroups";
            viewGroups();
            break;

        case "secviewgroup";
            viewGroup();
            break;

        case "secnewgroup";
            newGroup();
            break;

        case "secaddgroup";
            addGroup();
            break;

        case "secdeletegroup";
            deleteGroup();
            break;

        case "secselectuserforgroup";
            selectUserForGroup();
            break;

        case "secaddusertogroup";
            addUserToGroup();
            break;

        case "secdeleteuserfromgroup";
            deleteUserFromGroup();
            break;

        case "secmodifygroup";
            modifyGroup();
            break;

        case "secrenamegroup";
            renameGroup();
            break;

        default:
           viewGroups();
           break;
       }
   }
}
?>