<?php // $Id: index.php,v 1.17 2004/05/24 09:38:33 markwest Exp $ $Name: HEAD $
// ----------------------------------------------------------------------
// PostNuke Content Management System
// Copyright (C) 2001 by the PostNuke Development Team.
// http://www.postnuke.com/
// ----------------------------------------------------------------------
// Based on:
// PHP-NUKE Web Portal System - http://phpnuke.org/
// Thatware - http://thatware.org/
// ----------------------------------------------------------------------
// LICENSE
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License (GPL)
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// To read the license please visit http://www.gnu.org/copyleft/gpl.html
// ----------------------------------------------------------------------
// Filename: modules/Top_List/index.php
// Original Author of file: Francisco Burzi
// Purpose of file: Display top x listings on your site.
// ----------------------------------------------------------------------

if (!defined("LOADED_AS_MODULE")) {
    die ("You can't access this file directly...");
}

$ModName = basename(dirname(__FILE__));

modules_get_language();

$dbconn =& pnDBGetConn(true);
$pntable =& pnDBGetTables();

$currentlang = pnUserGetLang();

if (pnConfigGetVar('multilingual') == 1) {
    $column = &$pntable['stories_column'];
    $queryalang = "WHERE ($column[alanguage]='$currentlang' OR $column[alanguage]='')"; /* top stories */
    $column = &$pntable['seccont_column'];
    $queryslang = "WHERE ($column[slanguage]='$currentlang' OR $column[slanguage]='')"; /* top section articles */
    $column = &$pntable['poll_desc_column'];
    $queryplang = "WHERE ($column[planguage]='$currentlang' OR $column[planguage]='')"; /* top polls */
    $column = &$pntable['reviews_column'];
    $queryrlang = "WHERE ($column[rlanguage]='$currentlang' OR $column[rlanguage]='')"; /* top reviews */
} else {
    $queryalang = "";
    $queryrlang = "";
    $queryplang = "";
    $queryslang = "";
}

include 'header.php';

if (!pnSecAuthAction(0, 'Top_List::', '::', ACCESS_OVERVIEW)) {
echo _BADAUTHKEY;
include("footer.php");
return;
}

$top = pnVarPrepForDisplay(pnConfigGetVar('top'));
$sitename = pnVarPrepForDisplay(pnConfigGetVar('sitename'));

OpenTable();
echo "<div style=\"text-align:center\"><span class=\"pn-title\">"._TOPWELCOME." $sitename</span></div>";
CloseTable();
echo "\n";
OpenTable();

/**
 * Top 10 read stories
 */
$column = &$pntable['stories_column'];
//$myquery = buildSimpleQuery ('stories', array ('sid', 'title', 'time', 'counter'), $queryalang, "$column[counter] DESC", $top);
//$result =& $dbconn->Execute($myquery);
$myquery = "SELECT $column[sid], $column[title], $column[time], $column[counter]
			FROM $pntable[stories] ".$queryalang."
			ORDER BY $column[counter] DESC";
$result =& $dbconn->SelectLimit($myquery,$top);			
			
if (!$result->EOF) {
    echo "<table border=\"0\" cellpadding=\"10\" width=\"100%\"><tr><td align=\"left\">\n"
        ."<span class=\"pn-title\">$top "._READSTORIES.".</span><br /><br />\n";
    $lugar=1;

    while(list($sid, $title, $time, $counter) = $result->fields) {

        if($counter>0) {
            $commentlink = pnUserGetCommentOptions();

            if (empty($title)) {
                $title = '- '._NOTITLE.' -';
            }
            echo "<span class=\"pn-normal\">&nbsp;$lugar:</span> <a href=\"modules.php?op=modload&amp;name=News&amp;file=article&amp;sid=$sid&amp;$commentlink\">" . pnVarPrepForDisplay(pnVarCensor($title)) . "</a><span class=\"pn-normal\"> - ($counter "._READS.")</span><br />\n";
            $lugar++;
        }
        $result->MoveNext();
    }
    echo "</td></tr></table><br />\n";
}
$result->Close();

/**
 * Top 10 commented stories
 */
$column = &$pntable['stories_column'];
//$myquery = buildSimpleQuery ('stories', array ('sid', 'title', 'comments'), $queryalang, "$column[comments] DESC", $top);
//$result =& $dbconn->Execute($myquery);
$myquery = "SELECT $column[sid], $column[title], $column[comments]
			FROM $pntable[stories] ".$queryalang."
			ORDER BY $column[comments] DESC";
$result =& $dbconn->SelectLimit($myquery,$top);
			
if (!$result->EOF) {
    echo "<table border=\"0\" cellpadding=\"10\" width=\"100%\"><tr><td align=\"left\">\n"
    ."<span class=\"pn-title\">$top "._COMMENTEDSTORIES."</span><br /><br />\n";
    $lugar=1;

    while(list($sid, $title, $comments) = $result->fields) {
        if($comments>0) {
            $commentlink = pnUserGetCommentOptions();
            if ($title == "")
                {
                   $title = '- '._NOTITLE.' -';
                }
            echo "<span class=\"pn-normal\">&nbsp;$lugar:</span> <a href=\"modules.php?op=modload&amp;name=News&amp;file=article&amp;sid=$sid&amp;$commentlink\">" . pnVarPrepForDisplay(pnVarCensor($title)) . "</a><span class=\"pn-normal\"> - (".pnVarPrepForDisplay($comments)." "._COMMENTS.")</span><br />\n";
            $lugar++;
        }
        $result->MoveNext();
    }
    echo "</td></tr></table><br />\n";
}
$result->Close();

/**
 * Top 10 categories
 */

$column = &$pntable['stories_cat_column'];
//$myquery = buildSimpleQuery ('stories_cat', array ('catid', 'title', 'counter'), '', "$column[counter] DESC", $top);
//$result =& $dbconn->Execute($myquery);
$myquery = "SELECT $column[catid], $column[title], $column[counter]
			FROM $pntable[stories_cat]
			ORDER BY $column[counter] DESC";
$result =& $dbconn->SelectLimit($myquery,$top);			

if (!$result->EOF) {
    echo "<table border=\"0\" cellpadding=\"10\" width=\"100%\"><tr><td align=\"left\">\n"
            ."<span class=\"pn-title\">$top "._ACTIVECAT."</span><br /><br />\n";
    $lugar=1;

    while(list($catid, $title, $counter) = $result->fields) {
        if($counter>0) {
            echo "<span class=\"pn-normal\">&nbsp;$lugar:</span> <a href=\"index.php?&amp;catid=$catid\">" . pnVarPrepForDisplay($title) . "</a><span class=\"pn-normal\"> - (".pnVarPrepForDisplay($counter)." "._HITS.")</span><br />\n";
            $lugar++;
        }
        $result->MoveNext();
    }
    echo "</td></tr></table><br />\n";
}
$result->Close();

/**
 * Top 10 articles in special sections
 */

$column = &$pntable['seccont_column'];
//$myquery = buildSimpleQuery ('seccont', array ('artid', 'secid', 'title', 'content', 'counter'), $queryslang, "$column[counter] DESC", $top);
//$result =& $dbconn->Execute($myquery);
$myquery = "SELECT $column[artid], $column[secid], $column[title], $column[content], $column[counter]
			FROM $pntable[seccont] ".$queryslang."
			ORDER BY $column[counter] DESC";
$result =& $dbconn->SelectLimit($myquery,$top);	

if (!$result->EOF) {
    echo "<table border=\"0\" cellpadding=\"10\" width=\"100%\"><tr><td align=\"left\">\n"
            ."<span class=\"pn-title\">$top "._READSECTION."</span><br /><br />\n";
    $lugar=1;

    while(list($artid, $secid, $title, $content, $counter) = $result->fields) {
        echo "<span class=\"pn-normal\">&nbsp;$lugar:</span> <a href=\"modules.php?op=modload&amp;name=Sections&amp;file=index&amp;req=viewarticle&amp;artid=$artid\">" . pnVarPrepForDisplay($title) . "</a><span class=\"pn-normal\"> - (".pnVarPrepForDisplay($counter)." "._READS.")</span><br />\n";
       $lugar++;
        $result->MoveNext();
    }
    echo "</td></tr></table><br />\n";
}
$result->Close();

/**
 * Top 10 users submitters
 */

$column = &$pntable['users_column'];
//$myquery = buildSimpleQuery ('users', array ('uname', 'counter'), "$column[counter]>0", "$column[counter] DESC", $top);
//$result =& $dbconn->Execute($myquery);
$myquery = "SELECT $column[uname], $column[counter]
			FROM $pntable[users] 
			WHERE $column[counter] > 0
			ORDER BY $column[counter] DESC";
$result =& $dbconn->SelectLimit($myquery,$top);			
			
if (!$result->EOF) {
    echo "<table border=\"0\" cellpadding=\"10\" width=\"100%\"><tr><td align=\"left\">\n"
            ."<span class=\"pn-title\">$top "._NEWSSUBMITTERS."</span><br /><br />\n";
    $lugar=1;

    while(list($uname, $counter) = $result->fields) {
        if($counter>0) {
            echo "<span class=\"pn-normal\">&nbsp;$lugar:</span> <a href=\"user.php?op=userinfo&amp;uname=$uname\">$uname</a><span class=\"pn-normal\"> - (".pnVarPrepForDisplay($counter)." "._NEWSSENT.")</span><br />\n";
            $lugar++;
        }
        $result->MoveNext();
    }
    echo "</td></tr></table><br />\n";
}
$result->Close();

/**
 * Top 10 Polls
 */

$column = &$pntable['poll_desc_column'];
//$myquery = buildSimpleQuery ('poll_desc', array ('pollid', 'polltitle', 'voters'), $queryplang, "$column[voters] DESC", $top);
//$result =& $dbconn->Execute($myquery);
$myquery = "SELECT $column[pollid], $column[polltitle], $column[voters]
			FROM $pntable[poll_desc] ".$queryplang."
			ORDER BY $column[voters] DESC";
$result =& $dbconn->SelectLimit($myquery,$top);

if (!$result->EOF) {
    echo "<table border=\"0\" cellpadding=\"10\" width=\"100%\"><tr><td align=\"left\">\n"
        ."<span class=\"pn-title\">$top "._VOTEDPOLLS."</span><br /><br />\n";
    $lugar=1;

    while(list($pollID, $pollTitle, $voters) = $result->fields) {
        if(empty($pollTitle)) {
            $pollTitle = '';
        }
        $column = &$pntable['poll_data_column'];
        $result2 =& $dbconn->Execute("SELECT SUM($column[optioncount]) AS sum FROM $pntable[poll_data] WHERE $column[pollid]='".pnVarPrepForStore($pollID)."'");

        list($sum) = $result2->fields;
        if((int)$sum>0) {
            echo "<span class=\"pn-normal\">&nbsp;$lugar:</span> <a href=\"modules.php?op=modload&amp;name=NS-Polls&amp;file=index&amp;pollID=$pollID\">" . pnVarPrepForDisplay($pollTitle) . "</a><span class=\"pn-normal\"> - (".pnVarPrepForDisplay($voters)." "._TOPLISTVOTES.")</span><br />\n";
            $lugar++;
        }
        $result->MoveNext();
    }
    echo "</td></tr></table><br />\n";
}
$result->Close();

/**
 * Top 10 authors
 */

$column = &$pntable['stories_column'];
$column1 = &$pntable['users_column'];
$myquery ="SELECT $column1[uname], count(*) AS num
                                FROM $pntable[stories], $pntable[users]
                                WHERE  $column[aid] = '".pnVarPrepForStore($column1['uid'])."'
                                GROUP BY $column1[uname]
                                ORDER BY num DESC";

$result = $dbconn->SelectLimit($myquery,$top);

if (!$result->EOF) {
    echo "<table border=\"0\" cellpadding=\"10\" width=\"100%\"><tr><td align=\"left\">\n"
            ."<span class=\"pn-title\">$top "._MOSTACTIVEAUTHORS."</span><br /><br />\n";
    $lugar=1;

    while(list($aid, $counter) = $result->fields) {
        if($counter>0) {
            echo "<span class=\"pn-normal\">&nbsp;$lugar:</span>"
             ."<a class=\"pn-normal\" href=\"modules.php?op=modload&amp;name=Search&amp;file=index&amp;action=search&amp;overview=1&amp;active_stories=1&amp;stories_author=$aid\">$aid</a>"
             ."<span class=\"pn-normal\"> - (".pnVarPrepForDisplay($counter)." "._NEWSPUBLISHED.")</span><br />\n";
            $lugar++;
        }
    $result->MoveNext();
    }
    echo "</td></tr></table><br />\n";
}
$result->Close();

/**
 * Top 10 reviews
 */

$column = &$pntable['reviews_column'];
//$myquery = buildSimpleQuery ('reviews', array ('id', 'title', 'hits'), $queryrlang, "$column[hits] DESC", $top);
//$result =& $dbconn->Execute($myquery);
$myquery = "SELECT $column[id], $column[title], $column[hits]
			FROM $pntable[reviews] ".$queryrlang."
			ORDER BY $column[hits] DESC";
$result =& $dbconn->SelectLimit($myquery,$top);

if (!$result->EOF) {
    echo "<table border=\"0\" cellpadding=\"10\" width=\"100%\"><tr><td align=\"left\">\n"
            ."<span class=\"pn-title\">$top "._READREVIEWS."</span><br /><br />\n";
    $lugar=1;

    while(list($id, $title, $hits) = $result->fields) {
        if($hits>0) {
           if(empty($title))
               {
                  $title = '- '._NOTITLE.' -';
               }
           echo "<span class=\"pn-normal\">&nbsp;$lugar:</span> <a href=\"modules.php?op=modload&amp;name=Reviews&amp;file=index&amp;req=showcontent&amp;id=$id\">" . pnVarPrepForDisplay(pnVarCensor($title)) . "</a><span class=\"pn-normal\"> - (".pnVarPrepForDisplay($hits)." "._READS.")</span><br />\n";
           $lugar++;
       }
        $result->MoveNext();
    }
    echo "</td></tr></table><br />\n";
}
$result->Close();

/**
 * Top 10 downloads
 */

$column = &$pntable['downloads_downloads_column'];
//$myquery = buildSimpleQuery ('downloads_downloads', array ('lid', 'cid', 'title', 'hits'), '', "$column[hits] DESC", $top);
//$result =& $dbconn->Execute($myquery);
$myquery = "SELECT $column[lid], $column[cid], $column[title], $column[hits]
			FROM $pntable[downloads_downloads]
			ORDER BY $column[hits] DESC";
$result =& $dbconn->SelectLimit($myquery,$top);

if (!$result->EOF) {
    echo "<table border=\"0\" cellpadding=\"10\" width=\"100%\"><tr><td align=\"left\">\n"
            ."<span class=\"pn-title\">$top "._DOWNLOADEDFILES."</span><br /><br />\n";
    $lugar=1;
    while(list($lid, $cid, $title, $hits) = $result->fields) {
        if($hits>0) {
            $column = &$pntable['downloads_categories_column'];
            $res =& $dbconn->Execute("SELECT $column[title]
                                   FROM $pntable[downloads_categories]
                                   WHERE $column[cid]='".pnVarPrepForStore($cid)."'");

            list($ctitle) = $res->fields;
            $res->Close();
            $utitle = ereg_replace(" ", "_", $title);

            if(empty($title)) {
                $title = '- '._NOTITLE.' -';
            }
            echo "<span class=\"pn-normal\">&nbsp;$lugar:</span> <a href=\"modules.php?op=modload&amp;name=Downloads&amp;file=index&amp;req=viewdownloaddetails&amp;lid=$lid&amp;ttitle=$utitle\">" . pnVarPrepForDisplay($title) . "</a> <span class=\"pn-normal\"> ("._CATEGORY.": ".pnVarPrepForDisplay($ctitle).")</span><span class=\"pn-normal\"> - (".pnVarPrepForDisplay($hits)." "._DOWNLOADS.")</span><br />\n";
            $lugar++;
        }
        $result->MoveNext();
    }
    echo "</td></tr></table>\n\n";
}
$result->Close();

CloseTable();

include 'footer.php';
?>