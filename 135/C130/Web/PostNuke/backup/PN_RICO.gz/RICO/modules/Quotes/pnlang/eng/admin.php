<?php
// Generated: $d$ by $id$
// ----------------------------------------------------------------------
// PostNuke Content Management System
// Copyright (C) 2001 by The PostNuke Development Team.
// http://www.postnuke.com/
// ----------------------------------------------------------------------
// Based on:
// PHP-NUKE Web Portal System - http://phpnuke.org/
// Thatware - http://thatware.org/
// ----------------------------------------------------------------------
// LICENSE
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License (GPL)
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU General Public License for more details.
//
// To read the license please visit http://www.gnu.org/copyleft/gpl.html
// ----------------------------------------------------------------------
// Original Author of file: Everyone
// Purpose of file: Translation files
// Translation team: Read credits in /docs/CREDITS.txt
// ----------------------------------------------------------------------

define('_QOTDMISSINGVALUE','Sorry! Quote or author missing');
define('_CANCELQUOTEDELETE','Cancel');
define('_QOTDACTION','Action');
define('_QOTDADD','Add');
define('_QOTDADDSUCCESS','Quote added successfully.');
define('_QOTDAUTHOR','Author');
define('_QOTDDEL','Delete this quote?');
define('_QOTDDELETEACTION','Delete');
define('_QOTDDELETED','Quote deleted.');
define('_QOTDEDITACTION','Edit');
define('_QOTDMODIFY','Modify quotes');
define('_QOTDNOQUOTES','No quotes found.');
define('_QOTDNQ','No quotes found');
define('_QOTDQUOTE','Quote');
define('_QOTDSAVE','Save modification?');
define('_QOTDSEARCH','Search by keyword:');
define('_QOTDSEARCHRESULTS','Search results...');
define('_QOTDTEXT','Quote text:');
define('_QOTDTOTAL','Total number of quotes in database: ');
define('_QUOTESNOAUTH','Sorry! You do not have authorization to access quotes.');
define('_QAUTHUNKNOWN','Unknown');
?>