<?php
// $Id: pnversion.php,v 1.2 2002/11/28 13:16:30 neo Exp $
$modversion['name'] = 'XML-RPC Backend';
$modversion['id'] = '40';
$modversion['version'] = '1.1';
$modversion['description'] = 'XML-RPC Client and Server code';
$modversion['credits'] = 'docs/credits.txt';
$modversion['help'] = 'docs/help.txt';
$modversion['changelog'] = 'docs/changelog.txt';
$modversion['license'] = 'docs/license.txt';
$modversion['official'] = 1;
$modversion['author'] = 'Marcel van der Boom';
$modversion['contact'] = 'marcel@hsdev.com';
$modversion['admin'] = 0;
$modversion['class'] = 'Core Utility';
$modversion['category'] = 'Global'; 
?>