<?php
// File: $Id: index.php,v 1.30 2004/08/22 19:03:34 larsneo Exp $ $Name: HEAD $
// ----------------------------------------------------------------------
// PostNuke Content Management System
// Copyright (C) 2001 by the PostNuke Development Team.
// http://www.postnuke.com/
// ----------------------------------------------------------------------
// Based on:
// PHP-NUKE Web Portal System - http://phpnuke.org/
// Thatware - http://thatware.org/
// ----------------------------------------------------------------------
// LICENSE
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License (GPL)
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// To read the license please visit http://www.gnu.org/copyleft/gpl.html
// ----------------------------------------------------------------------
// Original Author of this file: Francisco Burzi
// Purpose of this file: Directs to the start page as defined in config.php
// ----------------------------------------------------------------------

// include base api
include 'includes/pnAPI.php';

// start PN
pnInit();

// Get variables
list($module,
     $func,
     $op,
     $name,
     $file,
     $type) = pnVarCleanFromInput('module',
                                  'func',
                                  'op',
                                  'name',
                                  'file',
                                  'type');

// Defaults for variables
if (isset($catid)) {
    pnVarCleanFromInput('catid');
}
if (empty($op)) {
    $op = 'modload';
}
if (empty($name) && empty($module)) {
	$modinfo = pnModGetInfo(pnModGetIDFromName(pnConfigGetVar('startpage')));
	if ($modinfo['type'] == 1) {
    	$name = $modinfo['name'];
	} else {
		$module = $modinfo['name'];
	}
}
if (empty($type)) {
    $type = 'user';
}
if (empty($file)) {
    $file = 'index';
}

if (!empty($module)) {
    // New-new style of loading modules
    if (empty($type)) {
        $type = 'user';
    }
    if (empty($func)) {
        $func = 'main';
    }
    if (!isset($arguments)) {
        $arguments = array();
    }

	// get the module info
	$modinfo = pnModGetInfo(pnModGetIDFromName($module));
    // it should be $module not $name [class007]
    if (pnModAvailable($modinfo['name']) && pnModLoad($modinfo['name'], $type)) {
		// Run the function
		$return = pnModFunc($modinfo['name'], $type, $func, $arguments);
    } else {
        $return = false;
    }
    // Sort out return of function.  Can be
    // true - finished
    // false - display error msg
    // text - return information
    if ((empty($return)) || ($return == false)) {
        // Failed to load the module
        $return = 'Failed to load module ' . $module .' (at function: "'.$func.'")';
    } 
    if (strlen($return) > 1) {
        // Text
    	include ('header.php');
        echo $return;
    	include ('footer.php');
    }
} else {
    // Old-old style of loading modules
    if (empty($op)) {
        $op = 'modload';
    }
    if (empty($file)) {
        $file = 'index';
    }

	// get the module info
	$modinfo = pnModGetInfo(pnModGetIDFromName($name));

    switch ($op) {
        case 'modload':
		    if (pnModAvailable($modinfo['name'])) {
	            define('LOADED_AS_MODULE','1');
    	        // added for the module/system seperation [class007]
        	    if (file_exists('modules/' . pnVarPrepForOS($modinfo['directory']) . '/' . pnVarPrepForOS($file) . '.php')) {
            	    include 'modules/' . pnVarPrepForOS($modinfo['directory']) . '/'  . pnVarPrepForOS($file) . '.php';
				} else {
                	// Failed to load the module
					include ('header.php');
					echo "Failed to load module ".$modinfo['name'];
					include ('footer.php');
            	}
			} else {
               	// module is deacitvated
				include ('header.php');
				echo 'Module ' . $modinfo['name'] . ' not available';
				include ('footer.php');
			}
            break;
        default:
            // Failed to load the module
			include ('header.php');
			echo 'Sorry, you cannot access this file directly...';
			include ('footer.php');
            break;
    }
}

?>