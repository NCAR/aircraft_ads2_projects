<?php
// File: $Id: admin.php,v 1.15 2004/08/22 19:56:39 markwest Exp $ $Name: HEAD $
// ----------------------------------------------------------------------
// PostNuke Content Management System
// Copyright (C) 2001 by the PostNuke Development Team.
// http://www.postnuke.com/
// ----------------------------------------------------------------------
// Based on:
// PHP-NUKE Web Portal System - http://phpnuke.org/
// Thatware - http://thatware.org/
// ----------------------------------------------------------------------
// LICENSE
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License (GPL)
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// To read the license please visit http://www.gnu.org/copyleft/gpl.html
// ----------------------------------------------------------------------
// Original Author of file: Francisco Burzi
// Purpose of file:
// ----------------------------------------------------------------------

include 'includes/pnAPI.php';
pnInit();

// eugenio themeover 20020413
//   pnThemeLoad();
include 'modules/NS-Admin/tools.php';

list($module, $func, $op, $file) = pnVarCleanFromInput('module', 'func', 'op', 'file');

$currentlangfile = 'language/' . pnVarPrepForOS(pnUserGetLang()) . '/admin.php';
$defaultlangfile = 'language/' . pnVarPrepForOS(pnConfigGetVar('language')) . '/admin.php';
if (file_exists($currentlangfile)) {
	include $currentlangfile;
} elseif (file_exists($defaultlangfile)) {
	include $defaultlangfile;
}

// $module / $op control
if (!isset($op) or $op=='adminMain') {
	$module = 'NS-Admin';
	$op     = 'main';
} elseif (!isset($module)) {
	$module = 'NS-Past_Nuke';
}

// prepare the menu
admin_menu('admin.html');

if (file_exists('install.php') || file_exists('install')) {
    include('header.php');
    echo "<br />\n
          <fieldset>\n
          <br /><div style=\"text-align: center; font-weight: bold; font-size: 14px; color: red;\">".pnVarPrepForDisplay(_PN_INSTALLWARNING)."</div><br />\n
          <br /><div style=\"text-align: center;\"><a href=\"admin.php\">".pnVarPrepForDisplay(_CONTINUE)."</a></div>\n
          </fieldset>";
    include('footer.php');
    exit;
}
if (file_exists('psak.php')) {
    include('header.php');
    echo "<br />\n
          <fieldset>\n
          <br /><div style=\"text-align: center; font-weight: bold; font-size: 14px; color: red;\">".pnVarPrepForDisplay(_PN_PSAKWARNING)."</div><br />\n
          <br /><div style=\"text-align: center;\"><a href=\"admin.php\">".pnVarPrepForDisplay(_CONTINUE)."</a></div>\n
          </fieldset>";
    include('footer.php');
    exit;
}

if (file_exists($file='modules/' . pnVarPrepForOS($module) . '/admin.php')) {
	$ModName = $module;
	include $file;

	// each individual module admin panel loads it language - markwest
	//modules_get_language();
	modules_get_manual();

	if (substr($module,0,3)=='NS-') {
		$function = substr($module,3).'_admin_';
	} else {
		$function = $module.'_admin_';
	}

	$function_op = $function.$op;
	$function_main = $function.'main';
	$var = array_merge($_GET,$_POST);
	if (function_exists($function_op)) {
		$function_op($var);
	} elseif (function_exists($function_main)) {
		$function_main($var);
	} else {
		die("error : admin_execute($file,$function_op)");
	}
} else {
	die("Fatal error :<br />module = $module<br />op = $op<br />");
}

?>