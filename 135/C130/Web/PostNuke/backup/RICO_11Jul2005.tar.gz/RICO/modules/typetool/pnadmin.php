<?php
// ----------------------------------------------------------------------
// PostNuke Content Management System
// Copyright (C) 2002 by the PostNuke Development Team.
// http://www.postnuke.com/
// ----------------------------------------------------------------------
// Based on:
// PHP-NUKE Web Portal System - http://phpnuke.org/
// Thatware - http://thatware.org/
// ----------------------------------------------------------------------
// LICENSE
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License (GPL)
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// To read the license please visit http://www.gnu.org/copyleft/gpl.html
// ----------------------------------------------------------------------
// Original Author of file: Brian Bain
// Purpose of file:  Censor administration display functions
// ----------------------------------------------------------------------

/**
 * @package PostNuke_Modules
 * @subpackage PostNuke_typetool
 * @license http://www.gnu.org/copyleft/gpl.html
*/

/**
 * TypeTool Module main admin function
 * @author Andreas Krapohl
 * @version
 * @return string HTML output string
 */
 
function typetool_admin_main()
{
    $output = new pnHTML();

    if (!pnSecAuthAction(0, 'typetool::', '::', ACCESS_ADMIN)) {
        $output->Text(_BADAUTHKEY);
        return $output->GetOutput();
    }

    $output->SetInputMode(_PNH_VERBATIMINPUT);
    $output->Text(typetool_admin_modify(array()));
    $output->SetInputMode(_PNH_PARSEINPUT);

    return $output->GetOutput();
}

/**
 * Modify TypeTool configuration
 * @author Andreas Krapohl
 * @version
 * @param int typetool on or off
 * @param string language for typetool userinterface
 * @return string HTML output string
 */
function typetool_admin_modify($args)
{
    list(
         $tt_enable,
         $tt_language
                    )= pnVarCleanFromInput(
                                           'tt_enable',
                                           'tt_language'
										   );
    extract($args);

    $output = new pnHTML();

    if (!pnSecAuthAction(0, 'typetool::', "::", ACCESS_ADMIN)) {
        $output->Text(_BADAUTHKEY);
        return $output->GetOutput();
    }

    $tt_enable = pnModGetVar('typetool', 'enable');
    $tt_language = pnModGetVar('typetool', 'language');

    $output->Title(_TYPETOOLSETTINGS);

    $output->FormStart(pnModURL('typetool', 'admin', 'update'));
    $output->FormHidden('authid', pnSecGenAuthKey());
    $output->TableStart();

    $row = array();
    $output->SetOutputMode(_PNH_RETURNOUTPUT);
    $row[] = $output->Text(_TYPETOOLONOFF);
    $row[] = $output->FormCheckBox('tt_enable', pnVarPrepForDisplay($tt_enable));
    $output->SetOutputMode(_PNH_KEEPOUTPUT);
    $output->SetInputMode(_PNH_VERBATIMINPUT);
    $output->TableAddrow($row, 'left');
    $output->SetInputMode(_PNH_PARSEINPUT);

    $row = array();
    $output->SetOutputMode(_PNH_RETURNOUTPUT);
    $row[] = $output->Text(_TYPETOOLLANGUAGE);
    $row[] = $output->FormText('tt_language', pnVarPrepForDisplay($tt_language), 35,35);
    $output->SetOutputMode(_PNH_KEEPOUTPUT);
    $output->SetInputMode(_PNH_VERBATIMINPUT);
    $output->TableAddrow($row, 'left');
    $output->SetInputMode(_PNH_PARSEINPUT);
    
    $output->TableEnd();
    $output->Linebreak(2);
    $output->FormSubmit(_TYPETOOLUPDATE);
    $output->FormEnd();
    
    return $output->GetOutput();
}

/**
 * Update TypeTool configuration
 * @author Andreas Krapohl
 * @version 
 * @param int typetool censor on or off
 * @param string language for typetool userinterface
 * @return bool true if successful, false otherwise
 */
function typetool_admin_update($args)
{
    list(
         $tt_enable,
         $tt_language
                     ) = pnVarCleanFromInput(
                                              'tt_enable',
                                              'tt_language'
                                                           );
    extract($args);
    
    if(empty($tt_language)){
        $tt_language = "language.js";
    }
    
    if (!pnSecConfirmAuthKey()) {
        pnSessionSetVar('errormsg', _BADAUTHKEY);
        pnRedirect(pnModURL('typetool', 'admin', 'main'));
        return true;
    }

    if (!pnModAPILoad('typetool', 'admin')) {
        pnSessionSetVar('errormsg', _TYPETOOLLOADFAILED);
        return $output->GetOutput();
    }


    if(pnModAPIFunc('typetool',
                    'admin',
                    'update',
                    array(
                          'tt_enable' => $tt_enable,
                          'tt_language' => $tt_language
                                                      ))) {

        pnSessionSetVar('statusmsg', _TYPETOOLUPDATED);
    }

    pnRedirect(pnModURL('typetool', 'admin', 'main'));

    return true;
}
?>