<?php
// $Id: Version.php,v 1.1.1.1 2002/09/15 22:26:15 root Exp $ $Name: HEAD $
$modversion['name'] = 'Ephemerids Admin';
$modversion['version'] = '1.2';
$modversion['description'] = "A 'This day in history' type module.";
$modversion['credits'] = '';
$modversion['help'] = '';
$modversion['changelog'] = '';
$modversion['license'] = '';
$modversion['official'] = 1;
$modversion['author'] = 'Francisco Burzi';
$modversion['contact'] = 'http://www.phpnuke.org';
$modversion['admin'] = 1;
$modversion['securityschema'] = array('Ephemerids::' => 'Ephemerid::Ephemerid ID');
?>