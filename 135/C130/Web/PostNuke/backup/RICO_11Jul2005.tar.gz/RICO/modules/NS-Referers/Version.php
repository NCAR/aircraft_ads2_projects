<?php
// $Id: Version.php,v 1.1.1.1 2002/09/15 22:26:15 root Exp $ $Name: HEAD $
$modversion['name'] = 'HTTP Referers Admin';
$modversion['version'] = '1.2';
$modversion['description'] = 'View HTTP referer statistics.';
$modversion['credits'] = '';
$modversion['help'] = '';
$modversion['changelog'] = '';
$modversion['license'] = '';
$modversion['official'] = 1;
$modversion['author'] = 'Michael Yarbrough';
$modversion['contact'] = 'gte649i@prism.gatech.edu';
$modversion['admin'] = 1;
$modversion['securityschema'] = array('Referers::' => '::');
?>