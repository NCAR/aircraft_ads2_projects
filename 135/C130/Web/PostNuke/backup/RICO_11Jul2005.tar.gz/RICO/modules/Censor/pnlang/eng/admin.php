<?php // $Id: admin.php,v 1.4 2004/05/24 08:54:39 markwest Exp $
// ----------------------------------------------------------------------
// Original Author of file: Jim McDonald
// Purpose of file:  Language defines for pnadmin.php
// ----------------------------------------------------------------------
//
define('_EDITCENSOR', 'Configure censorship options');
if (!defined('_LOADFAILED')) {
	define('_LOADFAILED', 'Error! Could not load module');
}
define('_CENSORUPDATE', 'Update');
define('_CENSORUPDATED', 'Censorship options updated');
define('_CENSORMODE', 'Censor mode on');
define('_CENSORLIST', 'List of censored words');
define('_CENSORREPLACE', 'Replace censored words with');
define('_CENSORMODEFAIL', 'Error! Could not update censor mode');
define('_CENSORLISTFAIL', 'Error! Could not update censor  list');
define('_CENSORREPLACEFAIL', 'Error! Could not replace censor list');

if (!defined('_CONFIRM')) {
	define('_CONFIRM', 'Confirm');
}
if (!defined('_CENSORNOAUTH')) {
	define('_CENSORNOAUTH','Sorry! You do not have authorization to access the Censor module');
}
?>