<?php 
// $Id: index.php,v 1.45 2004/08/20 15:48:29 markwest Exp $ $Name: HEAD $
// ----------------------------------------------------------------------
// PostNuke Content Management System
// Copyright (C) 2001 by the PostNuke Development Team.
// http://www.postnuke.com/
// ----------------------------------------------------------------------
// Based on Bjorn Sodergrens MyPHPortal Modified Member List.
// PHP-NUKE Web Portal System - http://phpnuke.org/
// Thatware - http://thatware.org/
// Some code taken from MemberList coded by Paul Joseph Thompson
// of www.slug.okstate.edu
// In memoriam of Members List War ;)
// ----------------------------------------------------------------------
// LICENSE
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License (GPL)
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// To read the license please visit http://www.gnu.org/copyleft/gpl.html
// ----------------------------------------------------------------------
// Original Author of file: Francisco Burzi
// Purpose of file: Displays member listings
// ----------------------------------------------------------------------
// Updated: Alexander Graef aka MagicX
// ----------------------------------------------------------------------
if (!defined("LOADED_AS_MODULE")) {
    die ("You can't access this file directly...");
}

$ModName = basename( dirname( __FILE__ ) );
modules_get_language();

function getnumber($get) {
	$a = 0;
	$dcolor_A = "".$GLOBALS['bgcolor3']."";
    $dcolor_B = "".$GLOBALS['bgcolor1']."";

	$dbconn =& pnDBGetConn(true);
	$pntable =& pnDBGetTables();
	$sessioninfocolumn = &$pntable['session_info_column'];
	$sessioninfotable = $pntable['session_info'];
	$activetime = time() - (pnConfigGetVar('secinactivemins') * 60);

	// Get list of users on-line
	$sql = "SELECT DISTINCT $sessioninfocolumn[uid]
                    FROM $sessioninfotable
                    WHERE $sessioninfocolumn[uid] != 0
                    AND $sessioninfocolumn[lastused] > $activetime
                   GROUP BY $sessioninfocolumn[uid]";
	$result3 =& $dbconn->Execute($sql);
	$numusers = $result3->RecordCount();

	$unames = array();
	for (; !$result3->EOF; $result3->MoveNext()) {
		$unames[] = pnUserGetVar('uname', $result3->fields[0]);
	}
	$result3->Close();

	$query = "SELECT count( 1 )
              FROM $sessioninfotable
              WHERE $sessioninfocolumn[lastused] > $activetime 
              AND $sessioninfocolumn[uid] = '0'
			  GROUP BY $sessioninfocolumn[ipaddr]";
    $result =& $dbconn->Execute($query);
	$numguests = $result->RecordCount();

/*    for (; !$result->EOF; $result->MoveNext()) {
        list($type, $num) = $result->fields;
        if ($type == 0) {
            $numguests = $num;
        } else {
            $numusers++;
        }
    }*/
    $result->Close();

    // Pluralise
    if ($numguests == 1) {
        $guests = _GUEST;
    } else {
        $guests = _GUESTS;
    }
    if ($numusers == 1) {
        $users = _MEMBER;
    } else {
        $users = _MEMBERS;
    }
    
	// Sort by username
	sort($unames);
	reset($unames);
	$numregusers = count($unames);

	if ($get=='number') {
		echo"<div style=\"text-align:center\">"._CURRENTLY." ".pnVarPrepForDisplay($numguests)."
".pnVarPrepForDisplay($guests)." "._AND." ".pnVarPrepForDisplay($numregusers)." ".pnVarPrepForDisplay($users)."
"._ONLINE."</div>";
	}

	if ($get=='online') {
echo"<a id=\"online\"></a>";	
echo"<br /><table width=\"95%\" cellspacing=\"1\" cellpadding=\"5\" style=\"background-color=:".$GLOBALS['bgcolor2']."\"><tr><td style=\"background-color:".$GLOBALS['bgcolor1']."\">";
		foreach ($unames as $uname) {
			//$myquery = buildSimpleQuery('users', array('uid', 'name', 'uname', 'femail', 'url'), 'pn_uname =$uname');
			//$result =& $dbconn->Execute($myquery);
			// $dcolor = ($a == 0 ? $dcolor_A : $dcolor_B);
			echo "<span class=\"pn-normal\"><strong>+ ".pnVarPrepForDisplay($uname)."&nbsp;</strong></span> ";
			//$a = ($dcolor == $dcolor_A ? 1 : 0);
		}
		echo"</td></tr></table>";
	}
	
	if($get=='countnum') {
		echo $numusers;
	}
}


function search() {
	echo"
<form method=\"post\" action=\"modules.php\">
	<div>
		<table border=\"0\" cellspacing=\"2\" width=\"100%\">
			<tr>
				<td valign=\"top\" style=\"text-align:center\"><span class=\"pn-normal\">
				<strong>"._SEARCH.":</strong> 
				<input type=\"text\" name=\"letter\" size=\"35\" /><br />
				<input type=\"hidden\" name=\"op\" value=\"modload\" />
				<input type=\"hidden\" name=\"name\" value=\"$GLOBALS[ModName]\" />
				<input type=\"hidden\" name=\"file\" value=\"index\" />
				<input type=\"radio\" name=\"sorting\" value=\"uname\" checked=\"checked\" />"._MNICKNAME."
				<input type=\"radio\" name=\"sorting\" value=\"name\" />"._MREALNAME."
				<input type=\"radio\" name=\"sorting\" value=\"url\" />"._MURL."
				<input type=\"hidden\" name=\"authid\" value=\"".pnSecGenAuthKey()."\" />
				<br />   
				<input type=\"submit\" value=\""._SUBMIT."\" />
				</span></td>
			</tr>
		</table>
	</div>
</form>";
}

function alpha(){
    // Creates the list of letters and makes them a link.
	$alphabet = array (_ALL, "A","B","C","D","E","F","G","H","I","J","K","L","M",
                            "N","O","P","Q","R","S","T","U","V","W","X","Y","Z",_OTHER);
	$num = count($alphabet) - 1;
	$authid = pnSecGenAuthKey();
	echo "<div style=\"text-align:center\">[ ";
	$counter = 0;
	while(list(, $ltr) = each($alphabet)) {
		echo "<a class=\"pn-normal\" href=\"modules.php?op=modload&amp;name=$GLOBALS[ModName]&amp;file=index&amp;letter=".pnVarPrepForDisplay($ltr)."&amp;sortby=$GLOBALS[sortby]&amp;authid=$authid\">".pnVarPrepForDisplay($ltr)."</a>";
		if ($counter == round($num/2)) {
			echo " ]\n<br />\n[ ";
		} elseif($counter != $num) {
			echo "&nbsp;|&nbsp;\n";
		}
		$counter++;
	}
	echo " ]\n</div>\n<br />\n";
}

// start of output
include 'header.php';
if (!pnSecAuthAction(0, 'Members_List::', '::', ACCESS_READ)) {
	echo _BADAUTHKEY;
	include 'footer.php';
	exit;
}

//Security Fix - Cleaning the search input
$sortby = pnVarCleanFromInput('sortby');
$pagesize = 20;
if ( (empty($sortby)) || ( ($sortby != "name") && ($sortby != "uname") && ($sortby != "femail") && ($sortby != "url") ) ){
	$sortby="uname";
} 
/* else {
	// Confirm authorisation code
	if (!pnSecConfirmAuthKey()) {
		echo _BADAUTHKEY;
		include 'footer.php';
		exit;
	}
} */

list ($letter, $page) = pnVarCleanFromInput('letter', 'page');
if (!isset($letter)) {
    $letter = "A";
}

if (!isset($page)) {
    $page = 1;
}


 // TODO
 // All of the code from here to around line 125 will be optimized a little later
 // This is the header section that displays the last registered and who's logged in and whatnot
$dbconn =& pnDBGetConn(true);
$pntable =& pnDBGetTables();

$column = &$pntable['users_column'];
//$myquery = buildSimpleQuery ('users', array ('uname'), '', "$column[uid] DESC", 1);
$myquery = "SELECT $column[uname]
			FROM $pntable[users]
			ORDER BY $column[uid] DESC";
$result =& $dbconn->SelectLimit($myquery,1);
list($lastuser) = $result->fields;

echo "\n\n<!-- MEMBERS LIST -->\n\n";
        echo"<a id=\"top\"></a>";
        echo "<div style=\"text-align:center\"><img src=\"modules/$GLOBALS[ModName]/images/logo.gif\" alt=\"\" /></div><br />\n";
        $result =& $dbconn->Execute("SELECT COUNT(*) FROM $pntable[users] where pn_uname NOT LIKE 'Anonymous'");
        list($numrows) = $result->fields;
        $result->Close();

        if(pnSecAuthAction(0, 'Users::', '::', ACCESS_COMMENT)){


            echo "<div style=\"text-align:center\"><span class=\"pn-normal\">[ <strong>"._NAVREG.": </strong>".pnVarPrepForDisplay($numrows)." | <strong>"._NAVONLINE.": </strong>";
                        getnumber('countnum');
                         echo" |\n";
            echo "<strong>"._NAVNEW.":</strong> ".pnVarPrepForDisplay($lastuser)." ]</span></div> <br />";
        }

        alpha();


// end of top memberlist section thingie
// This starts the beef...

        $min = $pagesize * ($page - 1); // This is where we start our record set from
        $max = $pagesize; // This is how many rows to select
        $column = &$pntable['users_column'];
        $count = "SELECT COUNT($column[uid]) FROM $pntable[users] ";

                //Security Fix - Cleaning the search input
                $sorting         = pnVarCleanFromInput('sorting');


                if (!$sorting){
        // Count all the users in the db..
        if (($letter != _OTHER) AND ($letter != _ALL)) {
            // are we listing all or "other" ?
            $where = "UPPER($column[uname]) LIKE UPPER('".pnVarPrepForStore($letter)."%')AND $column[uname] NOT LIKE 'Anonymous' ";
            // I guess we are not..
        } else if (($letter == _OTHER) AND ($letter != _ALL)) {
            // But other is numbers ?
            $where = "($column[uname] LIKE '0%'
                          OR $column[uname] LIKE '1%'
                          OR $column[uname] LIKE '2%'
                          OR $column[uname] LIKE '3%'
                          OR $column[uname] LIKE '4%'
                          OR $column[uname] LIKE '5%'
                          OR $column[uname] LIKE '6%'
                          OR $column[uname] LIKE '7%'
                          OR $column[uname] LIKE '8%'
                          OR $column[uname] LIKE '9%'
                          OR $column[uname] LIKE '-%'
                          OR $column[uname] LIKE '.%'
                          OR $column[uname] LIKE '@%'
                          OR $column[uname] LIKE '$%')";

            // fifers: while this is not the most eloquent solution, it is
            // cross database compatible.  We could do an if dbtype is mysql
            // then do the regexp.  consider for performance enhancement.
            //
            // "WHERE $column[uname] REGEXP \"^\[1-9]\" "
            // REGEX :D, although i think its MySQL only
            // Will have to change this later.
            // if you know a better way to match only the first char
            // to be a number in uname, please change it and email
            // sweede@gallatinriver.net the correction
            // or go to post-nuke project page and post
            // your correction there. Thanks, Bjorn.
        } else { // or we are unknown or all..
             $where = " $column[uname] NOT LIKE 'Anonymous'"; // this is to get rid of anoying "undefinied variable" message
        }
                }
                else
                {
                                $where = "$column[$sorting] LIKE '%".pnVarPrepForStore($letter)."%'";
                }
      search();

	  $where = "$where ORDER BY '".pnVarPrepForStore($sortby)."' ASC";
        // This is where we get our limit'd result set.
        //$myquery = buildSimpleQuery('users', array('uid', 'name', 'uname', 'femail', 'url', 'user_avatar','user_icq'), $where, "", $max, $min); //select our data
		$myquery = "SELECT $column[uid] AS \"uid\",
							$column[name] AS \"name\",
							$column[uname] AS \"uname\",
							$column[femail] AS \"femail\",
							$column[url] AS \"url\",
							$column[user_avatar] AS \"user_avatar\",
							$column[user_icq] AS \"user_icq\"
					FROM $pntable[users]
					WHERE ".$where."";
        $result =& $dbconn->SelectLimit($myquery,$max,$min);
		if ($dbconn->ErrorNo() != 0) {
			pnSessionSetVar('errormsg', 'Error: ' . $dbconn->ErrorNo() . ': ' . $dbconn->ErrorMsg());
		}
        $num_rows_per_order = $result->PO_RecordCount();
        echo "<br />";


        if ($letter != "front") {
            echo "<table width=\"95%\" style=\"text-align:center\"><tr><td style=\"text-align:right\"><span class=\"pn-normal\"> |<a href=\"#last\">"._LAST10REG."</a>| <a href=\"#online\">"._CURRENTONLINE."</a> |</span></td></tr></table><table width=\"95%\" border=\"0\" cellpadding=\"3\" cellspacing=\"1\" style=\"background-color:".$GLOBALS['bgcolor2']."text-align:center\"><tr style=\"background-color:".$GLOBALS['bgcolor2']."\">\n";
            echo "<td style=\"text-align:center\"><div style=\"text-align:center\"><span class=\"pn-normal\">"._ONLINESTATUS."</span></div></td><td style=\"text-align:center\" ><div style=\"text-align:center\"><span class=\"pn-normal\">"._MAVATAR."</span></div></td>\n";
                        echo "<td  style=\"text-align:center\">";
                        if ($GLOBALS['sortby'] == "uname" OR !$sortby) {
            echo "<span class=\"pn-normal\"><strong>"._MNICKNAME."</strong></span>";
        } else {
            echo "<a class=\"pn-normal\" href=\"modules.php?op=modload&amp;name=$GLOBALS[ModName]&amp;file=index&amp;letter=".pnVarPrepForDisplay($letter)."&amp;sortby=uname\">"._MNICKNAME."</a>";
        }
                        echo"</td>\n";
            echo "<td style=\"text-align:center\">";
                            if ($GLOBALS['sortby'] == "name") {
            echo "<span class=\"pn-normal\"><strong>"._MREALNAME."</strong></span>";
        } else {
            echo "<a class=\"pn-normal\" href=\"modules.php?op=modload&amp;name=$GLOBALS[ModName]&amp;file=index&amp;letter=".pnVarPrepForDisplay($letter)."&amp;sortby=name\">"._MREALNAME."</a>";
        }
                        echo"</td>\n";
            echo "<td style=\"text-align:center\">";
                            if ($GLOBALS['sortby'] == "femail") {
            echo "<span class=\"pn-normal\"><strong>"._PM."</strong></span>";
        } else {
            echo "<a class=\"pn-normal\" href=\"modules.php?op=modload&amp;name=$GLOBALS[ModName]&amp;file=index&amp;letter=".pnVarPrepForDisplay($letter)."&amp;sortby=femail\">"._PM."</a>";
        }
                        echo"</td>\n";
            echo "<td style=\"text-align:center\">";
                         if ($GLOBALS['sortby'] == "url") {
            echo "<span class=\"pn-normal\"><strong>"._MURL."&nbsp;</strong></span>";
        } else {
            echo "<a class=\"pn-normal\" href=\"modules.php?op=modload&amp;name=$GLOBALS[ModName]&amp;file=index&amp;letter=".pnVarPrepForDisplay($letter)."&amp;sortby=url\">"._MURL."</a>";
        }
                        echo"</td>\n";
            $cols = 4;
            if (pnSecAuthAction(0, 'Users::', '::', ACCESS_EDIT)){
                $cols = 6;
                echo "<td style=\"text-align:center\"><span class=\"pn-normal\"><strong>"._FUNCTIONS."</strong></span></td>\n";
            }
            echo "</tr>";
            $a = 0;

            $dcolor_A = "".$GLOBALS['bgcolor3']."";
            $dcolor_B = "".$GLOBALS['bgcolor1']."";

            $num_users = $result->PO_RecordCount(); //number of users per sorted and limit query
            if($num_rows_per_order > 0 ) {
                while(!$result->EOF) {
                    $user = $result->GetRowAssoc(false);
                    $result->MoveNext();
                                        $useruid= $user['uid'];
                                         $activetime = time() - (pnConfigGetVar('secinactivemins') * 60);
  $sessioninfocolumn = &$pntable['session_info_column'];
            $sessioninfotable = $pntable['session_info'];
 $onlinesess =& $dbconn->Execute("SELECT DISTINCT $sessioninfocolumn[uid]
                    FROM $sessioninfotable
                    WHERE $sessioninfocolumn[uid] = $useruid and $sessioninfocolumn[lastused] > $activetime");
    list($online) = $onlinesess->fields;
    if ($online > ''){
    $check = "<span style=\"color:red\" class=\"pn-normal\"><strong><img
src=\"modules/$GLOBALS[ModName]/images/online.gif\" alt=\"\" />"._STATUSONLINE."</strong></span>";
    }
    else
    {
    $check = "<span style=\"color:black\" class=\"pn-normal\"><img
src=\"modules/$GLOBALS[ModName]/images/offline.gif\" alt=\"\" />"._STATUSOFFLINE."</span>";
    }
                    $dcolor = ($a == 0 ? $dcolor_A : $dcolor_B);
                    echo "<tr><td style=\"text-align:center\;background-color:$dcolor;width:10px\">$check</td><td style=\"width40px;background-color:$dcolor;text-align:center;\">";
if($user['user_avatar']!=''){
echo"<img width=\"40\" src=\"images/avatar/".pnVarPrepForDisplay($user['user_avatar'])."\" alt=\"\" />";
}
echo"</td><td style=\"background-color:$dcolor\">&nbsp;&nbsp;<a class=\"pn-normal\" href=\"user.php?op=userinfo&amp;uname=$user[uname]\"><strong>".pnVarPrepForDisplay($user['uname'])."</strong></a>";
                                        if($user['user_icq'] >0) {
                echo "<img src=\"http://wwp.icq.com/scripts/online.dll?icq=".pnVarPrepForDisplay($user['user_icq'])."&amp;img=5\" />";
        }
                                        echo"&nbsp;</td>\n";
                    echo "<td style=\"background-color:$dcolor\">&nbsp;&nbsp;<span class=\"pn-normal\">".pnVarPrepForDisplay($user['name'])."&nbsp;</span></td>\n";
                    echo "<td style=\"background-color:$dcolor;text-align:center\"><strong><span class=\"pn-normal\">";
                                         if (pnUserLoggedIn()) {
                                        echo"<a href=\"modules.php?op=modload&amp;name=Messages&amp;file=replypmsg&amp;send=1&amp;uname=".pnVarPrepForDisplay($user['uname'])."\"><img src=\"modules/$GLOBALS[ModName]/images/mail.gif\" alt=\"\" /></a>";
}
else
{
echo"<a href=\"user.php\"><img src=\"modules/$GLOBALS[ModName]/images/mail.gif\" alt=\"\" /></a>";
}

echo"</span></strong></td>\n";
                    echo "<td style=\"background-color:$dcolor;text-align:center\">";

                if(!$user['url'] or $user['url']=="http://" or $user['url']=="http:///" )  {
                        $url = '';
                        $img ='';
                        }
                                else
                                {
                                $url = $user['url'] ;
                                $img ="<img src=\"modules/".$GLOBALS['ModName']."/images/url.gif\" alt=\"\" />";
                                }


            echo "<a href=\"$url\">$img</a>&nbsp;</td>\n";
                    if (pnSecAuthAction(0, 'Users::', '::', ACCESS_EDIT)){
                        $authid = pnSecGenAuthKey();
                        echo "<td style=\"background-color:$dcolor;text-align=:center;\"><span class=\"pn-normal\">[ <a class=\"pn-normal\" href=\"admin.php?module=NS-User&amp;op=modifyUser&amp;chng_uid=$user[uid]&amp;authid=$authid\"><span class=\"pn-normal\">"._EDIT."</span></a><span class=\"pn-sub\"> | </span>\n";
                        echo "<a class=\"pn-normal\" href=\"admin.php?module=NS-User&amp;op=delUser&amp;chng_uid=$user[uid]&amp;authid=$authid\"><span class=\"pn-normal\">"._DELETE."</span></a> ]</span></td>\n";
                    }
                    echo "</tr>";
                    $a = ($dcolor == $dcolor_A ? 1 : 0);
                }
                // start of next/prev/row links.
                echo "\n<tr><td colspan=\"9\" style=\"background-color:".$GLOBALS['bgcolor2']."\"><span class=\"pn-normal\">";
                getnumber('number');
                echo"</span></td></tr><tr style=\"background-color:".$GLOBALS['bgcolor2']."\"><td colspan=\"8\" style=\"background-color:".$GLOBALS['bgcolor2']."\"><span class=\"pn-normal\">";
                getnumber('online');
                echo"<br /></span></td></tr></table><br /><table width=\"95%\"><tr><td style=\"background-color:".$GLOBALS['bgcolor1']."\" colspan='7' align='right'>\n";


                echo "\t<table width=\"95%\" style=\"text-align:center\" cellspacing=\"0\" cellpadding=\"0\"><tr>";
                if (!empty($where)) {
                    $where = " WHERE $where";
                } else {
                    $where = '';
                }

                $resultcount =& $dbconn->Execute($count . $where);
                list ($numrows) = $resultcount->fields;
                $resultcount->Close();

                if ($numrows > $pagesize) {
                    $total_pages = ceil($numrows / $pagesize); // How many pages are we dealing with here ??
                    $prev_page = $page - 1;

                    if ( $prev_page > 0 ) {
                        echo "<td style=\"text-align:left;width:15%\"><a class=\"pn-normal\" href='modules.php?op=modload&amp;name=$GLOBALS[ModName]&amp;file=index&amp;letter=".pnVarPrepForDisplay($letter)."&amp;sortby=$sortby&amp;page=$prev_page'>";
                        echo "<img src=\"modules/$GLOBALS[ModName]/images/left.gif\" alt=\""._PREVIOUS." (".pnVarPrepForDisplay($prev_page).")\" /></a></td>";
                    } else {
                        echo "<td style=\"width:15%\">&nbsp;</td>\n";
                    }

                    echo "<td style=\"text-align:center;width:70%\">";
                    echo "<span class=\"pn-normal\"><strong>".pnVarPrepForDisplay($numrows)." "._USERSFOUND." ".pnVarPrepForDisplay($letter)."</strong><br />(".pnVarPrepForDisplay($total_pages)." "._PAGES.", ".pnVarPrepForDisplay($num_users)." "._USERSSHOWN.")</span>";
                    echo "</td>";

                    $next_page = $page + 1;
                    if ( $next_page <= $total_pages ) {
                        echo "<td align='right' width='15%'><a class=\"pn-normal\" href='modules.php?op=modload&amp;name=$GLOBALS[ModName]&amp;file=index&amp;letter=".pnVarPrepForDisplay($letter)."&amp;sortby=$sortby&amp;page=$next_page'>";
                        echo "<img src=\"modules/$GLOBALS[ModName]/images/right.gif\" alt=\""._NEXTPAGE." ($next_page)\" /></a></td>";
                    } else {
                        echo "<td width='15%'>&nbsp;</td></tr>\n";
                    }
                        // Added a numbered page list, only shows up to 50 pages.
                        echo "<tr><td colspan=\"3\"></td><tr><tr><td colspan=\"3\" style=\"text-align:center\">";
                        echo "<span class=\"pn-normal\">[ </span>";

                        for($n=1; $n < $total_pages; $n++) {
                            if ($n == $page) {
                                echo "<span class=\"pn-sub\"><strong>$n</strong></span></a>";
                        } else {
                echo "<a class=\"pn-normal\" href='modules.php?op=modload&amp;name=$GLOBALS[ModName]&amp;file=index&amp;letter=".pnVarPrepForDisplay($letter)."&amp;sortby=$GLOBALS[sortby]&amp;page=$n'>";
                echo "<span class=\"pn-sub\">".pnVarPrepForDisplay($n)."</span></a>";
                }
//                            if($n >= 50) {  // if more than 50 pages are required, break it at 50.
//                                $break = true;
//                                break;
//                            } else {  // guess not.
                                echo "<span class=\"pn-sub\"> | </span>";
//                            }
                        }

                        if(!isset($break)) { // are we supposed to break ?
                if($n == $page) {
                    echo "<span class=\"pn-sub\">".pnVarPrepForDisplay($n)."</span></a>";
                } else {
                    echo "<a class=\"pn-normal\" href='modules.php?op=modload&amp;name=$GLOBALS[ModName]&amp;file=index&amp;letter=".pnVarPrepForDisplay($letter)."&amp;sortby=$GLOBALS[sortby]&amp;page=$total_pages'>";
                    echo "<span class=\"pn-sub\">".pnVarPrepForDisplay($n)."</span></a>";
                }
                        }
                        echo "<span class=\"pn-sub\">]</span> ";
                        echo "</td></tr>";

// This is where it ends

                } else {  // or we dont have any users..
                    echo "<td align='center'>";
                    echo "<span class=\"pn-sub\">".pnVarPrepForDisplay($num_rows_per_order)." "._USERSFOUND." ".pnVarPrepForDisplay($letter)."</span>";
                    echo "</td></tr>";
                 }
                 echo "</table>\n";

                echo "</td></tr>\n";

// end of next/prev/row links

            } else { // no members for this letter.
                echo "<tr><td style=\"background-color:$dcolor_A;text-align:center;\" colspan=\"8\"><br />\n";
                echo "<span class=\"pn-normal\"><strong>"._NOMEMBERS."<br />- ".pnVarPrepForDisplay($letter)." -</strong></span>\n";
                echo "<br /><br /></td></tr>\n";
                echo "\n<tr><td colspan=\"9\" style=\"background-color:".$GLOBALS['bgcolor2']."\"><span class=\"pn-normal\">";
                getnumber('number');
                echo"</td></tr><tr style=\"background-color:".$GLOBALS['bgcolor2']."\"><td colspan=\"8\" style=\"background-color:".$GLOBALS['bgcolor2']."\">";
                getnumber('online');
                echo"<br /></span></td></tr>";
            }
            echo "\n</table><br />\n";
        }
echo"<a id=\"last\"></a>";
echo"<table width=\"95%\" style=\"background-color:".$GLOBALS['bgcolor2']."\" cellspacing=\"1\" cellpadding=\"3\"><tr style=\"background-color:".$GLOBALS['bgcolor2']."\"><td colspan=\"6\"><strong><span style=\"text-decoration:underline\" class=\"pn-normal\">"._LAST10REG.":</span></strong></td></tr>";
//$myquery2 = buildSimpleQuery('users', array('uid', 'name', 'uname', 'femail', 'url','user_regdate'),'pn_uname NOT LIKE "Anonymous"' , 'pn_uid DESC' , 10);
$myquery2 = "SELECT $column[uid] AS \"uid\",
					$column[name] AS \"name\",
					$column[uname] AS \"uname\",
					$column[femail] AS \"femail\",
					$column[url] AS \"url\",
					$column[user_regdate] AS \"user_regdate\"
			FROM $pntable[users]
			WHERE pn_uname NOT LIKE \"Anonymous\"
			ORDER BY $column[uid] DESC";
//select our data

        $result =& $dbconn->SelectLimit($myquery2,10);
		if ($dbconn->ErrorNo() != 0) {
			pnSessionSetVar('errormsg', 'Error: ' . $dbconn->ErrorNo() . ': ' . $dbconn->ErrorMsg());
		}
        $num_rows_per_order = $result->PO_RecordCount();
        //echo "<br />";
                  $a = 0;

            $dcolor_A = "".$GLOBALS['bgcolor3']."";
            $dcolor_B = "".$GLOBALS['bgcolor1']."";

            $num_users = $result->PO_RecordCount(); //number of users per sorted and limit query
            if($num_rows_per_order > 0 ) {
                while(!$result->EOF) {
                    $user = $result->GetRowAssoc(false);
                    $result->MoveNext();
                                        $useruid= $user['uid'];
                                         $activetime = time() - (pnConfigGetVar('secinactivemins') * 60);
                          $sessioninfocolumn = &$pntable['session_info_column'];
            $sessioninfotable = $pntable['session_info'];
                         $onlinesess =& $dbconn->Execute("SELECT DISTINCT $sessioninfocolumn[uid]
                    FROM $sessioninfotable
                    WHERE $sessioninfocolumn[uid] = $useruid and $sessioninfocolumn[lastused] > $activetime");
    list($online) = $onlinesess->fields;
    if ($online > ''){
    $check = "<span style=\"color:red\" class=\"pn-normal\"><strong><img
src=\"modules/$GLOBALS[ModName]/images/online.gif\" alt=\"\" />"._STATUSONLINE."</strong></span>";
    }
    else
    {
    $check = "<span style=\"color:black\" class=\"pn-normal\"><img
src=\"modules/$GLOBALS[ModName]/images/offline.gif\" alt=\"\" />"._STATUSOFFLINE."</span>";
    }
                    $dcolor = ($a == 0 ? $dcolor_A : $dcolor_B);
                                        $newresult =& $dbconn->Execute("select pn_user_regdate from $pntable[users] where pn_uid=".pnVarPrepForDisplay($user['uid'])."");
            list($user_regdate)= $newresult->fields;
                    echo "<tr><td style=\"background-color:$dcolor;text-align:center;width:10px\">
$check</td><td style=\"background-color:$dcolor\"><a class=\"pn-normal\" href=\"user.php?op=userinfo&amp;uname=".pnVarPrepForDisplay($user['uname'])."\"><strong>".pnVarPrepForDisplay($user['uname'])."</strong></a></td><td style=\"background-color:$dcolor\"><span class=\"pn-normal\">".date('d.m.Y',$user_regdate)."</span></td>\n";
                    echo "<td style=\"background-color:$dcolor\">&nbsp;&nbsp;<strong><span class=\"pn-normal\">".pnVarPrepForDisplay($user['name'])."&nbsp;</span></strong></td>\n";
                    echo "<td style=\"background-color:$dcolor;text-align:center;width:11px\">";
if(!$user['url'] or $user['url']=="http://" or $user['url']=="http:///")  {
                        $user['url'] = '';
                        $img ='&nbsp;';
                        }
                                else
                                {
                                $url = $user['url'] ;
                                $img ="<img src=\"modules/$GLOBALS[ModName]/images/url.gif\" alt=\"\" />";
                                }


            echo "<a href=\"$url\">$img</a></td>\n";

 echo "<td style=\"background-color:$dcolor;text-align:center;width:18px\"><a href=\"modules.php?op=modload&amp;name=Messages&amp;file=replypmsg&amp;send=1&amp;uname=".pnVarPrepForDisplay($user['uname'])."\"><img src=\"modules/$GLOBALS[ModName]/images/mail.gif\" alt=\"\" /></a></td>\n";


                    echo "</tr>";
                    $a = ($dcolor == $dcolor_A ? 1 : 0);
                }
                                }
echo"</table><table width=\"95%\"><tr><td style=\"text-align:right\"><span class=\"pn-normal\">|<a href=\"#top\">"._BACKTOTOP."</a>|</span></td></tr></table><br />";

        include 'footer.php';
?>