<?PHP
// File: $Id: admin.php,v 1.10 2004/05/06 16:25:46 landseer Exp $ $Name: HEAD $
// ----------------------------------------------------------------------
// PostNuke Content Management System
// Copyright (C) 2001 by the PostNuke Development Team.
// http://www.postnuke.com/
// ----------------------------------------------------------------------
// Based on:
// PHP-NUKE Web Portal System - http://phpnuke.org/
// Thatware - http://thatware.org/
// ----------------------------------------------------------------------
// LICENSE
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License (GPL)
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// To read the license please visit http://www.gnu.org/copyleft/gpl.html
// ----------------------------------------------------------------------
// Original Author of file:
// Purpose of file:
// ----------------------------------------------------------------------

if (!eregi("admin.php", $_SERVER['PHP_SELF'])) {
    die ("Access Denied");
}

if (pnSecAuthAction(0, 'Submit News::', '::', ACCESS_ADMIN)) {

modules_get_language();
modules_get_manual();

function submit_news_admin_getConfig() {

    include ("header.php");

    // prepare vars
    $sel_notify['0'] = '';
    $sel_notify['1'] = '';
    $sel_notify[pnConfigGetVar('notify')] = ' checked="checked"';

    GraphicAdmin();
    OpenTable();
    echo "<div style=\"text-align:center\"><span class=\"pn-title\"><strong>"._SUBMITCONF."</strong></span></div>";
    CloseTable();

    $status = pnGetStatusMsg();
    if(!empty($status)) {
        OpenTable();
        echo "<div class=\"pn-normal\" style=\"font-weight:bold;\">$status</div>";
        CloseTable();
    }
    
    OpenTable();
    print '<form action="admin.php" method="post"><div>' 
	    .'<table border="0"><tr><td class="pn-normal">'
        ._NOTIFYSUBMISSION.'</td><td class="pn-normal">'
	    ."<input type=\"radio\" name=\"xnotify\" value=\"1\" class=\"pn-normal\"".$sel_notify['1']." />"._YES.' &nbsp;'
        ."<input type=\"radio\" name=\"xnotify\" value=\"0\" class=\"pn-normal\"".$sel_notify['0']." />"._NO
        .'</td></tr><tr><td class="pn-normal">'
        ._EMAIL2SENDMSG.":</td><td><input type=\"text\" name=\"xnotify_email\" value=\"".pnConfigGetVar('notify_email')."\" size=\"30\" maxlength=\"100\" class=\"pn-normal\" />"
        .'</td></tr><tr><td class="pn-normal">'
        ._EMAILSUBJECT.":</td><td><input type=\"text\" name=\"xnotify_subject\" value=\"".pnConfigGetVar('notify_subject')."\" size=\"50\" maxlength=\"100\" class=\"pn-normal\" />"
        .'</td></tr><tr><td class="pn-normal">'
        ._EMAILMSG.':</td><td><textarea name="xnotify_message" cols="80" rows="10" class="pn-normal">'.htmlspecialchars(pnConfigGetVar('notify_message')).'</textarea>'
        .'</td></tr><tr><td class="pn-normal">'
        ._EMAILFROM.":</td><td><input type=\"text\" name=\"xnotify_from\" value=\"".pnConfigGetVar('notify_from')."\" size=\"15\" maxlength=\"255\" class=\"pn-normal\" />"
        .'</td></tr></table>'
        ."<input type=\"hidden\" name=\"module\" value=\"".$GLOBALS['module']."\" />"
        ."<input type=\"hidden\" name=\"op\" value=\"updateConfig\" />"
	    ."<input type=\"hidden\" name=\"authid\" value=\"" . pnSecGenAuthKey() . "\" />"
        ."<input type=\"submit\" value=\""._SUBMIT."\" />"
        ."</div></form>";
    ;
    CloseTable();

    include ("footer.php");

}

// new [landseer]
function submit_news_admin_updateConfig()
{
    if (!pnSecAuthAction(0, 'Submit News::', '::', ACCESS_ADMIN)) {
        include 'header.php';
        echo _NOAUTH;
        include 'footer.php';
    } 
    if (!pnSecConfirmAuthKey()) {
        include 'header.php';
        echo _BADAUTHKEY;
        include 'footer.php';
        exit;
    }
    
    list( $xnotify,
          $xnotify_email, 
          $xnotify_subject, 
          $xnotify_message, 
          $xnotify_from ) = pnVarCleanFromInput( 'xnotify',
                                                 'xnotify_email',
                                                 'xnotify_subject',
                                                 'xnotify_message',
                                                 'xnotify_from' );
    // minimum checks
    pnConfigSetVar('notify_subject', $xnotify_subject );
    pnConfigSetVar('notify_message', $xnotify_message );
    $xnotify_from = (isset($xnotify_from)) ? $xnotify_from : pnConfigGetVar('sitename');
    pnConfigSetVar('notify_from', $xnotify_from );
    if(($xnotify==0) || ($xnotify==1)) {
        pnConfigSetVar('notify',$xnotify);
    }
    if(($xnotify==1) && (isset($xnotify_email) && (pnVarValidate($xnotify_email,'email')==false ))) {
        pnSessionSetVar('errormsg', _SUBMITVALIDEMAILADDRESSNEEDED );
    } else {
        pnConfigSetVar('notify_email', $xnotify_email);
    }
    pnRedirect('admin.php?module=Submit_News&op=main');
}

/*
function submit_news_admin_setConfig($var)
{
    if (!pnSecConfirmAuthKey()) {
        include 'header.php';
        echo _BADAUTHKEY;
        include 'footer.php';
        exit;
    }
    // Escape some characters in these variables.
    // hehe, I like doing this, much cleaner :-)
    $fixvars = array('xnotify_message',
		     'xnotify_from',
		     'xnotify_subject');

    // todo: make FixConfigQuotes global / replace with other function
    foreach ($fixvars as $v) {
	//$var[$v] = FixConfigQuotes($var[$v]);
    }

    // Set any numerical variables that havn't been set, to 0. i.e. paranoia check :-)
    $fixvars = array ('xtop',);

    foreach($fixvars as $v) {
        if(empty($var[$v])) {
            $var[$v] = 0;
        }
    }

    // all variables starting with x are the config vars.
    while(list($key, $val) = each($var)) {
        if(substr($key, 0, 1) == 'x') {
            pnConfigSetVar(substr($key, 1), $val);
        }
    }
    pnRedirect('admin.php');
}
*/
function submit_news_admin_main($var)
{
   $op = pnVarCleanFromInput('op');
   extract($var);

   switch ($op) {

    case "getConfig":
        submit_news_admin_getConfig();
        break;
/*
    case "setConfig":
        submit_news_admin_setConfig($var);
        break;
*/
    case "updateConfig":
        submit_news_admin_updateConfig($var);
        break;

    default:
        submit_news_admin_getConfig();
        break;
   }
}

} else {
    echo "Access Denied";
}
?>