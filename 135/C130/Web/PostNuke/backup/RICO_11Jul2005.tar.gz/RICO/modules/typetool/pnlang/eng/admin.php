<?php
define('_TYPETOOLNOCONFCHANGE', 'Sorry! TypeTool configuration not updated');
define('_TYPETOOLSETTINGS', 'TypeTool settings');
define('_TYPETOOLONOFF', 'TypeTool active');
define('_TYPETOOLLANGUAGE', 'TypeTool language');
define('_TYPETOOLUPDATE', 'save');
define('_TYPETOOLLOADFAILED', 'Sorry! There was a problem loading the TypeTool administration page ');
define('_TYPETOOLUPDATED', 'TypeTool configuration updated');
?>