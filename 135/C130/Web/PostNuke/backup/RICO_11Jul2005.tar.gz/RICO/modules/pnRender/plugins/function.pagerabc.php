<?php

/**
 * pnRender plugin
 * 
 * This file is a plugin for pnRender, the PostNuke implementation of Smarty
 *
 * @package      Xanthia_Templating_Environment
 * @subpackage   pnRender
 * @version      $Id: function.pagerabc.php,v 1.6 2004/08/14 21:47:51 markwest Exp $
 * @author      Peter Dudas <duda at bigfish dot hu>
 */ 

/**
* Smarty plugin
* -------------------------------------------------------------
* Type:     function
* Name:     pagerabc
* Purpose:  displays selection links (eg: filter according the abc)
* Version:  1.0
* Date:     September 25, 2002
* Purpose:  print out
* Install:  Drop into the plugin directory
* Author:   Peter Dudas <duda at bigfish dot hu>
* -------------------------------------------------------------
*        CHANGES:     2002.09.25        - created
*
*    example:
*    code:
*    <{pagerabc posvar="abc" class_num="dl" class_numon="header" separator=" &nbsp;-&nbsp; " names="A,B;C,D;E,F;G,H;I,J;K,L;M,N,O;P,Q,R;S,T;U,V,W,X,Y,Z"}>
*    result
*<a class="header" href="/egyuttes.php?&abc=A,B">A,B</a> &nbsp;-&nbsp; <a class="dl" href="/egyuttes.php?&abc=C,D">C,D</a> &nbsp;-&nbsp; <a class="dl" href="/egyuttes.php?&abc=E,F">E,F</a> &nbsp;-&nbsp; <a class="dl" href="/egyuttes.php?&abc=G,H">G,H</a> &nbsp;-&nbsp; <a class="dl" href="/egyuttes.php?&abc=I,J">I,J</a> &nbsp;-&nbsp; <a class="dl" href="/egyuttes.php?&abc=K,L">K,L</a> &nbsp;-&nbsp; <a class="dl" href="/egyuttes.php?&abc=M,N,O">M,N,O</a> &nbsp;-&nbsp; <a class="dl" href="/egyuttes.php?&abc=P,Q,R">P,Q,R</a> &nbsp;-&nbsp; <a class="dl" href="/egyuttes.php?&abc=S,T">S,T</a> &nbsp;-&nbsp; <a class="dl" href="/egyuttes.php?&abc=U,V,W,X,Y,Z">U,V,W,X,Y,Z</a></p>
*
*
*/
function smarty_function_pagerabc($params, &$smarty)
{
/*    
Parameters
    @param    string     $posvar           - name of the php variable that contains the position data ($_REQUEST)
    @param    cvs        $forwardvars      - comma separated list of php variable names to forward in the links
	@param    cvs        $additionalvars   - comma separated list of addutional php variable names and values to forward in the links
    @param    string     $class_num        - class for the page numbers <A> tag!
    @param    string     $class_numon      - class for the active page!
    @param    string     $separator        - tags to print between the letters (eg: - )
    @param    string     $printempty       - print empty sel ('-')
    @param    string     $lang             - language
    @param    array      $names            - values to select from (array or csv)
    @param    array      $values           - values to select from (array or csv)
    @param    string     $skin             - use predefined values (hu - hungarian ABC)
*/
    foreach($params as $tmp=>$value)    {
        $tmp = strtolower($tmp);
        $$tmp = $value;
    }
    
    $out = '';
    if (empty($posvar))    {
        die('unset variable posvar in smarty func pagerabc');
    }
    
    if (!empty($names))    {
        if (!is_array($names))    {
            $names = explode(';', $names);
        }
        if (!empty($values))    {
            if (!is_array($values))    {
                $values = explode(';', $values);
            }
        } else    {
            $values = $names;
        }
    } else    {
        // predefined abc
        if (strtolower($skin) == 'hu') {
            $names = array('A','�','B','C','D','E','�','F','G','H','I','�','J','K','L','M','N','O','�','�','O','P','Q','R','S','T','U','�','�','U','V','W','X','Y','Z');
            $values = array('A','�','B','C','D','E','�','F','G','H','I','�','J','K','L','M','N','O','�','�','O','P','Q','R','S','T','U','�','�','U','V','W','X','Y','Z');
            //$names = array('A'    ,'B','C','D','E'    ,'F','G','H','I','J','K','L','M','N','O'        ,'P','Q','R','S','T','U'    ,'V','W','X','Y','Z');
            //$values = array('A,�','B','C','D','E,�','F','G','H','I,�','J','K','L','M','N','O,�,�,O','P','Q','R','S','T','U,�,�,U','V','W','X','Y','Z');
        } else    {    
            $names = array('A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U'    ,'V','W','X','Y','Z');
            $values = array('A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z');
        }
    }

    if (!is_array($forwardvars))    {
        $forwardvars = preg_split('/[,;]/', $forwardvars);
    }
    $url = $_SERVER['PHP_SELF'].'?';
    foreach ((array)$forwardvars as $tmp)    {
        if (!empty($tmp) AND (!empty($_REQUEST[$tmp])))
            $url .= '&amp;'.$tmp.'='.$_REQUEST[$tmp];
    }

	if (isset($additionalvars)) {
		if (!is_array($additionalvars))    {
			$additionalvars = preg_split('/[,;]/', $additionalvars);
		}
		foreach ((array)$additionalvars as $tmp)    {
			$additionalvar = preg_split('/[=]/', $tmp);
			if (!empty($tmp))
				$url .= '&amp;'.$additionalvar[0].'='.$additionalvar[1];
		}
	}
    $tmp = '';
    if (isset($printempty) && $printempty == true)    {
        if (!empty($class_num))    {
            $tmp = ' class="'.$class_num.'"';
        }
        $out .= '<a'.$tmp.' href="'.$url.'&amp;'.$posvar.'=">-</a>'.$separator;
    }
    
    $tmp = '';
    foreach($names as $i=>$nam) {
        if (!empty($class_numon))    {
            if ($_REQUEST[$posvar] == $values[$i])    {
                $tmp = ' class="'.$class_numon.'"';
            } elseif (!empty($class_num))    {
                $tmp = ' class="'.$class_num.'"';
            }
        }
        if ($i > 0)    {
            $out .= $separator;
        }
        $out .= '<a'.$tmp.' href="'.$url.'&amp;'.$posvar.'='.$values[$i].'">'.$nam.'</a>';
    }
    print $out;
}

?> 