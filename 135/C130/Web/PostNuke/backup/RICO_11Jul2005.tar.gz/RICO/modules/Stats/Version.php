<?php // $Id: Version.php,v 1.3 2002/11/03 05:40:40 neo Exp $ $Name: HEAD $

$modversion['name'] = 'Stats';
$modversion['version'] = '1.13';
$modversion['description'] = 'Display site statistics';
$modversion['credits'] = 'docs/credits.txt';
$modversion['help'] = 'docs/install.txt';
$modversion['changelog'] = 'docs/changelog.txt';
$modversion['license'] = 'docs/license.txt';
$modversion['official'] = 1;
$modversion['author'] = 'Francisco Burzi';
$modversion['contact'] = 'http://www.phpnuke.org';
$modversion['admin'] = 0;
$modversion['securityschema'] = array('Stats::' => '::');

?>