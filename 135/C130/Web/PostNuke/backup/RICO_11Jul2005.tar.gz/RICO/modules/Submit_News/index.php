<?php // $Id: index.php,v 1.33 2004/08/12 18:30:03 larsneo Exp $ $Name: HEAD $
// ----------------------------------------------------------------------
// PostNuke Content Management System
// Copyright (C) 2001 by the PostNuke Development Team.
// http://www.postnuke.com/
// ----------------------------------------------------------------------
// Based on:
// PHP-NUKE Web Portal System - http://phpnuke.org/
// Thatware - http://thatware.org/
// ----------------------------------------------------------------------
// LICENSE
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License (GPL)
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// To read the license please visit http://www.gnu.org/copyleft/gpl.html
// ----------------------------------------------------------------------
// Filename: modules/Submit_News/index.php
// Original Author of file: Francisco Burzi
// Purpose of file: Submit news to site
// ----------------------------------------------------------------------

if (!defined("LOADED_AS_MODULE")) {
    die ("You can't access this file directly...");
}

$ModName = basename( dirname( __FILE__ ) );

modules_get_language();

function defaultDisplay()
{
// ML added global and dropdown with available languages

   // global $ModName, $topic, $sel;

    $ModName = $GLOBALS['ModName'];
    if (isset($GLOBALS['topic'])) {
	    $topic = $GLOBALS['topic'];
	}
	if (isset($GLOBALS['sel'])) {
    	$sel = $GLOBALS['sel'];
    }

    $dbconn =& pnDBGetConn(true);
    $pntable =& pnDBGetTables();

    $currentlang = pnUserGetLang();

    include ('header.php');
    if (!pnSecAuthAction(0, 'Submit news::', '::', ACCESS_COMMENT)) {
        echo _NOTALLOWED;
        include 'footer.php';
        exit;
    }

    OpenTable();
    echo "<div style=\"text-align:center\"><span class=\"pn-title\">"._SUBMITNEWS."</span><br /><br />";
    echo "<span class=\"pn-normal\">"._SUBMITADVICE."</span></div><br />";
    CloseTable();

    OpenTable();

    echo "<div><form action=\"modules.php?op=modload&amp;name=$ModName&amp;file=index\" method=\"post\">"
    ."<span class=\"pn-normal\"><strong>"._YOURNAME.":</strong> ";
    if (pnUserLoggedIn()) {
        echo "<a class=\"pn-normal\" href=\"user.php\">" . pnUserGetVar('uname') . "</a>";
    } else {
        echo pnConfigGetVar('anonymous');
    }
    echo "<br /><br />"
        ."<strong><label for=\"subtitle\">"._SUBTITLE."</label></strong> "
        ."("._BEDESCRIPTIVE.")<br />"
        ."<input type=\"text\" name=\"subject\" size=\"50\" maxlength=\"80\" id=\"subtitle\" tabindex=\"0\" /> "._REQUIRED."<br />("._BADTITLES.")"
        ."<br /><br />"
        ."<strong><label for=\"topic\">"._TOPIC."</label>:</strong> <select name=\"topic\" class=\"pn-text\" id=\"topic\">";
    $column = &$pntable['topics_column'];
    $toplist =& $dbconn->Execute("SELECT $column[topicid], $column[topictext], $column[topicname]
                               FROM $pntable[topics]
                               ORDER BY $column[topictext]");
    echo "<option value=\"\">"._SELECTTOPIC."</option>\n";

    while(list($topicid, $topics, $topicname) = $toplist->fields) {
        if (pnSecAuthAction(0, 'Topics::Topic', "$topicname::$topicid", ACCESS_COMMENT))
        {
            if ($topicid==$topic) {
                $sel = "selected=\"selected\"";
            }
            echo "<option $sel value=\"".pnVarPrepForStore($topicid)."\">".pnVarPrepForDisplay($topics)."</option>\n";
            $sel = "";
        }
        $toplist->MoveNext();
    }
    echo "</select>";

    echo "<br /><br /><strong><label for=\"language\">"._LANGUAGE."</label>: </strong>"; // ML added dropdown , currentlang is pre-selected

    lang_dropdown();

    echo "<br /><br /><strong><label for=\"articletext\">"._ARTICLETEXT."</label></strong> "
        ."("._HTMLISFINE.")<br />"
        ."<textarea class=\"pn-normal\" cols=\"80\" rows=\"10\" name=\"storytext\" id=\"articletext\"></textarea> "._REQUIRED."<br />"
        ."<br /><strong><label for=\"extendedtext\">"._EXTENDEDTEXT."</label></strong>"
        ."<br /><textarea class=\"pn-normal\" cols=\"80\" rows=\"10\" name=\"bodytext\" id=\"extendedtext\"></textarea><br />";

	// show pagebreak instructions
	echo ''._PAGEBREAK.'<br />';
    // Show allowable HTML
    echo ''._ALLOWEDHTML.'<br />';
    $AllowableHTML = pnConfigGetVar('AllowableHTML');
    while (list($key, $access, ) = each($AllowableHTML)) {
        if ($access > 0) echo " &lt;".$key."&gt;";
    }
    echo "<br /><br />("._AREYOUSURE.")<br /><br />"
            ."<input type=\"submit\" name=\"request_preview\" value=\""._PREVIEW."\" />";
    echo "</span></form></div>";
    CloseTable();
    include ('footer.php');
}

function PreviewStory()
{
    list($name,
         $address,
         $subject,
         $storytext,
         $topic,
         $alanguage,
         $bodytext) = pnVarCleanFromInput('name',
                                          'address',
                                          'subject',
                                          'storytext',
                                          'topic',
                                          'alanguage',
                                          'bodytext');

    $subject    = pnVarCensor($subject);
    $storytext  = pnVarCensor($storytext);
    $bodytext   = pnVarCensor($bodytext);

    $dbconn =& pnDBGetConn(true);
    $pntable =& pnDBGetTables();

  //  global $bgcolor1, $bgcolor2, $ModName;

    //$bgcolor1 = $GLOBALS['bgcolor1'];
    //$bgcolor2 = $GLOBALS['bgcolor2'];
    $ModName = $GLOBALS['ModName'];


    include ('header.php');

    $tipath = pnConfigGetVar('tipath');
    $anonymous = pnConfigGetVar('anonymous');

    if (!pnSecAuthAction(0, 'Submit news::', '::', ACCESS_COMMENT)) {
        echo _NOTALLOWED;
        include 'footer.php';
        exit;
    }

    if($subject == '' || $storytext == '') {
        OpenTable2();
        echo "<span class=\"pn-normal\"><strong>"._MPROBLEM."</strong> "._NOSUBJECT."</span><br /><br /><br />";
        echo "<div style=\"text-align:center\"><span class=\"pn-normal\">"._GOBACK."</span></div><br /><br />";
        CloseTable2();
        include("footer.php");
        exit;
    }

    OpenTable();
    echo "<div style=\"text-align:center\"><span class=\"pn-title\">"._NEWSUBPREVIEW."</span></div>";
    CloseTable();

    OpenTable();
    echo "<div style=\"text-align:center\"><span class=\"pn-normal\"><em>"._STORYLOOK."</em></span></div><br /><br />";
    echo "<table width=\"70%\" bgcolor=\"".$GLOBALS['bgcolor2']."\" cellpadding=\"0\" cellspacing=\"1\" border=\"0\"align=\"center\"><tr><td>"
    ."<table width=\"100%\" bgcolor=\"".$GLOBALS['bgcolor1']."\" cellpadding=\"8\" cellspacing=\"1\" border=\"0\"><tr><td>";
    if ($topic=="") {
        $topicimage="AllTopics.gif";
        $warning = "<br /><br /><strong>"._SELECTTOPIC."</strong><br /><br />";
		$topictext='';
    } else {
        $warning = "";
        $column = &$pntable['topics_column'];
        $result =& $dbconn->Execute("SELECT $column[topicimage],
									       $column[topictext]
                                  FROM $pntable[topics]
                                  WHERE $column[topicid]='".pnVarPrepForStore($topic)."'");
        list($topicimage,$topictext) = $result->fields;
    }
    echo "<img src=\"$tipath$topicimage\" align=\"right\" alt=\"$topictext\" />";

    story_preview($subject, $storytext, $bodytext);

    echo "<div style=\"text-align:center\">"
    ."<span class=\"pn-title\">".pnVarPrepHTMLDisplay($warning)."</span>"
    ."</div>"
    ."</td></tr></table></td></tr></table>"
    ."<br /><br /><div style=\"text-align:center\"><span class=\"pn-sub\">"._CHECKSTORY."</span></div>";
    CloseTable();

    OpenTable();
    echo "<div><form action=\"modules.php?op=modload&amp;name=$ModName&amp;file=index\" method=\"post\"><div><span class=\"pn-normal\">"
    ."<strong>"._YOURNAME.":</strong> ";
    if (pnUserLoggedIn()) {
        echo "<a class=\"pn-normal\" href=\"user.php\">" . pnUserGetVar('uname') . "</a> <span class=\"pn-normal\">[ <a class=\"pn-normal\" href=\"user.php?module=NS-User&amp;op=logout\">"._LOGOUT."</a> ]</span>";
    } else {
        echo "".pnVarPrepForDisplay($anonymous)."";
    }
    echo "<br /><br /><strong>"._SUBTITLE.":</strong><br />"
    ."<input type=\"text\" name=\"subject\" size=\"50\" maxlength=\"80\" value=\"" . pnVarPrepForDisplay($subject) . "\" /> "
    ._REQUIRED."<br /><br /><strong>"._TOPIC.": </strong><select name=\"topic\" class=\"pn-text\">";
    $column = &$pntable['topics_column'];
    $toplist =& $dbconn->Execute("SELECT $column[topicid], $column[topictext], $column[topicname]
                               FROM $pntable[topics]
                               ORDER BY $column[topictext]");
    echo "<option value=\"\">"._SELECTTOPIC."</option>\n";
    while(list($topicid, $topics, $topicname) = $toplist->fields) {
        if (pnSecAuthAction(0,'Topics::Topic',"$topicname::$topicid", ACCESS_COMMENT))
        {
            if ($topicid == $topic) {
                $sel="selected=\"selected\"";
                echo "<option value=\"$topicid\" $sel>".pnVarPrepForDisplay($topics)."</option>\n";
            } else {
                echo "<option value=\"$topicid\">".pnVarPrepForDisplay($topics)."</option>\n";
            }
            $sel="";
        }
        $toplist->MoveNext();
    }
    echo "</select>";
    echo "<br /><br /><strong>"._LANGUAGE.": </strong>";

    lang_dropdown();

    echo"<br /><br /><strong>"._ARTICLETEXT."</strong> "
        ."("._HTMLISFINE.")<br />"
        ."<textarea cols=\"80\" rows=\"10\" name=\"storytext\">" . pnVarPrepForDisplay($storytext) . "</textarea> "._REQUIRED."<br />"
        ."<br /><strong>"._EXTENDEDTEXT."</strong>"
        ."<br /><textarea cols=\"80\" rows=\"10\" name=\"bodytext\">" . pnVarPrepForDisplay($bodytext) . "</textarea><br />"
        ."<span class=\"pn-normal\">("._AREYOUSURE.")</span><br /><br />"
        ."<input type=\"submit\" name=\"request_preview\" value=\""._PREVIEW."\"> <input type=\"submit\" name=\"request_ok\" value=\""._OK."\" />"
        ."</span></div></form></div>";
    CloseTable();

    include 'footer.php';
}

function submitStory()
{
    list($name,
         $subject,
         $storytext,
         $topic,
         $alanguage,
         $bodytext) = pnVarCleanFromInput('name',
                                          'subject',
                                          'storytext',
                                          'topic',
                                          'alanguage',
                                          'bodytext');

 //   global $EditedMessage, $ModName;

    //$EditedMessage = $GLOBALS['EditedMessage'];
    $ModName = $GLOBALS['ModName'];

    $dbconn =& pnDBGetConn(true);
    $pntable =& pnDBGetTables();

    if (!pnSecAuthAction(0, 'Submit news::', '::', ACCESS_COMMENT)) {
        include ('header.php');
        echo _NOTALLOWED;
        include 'footer.php';
        exit;
    }

    if (empty($subject)) {
        include 'header.php';
        ECHO _STORYNEEDSTITLE;
        include 'footer.php';
        exit;
    }

    if (pnUserLoggedIn()) {
        $uid = pnUserGetVar('uid');
        $name = pnUserGetVar('uname');
    } else {
        $uid = 1;
		$name = pnConfigGetVar('anonymous');
    }

    $column = &$pntable['queue_column'];
    $newid = $dbconn->GenId($pntable['queue']);
    $result =& $dbconn->Execute("INSERT INTO $pntable[queue] (
                                  $column[qid],
                                  $column[uid],
                                  $column[arcd],
                                  $column[uname],
                                  $column[subject],
                                  $column[story],
                                  $column[timestamp],
                                  $column[topic],
                                  $column[alanguage],
                                  $column[bodytext])
                                VALUES (" . pnVarPrepForStore($newid). ",
                                        '" . pnVarPrepForStore($uid) . "',
                                        '0',
                                        '" . pnVarPrepForStore($name) . "',
                                        '" . pnVarPrepForStore($subject) . "',
                                        '" . pnVarPrepForStore($storytext) . "',
                                        now(),
                                        '" . pnVarPrepForStore($topic) . "',
                                        '" . pnVarPrepForStore($alanguage) . "',
                                        '" . pnVarPrepForStore($bodytext) . "')");

    if($dbconn->ErrorNo()<>0) {
        echo $dbconn->ErrorNo(). ": ".$dbconn->ErrorMsg(). "<br />";
        exit();
    }
    if(pnConfigGetVar('notify')) {
        pnMail(pnConfigGetVar('notify_email'),
             str_replace("www.","",$_SERVER['SERVER_NAME']).' - '.pnConfigGetVar('notify_subject'),
             pnConfigGetVar('notify_message').': http://'.$_SERVER['SERVER_NAME'],
             'From: '.pnConfigGetVar('notify_from')
                     ."\nX-Mailer: PHP/".phpversion());
    }
    include 'header.php';

    OpenTable();
    $column = &$pntable['queue_column'];
    $result =& $dbconn->Execute("SELECT count(*) FROM $pntable[queue] WHERE $column[arcd]='0'");
    list($waiting) = $result->fields;
    echo "<div style=\"text-align:center\"><span class=\"pn-title\">"._SUBSENT."</span><br /><br />"
    ."<span class=\"pn-normal\">"._THANKSSUB."<br /><br />"
    .""._SUBTEXT.""
    ."<br />"._WEHAVESUB." $waiting "._WAITING."</span></div>";
    CloseTable();
    include ('footer.php');
}

/**
 * Preview function for submitted stories.
 */
function story_preview($title, $hometext, $bodytext="", $notes="") {
    list($hometext,
         $bodytext) = pnModCallHooks('item',
                                  'transform',
                                  '',
                                  array($hometext,
                                        $bodytext));

    echo "<span class=\"pn-title\"><strong>" . pnVarPrepForDisplay($title) . "</strong></span><br /><br /><span class=\"pn-normal\">" . pnVarPrepHTMLDisplay(nl2br($hometext)) . "</span>";
    if ($bodytext != "") {
        echo "<br /><br /><span class=\"pn-normal\">" . pnVarPrepHTMLDisplay(nl2br($bodytext)) . "</span>";
    }
    if ($notes != "") {
        echo "<br /><br /><span class=\"pn-normal\"><strong>"._NOTE."</strong> <em>" . pnVarPrepHTMLDisplay(nl2br($notes)) . "</em></span>";
    }
}

//
// Resolve the action requested: Preview or Ok (i.e. submit it!) ?
// [plamendp]
//  global $request_preview, $request_ok;
/*if (isset($GLOBALS['request_preview'])) {
	$request_preview = $GLOBALS['request_preview'];
} else {
	$request_preview = "";
}
if (isset($GLOBALS['request_ok'])) {
	$request_ok = $GLOBALS['request_ok'];
} else {
	$request_ok = "";
}*/
list ($request_preview, $request_ok) = pnVarCleanFromInput('request_preview', 'request_ok');
	
$req = "";
if ($request_preview) $req = "PREVIEW";
elseif ($request_ok)  $req = "OK";

switch($req) {

    case "PREVIEW":
        PreviewStory();
        break;

    case "OK":
        SubmitStory();
        break;

    default:
        defaultDisplay();
        break;
}
?>