<?php // $Id: changetheme.php,v 1.14 2004/05/15 19:45:19 markwest Exp $

if (eregi('changetheme.php', $_SERVER['PHP_SELF'])) {
	die ("You can't access this file directly...");
}

modules_get_language();

function chgtheme()
{
   if (!pnUserLoggedIn()) {
        return;
    }

    if(pnConfigGetVar('theme_change') == 1){
        return;
    }
    
    $Default_Theme = pnConfigGetVar('Default_Theme');
    
    include ("header.php");
    OpenTable();
    echo "<div style=\"text-align:center\"><span class=\"pn-title\">"._THEMESELECTION."</div></span>";
    CloseTable();

    OpenTable();
    $handle=opendir('themes');
    $themelist=array();
    while ($file = readdir($handle)) {
        if ((!ereg("[.]",$file)) ) {
            if($file != "CVS") {
                $themelist[] = $file;
            }
        }
    }
    closedir($handle);
	// modif sebastien multi sites
    $cWhereIsPerso = WHERE_IS_PERSO;
    if ( !(empty($cWhereIsPerso))) { 
        include("modules/NS-Multisites/chgtheme.inc.php"); 
    }
	// fin modif sebastien multi sites
    sort($themelist);

	// Remove inactive Xanthia themes from the theme list  -- jn
	if (pnModAPILoad('Xanthia', 'user')) {
    	// Get a list of all Xanthia themes
	    $allthemes = pnModAPIFunc('Xanthia','user','getAllThemes');

        if ($allthemes) {
        	// Get a list of all active Xanthia themes
	        $allskins = pnModAPIFunc('Xanthia','user','getAllSkins');
            $activethemes = array();
            if ($allskins) {
	            foreach($allskins as $allskin) {
	                $activethemes[] = $allskin['name'];
	            }
        	}
            // The difference are the inactive Xanthia themes, they need to be removed
            $inactive_themes = array_diff($allthemes, $activethemes);
            $themelist = array_diff($themelist, $inactive_themes);
        }
   	}
    // end of Xanthia insertion

    $usertheme = pnUserGetTheme();
    echo "<div style=\"text-align:center\">"
        ."<form action=\"user.php\" method=\"post\">"
        ."<span class=\"pn-title\">"._SELECTTHEME."</span><br />"
        ."<select name=\"newtheme\">";
    foreach($themelist as $theme) {
        if(isset($theme) && $theme != '') {
            echo "<option value=\"" . pnVarPrepForDisplay($theme) . "\" ";
            if ($theme == $usertheme) {
                echo "selected=\"selected\"";
            }
            echo ">" . pnVarPrepForDisplay($theme) . "\n";
        }
    }
    echo "</select><br />"
        ."<span class=\"pn-normal\">"._THEMETEXT1."<br />"
        .""._THEMETEXT2."<br />"
        .""._THEMETEXT3."<br /><br /></span>"

        ."<input type=\"hidden\" name=\"op\" value=\"savetheme\">"
        ."<input type=\"hidden\" name=\"authid\" value=\"" . pnSecGenAuthKey() . "\">"
        ."<input type=\"submit\" value=\""._SAVECHANGES."\">"
        ."</form>";
    CloseTable();
    include ("footer.php");
}

function savetheme()
{

    if (!pnSecConfirmAuthKey()) {
        die('Not allowed to directly update theme');
    }

    $newtheme = pnVarCleanFromInput('newtheme');

    if (pnUserLoggedIn()) {
        $uid = pnUserGetVar('uid');

        $dbconn =& pnDBGetConn(true);
        $pntable =& pnDBGetTables();
        $column = &$pntable['users_column'];
        $dbconn->Execute("UPDATE $pntable[users]
                          SET $column[theme]='" . pnVarPrepForStore($newtheme) . "'
                          WHERE $column[uid]='" . pnVarPrepForStore($uid)."'");
        pnRedirect('user.php');
    }
}


switch ($op) {
        case "chgtheme":
                chgtheme();
                break;
        case "savetheme":
        savetheme();
                break;

}

?>