<?php
function Censor_init()
    return true;
}

function Censor_upgrade($oldversion)
{
    return true;
}

function Censor_delete()
{
    return true;
}

?>