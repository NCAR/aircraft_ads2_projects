<?php // $Id: changehome.php,v 1.9 2004/08/22 18:45:10 larsneo Exp $

if (eregi('changehome.php', $_SERVER['PHP_SELF'])) {
	die ("You can't access this file directly...");
}

modules_get_language();

function edithome() {
    $Default_Theme = pnConfigGetVar('Default_Theme');

    if (!pnUserLoggedIn()) {
        return;
    }

    include ("header.php");
    OpenTable();
    echo "<div style=\"text-align:center\"><span class=\"pn-title\">"._HOMECONFIG."</span></div>";
    CloseTable();
    
    OpenTable();
    echo "<form action=\"user.php\" method=\"post\">";
	
	if (pnModAvailable('News')) {
		echo "<span class=\"pn-normal\">"._NEWSINHOME." "._MAX127."</span> "
    		."<input type=\"text\" name=\"storynum\" size=\"3\" maxlength=\"3\" value=\"" . pnVarPrepForDisplay(pnUserGetVar('storynum')) . "\">"
    		."<br /><br />";
	}
    if (pnUserGetVar('ublockon')==1) {
        $sel = " checked";
    } else {
        $sel = "";
    }
    echo "<input type=\"checkbox\" name=\"ublockon\"$sel>"
    ." <span class=\"pn-normal\">"._ACTIVATEPERSONAL."</span>"
    ."<br /><span class=\"pn-normal\">"._CHECKTHISOPTION."</span>"
    ."<br /><span class=\"pn-normal\">"._YOUCANUSEHTML."</span><br />"
    ."<textarea cols=\"80\" rows=\"10\" name=\"ublock\">" . pnVarPrepForDisplay(pnUserGetVar('ublock')) . "</textarea>"
    ."<br /><br />"
    ."<input type=\"hidden\" name=\"op\" value=\"savehome\">"
    ."<input type=\"hidden\" name=\"authid\" value=\"" . pnSecGenAuthKey() . "\">"
    ."<input type=\"submit\" value=\""._SAVECHANGES."\">"
    ."</form>";
    CloseTable();
    include ("footer.php");
}

function savehome()
{
    $dbconn =& pnDBGetConn(true);
    $pntable =& pnDBGetTables();

    list($storynum,
         $ublockon,
         $ublock) = pnVarCleanFromInput('storynum',
                                        'ublockon',
                                        'ublock');

    if (!pnSecConfirmAuthKey()) {
        die('Attempt to directly update user information - denied');
        exit;
    }

    if (pnUserLoggedIn()) {
        $uid = pnUserGetVar('uid');

        if (!empty($ublockon)) {
            $ublockon=1;
        } else {
            $ublockon=0;
        }
        $column = &$pntable['users_column'];
        $dbconn->Execute("UPDATE $pntable[users]
                          SET $column[storynum]='" . (int)pnVarPrepForStore($storynum) . "',
                              $column[ublockon]='" . (int)pnVarPrepForStore($ublockon) . "',
                              $column[ublock]='" . pnVarPrepForStore($ublock) . "'
                          WHERE $column[uid]='" . (int)pnVarPrepForStore($uid)."'");
        pnRedirect('user.php');
    }
}

switch($op) 
{
    case "edithome":
        edithome();
        break;
    case "savehome":
        savehome();
        break;
}

?>