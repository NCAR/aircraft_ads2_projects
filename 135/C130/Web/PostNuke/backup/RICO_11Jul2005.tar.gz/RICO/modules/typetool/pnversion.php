<?php
$modversion['name'] = 'typetool';
$modversion['version'] = '8.0';
$modversion['description'] = 'TypeTool Visual Editor Implementation';
$modversion['credits'] = 'pndocs/credits.txt';
$modversion['help'] = 'pndocs/help.txt';
$modversion['changelog'] = 'pndocs/changelog.txt';
$modversion['license'] = 'pndocs/license.txt';
$modversion['coding'] = 'pndocs/coding.txt';
$modversion['official'] = 1;
$modversion['author'] = 'Andreas Krapohl';
$modversion['contact'] = 'http://www.post-nuke.net/';
$modversion['admin'] = 1;
$modversion['securityschema'] = array('typetool::' => 'Module name::');
?>