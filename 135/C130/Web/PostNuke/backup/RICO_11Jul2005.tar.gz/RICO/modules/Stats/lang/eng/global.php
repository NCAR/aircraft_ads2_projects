<?php
// Generated: $d$ by $id$
// ----------------------------------------------------------------------
// PostNuke Content Management System
// Copyright (C) 2001 by The PostNuke Development Team.
// http://www.postnuke.com/
// ----------------------------------------------------------------------
// Based on:
// PHP-NUKE Web Portal System - http://phpnuke.org/
// Thatware - http://thatware.org/
// ----------------------------------------------------------------------
// LICENSE
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License (GPL)
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU General Public License for more details.
//
// To read the license please visit http://www.gnu.org/copyleft/gpl.html
// ----------------------------------------------------------------------
// Original Author of file: Everyone
// Purpose of file: Translation files
// Translation team: Read credits in /docs/CREDITS.txt
// ----------------------------------------------------------------------
define('_24HOUR','als');
define('_ARTICLESSEC','Articles in sections:');
define('_BROWSERS','Browsers');
define('_COMMENTSPOSTED','Comments posted:');
define('_KONQUEROR','Konqueror');
define('_LINKSCAT','Categories in links:');
define('_LINKSINLINKS','Links in web links:');
define('_LYNX','Lynx');
define('_MISCSTATS','Miscellaneous statistics');
define('_MOALLBESTDAY','The day on which there was the most traffic so far was ');
define('_MOALLWORSTDAY','was the day with the fewest hits');
define('_MODAPR','April');
define('_MODAT',') starts at');
define('_MODAUG','August');
define('_MODBYHOUR','Visits by hour');
define('_MODBYMONTH','Visits by month');
define('_MODBYWEEK','Visits by day of the week');
define('_MODDEC','December');
define('_MODFANSONLY','The hour during which traffic has been lightest starts at');
define('_MODFEB','February');
define('_MODFRI','Friday');
define('_MODINAVRG','On average, the busiest hour (with');
define('_MODISNTOURDAY','is the day with the fewest visits, with a total of');
define('_MODJAN','January');
define('_MODJUL','July');
define('_MODJUN','June');
define('_MODMAR','March');
define('_MODMAY','May');
define('_MODMON','Monday');
define('_MODNOV','November');
define('_MODOCLOCK','<strong>:00</strong>,');
define('_MODOCT','October');
define('_MODON','Most people visit on');
define('_MODPAGES','page views');
define('_MODSAT','Saturday');
define('_MODSEP','September');
define('_MODSUN','Sunday');
define('_MODTHU','Thursday');
define('_MODTODAY','today, and');
define('_MODTOTAL',', with a total of');
define('_MODTUE','Tuesday');
define('_MODWED','Wednesday');
define('_MODWHILE','while');
define('_MODWITHONLY','(with only');
define('_MODYESTERDAY','yesterday');
define('_MSIE','MSIE');
define('_NETSCAPE','Mozilla and Netscape');
define('_NEWSWAITING','News items waiting to be published:');
define('_NUKEVERSION','PostNuke version:');
define('_OPERA','Opera');
define('_OPERATINGSYS','Operating system');
define('_PAGESVIEWS','pages views since');
define('_REGUSERS','Registered users:');
define('_SACTIVETOPICS','Active topics:');
define('_SEARCHENGINES','Search engines');
define('_SSPECIALSECT','Special sections:');
define('_STATS','Traffic statistics');
define('_STORIESPUBLISHED','Stories published:');
define('_WERECEIVED','This site has received');
?>