<?php // $Id: init.php,v 1.1 2002/12/02 00:22:00 neo Exp $
// ----------------------------------------------------------------------
// Original Author of file: Jim McDonald
// Purpose of file:  Language defines for pninit.php
// ----------------------------------------------------------------------
//
define('_CREATETABLEFAILED', 'Table creation failed');
define('_UPDATETABLEFAILED', 'Table update failed');
?>