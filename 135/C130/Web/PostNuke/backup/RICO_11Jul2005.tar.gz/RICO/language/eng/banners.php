<?php
// Generated: $d$ by $id$
// ----------------------------------------------------------------------
// PostNuke Content Management System
// Copyright (C) 2001 by The PostNuke Development Team.
// http://www.postnuke.com/
// ----------------------------------------------------------------------
// Based on:
// PHP-NUKE Web Portal System - http://phpnuke.org/
// Thatware - http://thatware.org/
// ----------------------------------------------------------------------
// LICENSE
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License (GPL)
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU General Public License for more details.
//
// To read the license please visit http://www.gnu.org/copyleft/gpl.html
// ----------------------------------------------------------------------
// Original Author of file: Everyone
// Purpose of file: Translation files
// Translation team: Read credits in /docs/CREDITS.txt
// ----------------------------------------------------------------------
define('_BAN_ADVSTATS','Banner ad statistics.');
define('_BAN_BACK','Back');
define('_BAN_BADLOGINPASS','Your user name and password don\'t match.');
define('_BAN_CANTSEND','can\'t be sent because there isn\'t an e-mail address associated with the client name');
define('_BAN_CHANGEURL','Change URL');
define('_BAN_CLICKS','Clicks');
define('_BAN_CLIENTNAME','Client name');
define('_BAN_CONTACTADMIN','Please contact the administrator.');
define('_BAN_CURRACTIVE','Currently-active banners for');
define('_BAN_EMAIL_STATS','E-mail statistics');
define('_BAN_FORMAIL','The following are the complete statistics for your advertising at');
define('_BAN_FORTHIS','for this banner');
define('_BAN_FROM','From');
define('_BAN_FUNCTIONS','Actions');
define('_BAN_ID','Banner ID');
define('_BAN_IMAGE','Banner image');
define('_BAN_IMPPURCHASED','Impressions purchased');
define('_BAN_IMP_LEFT','Impressions remaining');
define('_BAN_IMP_MADE','Impressions  output');
define('_BAN_IMP_TOTAL','Total impressions');
define('_BAN_LOGIN','User name:');
define('_BAN_LOGINAGAIN','user name again');
define('_BAN_LOGININCORR','User name incorrect!');
define('_BAN_ONYOURSITE','You have the following banners running on');
define('_BAN_PASSWORD','Password');
define('_BAN_PERCENTCLICKS','% clicks');
define('_BAN_PLEASE','Please');
define('_BAN_REPORTMADEON','Report generated on');
define('_BAN_SEND','Send');
define('_BAN_SENTTO','have been sent to');
define('_BAN_STATSFORBAN','Statistics for banner no.');
define('_BAN_THISURL','this URL');
define('_BAN_UNLIMITED','Unlimited');
define('_BAN_URL','Banner URL');
define('_BAN_URLCHANGED','URL has been changed');
define('_BAN_YOURSTATS','Your banner statistics at');
?>