<?php
// $Id: pnAPI.php,v 1.86 2004/08/31 21:18:33 markwest Exp $
// ----------------------------------------------------------------------
// PostNuke Content Management System
// Copyright (C) 2001 by the PostNuke Development Team.
// http://www.postnuke.com/
// ----------------------------------------------------------------------
// LICENSE
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License (GPL)
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// To read the license please visit http://www.gnu.org/copyleft/gpl.html
// ----------------------------------------------------------------------
// Original Author of file: Jim McDonald
// Purpose of file: The PostNuke API
// ----------------------------------------------------------------------
/**
 * @package PostNuke_Core
 * @subpackage PostNuke_pnAPI
*/

/**
 * Defines
 */

/**
 * Yes/no integer
 */
define('_PNYES', 1);
define('_PNNO', 0);

/**
 * State of modules
 */
define('_PNMODULE_STATE_UNINITIALISED', 1);
define('_PNMODULE_STATE_INACTIVE', 2);
define('_PNMODULE_STATE_ACTIVE', 3);
define('_PNMODULE_STATE_MISSING', 4);
define('_PNMODULE_STATE_UPGRADED', 5);

/**
 * 'All' and 'unregistered' for user and group permissions
 */
define('_PNPERMS_ALL', '-1');
define('_PNPERMS_UNREGISTERED', '0');

/**
 * Core version informations - should be upgraded on each release for
 * better control on config settings
 */
define('_PN_VERSION_NUM',       '0.7.5.0');
define('_PN_VERSION_ID',        'PostNuke');
define('_PN_VERSION_SUB',       'Phoenix');

/**
 * Fake module for config vars
 */
define('_PN_CONFIG_MODULE',     '/PNConfig');

/**
 * Functions
 */

/**
 * get all configuration variable into $pnconfig
 * will be removed on .8
 * 
 * @param none $ 
 * @return bool true if successful, false otherwise 
 */
function pnConfigInit()
{
    $dbconn =& pnDBGetConn(true);
    $pntable =& pnDBGetTables();

    $table = $pntable['module_vars'];
    $columns = &$pntable['module_vars_column'];

    /**
     * Make query and go
     */
    $query = "SELECT $columns[name],
                     $columns[value]
              FROM $table
              WHERE $columns[modname]='" . pnVarPrepForStore(_PN_CONFIG_MODULE) . "'";
    $result =& $dbconn->Execute($query);
    // If execution returns an error or result is EOF return false
    if (($dbconn->ErrorNo() != 0)) {
        return false;
    }
    
    // Loop through the return result
    while (! $result->EOF) {
        // List the results as $key => $value
        list($key, $value) = $result->fields;

        // Do not overwrite base configuration variables!
        if (($key != 'dbtype') && ($key != 'dbhost') && ($key != 'dbuname') && ($key != 'dbpass')
         && ($key != 'dbname') && ($key != 'system') && ($key != 'prefix') && ($key != 'encoded')) {
            
            // If not one of the base configs, unserialize and add to the pnconfig array
            $value = @unserialize($value);
            $GLOBALS['pnconfig'][$key] = $value;
		}

		// Move the result indext forward for the next loop pass
        $result->MoveNext();
    }
	
    // Always close your database results!
    $result->Close();
    return true;
} 

/**
 * get a configuration variable
 * 
 * @param name $ the name of the variable
 * @return mixed value of the variable, or false on failure
 */
function pnConfigGetVar($name)
{
    if (isset($GLOBALS['pnconfig'][$name])) {
        $result = $GLOBALS['pnconfig'][$name];
    } else {
        /**
         * Fetch base data
         */
        $dbconn =& pnDBGetConn(true);
        $pntable =& pnDBGetTables();

        $table = $pntable['module_vars'];
        $columns = &$pntable['module_vars_column'];

        /**
         * Make query and go
         */
        $query = "SELECT $columns[value]
                  FROM $table
                  WHERE $columns[modname]='" . pnVarPrepForStore(_PN_CONFIG_MODULE) . "'
                    AND $columns[name]='" . pnVarPrepForStore($name) . "'";
        $dbresult =& $dbconn->Execute($query);

        /**
         * In any case of error return false
         */
        if ($dbconn->ErrorNo() != 0) {
            return false;
        } 
        if ($dbresult->EOF) {
            $dbresult->Close();
            return false;
        } 

        /**
         * Get data
         */
        list ($result) = $dbresult->fields;
        $result = unserialize($result);

        /**
         * Some caching
         */
        $GLOBALS['pnconfig'][$name] = $result;

        /**
         * That's all folks
         */
        $dbresult->Close();
    } 

    return $result;
} 

/**
 * set a configuration variable
 * 
 * @param name $ the name of the variable
 * @param value $ the value of the variable
 * @return bool true on success, false on failure
 */
function pnConfigSetVar($name, $value)
{
    /**
     * The database parameter are not allowed to change
     */
    if (empty($name) || ($name == 'dbtype') || ($name == 'dbhost') || ($name == 'dbuname') || ($name == 'dbpass')
            || ($name == 'dbname') || ($name == 'system') || ($name == 'prefix') || ($name == 'encoded')) {
        return false;
    } 

    /**
     * Test on missing record
     * 
     * Also solve SF-bug #580951
     */
    $must_insert = true;
    foreach($GLOBALS['pnconfig'] as $k => $v) {
        /**
         * Test if the key name is in the array
         */
        if ($k == $name) {
            /**
             * Set flag
             */
            $must_insert = false;
            /**
             * Test on change. If not, just quit now
             */
            if ($v == $value) {
                return true;
            } 
            /**
             * End loop after success
             */
            break;
        } 
    } 

    /**
     * Fetch base data
     */
    $dbconn =& pnDBGetConn(true);
    $pntable =& pnDBGetTables();
    $table = $pntable['module_vars'];
    $columns = &$pntable['module_vars_column'];

    /**
     * Update the table
     */
    if ($must_insert) {
        /**
         * Insert
         */
        $query = "INSERT INTO $table
                  ($columns[modname],
                   $columns[name],
                   $columns[value])
                  VALUES ('" . pnVarPrepForStore(_PN_CONFIG_MODULE) . "',
                          '" . pnVarPrepForStore($name) . "',
                          '" . pnVarPrepForStore(serialize($value)) . "')";
    } else {
        /**
         * Update
         */
        $query = "UPDATE $table
                   SET $columns[value]='" . pnVarPrepForStore(serialize($value)) . "'
                   WHERE $columns[modname]='" . pnVarPrepForStore(_PN_CONFIG_MODULE) . "'
                   AND $columns[name]='" . pnVarPrepForStore($name) . "'";
    } 
    $dbconn->Execute($query);
    if ($dbconn->ErrorNo() != 0) {
        return false;
    } 

    /**
     * Update my vars
     */
    $GLOBALS['pnconfig'][$name] = $value;

    return true;
} 

/**
 * delete a configuration variable
 * 
 * @param name $ the name of the variable
 * @return bool true on success, false on failure
 */
function pnConfigDelVar($name)
{
    if (empty($name)) {
        return false;
    }

    // Don't allow deleting at current
    return false;
} 

/**
 * Initialise PostNuke
 * <br />
 * Carries out a number of initialisation tasks to get PostNuke up and
 * running.
 *
 * @returns void
 */
function pnInit()
{
    // proper error_repoting
    // E_ALL for development
    //error_reporting(E_ALL);
    // without warnings and notices for release
    error_reporting(E_ALL & ~E_NOTICE & ~E_WARNING);

    // Hack for some weird PHP systems that should have the
    // LC_* constants defined, but don't
    if (!defined('LC_TIME')) {
        define('LC_TIME', 'LC_TIME');
    }

    // Initialise and load configuration
    $pnconfig = array();
	$pndebug = array();
    include 'config.php';
	$GLOBALS['pnconfig'] = $pnconfig;
	$GLOBALS['pndebug'] = $pndebug;

	// load ADODB
	pnADODBInit();

    // Connect to database
    if (!pnDBInit()) {
        die('Database initialisation failed');
    } 

    // Set up multisites
    // added this @define for .71, ugly ?
    // i guess the E_ALL stuff.
    @define('WHERE_IS_PERSO', '');

    // Initialise and load pntables
	pnDBSetTables();

    // Build up old config array
    pnConfigInit();

    // Set compression on if desired
    if (pnConfigGetVar('UseCompression') == 1) {
	    ob_start("ob_gzhandler");
    }

    // Other includes
    include 'includes/pnSession.php';
    include 'includes/pnUser.php';

    // Start session
    if (!pnSessionSetup()) {
        die('Session setup failed');
    }
    if (!pnSessionInit()) {
        die('Session initialisation failed');
    }

    include 'includes/pnSecurity.php';

    // See if a language update is required
    $newlang = pnVarCleanFromInput('newlang');
    if (!empty($newlang)) {
        $lang = $newlang;
        pnSessionSetVar('lang', $newlang);
    } else {
        $lang = pnSessionGetVar('lang');
    }

    // Load global language defines
    if (isset ($lang) && file_exists('language/' . pnVarPrepForOS($lang) . '/global.php')) {
        $currentlang = $lang;
    } else {
        $currentlang = pnConfigGetVar('language');
        pnSessionSetVar('lang', $currentlang);
    }
    include 'language/' . pnVarPrepForOS($currentlang) . '/global.php';
    include 'modules/NS-Languages/api.php';

    // Banner system
    include 'includes/pnBanners.php';

    // Other other includes
    include 'includes/pnBlocks.php';
    include 'includes/pnHTML.php';
    include 'includes/pnMod.php';
	// inclusion of pnrender class -- jn
    include 'includes/pnRender.class.php';
    include 'includes/legacy/counter.php';
	if (pnConfigGetVar('loadlegacy') == '1') {
		include 'includes/legacy/legacy.php';
		include 'includes/legacy/queryutil.php';
		include 'includes/legacy/xhtml.php';
		include 'includes/legacy/oldfuncs.php';
	}
	// Cross-Site Scripting attack defense - Sent by larsneo
	// some syntax checking against injected javascript
	$pnAntiCrackerMode = pnConfigGetVar('pnAntiCracker');
	if ( $pnAntiCrackerMode == 1 ) {
		pnSecureInput();
	}

    // Handle referer
    if (pnModAvailable('Referers') && pnConfigGetVar('httpref') == 1) {
        include 'referer.php';
        httpreferer();
    }

	// Load the theme
	pnThemeLoad(pnUserGetTheme());

    return true;
}

/**
 * Initialise DB connection
 * @return bool true if successful, false otherwise
 */
function pnDBInit()
{ 
    // Get database parameters
    $dbtype = $GLOBALS['pnconfig']['dbtype'];
    $dbhost = $GLOBALS['pnconfig']['dbhost'];
    $dbname = $GLOBALS['pnconfig']['dbname'];
    $dbuname = $GLOBALS['pnconfig']['dbuname'];
    $dbpass = $GLOBALS['pnconfig']['dbpass']; 
    $pconnect = $GLOBALS['pnconfig']['pconnect'];

    // Start connection
    $GLOBALS['pndbconn'] =& ADONewConnection($dbtype);
    if ($pconnect) {
        $dbh =& $GLOBALS['pndbconn']->PConnect($dbhost, $dbuname, $dbpass, $dbname);
    } else {
        $dbh =& $GLOBALS['pndbconn']->Connect($dbhost, $dbuname, $dbpass, $dbname);
    }
    if (!$dbh) {
        //$dbpass = "";
        //die("$dbtype://$dbuname:$dbpass@$dbhost/$dbname failed to connect" . $dbconn->ErrorMsg());
		die("<!DOCTYPE html PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">\n<html>\n<head>\n<meta http-equiv=\"Content-Type\" content=\"text/html; charset=ISO-8859-1\">\n<title>PostNuke powered Website</title>\n</head>\n<body>\n<center>\n<h1>Problem in Database Connection</h1>\n<br /><br />\n<h5>This Website is powered by PostNuke</h5>\n<a href=\"http://www.postnuke.com\" target=\"_blank\"><img src=\"images/powered/postnuke.butn.gif\" border=\"0\" alt=\"Web site powered by PostNuke\" hspace=\"10\" /></a> <a href=\"http://php.weblogs.com/ADODB\" target=\"_blank\"><img src=\"images/powered/adodb2.gif\" alt=\"ADODB database library\" border=\"0\" hspace=\"10\" /></a><a href=\"http://www.php.net\" target=\"_blank\"><img src=\"images/powered/php2.gif\" alt=\"PHP Scripting Language\" border=\"0\" hspace=\"10\" /></a><br />\n<h5>Although this site is running the PostNuke software<br />it has no other connection to the PostNuke Developers.<br />Please refrain from sending messages about this site or its content<br />to the PostNuke team, the end will result in an ignored e-mail.</h5>\n</center>\n</body>\n</html>");
    } 
    global $ADODB_FETCH_MODE;
    $ADODB_FETCH_MODE = ADODB_FETCH_NUM; 

    // force oracle to a consistent date format for comparison methods later on
    if (strcmp($dbtype, 'oci8') == 0) {
        $GLOBALS['pndbconn']->Execute("alter session set NLS_DATE_FORMAT = 'YYYY-MM-DD HH24:MI:SS'");
    } 

    return true;
} 

/**
 * get a list of database connections
 * 
 * @author Eric Barr 
 * @copyright Copyright (c) 2003 Envolution; Eric Barr. All rights reserved.
 * @author Roger Raymond 
 * @return array array of database connections
 */
function &pnDBGetConn($pass_by_reference = null)
{
    // If the function was called with pass_by_reference set to true
    // return a reference to the dbconn object
    if ($pass_by_reference == true) {
        return $GLOBALS['pndbconn'];
    } else {
	    return array($GLOBALS['pndbconn']);
	}
} 

/**
 * get a list of database tables
 *
 * @author Eric Barr
 * @copyright Copyright (c) 2003 Envolution; Eric Barr. All rights reserved.
 * @author Roger Raymond
 * @return array array of database tables
 */
function &pnDBGetTables()
{
    return $GLOBALS['pntables'];
}

/**
 * Set Database Table Listing
 *
 * @desc        Creates the database table listing if it hasn't been created yet
 *              and merges new table listings into the master list.
 * @author Eric Barr
 * @copyright Copyright (c) 2003 Envolution; Eric Barr. All rights reserved.
 * @access      public
 * @param       array $newtables
 * @return      void
 */
function pnDBSetTables()
{
    // Create a static var to hold the database table listing
    static $pntables;
    
    // If the table listing doesn't exist create it with the input array
    if(!is_array($pntables)) {
		// if a multisite has its own pntables.
		if (file_exists(WHERE_IS_PERSO . 'pntables.php')) {
			include WHERE_IS_PERSO . 'pntables.php';
		} else {
			include 'pntables.php';
		} 
    }
    
    // Set the pntables in the global listing for pnDBGetTables to have access to
    $GLOBALS['pntables'] = $pntable;
    return;
}

/**
 * clean user input
 * <br />
 * Gets a global variable, cleaning it up to try to ensure that
 * hack attacks don't work
 * 
 * @param var $ name of variable to get
 * @param  $ ...
 * @return mixed prepared variable if only one variable passed
 * in, otherwise an array of prepared variables
 */
function pnVarCleanFromInput()
{
    // Create an array of bad objects to clean out of input variables
	$search	= array('|</?\s*SCRIPT.*?>|si',
					'|</?\s*FRAME.*?>|si',
					'|</?\s*OBJECT.*?>|si',
					'|</?\s*META.*?>|si',
					'|</?\s*APPLET.*?>|si',
					'|</?\s*LINK.*?>|si',
					'|</?\s*IFRAME.*?>|si',
					'|STYLE\s*=\s*"[^"]*"|si');

    // Create an empty array that will be used to replace any malacious code
	$replace = array('');

	// Create an array to store cleaned variables
	$resarray =	array();
	
	// Loop through the function arguments
	// these arguments are input variables to be cleaned
	foreach (func_get_args() as $var) {
	    
	    // If the var is empty return void
	    if (empty($var) || is_array($var)) {
	        return;
	    }
	    
	    if (isset($_REQUEST[$var])) {
            // Set $ourvar from the $_REQUEST superglobal
            $ourvar = $_REQUEST[$var];
	    
            // If magic_quotes_gpc is on strip out the slashes
            if (get_magic_quotes_gpc()) {
                pnStripslashes($ourvar);
            }
	    
            // If at least ADMIN access level is not set clean the variable
            // @note: Since no security parameters have been passed to this
            // the variables will always be cleaned. 
            if (! pnSecAuthAction(0, '::', '::', ACCESS_ADMIN)) {
                $ourvar = preg_replace($search, $replace, $ourvar);
            }
	    } else if (isset($_FILES[$var])) {
            // Set $ourvar from the $_FILES superglobal
            $ourvar = $_FILES[$var];
	    } else {
	        $ourvar = null;
	    }
	    
	    // Add the cleaned var to the return array
	    array_push($resarray, $ourvar);
	}

	// If there was only one parameter passed return a variable
	if (func_num_args()	== 1) {
		return $resarray[0];
	// Else return an array
	} else {
		return $resarray;
	}
} 

/**
 * strip slashes
 * 
 * stripslashes on multidimensional arrays.
 * Used in conjunction with pnVarCleanFromInput
 * 
 * @access private 
 * @param any $ variables or arrays to be stripslashed
 */
function pnStripslashes (&$value) 
{
    if(!is_array($value)) {
        $value = stripslashes($value);
    } else {
        array_walk($value,'pnStripslashes');
    }
}

/**
 * ready user output
 * <br />
 * Gets a variable, cleaning it up such that the text is
 * shown exactly as expected
 * 
 * @param var $ variable to prepare
 * @param  $ ...
 * @return mixed prepared variable if only one variable passed
 * in, otherwise an array of prepared variables
 */
function pnVarPrepForDisplay()
{
    // This search and replace finds the text 'x@y' and replaces
    // it with HTML entities, this provides protection against
    // email harvesters
    static $search = array('/(.)@(.)/se');

    static $replace = array('"&#" .
                            sprintf("%03d", ord("\\1")) .
                            ";&#064;&#" .
                            sprintf("%03d", ord("\\2")) . ";";');

    $resarray = array();
    foreach (func_get_args() as $ourvar) {
        // Prepare var
        $ourvar = htmlspecialchars($ourvar);
        $ourvar = preg_replace($search, $replace, $ourvar);
        // Add to array
        array_push($resarray, $ourvar);
    }
    // Return vars
    if (func_num_args() == 1) {
        return $resarray[0];
    } else {
        return $resarray;
    }
}

/**
 * ready HTML output
 * <br />
 * Gets a variable, cleaning it up such that the text is
 * shown exactly as expected, except for allowed HTML tags which
 * are allowed through
 * @author Xaraya development team
 * @param var variable to prepare
 * @param ...
 * @return string/array prepared variable if only one variable passed
 * in, otherwise an array of prepared variables
 */
function pnVarPrepHTMLDisplay()
{
    // This search and replace finds the text 'x@y' and replaces
    // it with HTML entities, this provides protection against
    // email harvesters
    //
    // Note that the use of \024 and \022 are needed to ensure that
    // this does not break HTML tags that might be around either
    // the username or the domain name
    static $search = array('/([^\024])@([^\022])/se');

    static $replace = array('"&#" .
                            sprintf("%03d", ord("\\1")) .
                            ";&#064;&#" .
                            sprintf("%03d", ord("\\2")) . ";";');

    static $allowedtags = NULL;

    if (!isset($allowedtags)) {
        $allowedhtml = array();
        foreach(pnConfigGetVar('AllowableHTML') as $k=>$v) {
            if ($k == '!--') {
                if ($v <> 0) {
                    $allowedhtml[] = "$k.*?--";
                }
            } else {
                switch($v) {
                    case 0:
                        break;
                    case 1:
                        $allowedhtml[] = "/?$k\s*/?";
                        break;
                    case 2:
                        $allowedhtml[] = "/?$k(\s+[^>]*)?/?";
                        break;
                }
            }
        }
        if (count($allowedhtml) > 0) {
            $allowedtags = '~<(' . join('|',$allowedhtml) . ')>~is';
        } else {
            $allowedtags = '';
        }
    }

    $resarray = array();
    foreach (func_get_args() as $var) {
        // Preparse var to mark the HTML that we want
        if (!empty($allowedtags))
            $var = preg_replace($allowedtags, "\022\\1\024", $var);

        // Prepare var
        $var = htmlspecialchars($var);

        // Fix the HTML that we want
        $var = preg_replace_callback('/\022([^\024]*)\024/',
                                     'pnVarPrepHTMLDisplay__callback',
                                     $var);

        // Fix entities if required
        if (pnConfigGetVar('htmlentities')) {
            $var = preg_replace('/&amp;([a-z#0-9]+);/i', "&\\1;", $var);
        }

        // Add to array
        array_push($resarray, $var);
    }

    // Return vars
    if (func_num_args() == 1) {
        return $resarray[0];
    } else {
        return $resarray;
    }
}

/**
 * Callback function for pnVarPrepHTMLDisplay
 *
 * @author Xaraya development team
 * @access private
*/
function pnVarPrepHTMLDisplay__callback($matches)
{
    return '<' . strtr($matches[1],
                       array('&gt;' => '>',
                             '&lt;' => '<',
                             '&quot;' => '"'/*,
                             '&amp;' => '&'*/))
           . '>';
}

/**
 * ready databse output
 * <br />
 * Gets a variable, cleaning it up such that the text is
 * stored in a database exactly as expected
 * 
 * @param var $ variable to prepare
 * @param  $ ...
 * @return mixed prepared variable if only one variable passed
 * in, otherwise an array of prepared variables
 */
function pnVarPrepForStore()
{
    $resarray = array();
    foreach (func_get_args() as $ourvar) {
        // Prepare var
        if (!get_magic_quotes_runtime()) {
            $ourvar = addslashes($ourvar);
        }
        // Add to array
        array_push($resarray, $ourvar);
    }
    // Return vars
    if (func_num_args() == 1) {
        return $resarray[0];
    } else {
        return $resarray;
    }
}

/**
 * ready operating system output
 * <br />
 * Gets a variable, cleaning it up such that any attempts
 * to access files outside of the scope of the PostNuke
 * system is not allowed
 * 
 * @param var $ variable to prepare
 * @param  $ ...
 * @return mixed prepared variable if only one variable passed
 * in, otherwise an array of prepared variables
 */
function pnVarPrepForOS()
{
    static $search = array('!\.\./!si', // .. (directory traversal)
                           '!^.*://!si', // .*:// (start of URL)
                           '!^/!si',     // Forward slash (directory traversal)
                           '!^\\\\!si'); // Backslash (directory traversal)
    static $replace = array('',
                            '',
                            '_',
                            '_');

    $resarray = array();
    foreach (func_get_args() as $ourvar) {
        // Parse out bad things
        $ourvar = preg_replace($search, $replace, $ourvar);
        // Prepare var
        if (!get_magic_quotes_runtime()) {
            $ourvar = addslashes($ourvar);
        }
        // Add to array
        array_push($resarray, $ourvar);
    }
    // Return vars
    if (func_num_args() == 1) {
        return $resarray[0];
    } else {
        return $resarray;
    }
}

/**
 * remove censored words
 */
function pnVarCensor()
{
    static $docensor;
    if (!isset($docensor)) {
        $docensor = pnConfigGetVar('CensorMode');
    }

    static $search = array();
    if (empty($search)) {
        $repsearch = array('/o/i',
                           '/e/i',
                           '/a/i',
                           '/i/i');
        $repreplace = array('0',
                            '3',
                            '@',
                            '1');
        $censoredwords = pnConfigGetVar('CensorList');
        foreach ($censoredwords as $censoredword) {
            // Simple word
            $search[] = "/\b$censoredword\b/i";
            // Common replacements
            $mungedword = preg_replace($repsearch, $repreplace, $censoredword);
            if ($mungedword != $censoredword) {
                $search[] = "/\b$mungedword\b/";
            }
        }
    }

    $replace = pnConfigGetVar('CensorReplace');

    $resarray = array();
    foreach (func_get_args() as $ourvar) {
        if ($docensor) {
            // Parse out nasty words
            $ourvar = preg_replace($search, $replace, $ourvar);
        }
        // Add to array
        array_push($resarray, $ourvar);
    }
    // Return vars
    if (func_num_args() == 1) {
        return $resarray[0];
    } else {
        return $resarray;
    }
}

/**
 * validate a user variable
 * 
 * @access public 
 * @author Damien Bonvillain 
 * @author Gregor J. Rothfuss 
 * @since 1.23 - 2002/02/01
 * @param var $ the variable to validate
 * @param type $ the type of the validation to perform
 * @param args $ optional array with validation-specific settings
 * @return bool true if the validation was successful, false otherwise
 */
function pnVarValidate($var, $type, $args=0)
{
 switch ($type) {
    case 'email':
	    if (pnConfigGetVar('idnnames') == 1) {
        	// transfer between the encoded (Punycode) notation and the decoded (8bit) notation. 
        	include_once 'includes/classes/idna/idna_convert.class.php';
        	$IDN = new idna_convert();
        	$var = $IDN->encode($var);
		}
        // all characters must be 7 bit ascii
        $length = strlen($var);
        $idx = 0;
        while($length--) {
           $c = $var[$idx++];
           if(ord($c) > 127){
              return false;
           }
        }
        $regexp = '/^(?:[^\s\000-\037\177\(\)<>@,;:\\"\[\]]\.?)+@(?:[^\s\000-\037\177\(\)<>@,;:\\\"\[\]]\.?)+\.[a-z]{2,6}$/Ui';
        if(preg_match($regexp,$var)) {
            return true;
        } else {
            return false;
        }
        break;

    case 'url':
	    if (pnConfigGetVar('idnnames') == 1) {
        	// transfer between the encoded (Punycode) notation and the decoded (8bit) notation. 
        	include_once 'includes/classes/idna/idna_convert.class.php';
        	$IDN = new idna_convert();
        	$var = $IDN->encode($var);
		}
        // all characters must be 7 bit ascii
        $length = strlen($var);
        $idx = 0;
        while($length--) {
           $c = $var[$idx++];
           if(ord($c) > 127){
             return false;
           }
        }
		$regexp = '/^([!#\$\046-\073=\077-\132_\141-\172~]|(?:%[a-f0-9]{2}))+$/i';
        if(!preg_match($regexp, $var)) {
            return false;
        }
        $url_array = @parse_url($var);
        if(empty($url_array)) {
            return false;
        } else {
            return !empty($url_array['scheme']);
        }
        break;
   }
}

/**
 * check an assertion
 * <br />
 * Check an assertion to ensure that it is valid.  If not, then die
 * 
 * @param assertion $ the assertion
 * @param filename $ the filename the assertion occurs in
 * @param line $ the line number the assertion occurs in
 */
function pnAssert($assertion, $file='Unknown', $line='Unknown', $msg='')
{
    if ($assertion) {
        return;
    }
    // Assertion failed - log it
    if (!empty($msg)) {
        die("Assertion failed in $file at line $line - $msg");
    } else {
        die("Assertion failed in $file at line $line");
    }
}

/**
 * get status message from previous operation
 * <br />
 * Obtains any status message, and also destroys
 * it from the session to prevent duplication
 * 
 * @return string the status message
 */
function pnGetStatusMsg()
{
    $msg = pnSessionGetVar('statusmsg');
    pnSessionDelVar('statusmsg');
    $errmsg = pnSessionGetVar('errormsg');
    pnSessionDelVar('errormsg');
    // Error message overrides status message
    if (!empty($errmsg)) {
        return $errmsg;
    }
    return $msg;
}

/**
 * Load a theme
 * <br />
 * include theme.php for the requested theme
 * 
 * @return bool true if successful, false otherwiese
 */
function pnThemeLoad($thistheme)
{
    static $loaded = 0;

    if ($loaded) {
        return true;
    }
    // Lots of nasty globals for back-compatability with older themes
    global $bgcolor1;
    global $bgcolor2;
    global $bgcolor3;
    global $bgcolor4;
    global $bgcolor5;
    global $sepcolor;
    global $textcolor1;
    global $textcolor2;
    global $postnuke_theme;
    global $thename;

    // modification mouzaia .71
    // is this really useful ?
    /**
     * $themefile = 'themes/' . pnVarPrepForOS(pnUserGetTheme()) . '/theme.php';
     * if (!file_exists($themefile)) {
     * return false;
     * }
     */
    // eugenio themeover 20020413
    if (file_exists(WHERE_IS_PERSO . "themes/$thistheme/theme.php")) {
        include WHERE_IS_PERSO . "themes/$thistheme/theme.php";
    } elseif (file_exists("themes/$thistheme/theme.php")) {
        include "themes/$thistheme/theme.php";
    } else {
	    return false;
	}

    // end of modification
    $loaded = 1;
    return true;
}

/**
 * return a theme variable
 * 
 * @return mixed theme variable value
 */
function pnThemeGetVar($name)
{
    global $$name;
    if (isset($$name)) {
        return $$name;
    }
}

/**
 * get base URI for PostNuke
 * 
 * @return string base URI for PostNuke
 */
function pnGetBaseURI()
{
    // Get the name of this URI
    // Start of with REQUEST_URI
	$path = pnServerGetVar('REQUEST_URI');

    if ((empty($path)) || (substr($path, -1, 1) == '/')) {
        // REQUEST_URI was empty or pointed to a path
        // Try looking at PATH_INFO
        $path = pnServerGetVar('PATH_INFO');
        if (empty($path)) {
			$path = pnServerGetVar('SCRIPT_NAME');
        } 
    } 

    $path = preg_replace('/[#\?].*/', '', $path);
    $path = dirname($path);

    if (preg_match('!^[/\\\]*$!', $path)) {
        $path = '';
    } 

    return $path;
}

/**
 * get base URL for PostNuke
 * 
 * @return string base URL for PostNuke
 */
function pnGetBaseURL()
{
	$server = pnServerGetVar('HTTP_HOST');

    // IIS sets HTTPS=off
	$https = pnServerGetVar('HTTPS');
    if (isset($https) && $https != 'off') {
        $proto = 'https://';
    } else {
        $proto = 'http://';
    } 

    $path = pnGetBaseURI();

// return "$proto$server$path/";
// URL return hack due to proxy.  MDD 10/25/04

   return "http://www.eol.ucar.edu/RICO/";
}

/**
 * Carry out a redirect
 * 
 * @param the $ URL to redirect to
 * @returns void
 */
function pnRedirect($redirecturl)
{
    // Always close session before redirect
    if (function_exists('session_write_close')) {
        session_write_close();
    }

    if (preg_match('!^http!', $redirecturl)) {
        // Absolute URL - simple redirect
        Header("Location: $redirecturl");
        return;
    } else {
        // Removing leading slashes from redirect url
        $redirecturl = preg_replace('!^/*!', '', $redirecturl);
        // Get base URL
        $baseurl = pnGetBaseURL();

        Header("Location: $baseurl$redirecturl");
    }
}

/**
 * check to see if this is a local referral
 * 
 * @return bool true if locally referred, false if not
 */
function pnLocalReferer()
{
	$server = pnServerGetVar('HTTP_HOST');
    $referer = pnServerGetVar('HTTP_REFERER');

    if (empty($referer) || preg_match("!^http://$server/!", $referer)) {
        return true;
    } else {
        return false;
    } 
}

// Hack - we need this for themes, but will get rid of it soon
if (!function_exists('GetUserTime')) {
    function GetUserTime($time) 
	{
        if (pnUserLoggedIn()) {
            $time += (pnUserGetVar('timezone_offset') - pnConfigGetVar('timezone_offset')) * 3600;
        }
        return($time);
    }
}

/**
 * send an email
 * 
 * @param to $ - recipient of the email
 * @param subject $ - title of the email
 * @param message $ - body of the email
 * @param headers $ - extra headers for the email
 * @param debug $ - if 1, echo mail content
 * @return bool true if the email was sent, false if not
 * @note although the mailer module handled php mail
 * we include this here for ease of building xte for .726
 */
function pnMail($to, $subject, $message, $headers, $html = 0, $debug = 0)
{
    // set initial return value until we know we have a valid return
    $return = false;

	// check if the mailer module is availble and if so call the API
    if((pnModAvailable('Mailer')) && (pnModAPILoad('Mailer', 'user'))) {
        $return = pnModAPIFunc('Mailer', 'user', 'sendmessage', array('toaddress' => $to,
                                                                      'subject' => $subject,
                                                                      'headers' => $headers,
                                                                      'body' => $message,
																	  'html' => $html));

    } else {
		// Language translations      // set initial return value until we know we have a valid return 
    	switch(pnUserGetLang()) {
        	case 'rus':   
	         	if (!empty($headers)) $headers .= "\n";
            	$headers .= "Content-Type: text/plain; charset=koi8-r";
            	$subject = convert_cyr_string($subject,"w","k");
            	$message = convert_cyr_string($message,"w","k");
            	$headers = convert_cyr_string($headers,"w","k");
	            break;
		}
		// Mail message   
		// do not display error messages [class007]   
		$return = @mail($to, $subject, $message, $headers); 
     } 

    // Debug [class007]
    if ($debug) {
        echo 'Mail To: ' . $to . '<br />';
        echo 'Mail Subject: ' . $subject . '<br />';
        echo 'Mail Message: ' . $message . '<br />';
        echo 'Mail Headers: ' . $headers . '<br />';
		echo 'Return Message: ' . $return . '<br />';
    } 
	
    return $return;
}

/**
 * Function that compares the current php version on the
 * system with the target one
 *
 * Deprecate function reverting to php detecion function
 *
 * @deprecated
 */
function pnPhpVersionCheck($vercheck)
{
	$minver = str_replace(".","", $vercheck);
	$curver = str_replace(".","", phpversion());

	if($curver >= $minver){
		return true;
	} else {
		return false;
	}
}

/**
 * initialise ADODB
 * 
 * @return void
 */
function pnADODBInit()
{
    // ADODB configuration
    global $ADODB_CACHE_DIR;
    $ADODB_CACHE_DIR = realpath($GLOBALS['pnconfig']['temp'] . '/adodb');
	if (!defined('ADODB_DIR')) {
	    define('ADODB_DIR', 'pnadodb');
	}
    include 'pnadodb/adodb.inc.php'; 
    
    // ADODB Error handle
    if ($GLOBALS['pndebug']['debug_sql']) {
        include 'pnadodb/adodb-errorhandler.inc.php';
    }

    // Decode encoded DB parameters
    if ($GLOBALS['pnconfig']['encoded']) {
        $GLOBALS['pnconfig']['dbuname'] = base64_decode($GLOBALS['pnconfig']['dbuname']);
        $GLOBALS['pnconfig']['dbpass'] = base64_decode($GLOBALS['pnconfig']['dbpass']);
        $GLOBALS['pnconfig']['encoded'] = 0;
    } 

    // debugger if required
    if ($GLOBALS['pndebug']['debug']) {
        include_once 'includes/classes/lensdebug/lensdebug.inc.php';
        $GLOBALS['dbg'] =& new LensDebug();
        $GLOBALS['debug_sqlcalls'] = 0;
    }

	// initialise time to render
	if ($GLOBALS['pndebug']['pagerendertime']) {
		$mtime = explode(" ", microtime());
		$GLOBALS['dbg_starttime'] = $mtime[1] + $mtime[0];
	}
}

/**
 * Gets a server variable
 *
 * Returns the value of $name server variable.
 * Accepted values for $name are exactly the ones described by the
 * {@link http://www.php.net/manual/en/reserved.variables.html#reserved.variables.server PHP manual}.
 * If the server variable doesn't exist void is returned.
 *
 * @author Marco Canini <marco@xaraya.com>, Michel Dalle
 * @access public
 * @param name string the name of the variable
 * @return mixed value of the variable
 */
function pnServerGetVar($name)
{
    // Check the relevant superglobals
    if (isset($_SERVER[$name])) {
        return $_SERVER[$name];
    }
    if (isset($_ENV[$name])) {
        return $_ENV[$name];
    }
    if ($val = getenv($name)) {
        return $val;
    }
    return; // we found nothing here
}

/**
 * Get current URI (and optionally add/replace some parameters)
 *
 * @access public
 * @param args array additional parameters to be added to/replaced in the URI (e.g. theme, ...)
 * @return string current URI
 */
function pnGetCurrentURI($args = array())
{
    // get current URI
    $request = pnServerGetVar('REQUEST_URI');

    if (empty($request)) {
        // adapted patch from Chris van de Steeg for IIS
        // TODO: please test this :)
        $scriptname = pnServerGetVar('SCRIPT_NAME');
        $pathinfo = pnServerGetVar('PATH_INFO');
        if ($pathinfo == $scriptname) {
            $pathinfo = '';
        }
        if (!empty($scriptname)) {
            $request = $scriptname . $pathinfo;
            $querystring = pnServerGetVar('QUERY_STRING');
            if (!empty($querystring)) $request .= '?'.$querystring;
        } else {
            $request = '/';
        }
    }

    // add optional parameters
    if (count($args) > 0) {
        if (strpos($request,'?') === false) $request .= '?';
        else $request .= '&';

        foreach ($args as $k=>$v) {
            if (is_array($v)) {
                foreach($v as $l=>$w) {
                // TODO: replace in-line here too ?
                    if (!empty($w)) $request .= $k . "[$l]=$w&";
                }
            } else {
                // if this parameter is already in the query string...
                if (preg_match("/(&|\?)($k=[^&]*)/",$request,$matches)) {
                    $find = $matches[2];
                    // ... replace it in-line if it's not empty
                    if (!empty($v)) {
                        $request = preg_replace("/(&|\?)$find/","$1$k=$v",$request);

                    // ... or remove it otherwise
                    } elseif ($matches[1] == '?') {
                        $request = preg_replace("/\?$find(&|)/",'?',$request);
                    } else {
                        $request = preg_replace("/&$find/",'',$request);
                    }
                } elseif (!empty($v)) {
                    $request .= "$k=$v&";
                }
            }
        }

        $request = substr($request, 0, -1);
    }

    return $request;
}

/* 
	Protects better diverse attempts of Cross-Site Scripting
   	attacks, thanks to webmedic, Timax, larsneo.
 */
function pnSecureInput() 
{
	// Cross-Site Scripting attack defense - Sent by larsneo
	// some syntax checking against injected javascript
	// extended by Neo
	
	if (count($_GET) > 0) {
		//        Lets now sanitize the GET vars
        foreach ($_GET as $secvalue) {
        	if (!is_array($secvalue)) {
                if ((eregi("<[^>]*script.*\"?[^>]*>", $secvalue)) ||
                        (eregi(".*[[:space:]](or|and)[[:space:]].*(=|like).*", $secvalue)) ||
                        (eregi("<[^>]*object.*\"?[^>]*>", $secvalue)) ||
                        (eregi("<[^>]*iframe.*\"?[^>]*>", $secvalue)) ||
                        (eregi("<[^>]*applet.*\"?[^>]*>", $secvalue)) ||
                        (eregi("<[^>]*meta.*\"?[^>]*>", $secvalue)) ||
                        (eregi("<[^>]*style.*\"?[^>]*>", $secvalue)) ||
                        (eregi("<[^>]*form.*\"?[^>]*>", $secvalue)) ||
                        (eregi("<[^>]*window.*\"?[^>]*>", $secvalue)) ||
                        (eregi("<[^>]*alert.*\"?[^>]*>", $secvalue)) ||
                        (eregi("<[^>]*img.*\"?[^>]*>", $secvalue)) ||
                        (eregi("<[^>]*document.*\"?[^>]*>", $secvalue)) ||
                        (eregi("<[^>]*cookie.*\"?[^>]*>", $secvalue)) ||
                        (eregi("\"", $secvalue))) {
                        pnMailHackAttempt(__FILE__,__LINE__,'pnSecurity Alert','Intrusion detection.');
                        Header("Location: index.php");
                }
        	}
        }
	}

	//        Lets now sanitize the POST vars
	if ( count($_POST) > 0) {
        foreach ($_POST as $secvalue) {
        	if (!is_array($secvalue)) {
                if ((eregi("<[^>]*script.*\"?[^>]*>", $secvalue)) ||
                        (eregi("<[^>]*object.*\"?[^>]*>", $secvalue)) ||
                        (eregi("<[^>]*iframe.*\"?[^>]*>", $secvalue)) ||
                        (eregi("<[^>]*applet.*\"?[^>]*>", $secvalue)) ||
                        (eregi("<[^>]*window.*\"?[^>]*>", $secvalue)) ||
                        (eregi("<[^>]*alert.*\"?[^>]*>", $secvalue)) ||
                        (eregi("<[^>]*document.*\"?[^>]*>", $secvalue)) ||
                        (eregi("<[^>]*cookie.*\"?[^>]*>", $secvalue)) ||
                        (eregi("<[^>]*meta.*\"?[^>]*>", $secvalue))
                        ) {

                        pnMailHackAttempt(__FILE__,__LINE__,'pnSecurity Alert','Intrusion detection.');
                        Header("Location: index.php");
                }
         	}
        }
	}

	//        Lets now sanitize the COOKIE vars
	if ( count($_COOKIE) > 0) {
        foreach ($_COOKIE as $secvalue) {
			if (!is_array($secvalue)) {
                if ((eregi("<[^>]*script.*\"?[^>]*>", $secvalue)) ||
                        (eregi(".*[[:space:]](or|and)[[:space:]].*(=|like).*", $secvalue)) ||
                        (eregi("<[^>]*object.*\"?[^>]*>", $secvalue)) ||
                        (eregi("<[^>]*iframe.*\"?[^>]*>", $secvalue)) ||
                        (eregi("<[^>]*applet.*\"?[^>]*>", $secvalue)) ||
                        (eregi("<[^>]*meta.*\"?[^>]*>", $secvalue)) ||
                        (eregi("<[^>]*style.*\"?[^>]*>", $secvalue)) ||
                        (eregi("<[^>]*form.*\"?[^>]*>", $secvalue)) ||
                        (eregi("<[^>]*window.*\"?[^>]*>", $secvalue)) ||
                        (eregi("<[^>]*alert.*\"?[^>]*>", $secvalue)) ||
                        (eregi("<[^>]*document.*\"?[^>]*>", $secvalue)) ||
                        (eregi("<[^>]*cookie.*\"?[^>]*>", $secvalue)) ||
                        (eregi("<[^>]*img.*\"?[^>]*>", $secvalue))
                        ) {

                        pnMailHackAttempt(__FILE__,__LINE__,'pnSecurity Alert','Intrusion detection.');
                        Header("Location: index.php");
                }
        	}
        }
	}
}

function pnMailHackAttempt( $detecting_file        =        "(no filename available)",
                            $detecting_line        =        "(no line number available)",
                            $hack_type             =        "(no type given)",
                            $message               =        "(no message given)" ) {

        $output         =        "Attention site admin of ".pnConfigGetVar('sitename').",\n";
        $output        .=        "On ".ml_ftime( _DATEBRIEF, (GetUserTime(time())));
        $output        .=        " at ". ml_ftime( _TIMEBRIEF, (GetUserTime(time())));
        $output        .=        " the Postnuke code has detected that somebody tried to"
                           ." send information to your site that may have been intended"
                           ." as a hack. Do not panic, it may be harmless: maybe this"
                           ." detection was triggered by something you did! Anyway, it"
                           ." was detected and blocked. \n";
        $output        .=        "The suspicious activity was recognized in $detecting_file "
                              ."on line $detecting_line, and is of the type $hack_type. \n";
        $output        .=        "Additional information given by the code which detected this: ".$message;
        $output        .=        "\n\nBelow you will find a lot of information obtained about "
                           ."this attempt, that may help you to find  what happened and "
                           ."maybe who did it.\n\n";

        $output        .=        "\n=====================================\n";
        $output        .=        "Information about this user:\n";
        $output        .=        "=====================================\n";

        if ( !pnUserLoggedIn() ) {
			$output        .=  "This person is not logged in.\n";
        } else {
			$output .=        "Postnuke username:  ".pnUserGetVar('uname') ."\n"
							   ."Registered email of this Postnuke user: ". pnUserGetVar('email')."\n"
							   ."Registered real name of this Postnuke user: ".pnUserGetVar('name') ."\n";
        }

        $output        .=        "IP numbers: [note: when you are dealing with a real cracker "
                           ."these IP numbers might not be from the actual computer he is "
                           ."working on]"
                           ."\n\t IP according to HTTP_CLIENT_IP: ".pnServerGetVar( 'HTTP_CLIENT_IP' )
                           ."\n\t IP according to REMOTE_ADDR: ".pnServerGetVar( 'REMOTE_ADDR' )
                           ."\n\t IP according to GetHostByName(\$_SERVER['REMOTE_ADDR']): ".GetHostByName($_SERVER['REMOTE_ADDR'])
                           ."\n\n";

        $output .=        "\n=====================================\n";
        $output .=        "Information in the \$_REQUEST array\n";
        $output .=        "=====================================\n";

        while ( list ( $key, $value ) = each ( $_REQUEST ) ) {
                $output .= "REQUEST * $key : $value\n";
        }

        $output .=        "\n=====================================\n";
        $output .=        "Information in the \$_GET array\n";
        $output .=        "This is about variables that may have been ";
        $output .=        "in the URL string or in a 'GET' type form.\n";
        $output        .=        "=====================================\n";

        while ( list ( $key, $value ) = each ( $_GET ) ) {
                $output .= "GET * $key : $value\n";
        }

        $output        .=        "\n=====================================\n";
        $output        .=        "Information in the \$_POST array\n";
        $output        .=        "This is about visible and invisible form elements.\n";
        $output        .=        "=====================================\n";

        while ( list ( $key, $value ) = each ( $_POST ) ) {
                $output .= "POST * $key : $value\n";
        }

        $output        .=        "\n=====================================\n";
        $output        .=         "Browser information\n";
        $output        .=        "=====================================\n";

        $output        .=        "HTTP_USER_AGENT: ".$_SERVER['HTTP_USER_AGENT'] ."\n";

        $browser = (array) get_browser();
        while ( list ( $key, $value ) = each ( $browser ) ) {
                $output .= "BROWSER * $key : $value\n";
        }

        $output        .=        "\n=====================================\n";
        $output        .=        "Information in the \$_SERVER array\n";
        $output        .=        "=====================================\n";

        while ( list ( $key, $value ) = each ( $_SERVER ) ) {
                $output .= "SERVER * $key : $value\n";
        }

        $output        .=        "\n=====================================\n";
        $output        .=        "Information in the \$_ENV array\n";
        $output        .=        "=====================================\n";

        while ( list ( $key, $value ) = each ( $_ENV ) ) {
                $output .= "ENV * $key : $value\n";
        }

        $output        .=        "\n=====================================\n";
        $output        .=  "Information in the \$_COOKIE array\n";
        $output        .=        "=====================================\n";

        while ( list ( $key, $value ) = each ( $_COOKIE ) )  {
                $output .= "COOKIE * $key : $value\n";
        }

        $output        .=        "\n=====================================\n";
        $output        .=        "Information in the \$_FILES array\n";
        $output        .=        "=====================================\n";

        while ( list ( $key, $value ) = each ( $_FILES ) ) {
                $output .= "FILES * $key : $value\n";
        }

        $output        .=        "\n=====================================\n";
        $output        .=        "Information in the \$_SESSION array\n";
        $output .=  "This is session info. The variables\n";
        $output .=  "  starting with PNSV are PostNukeSessionVariables.\n";
        $output        .=        "=====================================\n";

        while ( list ( $key, $value ) = each ( $_SESSION ) ) {
                $output .= "SESSION * $key : $value\n";
        }

		$sitename = pnConfigGetVar('sitename');
		$adminmail = pnConfigGetVar('adminmail');
		
        $headers = "From: $sitename <$adminmail>\n"
                          ."X-Priority: 1 (Highest)\n";

        pnMail($adminmail, 'Attempted hack on your site? (type: '.$hack_type.')', $output, $headers );

        return;
}

?>
