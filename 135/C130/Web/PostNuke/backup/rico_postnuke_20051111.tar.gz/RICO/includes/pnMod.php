<?php 
// $Id: pnMod.php,v 1.27 2004/08/27 15:02:56 markwest Exp $
// ----------------------------------------------------------------------
// PostNuke Content Management System
// Copyright (C) 2001 by the PostNuke Development Team.
// http://www.postnuke.com/
// ----------------------------------------------------------------------
// Based on:
// PHP-NUKE Web Portal System - http://phpnuke.org/
// Thatware - http://thatware.org/
// ----------------------------------------------------------------------
// LICENSE
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License (GPL)
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// To read the license please visit http://www.gnu.org/copyleft/gpl.html
// ----------------------------------------------------------------------
// Original Author of file: Jim McDonald
// Purpose of file: Module variable handling
// ----------------------------------------------------------------------

/**
 * @package PostNuke_Core
 * @subpackage PostNuke_pnAPI
*/
/**
 * pnModVarExists - check to see if a module variable is set
 * @author Chris Miller
 * @param 'modname' the name of the module
 * @param 'name' the name of the variable
 * @return  true if the variable exists in the database, false if not
 */
function pnModVarExists($modname, $name)
{
	// make sure we have the necessary parameters
	if(empty($modname) || empty($name)){
		return false;
	}
	// get all module vars for this module
	$modvars = pnModGetVar($modname);
	if (array_key_exists($name,$modvars)) {
		// if $name is set
		return true;
	}
	return false;
}
/**
 * pnModGetVar - get a module variable
 * @author Jim McDonald <jim@mcdee.net>
 * @link http://www.mcdee.net
 * @param 'modname' the name of the module
 * @param 'name' the name of the variable
 * @return  if the name parameter is included then function returns
 * 			string - module variable value
 * @return  if the name parameter is ommitted then function returns
 *			array - multi dimentional array of the keys
 *                  and values for the module vars.
 */
function pnModGetVar($modname, $name='')
{
    global $pnmodvar;

	// if we don't know the modname then lets assume it is the current
	// active module
    if (empty($modname)) {
		$modname = pnModGetName();
    }

	// if we haven't got vars for this module yet then lets get them
	if (!isset($pnmodvar[$modname])) {

		$dbconn =& pnDBGetConn(true);
		$pntable =& pnDBGetTables();

		$modulevarstable = $pntable['module_vars'];
		$modulevarscolumn = &$pntable['module_vars_column'];

		$query = "SELECT $modulevarscolumn[name],
			$modulevarscolumn[value]
				FROM $modulevarstable
				WHERE $modulevarscolumn[modname] = '" . pnVarPrepForStore($modname) . "'";

		$result =& $dbconn->Execute($query);

		if($dbconn->ErrorNo() != 0) {
			return array();
		}

		if ($result->EOF) {
			$pnmodvar[$modname] = array();
			return array();
		}

		for (; !$result->EOF; $result->MoveNext()) {
			list($aname, $avalue) = $result->fields;
			$pnmodvar[$modname][$aname] = $avalue;
		}

		$result->Close();
	}

	// if they didn't pass a variable name then return every variable
	// for the specified module as an associative array.
	// array('var1'=>value1, 'var2'=>value2)
	if (empty($name)) {
		return $pnmodvar[$modname];
	}

	// since they passed a variable name then only return the value for
	// that variable
	if (isset($pnmodvar[$modname][$name])) {
		return $pnmodvar[$modname][$name];
	}
	// we don't know the required module var but we established all known
	// module vars for this module so the requested one can't exist.
	return false;
} 

/**
 * pnModSetVar - set a module variable
 * @author Jim McDonald <jim@mcdee.net>
 * @link http://www.mcdee.net
 * @param 'modname' the name of the module
 * @param 'name' the name of the variable
 * @param 'value' the value of the variable
 * @return bool true if successful, false otherwise
 */
function pnModSetVar($modname, $name, $value)
{
    // Modified by Segr function start
    if ((empty($modname)) || (empty($name))) {
		return false;
	}

    global $pnmodvar;

    $dbconn =& pnDBGetConn(true);
    $pntable =& pnDBGetTables();
    $modulevarstable = $pntable['module_vars'];
    $modulevarscolumn = &$pntable['module_vars_column'];
    if (pnModVarExists($modname,$name)) {
        $query = "UPDATE $modulevarstable
                  SET $modulevarscolumn[value] = '".pnVarPrepForStore($value)."'
                  WHERE $modulevarscolumn[modname] = '".pnVarPrepForStore($modname)."'
                  AND $modulevarscolumn[name] = '".pnVarPrepForStore($name)."'";
    } else {
        $query = "INSERT INTO $modulevarstable
                    ( $modulevarscolumn[modname], $modulevarscolumn[name], $modulevarscolumn[value])
                  VALUES
                    ('".pnVarPrepForStore($modname)."', '".pnVarPrepForStore($name)."', '".pnVarPrepForStore($value)."');";
    }
    $dbconn->Execute($query);

    if ($dbconn->ErrorNo()!=0) {
		return false;
	}

    $pnmodvar[$modname][$name] = $value;
    return true;
    // Modified by Segr function end
} 

/**
 * pnModDelVar - delete a module variable
 * @author Jim McDonald <jim@mcdee.net>
 * @link http://www.mcdee.net
 * @param 'modname' the name of the module
 * @param 'name' the name of the variable
 * @return bool true if successful, false otherwise
 */
function pnModDelVar($modname, $name)
{
    // Modified by Segr function start
    if ((empty($modname)) || (empty($name))) {
        return;
    }

    global $pnmodvar;

    if (isset($pnmodvar[$modname][$name])) {
	    unset($pnmodvar[$modname][$name]);
	}
	
    $dbconn =& pnDBGetConn(true);
    $pntable =& pnDBGetTables();
    $modulevarstable = $pntable['module_vars'];
    $modulevarscolumn = &$pntable['module_vars_column'];
    $query = "DELETE FROM $modulevarstable
              WHERE $modulevarscolumn[modname] = '".pnVarPrepForStore($modname)."'
              AND $modulevarscolumn[name] = '".pnVarPrepForStore($name)."'";
    $dbconn->Execute($query);
  
    if ($dbconn->ErrorNo()!=0) {
	    return;
	}
    return true;
    // Modified by Segr function end
} 

/**
 * pnModGetIDFromName - get module ID given its name
 * @author Jim McDonald <jim@mcdee.net>
 * @link http://www.mcdee.net
 * @param 'module' the name of the module
 * @return int module ID
 */
function pnModGetIDFromName($module)
{
    if (empty($module)) {
        return false;
    } 

	$module = preg_replace('/^NS-/', '', $module);

    static $modid;

	if (!is_array($modid) && !isset($modid[$module])) {
		$dbconn =& pnDBGetConn(true);
		$pntable =& pnDBGetTables();
	
		$modulestable = $pntable['modules'];
		$modulescolumn = &$pntable['modules_column'];
		$query = "SELECT $modulescolumn[name],
						 $modulescolumn[id]
				  FROM $modulestable";
		$result =& $dbconn->Execute($query);
	
		if ($dbconn->ErrorNo() != 0) {
			return;
		} 

		for (; !$result->EOF; $result->MoveNext()) {
			list($modname, $id) = $result->fields;
			$modid[strtolower($modname)] = $id;
		}
	
		if (!isset($modid[strtolower($module)])) {
			$modid[strtolower($module)] = false;
			return false;
		} 
		$result->Close();
	}
	
    if (isset($modid[strtolower($module)])) {
        return $modid[strtolower($module)];
    } 

    return false;
} 

/**
 * get information on module
 * return array of module information or false if core ( id = 0 )
 * @author Jim McDonald <jim@mcdee.net>
 * @link http://www.mcdee.net
 * @param 'id' module ID
 * @return array module information array
 */
function pnModGetInfo($modid)
{ 
    // a $modid of 0 is associated with core ( pn_blocks.mid, ... ).
    if ($modid == 0) {
        return false;
    } 

    static $modinfo;

    if (!is_array($modinfo) && !isset($modinfo[$modid])) {
		$dbconn =& pnDBGetConn(true);
		$pntable =& pnDBGetTables();
	
		$modulestable = $pntable['modules'];
		$modulescolumn = &$pntable['modules_column'];
		$query = "SELECT $modulescolumn[id],
						 $modulescolumn[name],
						 $modulescolumn[type],
						 $modulescolumn[directory],
						 $modulescolumn[regid],
						 $modulescolumn[displayname],
						 $modulescolumn[description],
						 $modulescolumn[state],
						 $modulescolumn[version]
				  FROM $modulestable";
		$result =& $dbconn->Execute($query);
	
		if ($dbconn->ErrorNo() != 0) {
			return;
		} 
	
		for (; !$result->EOF; $result->MoveNext()) {
			list($id,
				 $resarray['name'],
				 $resarray['type'],
				 $resarray['directory'],
				 $resarray['regid'],
				 $resarray['displayname'],
				 $resarray['description'],
				 $resarray['state'],
				 $resarray['version']) = $result->fields;
			$modinfo[$id] = $resarray;
		}

		if (!isset($modinfo[$modid])) {
			$modinfo[$modid] = false;
			return false;
		} 
	    $result->Close();
	}

    return $modinfo[$modid];
} 

/**
 * get list of user modules
 * @author Jim McDonald <jim@mcdee.net>
 * @link http://www.mcdee.net
 * @return array array of module information arrays
 */
function pnModGetUserMods()
{
	static $usermods = array();
	
	if (empty($usermods)) {
		$mods = pnModGetAllMods();
		foreach ($mods as $mod) {
			if ($mod['user_capable']) {
				array_push($usermods, $mod);
			}
		}
	}

    return $usermods;

} 

/**
 * get list of administration modules
 * @author Jim McDonald <jim@mcdee.net>
 * @link http://www.mcdee.net
 * @return array array of module information arrays
 */
function pnModGetAdminMods()
{
	static $adminmods = array();
	
	if (empty($adminmods)) {
		$mods = pnModGetAllMods();
		foreach ($mods as $mod) {
			if ($mod['admin_capable']) {
				array_push($adminmods, $mod);
			}
		}
	}

    return $adminmods;
} 

/**
 * get list of all modules
 * @author Mark West <mark@markwest.me.uk>
 * @link http://www.markwest.me.uk
 * @return array array of module information arrays
 */
function pnModGetAllMods()
{
	static $modsarray = array();

	if (empty($modsarray)) {
		$dbconn =& pnDBGetConn(true);
		$pntable =& pnDBGetTables();
	
		$modulestable = $pntable['modules'];
		$modulescolumn = &$pntable['modules_column'];
		$query = "SELECT $modulescolumn[name],
						 $modulescolumn[type],
						 $modulescolumn[directory],
						 $modulescolumn[regid],
						 $modulescolumn[displayname],
						 $modulescolumn[description],
						 $modulescolumn[admin_capable],
						 $modulescolumn[user_capable],
						 $modulescolumn[version]
				  FROM $modulestable
				  WHERE $modulescolumn[state] = " . _PNMODULE_STATE_ACTIVE . "
                  AND $modulescolumn[directory] != 'NS-Admin'
				  ORDER BY $modulescolumn[name]";
	
		$result =& $dbconn->Execute($query);
	
		if ($dbconn->ErrorNo() != 0) {
			return;
		}

		if ($result->EOF) {
			return false;
		}
	
		while (list($name,
				$modtype,
				$directory,
				$regid,
				$displayname,
				$description,
				$admin_capable,
				$user_capable,
				$version) = $result->fields) {
			$result->MoveNext();
	
			$tmparray = array('name' => $name,
							'type' => $modtype,
							'directory' => $directory,
							'regid' => $regid,
							'displayname' => $displayname,
							'description' => $description,
							'admin_capable' => $admin_capable,
							'user_capable' => $user_capable,
							'version' => $version);
	
			array_push($modsarray, $tmparray);
		}
		$result->Close();
	}

    return $modsarray;
}

/**
 * load an API for a module
 * @author Jim McDonald <jim@mcdee.net>
 * @link http://www.mcdee.net
 * @param 'modname' the name of the module
 * @param 'type' type of functions to load
 * @param 'force' determines to load API even if module isn't active
 * @return bool true on success, false on failure
 */
function pnModAPILoad($modname, $type = 'user', $force = false)
{
    static $loaded = array();

    if (empty($modname)) {
        return false;
    } 

    if (!empty($loaded["$modname$type"])) {
        // Already loaded from somewhere else
        return true;
    } 

	// get the module info
	$modinfo = pnModGetInfo(pnModGetIDFromName($modname));
	
	// check the modules state
	if (!$force && !pnModAvailable($modname) && pnModGetName() != 'Modules') {
		return false;
	}

	// create variables for the OS preped version of the directory
    list($osdirectory, $ostype) = pnVarPrepForOS($modinfo['directory'], $type);

    $mosfile = "modules/$osdirectory/pn{$ostype}api.php";
    $mosdir = "modules/$osdirectory/pn{$ostype}api";

    if (file_exists($mosfile)) {
	    // Load the file from modules
	    include $mosfile;
	} elseif (is_dir($mosdir)) {
	} else {
        // File does not exist
        return false;
    } 
    $loaded["$modname$type"] = 1; 
    // Load the module language files
    $currentlang = pnUserGetLang();
    $defaultlang = pnConfigGetVar('language');
    if (empty($defaultlang)) {
        $defaultlang = 'eng';
    } 

    list($oscurrentlang, $osdefaultlang) = pnVarPrepForOS($currentlang, $defaultlang);
    if (file_exists("modules/$osdirectory/pnlang/$oscurrentlang/{$ostype}api.php")) {
        include "modules/$osdirectory/pnlang/$oscurrentlang/{$ostype}api.php";
    } elseif (file_exists("modules/$osdirectory/pnlang/$osdefaultlang/{$ostype}api.php")) {
        include "modules/$osdirectory/pnlang/$osdefaultlang/{$ostype}api.php";
    } 
    // Load datbase info
    pnModDBInfoLoad($modname, $modinfo['directory']);

    return true;
} 

/**
 * load datbase definition for a module
 * @author Jim McDonald <jim@mcdee.net>
 * @link http://www.mcdee.net
 * @param 'name' the name of the module to load database definition for
 * @param 'directory' directory that module is in (if known)
 * @return bool true if successful, false otherwise
 */
function pnModDBInfoLoad($modname, $directory = '')
{
    static $loaded = array(); 
    // Check to ensure we aren't doing this twice
    if (isset($loaded[$modname])) {
        return true;
    } 
	
	// Get the directory if we don't already have it
    if (empty($directory)) {	
		// get the module info
		$modinfo = pnModGetInfo(pnModGetIDFromName($modname));
		$directory = $modinfo['directory'];
	}

    // Load the database definition if required
    $mospntablefile = 'modules/' . pnVarPrepForOS($directory) . '/pntables.php'; 

    // Ignore errors for this, if it fails we'll find out and handle
    // it when we look for the function itself
	if (file_exists($mospntablefile)) {
		include_once $mospntablefile;
	}
    $tablefunc = $modname . '_' . 'pntables';
    if (function_exists($tablefunc)) {
        $GLOBALS['pntables'] = array_merge($GLOBALS['pntables'], $tablefunc());
    } 
    $loaded[$modname] = true;

    return true;
} 

/**
 * load a module
 * @author Jim McDonald <jim@mcdee.net>
 * @link http://www.mcdee.net
 * @param 'name' the name of the module
 * @param 'type' the type of functions to load
 * @param 'force' determines to load Module even if module isn't active
 * @return string name of module loaded, or false on failure
 */
function pnModLoad($modname, $type = 'user', $force = false)
{
    static $loaded = array();

    if (empty($modname)) {
        return false;
    } 

    if (!empty($loaded["$modname$type"])) {
        // Already loaded from somewhere else
        return $modname;
    } 

	// get the module info
	$modinfo = pnModGetInfo(pnModGetIDFromName($modname));

	// check the modules state
	if (!$force && !pnModAvailable($modname) && pnModGetName() != 'Modules') {
		return false;
	}

    // Load the module and module language files
    list($osdirectory, $ostype) = pnVarPrepForOS($modinfo['directory'], $type);
    $mosfile = "modules/$osdirectory/pn$ostype.php";
    $mosdir = "modules/$osdirectory/pn$ostype";
    if (file_exists($mosfile)) {
	    // Load the file from modules
	    include $mosfile;
	} elseif (is_dir($mosdir)) {
	} else {
        // File does not exist
        return false;
    } 
    $loaded["$modname$type"] = 1;

    $defaultlang = pnConfigGetVar('language');
    if (empty($defaultlang)) {
        $defaultlang = 'eng';
    } 

    $currentlang = pnUserGetLang();
    if (file_exists("modules/$osdirectory/pnlang/$currentlang/$ostype.php")) {
        include "modules/$osdirectory/pnlang/" . pnVarPrepForOS($currentlang) . "/$ostype.php";
    } elseif (file_exists("modules/$osdirectory/pnlang/$defaultlang/$ostype.php")) {
        include "modules/$osdirectory/pnlang/" . pnVarPrepForOS($defaultlang) . "/$ostype.php";
    }
    // Load datbase info
    pnModDBInfoLoad($modname, $modinfo['directory']); 
    // Return the module name
    return $modname;
} 

/**
 * run a module API function
 * @author Jim McDonald <jim@mcdee.net>
 * @link http://www.mcdee.net
 * @param 'modname' the name of the module
 * @param 'type' the type of function to run
 * @param 'func' the specific function to run
 * @param 'args' the arguments to pass to the function
 * @returns mixed
 */
function pnModAPIFunc($modname, $type = 'user', $func = 'main', $args = array())
{
    if (empty($modname)) {
        return false;
    } 

    if (empty($type)) {
        $type = 'user';
    } 
    if (empty($func)) {
        $func = 'main';
    } 
    // Build function name and call function
    $modapifunc = "{$modname}_{$type}api_{$func}";
    if (function_exists($modapifunc)) {
        return $modapifunc($args);
    } else {
	    if (file_exists("modules/$modname/pn{$type}api/$func.php")) {
		    require_once("modules/$modname/pn{$type}api/$func.php");
	        return $modapifunc($args);
		}
	}

    return false;
} 

/**
 * run a module function
 * @author Jim McDonald <jim@mcdee.net>
 * @link http://www.mcdee.net
 * @param 'modname' the name of the module
 * @param 'type' the type of function to run
 * @param 'func' the specific function to run
 * @param 'args' the arguments to pass to the function
 * @returns mixed
 */
function pnModFunc($modname, $type = 'user', $func = 'main', $args = array())
{
    if (empty($modname)) {
        return false;
    } 

    if (empty($type)) {
        $func = 'user';
    } 
    if (empty($func)) {
        $func = 'main';
    } 
    // Build function name and call function
    $modfunc = "{$modname}_{$type}_{$func}";
    if (function_exists($modfunc)) {
        return $modfunc($args);
    } else {
	    if (file_exists("modules/$modname/pn$type/$func.php")) {
		    require_once("modules/$modname/pn$type/$func.php");
	        return $modfunc($args);
		}
	}


    return false;
} 

/**
 * generate a module function URL
 * @author Jim McDonald <jim@mcdee.net>
 * @link http://www.mcdee.net
 * @param 'modname' the name of the module
 * @param 'type' the type of function to run
 * @param 'func' the specific function to run
 * @param 'args' the array of arguments to put on the URL
 * @param ssl - set to constant null,true,false $ssl = true not $ssl = 'true'  null - leave the current status untouched, true - create a ssl url, false - create a non-ssl url
 * @return sting absolute URL for call
 */
function pnModURL($modname, $type = 'user', $func = 'main', $args = array(), $ssl=null)
{
    if (empty($modname)) {
        return false;
    } 

    // The arguments
    $urlargs[] = "module=$modname";
    if ((!empty($type)) && ($type != 'user')) {
        $urlargs[] = "type=$type";
    } 
    if ((!empty($func)) && ($func != 'main')) {
        $urlargs[] = "func=$func";
    } 
    $urlargs = join('&', $urlargs);
    $url = "index.php?$urlargs";
    // <rabbitt> added array check on args
	// April 11, 2003
	if (!is_array($args)) {
		return false;
	} else {
		foreach ($args as $k => $v) {
        	if (is_array($v)) {
        	    foreach($v as $l => $w) {
        	        $url .= "&$k" . "[$l]=$w";
        	    } 
        	} else {
        	    $url .= "&$k=$v";
        	} 
		}
    } 

    // Changes by pnCommerce team + the additional parameter SSL
    // The URL 
    $url = pnGetBaseURL() . $url;

    // pnc addon - if ssl is set to true, change protocol to https
    // otherwise make sure http is used
    if ($ssl===true) {
          $url = ereg_replace ( "http://","https://", $url );
    } else if ($ssl===false) {
          $url = ereg_replace ( "https://","http://", $url );
    }

    return $url;
    //End Changes by pnCommerce team
} 

/**
 * see if a module is available
 * @author Jim McDonald <jim@mcdee.net>
 * @link http://www.mcdee.net
 * @param 'modname' the name of the module
 * @return bool true if the module is available, false if not
 */
function pnModAvailable($modname)
{
    if (empty($modname)) {
        return false;
    } 

    static $modstate;

    if (!is_array($modstate) && !isset($modstate[$modname]))  {
		$dbconn =& pnDBGetConn(true);
		$pntable =& pnDBGetTables();
	
		$modulestable = $pntable['modules'];
		$modulescolumn = &$pntable['modules_column'];
		$query = "SELECT $modulescolumn[name], 
						 $modulescolumn[state]
				  FROM $modulestable";
				  //WHERE $modulescolumn[name] = '" . pnVarPrepForStore($modname) . "'";
		$result =& $dbconn->Execute($query);
	
		if ($dbconn->ErrorNo() != 0) {
			return;
		} 
	
		for (; !$result->EOF; $result->MoveNext()) {
			list($mod, $state) = $result->fields;
			$modstate[$mod] = $state;
		}
        
        // is this useful? I don't think for pnModAvailable -- jn
        /*
		if (!isset($modstate[$modname])) {
			$modstate[$modname] = _PNMODULE_STATE_MISSING;
			return false;
		} 
        */
		$result->Close();
	}

	if (isset($modstate[$modname]) && $modstate[$modname] == _PNMODULE_STATE_ACTIVE) {
		return true;
	} else {
		return false;
	} 

} 

/**
 * get name of current top-level module
 * @author Jim McDonald <jim@mcdee.net>
 * @link http://www.mcdee.net
 * @return string the name of the current top-level module, false if not in a module
 */
function pnModGetName()
{
    $modname = pnVarCleanFromInput('module');
    if (empty($modname)) {
        $name = pnVarCleanFromInput('name');
        if (empty($name)) {
			if (stristr($_SERVER['PHP_SELF'], 'admin.php')) {
				// admin.php -> Admin module
				$ourmod = 'Admin';
			} else {
				$ourmod = pnConfigGetVar('startpage');
			}
        } else {
			$ourmod = $name;
		}
    } else {
        $ourmod = $modname;
    }

	$ourmod = preg_replace('/^NS-/', '', $ourmod);
	return $ourmod;
} 

/**
 * register a hook function
 * @author Jim McDonald <jim@mcdee.net>
 * @link http://www.mcdee.net
 * @param 'hookobject' the hook object
 * @param 'hookaction' the hook action
 * @param 'hookarea' the area of the hook (either 'GUI' or 'API')
 * @param 'hookmodule' name of the hook module
 * @param 'hooktype' name of the hook type
 * @param 'hookfunc' name of the hook function
 * @return bool true if successful, false otherwise
 */
function pnModRegisterHook($hookobject,
    $hookaction,
    $hookarea,
    $hookmodule,
    $hooktype,
    $hookfunc)
{ 
    // Get database info
    $dbconn =& pnDBGetConn(true);
    $pntable =& pnDBGetTables();
    $hookstable = $pntable['hooks'];
    $hookscolumn = &$pntable['hooks_column']; 
    // Insert hook
    $sql = "INSERT INTO $hookstable (
              $hookscolumn[id],
              $hookscolumn[object],
              $hookscolumn[action],
              $hookscolumn[tarea],
              $hookscolumn[tmodule],
              $hookscolumn[ttype],
              $hookscolumn[tfunc])
            VALUES (
              " . pnVarPrepForStore($dbconn->GenId($hookstable)) . ",
              '" . pnVarPrepForStore($hookobject) . "',
              '" . pnVarPrepForStore($hookaction) . "',
              '" . pnVarPrepForStore($hookarea) . "',
              '" . pnVarPrepForStore($hookmodule) . "',
              '" . pnVarPrepForStore($hooktype) . "',
              '" . pnVarPrepForStore($hookfunc) . "')";
    $dbconn->Execute($sql);

    if ($dbconn->ErrorNo() != 0) {
        return false;
    } 

    return true;
} 

/**
 * unregister a hook function
 * @author Jim McDonald <jim@mcdee.net>
 * @link http://www.mcdee.net
 * @param 'hookobject' the hook object
 * @param 'hookaction' the hook action
 * @param 'hookarea' the area of the hook (either 'GUI' or 'API')
 * @param 'hookmodule' name of the hook module
 * @param 'hooktype' name of the hook type
 * @param 'hookfunc' name of the hook function
 * @return bool true if successful, false otherwise
 */
function pnModUnregisterHook($hookobject,
    $hookaction,
    $hookarea,
    $hookmodule,
    $hooktype,
    $hookfunc)
{ 
    // Get database info
    $dbconn =& pnDBGetConn(true);
    $pntable =& pnDBGetTables();
    $hookstable = $pntable['hooks'];
    $hookscolumn = &$pntable['hooks_column']; 
    // Remove hook
    $sql = "DELETE FROM $hookstable
            WHERE $hookscolumn[object] = '" . pnVarPrepForStore($hookobject) . "'
             AND $hookscolumn[action] = '" . pnVarPrepForStore($hookaction) . "'
             AND $hookscolumn[tarea] = '" . pnVarPrepForStore($hookarea) . "'
             AND $hookscolumn[tmodule] = '" . pnVarPrepForStore($hookmodule) . "'
             AND $hookscolumn[ttype] = '" . pnVarPrepForStore($hooktype) . "'
             AND $hookscolumn[tfunc] = '" . pnVarPrepForStore($hookfunc) . "'";
    $dbconn->Execute($sql);

    if ($dbconn->ErrorNo() != 0) {
        return false;
    } 

    return true;
} 

/**
 * carry out hook operations for module
 * @author Jim McDonald <jim@mcdee.net>
 * @link http://www.mcdee.net
 * @param 'hookobject' the object the hook is called for - one of 'item', 'category' or 'module'
 * @param 'hookaction' the action the hook is called for - one of 'new', 'create', 'modify', 'update', 'delete', 'transform', 'display', 'modifyconfig', 'updateconfig'
 * @param 'hookid' the id of the object the hook is called for (module-specific)
 * @param 'extrainfo' extra information for the hook, dependent on hookaction
 * @return mixed string output from GUI hooks, extrainfo array for API hooks
 */
function pnModCallHooks($hookobject, $hookaction, $hookid, $extrainfo)
{
	static $modulehooks;

	if (isset($extrainfo['module']) && pnModAvailable($extrainfo['module'])) {
		$modname = $extrainfo['module'];
	} else {
		$modname = pnModGetName();
	}

	if (!isset($modulehooks[$modname])) {
		// Get database info
		$dbconn =& pnDBGetConn(true);
		$pntable =& pnDBGetTables();
		$hookstable = $pntable['hooks'];
		$hookscolumn = &$pntable['hooks_column']; 
		// Get applicable hooks
		$sql = "SELECT $hookscolumn[tarea],
					   $hookscolumn[tmodule],
					   $hookscolumn[ttype],
					   $hookscolumn[tfunc],
					   $hookscolumn[action],
					   $hookscolumn[object]
				FROM $hookstable
				WHERE $hookscolumn[smodule] = '" . pnVarPrepForStore($modname) . "'";
		$result =& $dbconn->Execute($sql);
	
		if ($dbconn->ErrorNo() != 0) {
			return null;
		} 
		$hooks = array();
	    for (; !$result->EOF; $result->MoveNext()) {
			list($area, $module, $type, $func, $action, $object) = $result->fields;
			$hooks[] = array('area' => $area,
							 'module' => $module,
							 'type' => $type,
							 'func' => $func,
							 'action' => $action,
							 'object' => $object);
		}
		$modulehooks[$modname] = $hooks;
	}
    $gui = false;
    $output = ''; 

    // Call each hook
	foreach($modulehooks[$modname] as $modulehook) {
		if (($modulehook['action'] == $hookaction) && ($modulehook['object'] == $hookobject)) {
			if ($modulehook['area'] == 'GUI') {
				if (pnModAvailable($modulehook['module'], $modulehook['type']) && pnModLoad($modulehook['module'], $modulehook['type'])) {
					$gui = true;
					$output .= pnModFunc($modulehook['module'],
										 $modulehook['type'],
										 $modulehook['func'],
										 array('objectid' => $hookid,
											   'extrainfo' => $extrainfo));
				} 
			} else {
				if (pnModAvailable($modulehook['module'], $modulehook['type']) && pnModAPILoad($modulehook['module'], $modulehook['type'])) {
					$extrainfo = pnModAPIFunc($modulehook['module'],
											  $modulehook['type'],
											  $modulehook['func'],
											  array('objectid' => $hookid,
												    'extrainfo' => $extrainfo));
				} 
			} 
		}
    } 

	// check what type of information we need to return
	// credit to the xaraya team for the eregi check
    if (($gui == true) || eregi('^(display|new|modify|modifyconfig)$',$hookaction)) {
        return $output;
    } else {
        return $extrainfo;
    } 
} 

/**
 * Determine if a module is hooked by another module
 * @author Mark West (mark@markwest.me.uk)
 * @link http://www.markwest.me.uk
 * @param 'tmodule' the target module
 * @param 'smodule' the source module - default the current top most module
 * @return bool true if the current module is hooked by the target module, false otherwise 
 */
function pnModIsHooked($tmodule, $smodule)
{
    if (empty($tmodule) || empty($smodule)){
        return false;
    } 

    // Get database info
    $dbconn =& pnDBGetConn(true);
    $pntable =& pnDBGetTables();
    $hookstable = $pntable['hooks'];
    $hookscolumn = &$pntable['hooks_column']; 

    // Get applicable hooks
    $sql = "SELECT COUNT(1)
            FROM $hookstable
            WHERE $hookscolumn[smodule] = '" . pnVarPrepForStore($smodule) . "'
            AND $hookscolumn[tmodule] = '" . pnVarPrepForStore($tmodule) . "'";
    $result =& $dbconn->Execute($sql);

    if ($dbconn->ErrorNo() != 0) {
        return null;
    } 

    // Obtain the number of items
    list($numitems) = $result->fields;

    // All successful database queries produce a result set, and that result
    // set should be closed when it has been finished with
    $result->Close();

    // Return the number of items
	if ($numitems > 0) { 
	    return true;
	} else {
	    return false;
    }
 
} 

?>
