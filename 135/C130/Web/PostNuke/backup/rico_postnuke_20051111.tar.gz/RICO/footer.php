<?php
// File: $Id: footer.php,v 1.18 2004/08/10 11:16:06 markwest Exp $ $Name: HEAD $
// ----------------------------------------------------------------------
// PostNuke Content Management System
// Copyright (C) 2001 by the PostNuke Development Team.
// http://www.postnuke.com/
// ----------------------------------------------------------------------
// Based on:
// PHP-NUKE Web Portal System - http://phpnuke.org/
// Thatware - http://thatware.org/
// ----------------------------------------------------------------------
// LICENSE
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License (GPL)
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// To read the license please visit http://www.gnu.org/copyleft/gpl.html
// ----------------------------------------------------------------------
// Original Author of file: Francisco Burzi
// Purpose of file:
// ----------------------------------------------------------------------

if (stristr('footer.php', $_SERVER['PHP_SELF'])) {
	die ("You can't access this file directly...");
}

// XHTML Support by Matt Jarjoura. <mjarjo1@umbc.edu>

function footmsg()
{
   echo "<span class=\"pn-sub\">\n".pnConfigGetVar('foot1')."<br />\n</span>\n";
}

function foot()
{
	// modification .71 multisites mouzaia
	/* it should not be necessary here, since config.php is in a table.
		if (!isset($index)) {
		include(WHERE_IS_PERSO."config.php");
		}
	*/
    themefooter();

	if (!isset($GLOBALS['xanthia_theme']) || !$GLOBALS['xanthia_theme']) {
		// show time to render
		$mtime = explode(" ",microtime());
		$dbg_endtime = $mtime[1] + $mtime[0];
		$dbg_totaltime = ($dbg_endtime - $GLOBALS['dbg_starttime']);

		if ($GLOBALS['pndebug']['pagerendertime']) {
			printf("<div style=\"text-align:center\" class=\"pn-sub\">Page created in %f seconds.</div>", $dbg_totaltime);
		}
		if ($GLOBALS['pndebug']['debug']){
			$GLOBALS['dbg']->v($dbg_totaltime,"Page created in (seconds)");
			$GLOBALS['dbg']->v($GLOBALS['debug_sqlcalls'],"Number of SQL Calls");
		}
	
		// include typetool 8.0 [larsneo]
		// (upload option disabled for security reasons) 
		$tt_enable = pnModGetVar('typetool', 'enable');
		$baseURL = pnGetBaseURL();
		$ModName = pnModGetName(); 
		if ( is_numeric( $tt_enable ) && $tt_enable == 1) {  
			if (pnSecAuthAction(0, 'typetool::', "$ModName::", ACCESS_COMMENT) && 
					$ModName != "Settings" && 
					$ModName != "Permissions" && 
					$ModName != "Censor") {
				// enable the wysiwyg editor when user has at least comment rights 
				// no WYSIWYG in Settings, Permissions and Censor anyway...
			    echo "\n<!--Visual Editor Plug-in-->\n";
   	 			echo "<script type=\"text/javascript\">VISUAL=0; FULLCTRL=1; SECURE=1; LANGUAGE='".pnModGetVar('typetool', 'language')."';</script>\n";
   	 			echo "<script type=\"text/javascript\" src='".$baseURL."modules/typetool/pnincludes/quickbuild.js'></script>\n";
    			echo "<!--End Visual Editor Plug-in-->\n";
			}
		}
	
		echo "</body>\n</html>";
		ob_end_flush();
	}
}

foot();
?>