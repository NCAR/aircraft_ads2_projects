<?php // $Id: Version.php,v 1.2 2002/10/27 20:13:46 larsneo Exp $ $Name: HEAD $

$modversion['name'] = 'Top_List';
$modversion['version'] = '1.0';
$modversion['description'] = 'Display top x listings';
$modversion['credits'] = 'docs/credits.txt';
$modversion['help'] = 'docs/install.txt';
$modversion['changelog'] = 'docs/changelog.txt';
$modversion['license'] = 'docs/license.txt';
$modversion['official'] = 1;
$modversion['author'] = 'Francisco Burzi';
$modversion['contact'] = 'http://www.phpnuke.org';
$modversion['admin'] = 1;
$modversion['securityschema'] = array('Top_List::' => '::');

?>