<?php
// Generated: $d$ by $id$
// ----------------------------------------------------------------------
// PostNuke Content Management System
// Copyright (C) 2001 by The PostNuke Development Team.
// http://www.postnuke.com/
// ----------------------------------------------------------------------
// Based on:
// PHP-NUKE Web Portal System - http://phpnuke.org/
// Thatware - http://thatware.org/
// ----------------------------------------------------------------------
// LICENSE
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License (GPL)
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU General Public License for more details.
//
// To read the license please visit http://www.gnu.org/copyleft/gpl.html
// ----------------------------------------------------------------------
// Original Author of file: Everyone
// Purpose of file: Translation files
// Translation team: Read credits in /docs/CREDITS.txt
// ----------------------------------------------------------------------
define('_AT','at');
define('_AWEBUSERFROM','A user from');
define('_CODEFOR','Confirmation code for');
define('_CODEREQUESTED','has just requested a confirmation code to change his/her password.');
define('_CONFIRMATIONCODE','Confirmation code');
define('_HASREQUESTED','has just requested that a password be sent.');
define('_HASTHISEMAIL','has this e-mail address associated with it.');
define('_IFYOUDIDNOTASK','If you didn\'t request the password, please don\'t worry. You\'re seeing this message, not \'them\', so they do not have the requested information. If this was an error, please just log-in with your new password.');
define('_IFYOUDIDNOTASK2','If you didn\'t ask for this, please don\'t worry. Just delete this e-mail message.');
define('_MAILED','mailed.');
define('_NOPROBLEM','
No problem!<br /><br />
Just type your user name and click the Send button, and an e-mail message will be sent to you with a \'confirmation code\'. After you receive the confirmation code, re-type your user name and the \'confirmation code\' into this form. After this form has been submitted, a new password will be generated and mailed  to you.<br /><br />');
define('_PASSWORD4','Password for');
define('_PASSWORDLOST','Lost your password?');
define('_SENDPASSWORD','Send password');
define('_SORRYNOUSERINFO','Sorry! There is no corresponding user information.');
define('_USERACCOUNT','The user account');
define('_USERPASSWORD4','User password for');
define('_WITHTHISCODE','With this code, you can now create a new password at');
define('_YOUCANCHANGE','You can change your password after you log-in at');
define('_YOURCODEIS','Your confirmation code is:');
define('_YOURNEWPASSWORD','Your new password is:');
?>