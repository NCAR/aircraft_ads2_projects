<?php // $Id: Version.php,v 1.1.1.1 2002/09/15 22:26:15 root Exp $ $Name: HEAD $

$modversion['name'] = 'AvantGo';
$modversion['version'] = '1.3';
$modversion['description'] = 'AvantGo Mobile News Module';
$modversion['credits'] = 'docs/credits.txt';
$modversion['help'] = 'docs/install.txt';
$modversion['changelog'] = 'docs/changelog.txt';
$modversion['license'] = 'docs/license.txt';
$modversion['official'] = 1;
$modversion['author'] = 'Tim Litwiller - The PostNuke Project';
$modversion['contact'] = 'http://www.linux.made-to-order.net';
$modversion['admin'] = 0;
$modversion['securityschema'] = array('AvantGo::' => '::');

?>