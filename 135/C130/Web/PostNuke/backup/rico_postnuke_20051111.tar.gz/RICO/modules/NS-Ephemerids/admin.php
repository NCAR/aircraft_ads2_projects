<?php
// File: $Id: admin.php,v 1.19 2004/08/24 18:47:08 markwest Exp $ $Name: HEAD $
// ----------------------------------------------------------------------
// POSTNUKE Content Management System
// Copyright (C) 2001 by the PostNuke Development Team.
// http://www.postnuke.com/
// ----------------------------------------------------------------------
// Based on:
// PHP-NUKE Web Portal System - http://phpnuke.org/
// Thatware - http://thatware.org/
// ----------------------------------------------------------------------
// LICENSE
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License (GPL)
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// To read the license please visit http://www.gnu.org/copyleft/gpl.html
// ----------------------------------------------------------------------
// Original Author of file:
// Purpose of file:
// ----------------------------------------------------------------------

if (!eregi("admin.php", $_SERVER['PHP_SELF'])) {
    die ("Access Denied");
}

$ModName = $module;
modules_get_language();
modules_get_manual();

/**
 * Ephemerids Functions to have a Historic Ephemerids
 */

function Ephemerids()
{
    include 'header.php';
    $bgcolor1 = $GLOBALS['bgcolor1'];
    list($elanguage) = pnVarCleanFromInput('elanguage');
    

    $dbconn =& pnDBGetConn(true);
    $pntable =& pnDBGetTables();

    $currentlang = pnUserGetLang();

    GraphicAdmin();
    OpenTable();
    echo "<div style=\"text-align:center\"><span class=\"pn-title\"><strong>"._EPHEMADMIN."</strong></span></div>";
    CloseTable();

    if (!pnSecAuthAction(0, 'Ephemerids::', '::', ACCESS_EDIT)) {
        echo _EPHEMNOAUTH;
        include 'footer.php';
        return;
    }

    if (pnSecAuthAction(0, 'Ephemerids::', '::', ACCESS_ADD)) {
        OpenTable();
        echo "<div style=\"text-align:center\"><span class=\"pn-title\"><strong>"._ADDEPHEM."</strong></span></div><br />"
            ."<form action=\"admin.php\" method=\"post\"><div>";
        $nday = "1";
        echo "<span class=\"pn-normal\">"._DAY.": <select name=\"did\">";
        while ($nday<=31) {
            echo "<option>$nday</option>";
            $nday++;
        }
        echo "</select>";
        $nmonth = "1";
        echo ""._UMONTH.": <select name=\"mid\">";
        while ($nmonth<=12) {
            echo "<option>$nmonth</option>";
            $nmonth++;
        }
        echo "</select>"._YEAR.": <input type=\"text\" name=\"yid\" maxlength=\"4\" size=\"5\" /><br /><br />"
            .'<strong>'._LANGUAGE.': </strong>'
            .'<select name="elanguage" size="1">';
        $lang = languagelist();
        if (!isset($elanguage))
        {
            $sel_lang[0] = ' selected="selected"';
        } else {
			$sel_lang[0] = '';
            $sel_lang[$elanguage] = ' selected="selected"';
        }
        print "<option value=\"\" $sel_lang[0]>"._ALL.'</option>';
        $handle = opendir('language');
        while ($f = readdir($handle))
        {
            if (is_dir("language/$f") && (!empty($lang[$f])))
            {
                $langlist[$f] = $lang[$f];
            }
        }
        asort($langlist);
        foreach ($langlist as $k=>$v) {
        echo '<option value="'.$k.'"';
        if (isset($sel_lang[$k])) {
            echo ' selected="selected"';
        }
        echo '>'. $v . '</option>';
        }
		echo "</select>";
        print '<br /><br />' /* ML END */
              ."<strong>"._EPHEMDESC.":</strong><br />"
              ."<textarea name=\"content\" cols=\"80\" rows=\"10\"></textarea><br /><br />"
              ."<input type=\"hidden\" name=\"module\" value=\"".$GLOBALS['module']."\" />"
              ."<input type=\"hidden\" name=\"op\" value=\"Ephemeridsadd\" />"
		      ."<input type=\"hidden\" name=\"authid\" value=\"" . pnSecGenAuthKey() . "\" />"
              ."<input type=\"submit\" value=\""._OK."\" />"
              ."</span></div></form>";
        CloseTable();
    }

    if (pnSecAuthAction(0, 'Ephemerids::', '::', ACCESS_EDIT)) {
        OpenTable();
            echo "<div style=\"text-align:center\"><span class=\"pn-title\"><strong>"._EPHEMMAINT."</strong></span></div><br />"
            ."<div style=\"text-align:center\"><form action=\"admin.php\" method=\"post\"><div>";
        $nday = "1";
        echo "<span class=\"pn-normal\">"._DAY.": <select name=\"did\">";
        while ($nday<=31) {
            echo "<option>$nday</option>";
            $nday++;
        }
        echo "</select>";
        $nmonth = "1";
        echo ""._UMONTH.": <select name=\"mid\">";
        while ($nmonth<=12) {
            echo "<option>$nmonth</option>";
            $nmonth++;
        }
        echo "</select>"
            ."<input type=\"hidden\" name=\"module\" value=\"".$GLOBALS['module']."\" />"
            ."<input type=\"hidden\" name=\"op\" value=\"Ephemeridsmaintenance\" />"
		    ."<input type=\"hidden\" name=\"authid\" value=\"" . pnSecGenAuthKey() . "\" />"
            ."<input type=\"submit\" value=\""._EDIT."\" />"
            ."</span></div></form></div>";
        CloseTable();
    }

    OpenTable();
    echo "<br />";
    echo "<div style=\"text-align:center\"><span class=\"pn-title\"><strong>"._EPHEMCURRENT."</strong></span></div><br />";
    echo "<div style=\"text-align:center\"><table border=\"1\" width=\"100%\" style=\"background-color:$bgcolor1\"><tr>"
        ."<td><strong><span class=\"pn-normal\">&nbsp;&nbsp;"._DAY."&nbsp;&nbsp;</span></strong></td>"
        ."<td><strong><span class=\"pn-normal\">&nbsp;&nbsp;"._UMONTH."&nbsp;&nbsp;</span></strong></td>"
        ."<td><strong><span class=\"pn-normal\">&nbsp;&nbsp;"._YEAR."&nbsp;&nbsp;</span></strong></td>"
        ."<td><strong><span class=\"pn-normal\">&nbsp;&nbsp;"._EPHEMDESC."</span></strong></td>"
        ."<td colspan=\"2\"><span class=\"pn-normal\">"._EPHEMEDIT."</span></td></tr>";
    //$result =& $dbconn->Execute(buildSimpleQuery('ephem', array ('eid', 'did', 'mid', 'yid', 'content', 'elanguage')));
    $column =&$pntable['ephem_column'];
	$sql = "SELECT $column[eid], $column[did], $column[mid], $column[yid], $column[content], $column[elanguage]
			FROM $pntable[ephem]";
	$result =& $dbconn->Execute($sql);
    while(list($eid, $did, $mid, $yid, $content, $elanguage) = $result->fields) {

        $result->MoveNext();

        if (pnSecAuthAction(0, 'Ephemerids::', "$content:$eid", ACCESS_EDIT)) {
            echo "<tr><td align=\"center\"><span class=\"pn-normal\">". pnVarPrepForDisplay($did)."</span></td>"
                ."<td align=\"center\"><span class=\"pn-normal\">". pnVarPrepForDisplay($mid)."</span></td>"
                ."<td align=\"center\"><span class=\"pn-normal\">". pnVarPrepForDisplay($yid)."</span></td>"
                ."<td align=\"center\">&nbsp;&nbsp;<span class=\"pn-normal\">". pnVarPrepHTMLDisplay(nl2br($content))."</span></td>";
            if (pnSecAuthAction(0, 'Ephemerids::', "$content:$eid", ACCESS_EDIT)) {

				$authid = pnSecGenAuthKey();

                echo "<td align=\"center\"><span class=\"pn-normal\"><a href=\"admin.php?module=".$GLOBALS['module']."&amp;op=Ephemeridsedit&amp;eid=$eid&amp;did=$did&amp;mid=$mid&amp;authid=$authid\">"._EDIT."</a></span></td>";
                if (pnSecAuthAction(0, 'Ephemerids::', "$content::$eid", ACCESS_DELETE)) {
                    echo "<td align=\"center\"><span class=\"pn-normal\"><a href=\"admin.php?module=".$GLOBALS['module']."&amp;op=Ephemeridsdel&amp;eid=$eid&amp;did=$did&amp;mid=$mid&amp;authid=$authid\">"._DELETE."</a></span></td>";
                } else {
                    echo "<td>&nbsp;</td>";
                }
            } else {
                echo "<td>&nbsp;</td><td>&nbsp;</td>";
            }
            echo "</tr>";
        }
    }
    echo "</table></div>";
    CloseTable();

    include 'footer.php';
}

function Ephemeridsadd()
{
   list($did,
	$mid,
	$yid,
	$content,
	$elanguage) = pnVarCleanFromInput('did',
					  'mid',
					  'yid',
					  'content',
					  'elanguage');
    if (!pnSecConfirmAuthKey()) {
        include 'header.php';
        echo _BADAUTHKEY;
        include 'footer.php';
        exit;
    }
    $dbconn =& pnDBGetConn(true);
    $pntable =& pnDBGetTables();

    if (!pnSecAuthAction(0, 'Ephemerids::', "$content::", ACCESS_ADD)) {
        include "header.php";
        GraphicAdmin();
        OpenTable();
        echo "<div style=\"text-align:center\"><span class=\"pn-title\"><strong>"._EPHEMADMIN."</strong></span></div>";
        CloseTable();

	echo _EPHEMADDNOAUTH;
        include "footer.php";
        return;
    }
    $column =&$pntable['ephem_column'];
    $nextid = $dbconn->GenId($pntable['ephem']);
    $dbconn->Execute("INSERT INTO $pntable[ephem] ($column[eid], $column[did], $column[mid], $column[yid], $column[content], $column[elanguage]) VALUES (
    $nextid,
        '" .(int)pnVarPrepForStore($did). "',
        '" .(int)pnVarPrepForStore($mid). "',
        '" .(int)pnVarPrepForStore($yid). "',
        '" .pnVarPrepForStore($content). "',
        '" .pnVarPrepForStore($elanguage). "'
    )");
    pnRedirect('admin.php?module='.$GLOBALS['module'].'&op=Ephemerids');
}

function Ephemeridsmaintenance()
{
    list($did,
	 $mid) = pnVarCleanFromInput('did',
				     'mid');
    $dbconn =& pnDBGetConn(true);
    $pntable =& pnDBGetTables();

    $authid = pnSecGenAuthKey();

    include 'header.php';

    GraphicAdmin();
    OpenTable();
    echo "<div style=\"text-align:center\"><span class=\"pn-title\"><strong>"._EPHEMADMIN."</strong></span></div>";
    CloseTable();

    if (!pnSecAuthAction(0, 'Ephemerids::', '::', ACCESS_EDIT)) {
        echo _EPHEMEDITNOAUTH;
        include 'footer.php';
        return;
    }

    OpenTable();
    echo "<div style=\"text-align:center\"><span class=\"pn-title\"><strong>"._EPHEMMAINT." $did/$mid</strong></span></div><br />";

    $column = &$pntable['ephem_column'];
    $result =& $dbconn->Execute("SELECT $column[eid], $column[did], $column[mid], $column[yid], $column[content], $column[elanguage] " .
    			     "FROM $pntable[ephem] " .
    			     "WHERE $column[did]='" . (int)pnVarPrepForStore($did) . "' AND $column[mid]='" . (int)pnVarPrepForStore($mid)."'");
    while(list($eid, $did, $mid, $yid, $content, $elanguage) = $result->fields) {
	$result->MoveNext();
        echo "<span class=\"pn-normal\"><strong>$yid</strong> - ";
    if (!empty($elanguage)) {
        echo "($elanguage) - ";
    }
        if (pnSecAuthAction(0, 'Ephemerids::', "$content::$eid", ACCESS_EDIT)) {
        echo "<span class=\"pn-normal\">[ <a href=\"admin.php?module=".$GLOBALS['module']."&amp;op=Ephemeridsedit&amp;eid=$eid&amp;did=$did&amp;mid=$mid&amp;authid=$authid\">"._EDIT."</a> ";
            if (pnSecAuthAction(0, 'Ephemerids::', "$content::$eid", ACCESS_DELETE)) {
                echo " | <a href=\"admin.php?module=".$GLOBALS['module']."&amp;op=Ephemeridsdel&amp;eid=$eid&amp;did=$did&amp;mid=$mid&amp;authid=$authid\">"
                ._DELETE."</a> ]";
            } else {
                echo "</span> ]";
            }
        }
        echo "<br /><span class=\"pn-sub\">". pnVarPrepHTMLDisplay(nl2br($content))."</span><br /><br /><br />";
    }

    CloseTable();
    include 'footer.php';
}

function Ephemeridsdel()
{
    list($eid,
	 $did,
	 $mid) = pnVarCleanFromInput('eid',
				     'did',
				     'mid');

    list($authid) = pnVarCleanFromInput('authid');

    if (!pnSecConfirmAuthKey()) {
        include 'header.php';
        echo _BADAUTHKEY;
        include 'footer.php';
        exit;
    }
    $dbconn =& pnDBGetConn(true);
    $pntable =& pnDBGetTables();

    $column = &$pntable['ephem_column'];

    $result =& $dbconn->Execute("SELECT $column[content]
                              FROM $pntable[ephem]
                              WHERE $column[eid]='" . (int)pnVarPrepForStore($eid)."'");
    list($content) = $result->fields;
    $result->Close();

    if (!pnSecAuthAction(0, 'Ephemerids::', "$content::$eid", ACCESS_DELETE)) {
        include 'header.php';
        GraphicAdmin();
        OpenTable();
        echo "<div style=\"text-align:center\"><span class=\"pn-title\"><strong>"._EPHEMADMIN."</strong></span></div>";
        CloseTable();

        echo _EPHEMDELETENOAUTH;
        include 'footer.php';
        return;
    }

    $dbconn->Execute("DELETE FROM $pntable[ephem] WHERE $column[eid]='" . (int)pnVarPrepForStore($eid)."'");
    //pnRedirect('admin.php?module='.$GLOBALS['module'].'&op=Ephemeridsmaintenance&did='.$did.'&mid='.$mid);
	pnRedirect('admin.php?module='.$GLOBALS['module'].'&op=Ephemerids');
}

function Ephemeridsedit()
{
    list($eid,
	 $did,
	 $mid) = pnVarCleanFromInput('eid',
				     'did',
				     'mid');

    list($authid) = pnVarCleanFromInput('authid');

    if (!pnSecConfirmAuthKey()) {
        include 'header.php';
        echo _BADAUTHKEY;
        include 'footer.php';
        exit;
    }
    $dbconn =& pnDBGetConn(true);
    $pntable =& pnDBGetTables();

    include ("header.php");

    GraphicAdmin();
    OpenTable();
    echo "<div style=\"text-align:center\"><span class=\"pn-title\"><strong>"._EPHEMADMIN."</strong></span></div>";
    CloseTable();

    $column = &$pntable['ephem_column'];
    $result =& $dbconn->Execute("SELECT $column[yid], $column[content], $column[elanguage] 
    				FROM $pntable[ephem] 
    				WHERE $column[eid]='".(int)pnVarPrepForStore($eid)."'");
    list($yid, $content, $elanguage) = $result->fields;

    if (!pnSecAuthAction(0, 'Ephemerids::', "$content::$eid", ACCESS_EDIT)) {
        echo _EPHEMEDITNOAUTH;
        include "footer.php";
        return;
    }
    OpenTable();
    echo "<div style=\"text-align:center\"><span class=\"pn-title\"><strong>"._EPHEMEDIT."</strong></span></div><br />"
    ."<form action=\"admin.php\" method=\"post\">";

    $nday = "1";
    echo "<span class=\"pn-normal\">"._DAY.": <select name=\"did\">";
    while ($nday<=31) {
        echo "<option ";
	    if (pnVarPrepForDisplay($did) == $nday) {
		 echo "SELECTED";
	    }
	echo ">$nday</option>";
        $nday++;
    }
    echo "</select>&nbsp;&nbsp;";
    $nmonth = "1";
    echo ""._UMONTH.": <select name=\"mid\">";
    while ($nmonth<=12) {
        echo "<option ";
	    if (pnVarPrepForDisplay($mid) == $nmonth) {
		 echo "SELECTED";
	    }
	echo ">$nmonth</option>";
        $nmonth++;
    }
    echo "</select>&nbsp;&nbsp;"
    ."<strong>"._YEAR.":</strong> <input type=\"text\" name=\"yid\" value=\"". pnVarPrepForDisplay($yid)."\" maxlength=\"4\" size=\"5\"><br /><br />"
        .'<strong>'._LANGUAGE.': </strong>' /* ML Added drop down to select one of the available languages, currentlang is pre-selected */
        .'<select name="elanguage" size="1">'   /* we could also set admlanguage (admin) to be default selected instead of currentlang */
    ;
    $lang = languagelist();
    if (!$elanguage) {
        $sel_lang[0] = ' selected';
    } else {
	$sel_lang[0] = '';
	$sel_lang[$elanguage] = ' selected';
    }
    print "<option value=\"\" $sel_lang[0]>"._ALL.'</option>';
    $handle = opendir('language');
    while ($f = readdir($handle)) {
        if (is_dir("language/$f") && (!empty($lang[$f]))) {
            $langlist[$f] = $lang[$f];
        }
    }
    asort($langlist);
    foreach ($langlist as $k=>$v) {
    echo '<option value="'.$k.'"';
    if (isset($sel_lang[$k])) {
        echo ' selected';
    }
    echo '>'. $v . '</option>';
    }
    echo "</select>";
    print '<br /><br />' /* ML END */
    ."<strong>"._EPHEMDESC."</strong><br />"
    ."<textarea name=\"content\" cols=\"80\" rows=\"10\">". pnVarPrepHTMLDisplay($content)."</textarea><br /><br />"
    ."<input type=\"hidden\" name=\"eid\" value=\"". pnVarPrepForDisplay($eid)."\">"
    ."<input type=\"hidden\" name=\"module\" value=\"".$GLOBALS['module']."\">"
    ."<input type=\"hidden\" name=\"op\" value=\"Ephemeridschange\">"
    ."<input type=\"hidden\" name=\"authid\" value=\"" . pnSecGenAuthKey() . "\">"
    ."<input type=\"submit\" value=\""._SAVECHANGES."\">"
    ."</span></form>";
    CloseTable();
    include 'footer.php';
}

function Ephemeridschange()
{
    list($eid,
	 $did,
	 $mid,
	 $yid,
	 $content,
	 $elanguage) = pnVarCleanFromInput('eid',
					   'did',
					   'mid',
					   'yid',
					   'content',
					   'elanguage');
    if (!pnSecConfirmAuthKey()) {
        include 'header.php';
        echo _BADAUTHKEY;
        include 'footer.php';
        exit;
    }
    $dbconn =& pnDBGetConn(true);

    $pntable =& pnDBGetTables();
    $column = &$pntable['ephem_column'];
    $result =& $dbconn->Execute("SELECT $column[content]
                              FROM $pntable[ephem]
                              WHERE $column[eid]='".(int)pnVarPrepForStore($eid)."'");
    list($oldcontent) = $result->fields;
    $result->Close();

    if (!pnSecAuthAction(0, 'Ephemerids::', "$oldcontent::$eid", ACCESS_EDIT)) {
        include "header.php";
        GraphicAdmin();
        OpenTable();
        echo "<div style=\"text-align:center\"><span class=\"pn-title\"><strong>"._EPHEMADMIN."</strong></span></div>";
        CloseTable();

        echo _EPHEMEDITNOAUTH;
        include 'footer.php';
        return;
    }

    $dbconn->Execute("UPDATE $pntable[ephem] SET $column[yid]='". (int)pnVarPrepForStore($yid)."', $column[content]='". pnVarPrepForStore($content)."', $column[elanguage]='". pnVarPrepForStore($elanguage)."', $column[did]='". (int)pnVarPrepForStore($did)."', $column[mid]='".(int)pnVarPrepForStore($mid)."' WHERE $column[eid]='".(int)pnVarPrepForStore($eid)."'");

    pnRedirect('admin.php?module='.$GLOBALS['module'].'&op=Ephemerids');
}

function ephemerids_admin_main($var)
{
   $op = pnVarCleanFromInput('op');
   extract($var);

   if (!pnSecAuthAction(0, 'Ephemerids::', '::', ACCESS_EDIT)) {
       include 'header.php';
       GraphicAdmin();
       OpenTable();
       echo "<div style=\"text-align:center\"><span class=\"pn-title\"><strong>"._EPHEMADMIN."</strong></span></div>";
       CloseTable();

       echo _EPHEMNOAUTH;
       include 'footer.php';

   } else {
       switch($op) {

        case "Ephemeridsedit":
            Ephemeridsedit();
            break;

        case "Ephemeridschange":
            Ephemeridschange();
            break;

        case "Ephemeridsdel":
            Ephemeridsdel();
            break;

        case "Ephemeridsmaintenance":
            Ephemeridsmaintenance();
            break;

        case "Ephemeridsadd":
            Ephemeridsadd();
            break;

        case "Ephemerids":
            Ephemerids();
            break;

        default:
           Ephemerids();
           break;
       }
   }
}
?>