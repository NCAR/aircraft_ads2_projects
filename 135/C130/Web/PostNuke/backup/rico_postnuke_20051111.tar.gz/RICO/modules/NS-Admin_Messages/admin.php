<?php
// File: $Id: admin.php,v 1.22 2004/07/05 10:40:05 landseer Exp $ $Name: HEAD $
// ----------------------------------------------------------------------
// PostNuke Content Management System
// Copyright (C) 2001 by the PostNuke Development Team.
// http://www.postnuke.com/
// ----------------------------------------------------------------------
// Based on:
// PHP-NUKE Web Portal System - http://phpnuke.org/
// Thatware - http://thatware.org/
// ----------------------------------------------------------------------
// LICENSE
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License (GPL)
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// To read the license please visit http://www.gnu.org/copyleft/gpl.html
// ----------------------------------------------------------------------
// Original Author of file: 
// Purpose of file: 
// ----------------------------------------------------------------------

if (!eregi("admin.php", $_SERVER['PHP_SELF'])) { 
	die ("Access Denied"); 
}
$ModName = $module;

modules_get_language();
modules_get_manual();

/*********************************************************/
/* Messages Functions                                    */
/*********************************************************/

function MsgDeactive()
{
    $mid = (int)pnVarCleanFromInput('mid');

    $dbconn =& pnDBGetConn(true);
    $pntable =& pnDBGetTables();

    $column = &$pntable['message_column'];
    $result =& $dbconn->Execute("SELECT $column[title]
                              FROM $pntable[message]
                              WHERE $column[mid] = '" . (int)pnVarPrepForStore($mid)."'");
    if($dbconn->ErrorNo() != 0) {
        error_log("Error: " . $dbconn->ErrorMsg());
    }
    list($title) = $result->fields;
    if (!pnSecAuthAction(0, 'Messages::', "$title::$mid", ACCESS_EDIT)) {
        include 'header.php';
        echo _MESSAGESDEACTIVATENOAUTH;
        include 'footer.php';
        return;
    }

    $result =& $dbconn->Execute("UPDATE $pntable[message] 
                              SET $column[active]=0 
                              WHERE $column[mid]='" . (int)pnVarPrepForStore($mid)."'");
    if($dbconn->ErrorNo() != 0) {
        error_log("Error: " . $dbconn->ErrorMsg());
    }
    pnRedirect('admin.php?module='.$GLOBALS['module'].'&op=messages');
}

function messages()
{
    //$bgcolor1 = $GLOBALS["bgcolor1"];
    //$bgcolor2 = $GLOBALS["bgcolor2"];

    $authid = pnSecGenAuthKey();

    $dbconn =& pnDBGetConn(true);
    $pntable =& pnDBGetTables();

    include ("header.php");
    $lang = languagelist();
    GraphicAdmin();
    OpenTable();
    echo "<div style=\"text-align:center\"><span class=\"pn-title\"><strong>"._MESSAGESADMIN."</strong></span></div>";
    CloseTable();

    // Current messages
    if (pnSecAuthAction(0, 'Messages::', '::', ACCESS_EDIT)) {
        OpenTable();
        echo "<div style=\"text-align:center\"><span class=\"pn-title\"><strong>"._ALLMESSAGES."</strong></span><br /><br /><table border=\"1\" width=\"100%\" style=\"background-color:".$GLOBALS["bgcolor1"]."\"><tr>"
            ."<td style=\"background-color:".$GLOBALS["bgcolor2"]."\" align=\"center\"><strong><span class=\"pn-title\">"._ID."</span></strong></td>"
            ."<td style=\"background-color:".$GLOBALS["bgcolor2"]."\" align=\"center\"><strong><span class=\"pn-title\">"._TITLE."</span></strong></td>"
            ."<td style=\"background-color:".$GLOBALS["bgcolor2"]."\" align=\"center\">&nbsp;<strong><span class=\"pn-title\">"._LANGUAGE."</span></strong>&nbsp;</td>"
            ."<td style=\"background-color:".$GLOBALS["bgcolor2"]."\" align=\"center\">&nbsp;<strong><span class=\"pn-title\">"._VIEW."</span></strong>&nbsp;</td>"
            ."<td style=\"background-color:".$GLOBALS["bgcolor2"]."\" align=\"center\">&nbsp;<strong><span class=\"pn-title\">"._ACTIVE."</span></strong>&nbsp;</td>"
            ."<td style=\"background-color:".$GLOBALS["bgcolor2"]."\" align=\"center\">&nbsp;<strong><span class=\"pn-title\">"._FUNCTIONS."</span></strong>&nbsp;</td></tr>";
        $column = &$pntable['message_column'];
        $result =& $dbconn->Execute("SELECT $column[mid],
                                           $column[title],
                                           $column[content],
                                           $column[date],
                                           $column[expire],
                                           $column[active],
                                           $column[view],
                                           $column[mlanguage] 
                                    FROM $pntable[message] ");
        while(list($mid, $title, $content, $mdate, $expire, $active, $view, $mlanguage) = $result->fields) {

            $result->MoveNext();

            if (!pnSecAuthAction(0, 'Messages::', "$title::$mid", ACCESS_EDIT)) {
                continue;
            }
            if ($active == 1) {
                $mactive = ""._YES."";
            } elseif ($active == 0) {
                $mactive = ""._NO."";
            }
            switch ($view) {
                case "1":
                    $mview = ""._MVALL."";
                    break;
                case "2":
                    $mview = ""._MVUSERS."";
                    break;
                case "3":
                    $mview = ""._MVANON."";
                    break;
                case "4":
                    $mview = ""._MVADMIN."";
                    break;
            }
            if ($mlanguage == "") {
                $mlanguage = ""._ALL."";
            }
            echo "<tr><td align=\"right\"><span class=\"pn-normal\"><strong>" . pnVarPrepForDisplay($mid) . "</strong>"
                ."</span></td><td align=\"left\"><span class=\"pn-normal\"><strong>" . pnVarPrepForDisplay($title) . "</strong>"
                ."</span></td><td align=\"center\"><span class=\"pn-normal\">" . pnVarPrepForDisplay($mlanguage)
                ."</span></td><td align=\"center\"><span class=\"pn-normal\">" . pnVarPrepForDisplay($mview)
                ."</span></td><td align=\"center\"><span class=\"pn-normal\">" . pnVarPrepForDisplay($mactive)
                ."</span></td><td align=\"right\"><span class=\"pn-normal\">(<a href=\"admin.php?module=".$GLOBALS['module']."&amp;op=editmsg&amp;mid=$mid&amp;authid=$authid\">"._EDIT."</a></span>";
            if (pnSecAuthAction(0, 'Messages::', "$title::$mid", ACCESS_DELETE)) {
                echo "-<a href=\"admin.php?module=".$GLOBALS['module']
                ."&amp;op=deletemsg&amp;mid=$mid\">"._DELETE."</a>)";
            } else {
                echo ")";
            }
            echo "</td></tr>";
        }
        echo "</table></div><br />";
    }
    CloseTable();

    // New message
    if (pnSecAuthAction(0, 'Messages::', '::', ACCESS_ADD)) {
        OpenTable();
        echo "<div style=\"text-align:center\"><span class=\"pn-title\"><strong>"._ADDMSG."</strong></span></div><br />";
        echo "<form action=\"admin.php\" method=\"post\"><div>";

        echo "<strong><span class=\"pn-normal\">"._MESSAGETITLE.":</span></strong><br />"
            ."<input type=\"text\" name=\"add_title\" value=\"\" size=\"50\" maxlength=\"100\" /><br /><br />"
            ."<strong><span class=\"pn-normal\">"._MESSAGECONTENT.":</span></strong><br />"
            ."<textarea name=\"add_content\" rows=\"10\" cols=\"80\"></textarea><br /><br /><span class=\"pn-normal\">"
            .'<strong>'._LANGUAGE.': </strong></span>'
            .'<select name="add_mlanguage" size="1">'
            .'<option value="">'._ALL.'</option>';

        $sel_lang[pnUserGetLang()] = ' selected="selected"';
        $handle = opendir('language');
        while ($f = readdir($handle)) {
            if (is_dir("language/$f") && (!empty($lang[$f]))) {
                $langlist[$f] = $lang[$f];
            }
        }
        asort($langlist);
        //  a bit ugly, but it works in E_ALL conditions (Andy Varganov)
        foreach ($langlist as $k=>$v){
        echo '<option value="'.$k.'"';
        if (isset($sel_lang[$k])) echo ' selected="selected"';
        echo '>'. $v . '</option>';
        }
        print '</select><br /><br />';
        $now = time();
        //print '<strong>'._EXPIRATION.':</strong> <select name="add_expire">'
            //."<option value=\"86400\" >1 "._DAY."</option>"
            //."<option value=\"172800\" >2 "._DAYS."</option>"
            //."<option value=\"432000\" >5 "._DAYS."</option>"
            //."<option value=\"1296000\" >15 "._DAYS."</option>"
            //."<option value=\"2592000\" >30 "._DAYS."</option>"
            //."<option value=\"0\" >"._UNLIMITED."</option>"
            //."</select><br /><br />"
        print "<span class=\"pn-normal\"><strong>"._ACTIVE."?</strong> <input type=\"radio\" name=\"add_active\" value=\"1\" checked=\"checked\" />"._YES." "
            ."<input type=\"radio\" name=\"add_active\" value=\"0\" />"._NO."</span>";
        echo "<br /><br /><strong><span class=\"pn-normal\">"._VIEWPRIV."</span></strong> <select name=\"add_view\">"
            ."<option value=\"1\" >"._MVALL."</option>"
            ."<option value=\"2\" >"._MVUSERS."</option>"
            ."<option value=\"3\" >"._MVANON."</option>"
            ."<option value=\"4\" >"._MVADMIN."</option>"
            ."</select><br /><br />"
            ."<input type=\"hidden\" name=\"module\" value=\"".$GLOBALS['module']."\" />"
            ."<input type=\"hidden\" name=\"op\" value=\"addmsg\" />"
            ."<input type=\"hidden\" name=\"add_mdate\" value=\"$now\" />"
	    ."<input type=\"hidden\" name=\"authid\" value=\"" . pnSecGenAuthKey() . "\" />"
            ."<input type=\"submit\" value=\""._ADDMSG."\" />"
            ."</div></form>";
        CloseTable();
    }
    include ("footer.php");
}

function editmsg()
{
    list($mid, $authid) = pnVarCleanFromInput('mid', 'authid');

    $dbconn =& pnDBGetConn(true);
    $pntable =& pnDBGetTables();

    include ("header.php");

    GraphicAdmin();
    OpenTable();
    echo "<div style=\"text-align:center\"><span class=\"pn-title\"><strong>"._MESSAGESADMIN."</strong></span></div>";
    CloseTable();

    $column = &$pntable['message_column'];
    $result =& $dbconn->Execute("SELECT $column[title],
                                       $column[content],
                                       $column[date],
                                       $column[expire],
                                       $column[active],
                                       $column[view],
                                       $column[mlanguage] 
                                FROM $pntable[message]
                                WHERE $column[mid]= '" . pnVarPrepForStore($mid)."'");
    list($title, $content, $mdate, $expire, $active, $view, $mlanguage) = $result->fields;

    if (!pnSecAuthAction(0, 'Messages::', "$title::$mid", ACCESS_EDIT)) {
        echo _MESSAGESEDITNOAUTH;
        include 'footer.php';
        return;
    }
    OpenTable();
    echo "<div style=\"text-align:center\"><span class=\"pn-title\"><strong>"._EDITMSG."</strong></span></div>";
    $asel1 = '';
    $asel2 = '';
    if ($active == 1) {
        $asel1 = 'checked="checked"';
    } elseif ($active == 0) {
        $asel2 = 'checked="checked"';
    }

    $sel1 = '';
    $sel2 = '';
    $sel3 = '';
    $sel4 = '';
    if ($view == 1) {
        $sel1 = 'selected="selected"';
    } elseif ($view == 2) {
        $sel2 = 'selected="selected"';
    } elseif ($view == 3) {
        $sel3 = 'selected="selected"';
    } elseif ($view == 4) {
        $sel4 = 'selected="selected"';
    }

    $esel1 = '';
    $esel2 = '';
    $esel3 = '';
    $esel4 = '';
    $esel5 = '';
    $esel6 = '';
    if ($expire == 86400) {
        $esel1 = 'selected="selected"';
    } elseif ($expire == 172800) {
        $esel2 = 'selected="selected"';
    } elseif ($expire == 432000) {
        $esel3 = 'selected="selected"';
    } elseif ($expire == 1296000) {
        $esel4 = 'selected="selected"';
    } elseif ($expire == 2592000) {
        $esel5 = 'selected="selected"';
    } elseif ($expire == 0) {
        $esel6 = 'selected="selected"';
    }

    echo "<form action=\"admin.php\" method=\"post\"><div>";

    echo "<strong><span class=\"pn-normal\">"._MESSAGETITLE.":</span></strong><br />"
    ."<input type=\"text\" name=\"title\" value=\"" . pnVarPrepForDisplay($title) . "\" size=\"50\" maxlength=\"100\" /><br /><br />"
    ."<strong><span class=\"pn-normal\">"._MESSAGECONTENT.":</span></strong><br />"
    ."<textarea name=\"content\" rows=\"10\" cols=\"80\">" . pnVarPrepForDisplay($content) . "</textarea><br /><br /><span class=\"pn-normal\">"
    .'<strong>'._LANGUAGE.': </strong></span>'
    .'<select name="mlanguage" size="1">'
    .'<option value="">'._ALL.'</option>'
    ;
    $lang = languagelist();
    $sel_lang[$mlanguage] = ' selected="selected"';
	$handle = opendir('language');
	while ($f = readdir($handle)) {
		if (is_dir("language/$f") && (!empty($lang[$f]))) {
			$langlist[$f] = $lang[$f];
		}
	}
	asort($langlist);
	//  a bit ugly, but it works in E_ALL conditions (Andy Varganov)
	foreach ($langlist as $k=>$v){
		echo '<option value="'.$k.'"';
		if (isset($sel_lang[$k])) echo ' selected="selected"';
		echo '>'. $v . '</option>';
	}
    print '</select><br /><br />'
    //."<strong>"._EXPIRATION.":</strong> <select name=\"expire\">"
    //."<option name=\"expire\" value=\"86400\" $esel1>1 "._DAY."</option>"
    //."<option name=\"expire\" value=\"172800\" $esel2>2 "._DAYS."</option>"
    //."<option name=\"expire\" value=\"432000\" $esel3>5 "._DAYS."</option>"
    //."<option name=\"expire\" value=\"1296000\" $esel4>15 "._DAYS."</option>"
    //."<option name=\"expire\" value=\"2592000\" $esel5>30 "._DAYS."</option>"
    //."<option name=\"expire\" value=\"0\" $esel6>"._UNLIMITED."</option>"
    //."</select><br /><br />"
    ."<span class=\"pn-normal\"><strong>"._ACTIVE."?</strong> <input type=\"radio\" name=\"active\" value=\"1\" $asel1 />"._YES." "
    ."<input type=\"radio\" name=\"active\" value=\"0\" $asel2 />"._NO."</span>";
    if ($active == 1) {
        echo "<br /><br /><span class=\"pn-normal\"><strong>"._CHANGEDATE."</strong>"
            ."<input type=\"radio\" name=\"chng_date\" value=\"1\" />"._YES." "
            ."<input type=\"radio\" name=\"chng_date\" value=\"0\" checked=\"checked\" />"._NO."</span><br /><br />";
    } elseif ($active == 0) {
        echo "<br /><span class=\"pn-sub\">"._IFYOUACTIVE."</span><br /><br />"
            ."<input type=\"hidden\" name=\"chng_date\" value=\"1\" />";
    }
    echo "<span class=\"pn-normal\"><strong>"._VIEWPRIV."</strong> <select name=\"view\">"
        ."<option value=\"1\" $sel1>"._MVALL."</option>"
        ."<option value=\"2\" $sel2>"._MVUSERS."</option>"
        ."<option value=\"3\" $sel3>"._MVANON."</option>"
        ."<option value=\"4\" $sel4>"._MVADMIN."</option>"
        ."</select></span><br /><br />"
        ."<input type=\"hidden\" name=\"mdate\" value=\"$mdate\" />"
        ."<input type=\"hidden\" name=\"mid\" value=\"$mid\" />"
        ."<input type=\"hidden\" name=\"module\" value=\"".$GLOBALS['module']."\" />"
        ."<input type=\"hidden\" name=\"op\" value=\"savemsg\" />"
	."<input type=\"hidden\" name=\"authid\" value=\"" . pnSecGenAuthKey() . "\" />"
        ."<input type=\"submit\" value=\""._SAVECHANGES."\" />"
        ."</div></form>";
    CloseTable();
    include ("footer.php");
}

function savemsg()
{
    if (!pnSecConfirmAuthKey()) {
        include 'header.php';
        echo _BADAUTHKEY;
        include 'footer.php';
        exit;
    }
    list($mid,
         $title,
         $content,
         $mdate,
         $expire,
         $active,
         $view,
         $chng_date,
         $mlanguage) = pnVarCleanFromInput('mid',
                                           'title',
                                           'content',
                                           'mdate',
                                           'expire',
                                           'active',
                                           'view',
                                           'chng_date',
                                           'mlanguage');

    $dbconn =& pnDBGetConn(true);
    $pntable =& pnDBGetTables();

    if (!pnSecAuthAction(0, 'Messages::', "$title::$mid", ACCESS_EDIT)) {
        include 'header.php';
        echo _MESSAGESEDITNOAUTH;
        include 'footer.php';
        return;
    }
    
    if ($chng_date == 1) {
        $newdate = time();
    } elseif ($chng_date == 0) {
        $newdate = $mdate;
    }

    // Work out expiry of message
    if ($expire  != 0) {
        $expire += time();
    }
    //$column[expire]=" . pnVarPrepForStore($expire) . ", -- Removed as a temp fix
    $column = &$pntable['message_column'];
    $sql = "UPDATE $pntable[message] 
            SET $column[title]='" . pnVarPrepForStore($title) . "', 
                $column[content]='" . pnVarPrepForStore($content) . "',
                $column[date]='" . pnVarPrepForStore($newdate) . "',
                $column[expire] = '0',
                $column[active]=" . pnVarPrepForStore($active) . ",
                $column[view]=" . pnVarPrepForStore($view) . ",
                $column[mlanguage]='" . pnVarPrepForStore($mlanguage) . "'
            WHERE $column[mid]='" . pnVarPrepForStore($mid)."'";
    $result =& $dbconn->Execute($sql);
    if($dbconn->ErrorNo() != 0) {
        error_log("Error: " . $dbconn->ErrorMsg());
    }
    pnRedirect('admin.php?module='.$GLOBALS['module'].'&op=messages');
}

function addmsg()
{
    if (!pnSecConfirmAuthKey()) {
        include 'header.php';
        echo _BADAUTHKEY;
        include 'footer.php';
        exit;
    }
    list($title,
         $content,
         $mdate,
         $expire,
         $active,
         $view,
         $mlanguage) = pnVarCleanFromInput('add_title',
                                           'add_content',
                                           'add_mdate',
                                           'add_expire',
                                           'add_active',
                                           'add_view',
                                           'add_mlanguage');

    $dbconn =& pnDBGetConn(true);
    $pntable =& pnDBGetTables();

    if (!pnSecAuthAction(0, 'Messages::', "$title::", ACCESS_ADD)) {
        include 'header.php';
        echo _MESSAGESADDNOAUTH;
        include 'footer.php';
        return;
    }
    
    // Work out expiry of message
    if ($expire  != 0) {
        $expire += time();
    }
    //" . pnVarPrepForStore($expire) . ", -- Removed as a temp fix
    $column = &$pntable['message_column'];
    $nextid = $dbconn->GenId($pntable['message']);
    $sql = "INSERT INTO $pntable[message]
              ($column[mid],
               $column[title],
               $column[content],
               $column[date],
               $column[expire],
               $column[active],
               $column[view],
               $column[mlanguage])
            VALUES
              (" . pnVarPrepForStore($nextid) . ",
              '" . pnVarPrepForStore($title) . "',
              '" . pnVarPrepForStore($content) . "',
              '" . pnVarPrepForStore($mdate) . "',
              0,
              " . pnVarPrepForStore($active) . ",
              " . pnVarPrepForStore($view) . ",
              '" . pnVarPrepForStore($mlanguage) . "')";
    $result =& $dbconn->Execute($sql);
    if($dbconn->ErrorNo() != 0) {
        error_log("Error: " . $dbconn->ErrorMsg());
        echo $dbconn->ErrorNo(). ": ".$dbconn->ErrorMsg(). "<br />";
        exit();
    }

    pnRedirect('admin.php?module='.$GLOBALS['module'].'&op=messages');
}

function deletemsg()
{
    list($mid,
         $ok) = pnVarCleanFromInput('mid',
                                    'ok');

    if (!isset($ok)) {
        $ok = 0;
    }

    $dbconn =& pnDBGetConn(true);
    $pntable =& pnDBGetTables();

    $column = &$pntable['message_column'];
    $result =& $dbconn->Execute("SELECT $column[title]
                                FROM $pntable[message]
                                WHERE $column[mid] = '" . pnVarPrepForStore($mid)."'");
    list($title) = $result->fields;
    $result->Close();
    if (!pnSecAuthAction(0, 'Messages::', "$title::$mid", ACCESS_DELETE)) {
        include 'header.php';
        echo _MESSAGESDELNOAUTH;
        include 'footer.php';
        return;
    }
    if ($ok) {
        if (!pnSecConfirmAuthKey()) {
            include 'header.php';
            echo _BADAUTHKEY;
            include 'footer.php';
            return;
        }
            
        $result =& $dbconn->Execute("DELETE FROM $pntable[message]
                                    WHERE $column[mid]='" . pnVarPrepForStore($mid)."'");
        if($dbconn->ErrorNo() != 0) {
            error_log("Error: " . $dbconn->ErrorMsg());
            echo $dbconn->ErrorNo(). ": ".$dbconn->ErrorMsg(). "<br />";
            return;
        }

        pnRedirect('admin.php?module='.$GLOBALS['module'].'&op=messages');
    } else {
        include("header.php");
        GraphicAdmin();
        OpenTable();
        echo "<div style=\"text-align:center\"><span class=\"pn-title\"><strong>"._MESSAGESADMIN."</strong></span></div>";
        CloseTable();

	OpenTable();
        echo "<div style=\"text-align:center\"><span class=\"pn-normal\">"._REMOVEMSG." <strong>$mid</strong></span>";
        echo "<table><tr><td>\n";
        echo "<form action=\"admin.php?module=".$GLOBALS['module']."&amp;op=messages\" method=\"post\"><div>";
        echo "<input type=\"submit\" value=\"".pnVarPrepForDisplay(_NO)."\" class=\"pn-normal\" style=\"text-align:center\" />";
        echo "<input type=\"hidden\" name=\"postnuke\" value=\"postnuke\" /></div></form>\n";
//        echo my_Text_Form("admin.php?module=".$GLOBALS['module']."&amp;op=messages", _NO);
        echo "</td><td>\n";
        echo "<form action=\"admin.php?module=".$GLOBALS['module']."&amp;op=deletemsg&amp;mid=$mid&amp;ok=1&amp;authid=".pnSecGenAuthKey()."\" method=\"post\"><div>";
        echo "<input type=\"submit\" value=\"".pnVarPrepForDisplay(_YES)."\" class=\"pn-normal\" style=\"text-align:center\" />";
        echo "<input type=\"hidden\" name=\"postnuke\" value=\"postnuke\" /></div></form>\n";
//        echo my_Text_Form("admin.php?module=".$GLOBALS['module']."&amp;op=deletemsg&amp;mid=$mid&amp;ok=1&amp;authid=" . pnSecGenAuthKey(), _YES);
        echo "</td></tr></table>\n";
        echo "</div>\n";
        CloseTable();
        include("footer.php");
    }
}

function admin_messages_admin_main($var)
{
   $op = pnVarCleanFromInput('op');

   if (!(pnSecAuthAction(0, 'Messages::', '::', ACCESS_EDIT))) {
      include 'header.php';
       echo _MESSAGESNOAUTH;
       include 'footer.php';
   } else {
       switch ($op){

        case "messages":
            messages();
            break;

        case "editmsg":
            
            editmsg();
            break;

        case "addmsg":
            addmsg();
            break;

        case "deletemsg":
            deletemsg();
            break;

        case "savemsg":
            savemsg();
            break;
            
        default:
            messages();
            break;
       }
   }
}

?>