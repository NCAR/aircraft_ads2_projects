<?php
// ----------------------------------------------------------------------
// PostNuke Content Management System
// Copyright (C) 2002 by the PostNuke Development Team.
// http://www.postnuke.com/
// ----------------------------------------------------------------------
// Based on:
// PHP-NUKE Web Portal System - http://phpnuke.org/
// Thatware - http://thatware.org/
// ----------------------------------------------------------------------
// LICENSE
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License (GPL)
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// To read the license please visit http://www.gnu.org/copyleft/gpl.html
// ----------------------------------------------------------------------
// Original Author of file: Brian Bain
// Purpose of file:  Censor administration display functions
// ----------------------------------------------------------------------

/**
 * @package PostNuke_Modules
 * @subpackage PostNuke_typetool
 * @license http://www.gnu.org/copyleft/gpl.html
*/

/**
 * Update TypeTool config
 * @author Andreas Krapohl
 * @version
 * @param int $args['tt_enable'] typetool on or off
 * @param string $args['tt_language'] language for typetool userinterface
 * @return bool true if succesful, false otherwise
 */
function typetool_adminapi_update($args)
{
    extract($args);
    if (!pnSecAuthAction(0, 'typetool::', "::", ACCESS_ADMIN)) {
        pnSessionSetVar('errormsg', _BADAUTHKEY);
        return false;
    }

    if(!pnModSetVar('typetool', 'enable', $tt_enable)){
        pnSessionSetVar('errormsg', _TYPETOOLNOCONFCHANGE);
        return false;
    }

    if(!pnModSetVar('typetool', 'language', $tt_language)){
        pnSessionSetVar('errormsg', _TYPETOOLNOCONFCHANGE);
        return false;
    }
    
    return true;
}
?>