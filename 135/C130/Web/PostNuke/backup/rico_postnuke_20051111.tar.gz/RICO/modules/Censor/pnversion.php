<?php
$modversion['name'] = 'Censor';
$modversion['version'] = '1.0';
$modversion['description'] = 'Site Censorship Control';
$modversion['official'] = 1;
$modversion['author'] = 'Brian Bain';
$modversion['contact'] = 'http://tefen.net';
$modversion['admin'] = 1;
$modversion['securityschema'] = array('Censor::' => ':CensorList:', 'Censor::' => ':CensorMode:');
?>