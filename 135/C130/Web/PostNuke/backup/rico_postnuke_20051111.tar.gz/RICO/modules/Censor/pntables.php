<?php
function template_pntables()
{
    return array();
}

?>