-- MySQL dump 8.22
--
-- Host: localhost    Database: ideas3-Phoenix
---------------------------------------------------------
-- Server version	3.23.54

--
-- Table structure for table 'nuke_autonews'
--

CREATE TABLE nuke_autonews (
  pn_anid int(11) NOT NULL auto_increment,
  pn_catid int(11) NOT NULL default '0',
  pn_aid varchar(30) NOT NULL default '',
  pn_title varchar(80) NOT NULL default '',
  pn_time varchar(19) NOT NULL default '',
  pn_hometext text NOT NULL,
  pn_bodytext text NOT NULL,
  pn_topic tinyint(4) NOT NULL default '1',
  pn_informant varchar(20) NOT NULL default '',
  pn_notes text NOT NULL,
  pn_ihome tinyint(1) NOT NULL default '0',
  pn_language varchar(30) NOT NULL default '',
  pn_withcomm int(1) NOT NULL default '0',
  PRIMARY KEY  (pn_anid)
) TYPE=MyISAM;

--
-- Dumping data for table 'nuke_autonews'
--



--
-- Table structure for table 'nuke_banner'
--

CREATE TABLE nuke_banner (
  pn_bid int(11) NOT NULL auto_increment,
  pn_cid int(11) NOT NULL default '0',
  pn_type char(2) NOT NULL default '0',
  pn_imptotal int(11) NOT NULL default '0',
  pn_impmade int(11) NOT NULL default '0',
  pn_clicks int(11) NOT NULL default '0',
  pn_imageurl varchar(255) NOT NULL default '',
  pn_clickurl varchar(255) NOT NULL default '',
  pn_date datetime default NULL,
  PRIMARY KEY  (pn_bid)
) TYPE=MyISAM;

--
-- Dumping data for table 'nuke_banner'
--



--
-- Table structure for table 'nuke_bannerclient'
--

CREATE TABLE nuke_bannerclient (
  pn_cid int(11) NOT NULL auto_increment,
  pn_name varchar(60) NOT NULL default '',
  pn_contact varchar(60) NOT NULL default '',
  pn_email varchar(60) NOT NULL default '',
  pn_login varchar(10) NOT NULL default '',
  pn_passwd varchar(10) NOT NULL default '',
  pn_extrainfo text NOT NULL,
  PRIMARY KEY  (pn_cid)
) TYPE=MyISAM;

--
-- Dumping data for table 'nuke_bannerclient'
--



--
-- Table structure for table 'nuke_bannerfinish'
--

CREATE TABLE nuke_bannerfinish (
  pn_bid int(11) NOT NULL auto_increment,
  pn_cid int(11) NOT NULL default '0',
  pn_impressions int(11) NOT NULL default '0',
  pn_clicks int(11) NOT NULL default '0',
  pn_datestart datetime default NULL,
  pn_dateend datetime default NULL,
  PRIMARY KEY  (pn_bid)
) TYPE=MyISAM;

--
-- Dumping data for table 'nuke_bannerfinish'
--



--
-- Table structure for table 'nuke_blocks'
--

CREATE TABLE nuke_blocks (
  pn_bid int(11) unsigned NOT NULL auto_increment,
  pn_bkey varchar(255) NOT NULL default '',
  pn_title varchar(255) NOT NULL default '',
  pn_content text NOT NULL,
  pn_url varchar(254) NOT NULL default '',
  pn_mid int(11) unsigned NOT NULL default '0',
  pn_position char(1) NOT NULL default 'l',
  pn_weight decimal(10,1) NOT NULL default '0.0',
  pn_active tinyint(3) unsigned NOT NULL default '1',
  pn_refresh int(11) unsigned NOT NULL default '0',
  pn_last_update timestamp(14) NOT NULL,
  pn_language varchar(30) NOT NULL default '',
  PRIMARY KEY  (pn_bid)
) TYPE=MyISAM;

--
-- Dumping data for table 'nuke_blocks'
--


INSERT INTO nuke_blocks VALUES (1,'menu','Main Menu','a:4:{s:5:\"style\";s:1:\"1\";s:14:\"displaywaiting\";i:0;s:14:\"displaymodules\";i:0;s:7:\"content\";s:1569:\"|General|LINESPLITindex.php|Home|Back to the home page.LINESPLITuser.php|My Account|Administer your personal account.LINESPLITadmin.php|Administration|Administer your PostNuked site.LINESPLIT[Search]|Site Search|Search our website.LINESPLITuser.php?module=NS-User&op=logout|Logout|Logout of your account.LINESPLIT|Dates and News|LINESPLIT[News]|What\'s New|Latest News on this site.LINESPLIT[Submit_News]|Submit News|Submit a news article.LINESPLITindex.php?module=PostCalendar&func=view&tplview=&viewtype=month&pc_username=&pc_category=&pc_topic=&print=|Calendar|View the CalendarLINESPLITindex.php?module=PostCalendar&func=submit&tplview=|Submit Calendar Event|Submit a new activity to the CalendarLINESPLITindex.php?module=PostCalendar&func=search|Search the Calendar|Search the CalendarLINESPLIT|Collaboration|LINESPLIT[pnCGIIRC]|Online Chat|Enter the IDEAS-3 Chat room (entries are time-stamped now)LINESPLIT[phpBB_14]|Discussion Forums|Enter the forums.LINESPLITmodules.php?op=modload&name=PostWrap&file=index&page=http://www.atd.ucar.edu/mailman/listinfo/ideas3|Email List|Moderated IDEAS3 email listLINESPLITmodules.php?op=modload&name=PostWrap&file=index&page=http://www.atd.ucar.edu/pipermail/ideas3/|View Email Postings|View Archived IDEAS3 email postingsLINESPLITindex.php?module=ew_filemanager&type=admin&func=manager|File Exchange|The file exchangeLINESPLIT|Help and Resources|LINESPLIT[FAQ]|FAQ|Frequently Asked QuestionsLINESPLIT[Members_List]|Web Site Members|Listing of registered users on this site.LINESPLIT[Web_Links]|Web Links|Links to other sites.\";}','',0,'l',7.0,1,1800,20030908134430,'');
INSERT INTO nuke_blocks VALUES (18,'content','','','',47,'r',6.0,0,3600,20030716101157,'eng');
INSERT INTO nuke_blocks VALUES (2,'menu','Incoming','style:=1\ndisplaymodules:=0\ndisplaywaiting:=1\ncontent:=','',0,'l',5.0,1,0,20030729113639,'');
INSERT INTO nuke_blocks VALUES (3,'online','Who\'s Online','','',0,'r',8.0,1,1800,20030716101157,'');
INSERT INTO nuke_blocks VALUES (4,'stories','Stories Summary','a:4:{s:5:\"limit\";s:2:\"10\";s:8:\"category\";s:2:\"-1\";s:5:\"topic\";s:3:\"-1\\\";s:11:\"storiestype\";s:1:\"2\";}','',0,'r',14.0,1,1800,20030724162832,'');
INSERT INTO nuke_blocks VALUES (5,'user','Users Block','Put anything you want here','',0,'l',4.0,1,0,20030729113637,'');
INSERT INTO nuke_blocks VALUES (6,'search','Search Box','','',0,'l',16.0,0,0,20030729113544,'');
INSERT INTO nuke_blocks VALUES (7,'ephem','Ephemerids','','',0,'l',17.0,0,0,20030729113544,'');
INSERT INTO nuke_blocks VALUES (8,'thelang','Languages','','',0,'r',11.0,0,1800,20030716101157,'');
INSERT INTO nuke_blocks VALUES (9,'category','Categories Menu','','',0,'r',7.0,0,0,20030807163017,'');
INSERT INTO nuke_blocks VALUES (10,'random','Random Headlines','','',0,'r',9.0,0,0,20030716101157,'');
INSERT INTO nuke_blocks VALUES (11,'poll','Poll','','',0,'r',10.0,0,0,20030716101157,'');
INSERT INTO nuke_blocks VALUES (12,'big','Today\'s Big Story','','',0,'r',13.0,1,1800,20030724162821,'');
INSERT INTO nuke_blocks VALUES (13,'login','User\'s Login','','',0,'l',6.0,1,1800,20030729113641,'');
INSERT INTO nuke_blocks VALUES (14,'past','Past Articles','','',0,'r',12.0,1,0,20030716101157,'');
INSERT INTO nuke_blocks VALUES (15,'messages','Administration Messages','','',8,'c',1.0,1,1800,20030716101029,'');
INSERT INTO nuke_blocks VALUES (19,'jsmenu','Javascript','a:35:{s:8:\"jmbwidth\";s:0:\"\";s:10:\"lowbgcolor\";s:7:\"#DEE4EB\";s:9:\"hibgcolor\";s:7:\"#9CA2B6\";s:12:\"fontlowcolor\";s:7:\"#000000\";s:11:\"fonthicolor\";s:7:\"#FFFFFF\";s:11:\"bordercolor\";s:7:\"#000000\";s:15:\"borderwidthmain\";s:1:\"0\";s:14:\"borderwidthsub\";s:1:\"0\";s:13:\"borderbtwmain\";i:0;s:12:\"borderbtwsub\";i:0;s:13:\"menumaxheight\";s:2:\"12\";s:12:\"menumaxwidth\";s:3:\"100\";s:10:\"fontfamily\";s:6:\"Tahoma\";s:8:\"fontsize\";s:1:\"8\";s:8:\"fontbold\";i:0;s:10:\"fontitalic\";i:0;s:16:\"menutextcentered\";s:4:\"left\";s:12:\"menucentered\";s:4:\"left\";s:16:\"menuvertcentered\";s:3:\"top\";s:11:\"targetlocid\";s:9:\"jsmenu_19\";s:8:\"starttop\";s:1:\"0\";s:9:\"startleft\";s:1:\"0\";s:10:\"vercorrect\";s:1:\"0\";s:10:\"horcorrect\";s:1:\"0\";s:10:\"toppadding\";s:1:\"0\";s:11:\"leftpadding\";s:1:\"6\";s:11:\"unfolddelay\";s:3:\"100\";s:10:\"menuorient\";s:1:\"0\";s:14:\"disappeardelay\";s:4:\"1000\";s:8:\"basehref\";s:0:\"\";s:13:\"unfoldonclick\";i:0;s:10:\"msie6slide\";b:0;s:11:\"msie6shadow\";b:0;s:12:\"msie6opacity\";s:3:\"100\";s:13:\"buildondemand\";i:0;}','',47,'r',5.0,0,3600,20030716101157,'eng');
INSERT INTO nuke_blocks VALUES (17,'phplive','Live support','company:=Demo\nid:=3','',0,'l',18.0,0,0,20030729113544,'');
INSERT INTO nuke_blocks VALUES (20,'menu','','a:1:{s:7:\"dynmenu\";i:0;}','',47,'r',4.0,0,3600,20030716101157,'eng');
INSERT INTO nuke_blocks VALUES (21,'topic','','','',0,'r',3.0,0,3600,20030716101157,'eng');
INSERT INTO nuke_blocks VALUES (22,'banners','','','',0,'l',15.0,0,3600,20030729113544,'eng');
INSERT INTO nuke_blocks VALUES (23,'calendar','calendar','a:6:{s:14:\"pcbshowsslinks\";s:1:\"1\";s:14:\"pcbeventsrange\";s:1:\"1\";s:13:\"pcbnextevents\";s:1:\"1\";s:16:\"pcbeventoverview\";s:1:\"1\";s:14:\"pcbeventslimit\";s:2:\"10\";s:15:\"pcbshowcalendar\";s:1:\"1\";}','',49,'r',2.0,1,3600,20030825165822,'eng');
INSERT INTO nuke_blocks VALUES (24,'finclude','','','',0,'r',1.0,0,3600,20030716101029,'eng');
INSERT INTO nuke_blocks VALUES (25,'category','','','',0,'l',14.0,0,3600,20030729113544,'eng');
INSERT INTO nuke_blocks VALUES (26,'finclude','','','|0',0,'l',13.0,0,3600,20030729113544,'eng');
INSERT INTO nuke_blocks VALUES (28,'sms','','','',0,'l',12.0,0,3600,20030729113544,'eng');
INSERT INTO nuke_blocks VALUES (29,'button','','','',0,'l',9.0,0,3600,20030729113645,'eng');
INSERT INTO nuke_blocks VALUES (30,'pnForum_Centerblock','Forum','a:3:{s:7:\"shorten\";s:1:\"2\";s:6:\"option\";s:1:\"2\";s:7:\"postmax\";s:1:\"5\";}','',58,'r',15.0,1,3600,20030825165833,'eng');
INSERT INTO nuke_blocks VALUES (31,'pnForum_Statsblock','','a:6:{s:7:\"shorten\";s:1:\"1\";s:9:\"postermax\";s:1:\"3\";s:6:\"option\";s:1:\"1\";s:7:\"stat_on\";s:1:\"1\";s:7:\"postmax\";s:1:\"5\";s:8:\"forummax\";s:1:\"3\";}','',58,'l',2.0,0,3600,20030729113634,'eng');
INSERT INTO nuke_blocks VALUES (33,'category','','','',0,'l',3.0,0,3600,20030807161237,'eng');
INSERT INTO nuke_blocks VALUES (35,'menu','Current Weather','a:4:{s:5:\"style\";s:1:\"1\";s:14:\"displaywaiting\";i:0;s:14:\"displaymodules\";i:0;s:7:\"content\";s:3596:\"|Maps|LINESPLITmodules.php?op=modload&name=PostWrap&file=index&page=http://www.rap.ucar.edu/weather/upper/upaCNTR_300.gif|300 mbar|From NCAR/RAPLINESPLITmodules.php?op=modload&name=PostWrap&file=index&page=http://www.rap.ucar.edu/weather/upper/upaCNTR_500.gif|500 mbar|From NCAR/RAPLINESPLITmodules.php?op=modload&name=PostWrap&file=index&page=http://www.rap.ucar.edu/weather/upper/upaCNTR_700.gif|700 mbar|From NCAR/RAPLINESPLITmodules.php?op=modload&name=PostWrap&file=index&page=http://www.rap.ucar.edu/weather/surface/sfc_den.gif|Surface|From NCAR/RAPLINESPLIT|Soundings|LINESPLITmodules.php?op=modload&name=PostWrap&file=index&page=http://www.rap.ucar.edu/weather/upper/riw.gif|Riverton|From NCAR/RAPLINESPLITmodules.php?op=modload&name=PostWrap&file=index&page=http://www.rap.ucar.edu/weather/upper/gjt.gif|Grand Junction|From NCAR/RAPLINESPLITmodules.php?op=modload&name=PostWrap&file=index&page=http://www.rap.ucar.edu/weather/upper/dnr.gif|Denver|From NCAR/RAPLINESPLITmodules.php?op=modload&name=PostWrap&file=index&page=http://weather.uwyo.edu/upperair/|U Wyo UpperAir|LINESPLIT|Observations|LINESPLITmodules.php?op=modload&name=PostWrap&file=index&page=http://www.nrel.gov/midc/nwtc_m2/display/|NREL\'s WTC|Weather conditions from the National Wind Technology Center\'s 82-meter M2 TowerLINESPLITmodules.php?op=modload&name=PostWrap&file=index&page=http://weather.noaa.gov/weather/current/KBJC.html|ATIS Jeffco|Latest NWS ATIS observation from Jeffco AirportLINESPLIT|Satellite|LINESPLITmodules.php?op=modload&name=PostWrap&file=index&page=http://www.rap.ucar.edu/weather/satellite/latest_DEN_ir.jpg|Latest IR|Latest InfraRed Image from RAPLINESPLITmodules.php?op=modload&name=PostWrap&file=index&page=http://nimbo.wrh.noaa.gov/satellite/1km/VIS1RIW.GIF| Latest Visible|Latest NOAA GOES-10 Visible from NOAALINESPLITmodules.php?op=modload&name=PostWrap&file=index&page=http://www.cira.colostate.edu/RAMM/Rmsdsol/main.html| CIRA Loops|Real-Time Satellite Data Animations (from CSU)LINESPLIThttp://hadar.cira.colostate.edu/ramsdis/online/data/goes_west/ROL0VIS1.ZIP|GOES-10 1km Visible Loop|GOES-10 1km Visible Zip File DownloadLINESPLIThttp://hadar.cira.colostate.edu/ramsdis/online/data/goes_west/ROL0IR4.ZIP|GOES-10 4km IR Loop|GOES-10 4km Infrared Zip File DownloadLINESPLITmodules.php?op=modload&name=PostWrap&file=index&page=http://orbit-net.nesdis.noaa.gov/goes/sat/images.html|NOAA - GOES |NOAA GOES Real-Time Satellite Images and AnimationsLINESPLITmodules.php?op=modload&name=PostWrap&file=index&page=http://www.ssec.wisc.edu/datacenter/terra/|Terra Tracks|U Wisconsin Terra Global Orbit TracksLINESPLIT|Web Cams|LINESPLITmodules.php?op=modload&name=PostWrap&file=index&page=http://www.wyomingcompanion.com/wcvis_2.html#cams|Wyoming\'s List|LINESPLITmodules.php?op=modload&name=PostWrap&file=index&page=http://www.steamboat-ski.com/images/mtncam/current.jpg|Steamboat, CO|(seasonal)LINESPLITmodules.php?op=modload&name=PostWrap&file=index&page=http://news4colorado.com/citycams/|KCNC News 4 Denver|CityCam networkLINESPLITmodules.php?op=modload&name=PostWrap&file=index&page=http://www.thedenverchannel.com/livecams/|KMGH 7News Denver|LINESPLITmodules.php?op=modload&name=PostWrap&file=index&page=http://www.9news.com/9live/|KUSA 9News Denver|LINESPLITmodules.php?op=modload&name=PostWrap&file=index&page=http://cirrus.sprl.umich.edu/wxnet/wxcam.html|U Michigan\'s List|UM WeatherCamsLINESPLITmodules.php?op=modload&name=PostWrap&file=index&page=http://www.dayweather.com/wxcams.htm|Regional Webcams|Regional webcams in Colorado, Wyoming, Montana, Nebraska, North and South Dakota\";}','',0,'l',10.0,1,3600,20030904155105,'eng');
INSERT INTO nuke_blocks VALUES (36,'menu','menu','a:4:{s:5:\"style\";s:1:\"1\";s:14:\"displaywaiting\";i:0;s:14:\"displaymodules\";i:0;s:7:\"content\";s:0:\"\";}','',0,'l',1.0,1,3600,20030825165810,'eng');
INSERT INTO nuke_blocks VALUES (37,'menu','C-130 Configuration','a:4:{s:5:\"style\";s:1:\"1\";s:14:\"displaywaiting\";i:0;s:14:\"displaymodules\";i:0;s:7:\"content\";s:369:\"index.php?module=ew_filemanager&type=admin&func=manager&pathext=Aircraft/&view=C130_front_ideas3a.gif|Front View (1st)|LINESPLITindex.php?module=ew_filemanager&type=admin&func=manager&pathext=Aircraft/&view=C130_front_ideas3b.gif|Front View (2nd)|LINESPLITindex.php?module=ew_filemanager&type=admin&func=manager&pathext=Aircraft/&view=C130_floor_ideas3a.gif|Floor Plan|\";}','',0,'l',8.0,1,3600,20030812145207,'eng');
INSERT INTO nuke_blocks VALUES (39,'menu','Wx Forecasts','a:4:{s:5:\"style\";s:1:\"1\";s:14:\"displaywaiting\";i:0;s:14:\"displaymodules\";i:0;s:7:\"content\";s:1168:\"|CSU|LINESPLITmodules.php?op=modload&name=PostWrap&file=index&page=http://rams.atmos.colostate.edu/cases/|RAMS Realtime|CSU Prototype Realtime RAMS ForecastLINESPLITmodules.php?op=modload&name=PostWrap&file=index&page=|RAMS Interactive|CSU RAMS Forecasts (Interactive)LINESPLIT|NCAR|LINESPLITmodules.php?op=modload&name=PostWrap&file=index&page=http://www.rap.ucar.edu/weather/model/|RAP Realtime Wx|NCAR-RAP Numerical Model data pageLINESPLITmodules.php?op=modload&name=PostWrap&file=index&page=http://rain.mmm.ucar.edu/mm5/|MM5|NCAR/MMM Real-Time MM5 Web PageLINESPLIT|NOAA/NWS|LINESPLITmodules.php?op=modload&name=PostWrap&file=index&page=http://www.crh.noaa.gov/den/|Denver-Boulder FO|NWS Forecast Office Denver-Boulder, COLINESPLITmodules.php?op=modload&name=PostWrap&file=index&page=http://www.wrh.noaa.gov/wrhq/javaLinks/wrhqJava.html|Western Region Map|NWS Western Region Interactive Forecast MapLINESPLIT|Aviation|LINESPLITmodules.php?op=modload&name=PostWrap&file=index&page=|Aviation Weather|NOAA ADDS - Aviation Digital Data ServiceLINESPLIThttp://www.nws.noaa.gov/forecasts/graphical/|National Forecast Map|Forecasts for the US normally updated every hour\";}','',0,'l',11.0,1,3600,20030808101834,'eng');

--
-- Table structure for table 'nuke_blocks_buttons'
--

CREATE TABLE nuke_blocks_buttons (
  pn_id int(11) unsigned NOT NULL auto_increment,
  pn_bid int(11) unsigned NOT NULL default '0',
  pn_title varchar(255) NOT NULL default '',
  pn_url varchar(254) NOT NULL default '',
  pn_images longtext NOT NULL,
  PRIMARY KEY  (pn_id)
) TYPE=MyISAM;

--
-- Dumping data for table 'nuke_blocks_buttons'
--



--
-- Table structure for table 'nuke_ce_categories'
--

CREATE TABLE nuke_ce_categories (
  mc_id int(11) NOT NULL auto_increment,
  mc_parent_id int(11) NOT NULL default '-1',
  mc_title text NOT NULL,
  mc_language varchar(30) NOT NULL default '',
  PRIMARY KEY  (mc_id)
) TYPE=MyISAM;

--
-- Dumping data for table 'nuke_ce_categories'
--


INSERT INTO nuke_ce_categories VALUES (1,-1,'No Category','x_all');

--
-- Table structure for table 'nuke_ce_contentitems'
--

CREATE TABLE nuke_ce_contentitems (
  mc_id int(11) NOT NULL auto_increment,
  mc_parent_id int(11) NOT NULL default '-1',
  mc_cat_id int(11) NOT NULL default '-1',
  mc_language varchar(30) NOT NULL default '',
  mc_title text NOT NULL,
  mc_title_align tinyint(4) NOT NULL default '1',
  mc_text longtext NOT NULL,
  mc_enable_title tinyint(4) NOT NULL default '1',
  mc_media_url text,
  mc_media_width int(11) NOT NULL default '0',
  mc_media_height int(11) NOT NULL default '0',
  mc_media_text text,
  mc_layout_id int(11) NOT NULL default '-1',
  mc_start_date datetime NOT NULL default '2003-07-08 16:19:46',
  mc_end_date datetime NOT NULL default '2038-01-18 00:00:00',
  mc_top_print tinyint(4) NOT NULL default '0',
  mc_bottom_print tinyint(4) NOT NULL default '0',
  mc_status tinyint(4) NOT NULL default '1',
  mc_weight float NOT NULL default '0',
  mc_navigation tinyint(4) NOT NULL default '0',
  mc_top_sendfriend tinyint(4) NOT NULL default '1',
  mc_bottom_sendfriend tinyint(4) NOT NULL default '0',
  mc_backgroundcolor varchar(7) NOT NULL default '',
  mc_last_updated datetime NOT NULL default '2003-07-08 16:19:46',
  mc_times_read int(11) NOT NULL default '0',
  mc_show_last_updated tinyint(4) NOT NULL default '1',
  mc_show_times_read tinyint(4) NOT NULL default '1',
  mc_author varchar(30) NOT NULL default '',
  mc_notes text,
  PRIMARY KEY  (mc_id)
) TYPE=MyISAM;

--
-- Dumping data for table 'nuke_ce_contentitems'
--



--
-- Table structure for table 'nuke_ce_layout'
--

CREATE TABLE nuke_ce_layout (
  mc_id int(11) NOT NULL auto_increment,
  mc_name text NOT NULL,
  mc_description text NOT NULL,
  mc_text text NOT NULL,
  PRIMARY KEY  (mc_id)
) TYPE=MyISAM;

--
-- Dumping data for table 'nuke_ce_layout'
--


INSERT INTO nuke_ce_layout VALUES (1,'TopLeft','Image aligned to left with vertical alignment to top','Top Left');
INSERT INTO nuke_ce_layout VALUES (2,'TopRight','Image aligned to right with vertical alignment to top','Top Right');
INSERT INTO nuke_ce_layout VALUES (3,'BottomLeft','Image aligned to left with vertical alignment to bottom','Bottom Left');
INSERT INTO nuke_ce_layout VALUES (4,'BottomRight','Image aligned to right with vertical alignment to bottom','Bottom Right');
INSERT INTO nuke_ce_layout VALUES (5,'Top','Image aligned to center with vertical alignment to top','Top');
INSERT INTO nuke_ce_layout VALUES (6,'Bottom','Image aligned to center with vertical alignment to bottom','Bottom');

--
-- Table structure for table 'nuke_ce_statuses'
--

CREATE TABLE nuke_ce_statuses (
  mc_id int(11) NOT NULL auto_increment,
  mc_parent_id int(11) NOT NULL default '-1',
  mc_title text NOT NULL,
  mc_language varchar(30) NOT NULL default '',
  PRIMARY KEY  (mc_id)
) TYPE=MyISAM;

--
-- Dumping data for table 'nuke_ce_statuses'
--


INSERT INTO nuke_ce_statuses VALUES (1,-1,'Preview','x_all');
INSERT INTO nuke_ce_statuses VALUES (2,-1,'Posted','x_all');

--
-- Table structure for table 'nuke_comments'
--

CREATE TABLE nuke_comments (
  pn_tid int(11) NOT NULL auto_increment,
  pn_pid int(11) default '0',
  pn_sid int(11) default '0',
  pn_date datetime default NULL,
  pn_name varchar(60) NOT NULL default '',
  pn_email varchar(60) default NULL,
  pn_url varchar(254) default NULL,
  pn_host_name varchar(60) default NULL,
  pn_subject varchar(85) NOT NULL default '',
  pn_comment text NOT NULL,
  pn_score tinyint(4) NOT NULL default '0',
  pn_reason tinyint(4) NOT NULL default '0',
  PRIMARY KEY  (pn_tid)
) TYPE=MyISAM;

--
-- Dumping data for table 'nuke_comments'
--



--
-- Table structure for table 'nuke_counter'
--

CREATE TABLE nuke_counter (
  pn_type varchar(80) NOT NULL default '',
  pn_var varchar(80) NOT NULL default '',
  pn_count int(11) unsigned NOT NULL default '0'
) TYPE=MyISAM;

--
-- Dumping data for table 'nuke_counter'
--


INSERT INTO nuke_counter VALUES ('total','hits',201546);
INSERT INTO nuke_counter VALUES ('browser','Lynx',9);
INSERT INTO nuke_counter VALUES ('browser','MSIE',1255);
INSERT INTO nuke_counter VALUES ('browser','Opera',3);
INSERT INTO nuke_counter VALUES ('browser','Konqueror',12);
INSERT INTO nuke_counter VALUES ('browser','Netscape',4397);
INSERT INTO nuke_counter VALUES ('browser','Bot',2055);
INSERT INTO nuke_counter VALUES ('browser','Other',193815);
INSERT INTO nuke_counter VALUES ('os','Windows',2295);
INSERT INTO nuke_counter VALUES ('os','Linux',1929);
INSERT INTO nuke_counter VALUES ('os','Mac',197);
INSERT INTO nuke_counter VALUES ('os','FreeBSD',0);
INSERT INTO nuke_counter VALUES ('os','SunOS',3);
INSERT INTO nuke_counter VALUES ('os','IRIX',1);
INSERT INTO nuke_counter VALUES ('os','BeOS',0);
INSERT INTO nuke_counter VALUES ('os','OS/2',0);
INSERT INTO nuke_counter VALUES ('os','AIX',0);
INSERT INTO nuke_counter VALUES ('os','Other',197121);

--
-- Table structure for table 'nuke_downloads_categories'
--

CREATE TABLE nuke_downloads_categories (
  pn_cid int(11) NOT NULL auto_increment,
  pn_title varchar(50) NOT NULL default '',
  pn_description text NOT NULL,
  PRIMARY KEY  (pn_cid)
) TYPE=MyISAM;

--
-- Dumping data for table 'nuke_downloads_categories'
--



--
-- Table structure for table 'nuke_downloads_downloads'
--

CREATE TABLE nuke_downloads_downloads (
  pn_lid int(11) NOT NULL auto_increment,
  pn_cid int(11) NOT NULL default '0',
  pn_sid int(11) NOT NULL default '0',
  pn_title varchar(100) NOT NULL default '',
  pn_url varchar(254) NOT NULL default '',
  pn_description text NOT NULL,
  pn_date datetime default NULL,
  pn_name varchar(100) NOT NULL default '',
  pn_email varchar(100) NOT NULL default '',
  pn_hits int(11) NOT NULL default '0',
  pn_submitter varchar(60) NOT NULL default '',
  pn_ratingsummary double(6,4) NOT NULL default '0.0000',
  pn_totalvotes int(11) NOT NULL default '0',
  pn_totalcomments int(11) NOT NULL default '0',
  pn_filesize int(11) NOT NULL default '0',
  pn_version varchar(10) NOT NULL default '',
  pn_homepage varchar(200) NOT NULL default '',
  PRIMARY KEY  (pn_lid)
) TYPE=MyISAM;

--
-- Dumping data for table 'nuke_downloads_downloads'
--



--
-- Table structure for table 'nuke_downloads_editorials'
--

CREATE TABLE nuke_downloads_editorials (
  pn_id int(11) NOT NULL default '0',
  pn_adminid varchar(60) NOT NULL default '',
  pn_timestamp datetime NOT NULL default '0000-00-00 00:00:00',
  pn_text text NOT NULL,
  pn_title varchar(100) NOT NULL default '',
  PRIMARY KEY  (pn_id)
) TYPE=MyISAM;

--
-- Dumping data for table 'nuke_downloads_editorials'
--



--
-- Table structure for table 'nuke_downloads_modrequest'
--

CREATE TABLE nuke_downloads_modrequest (
  pn_requestid int(11) NOT NULL auto_increment,
  pn_lid int(11) NOT NULL default '0',
  pn_cid int(11) NOT NULL default '0',
  pn_sid int(11) NOT NULL default '0',
  pn_title varchar(100) NOT NULL default '',
  pn_url varchar(254) NOT NULL default '',
  pn_description text NOT NULL,
  pn_modifysubmitter varchar(60) NOT NULL default '',
  pn_brokendownload int(3) NOT NULL default '0',
  pn_name varchar(100) NOT NULL default '',
  pn_email varchar(100) NOT NULL default '',
  pn_filesize int(11) NOT NULL default '0',
  pn_version varchar(10) NOT NULL default '',
  pn_homepage varchar(200) NOT NULL default '',
  PRIMARY KEY  (pn_requestid)
) TYPE=MyISAM;

--
-- Dumping data for table 'nuke_downloads_modrequest'
--



--
-- Table structure for table 'nuke_downloads_newdownload'
--

CREATE TABLE nuke_downloads_newdownload (
  pn_lid int(11) NOT NULL auto_increment,
  pn_cid int(11) NOT NULL default '0',
  pn_sid int(11) NOT NULL default '0',
  pn_title varchar(100) NOT NULL default '',
  pn_url varchar(254) NOT NULL default '',
  pn_description text NOT NULL,
  pn_name varchar(100) NOT NULL default '',
  pn_email varchar(100) NOT NULL default '',
  pn_submitter varchar(60) NOT NULL default '',
  pn_filesize int(11) NOT NULL default '0',
  pn_version varchar(10) NOT NULL default '',
  pn_homepage varchar(200) NOT NULL default '',
  PRIMARY KEY  (pn_lid)
) TYPE=MyISAM;

--
-- Dumping data for table 'nuke_downloads_newdownload'
--



--
-- Table structure for table 'nuke_downloads_subcategories'
--

CREATE TABLE nuke_downloads_subcategories (
  pn_sid int(11) NOT NULL auto_increment,
  pn_cid int(11) NOT NULL default '0',
  pn_title varchar(50) NOT NULL default '',
  PRIMARY KEY  (pn_sid)
) TYPE=MyISAM;

--
-- Dumping data for table 'nuke_downloads_subcategories'
--



--
-- Table structure for table 'nuke_downloads_votedata'
--

CREATE TABLE nuke_downloads_votedata (
  pn_id int(11) NOT NULL auto_increment,
  pn_lid int(11) NOT NULL default '0',
  pn_user varchar(60) NOT NULL default '',
  pn_rating int(11) NOT NULL default '0',
  pn_hostname varchar(60) NOT NULL default '',
  pn_comments text NOT NULL,
  pn_timestamp datetime NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (pn_id)
) TYPE=MyISAM;

--
-- Dumping data for table 'nuke_downloads_votedata'
--



--
-- Table structure for table 'nuke_ephem'
--

CREATE TABLE nuke_ephem (
  pn_eid int(11) NOT NULL auto_increment,
  pn_did tinyint(2) NOT NULL default '0',
  pn_mid tinyint(2) NOT NULL default '0',
  pn_yid int(4) NOT NULL default '0',
  pn_content text NOT NULL,
  pn_language varchar(30) NOT NULL default '',
  PRIMARY KEY  (pn_eid)
) TYPE=MyISAM;

--
-- Dumping data for table 'nuke_ephem'
--



--
-- Table structure for table 'nuke_ew_filemanager'
--

CREATE TABLE nuke_ew_filemanager (
  uid int(11) NOT NULL default '0',
  path varchar(255) NOT NULL default 'slash/ended/path/to/files/',
  PRIMARY KEY  (uid)
) TYPE=MyISAM;

--
-- Dumping data for table 'nuke_ew_filemanager'
--



--
-- Table structure for table 'nuke_faqanswer'
--

CREATE TABLE nuke_faqanswer (
  pn_id int(6) NOT NULL auto_increment,
  pn_id_cat int(6) default NULL,
  pn_question text,
  pn_answer text,
  pn_submittedby varchar(250) NOT NULL default '',
  PRIMARY KEY  (pn_id)
) TYPE=MyISAM;

--
-- Dumping data for table 'nuke_faqanswer'
--


INSERT INTO nuke_faqanswer VALUES (1,2,'What is the IDEAS Project?','I dunno.','');
INSERT INTO nuke_faqanswer VALUES (3,3,'How do I post an image on the Forums?','You can post an image with the html tag img.  You create a line like this &lt;img src=\"URL\"&gt;, where URL is the location of the image.  You must have posted the image on a web server somewhere.  You can post the image in our file exchange on this server by clicking on the \'file exchange\' link on the left.  You may create a subdirectory there if you wish.  Once the file (e.g., FILENAME) is transferred, the tag to use is &lt;img src=\"filex/FILENAME\"&gt;.','');
INSERT INTO nuke_faqanswer VALUES (4,3,'Can I post documents on this web server?','This web server is set up as a place for scholarly exchange of experience and information between and among students and researchers.  The file exchange is a good place to post documents which you wish to share.  The forums provide a good place to announce and discuss documents.  You can post links to files in the file exchange with a URL like \"filex/<i>FILENAME</i>\".  We ask that you only keep these things in mind.\r\n<li>  The file exchange is for scholarly documents (no porn, pirated software, etc.).   Use your judgement, but remember that you can be traced if you post inappropriate things habitually.  Any files that do not meet these guidelines will be removed.</li>\r\n<li>Large files are not allowed.  There are caps on file size, and on the overall amount of storage that the file exchange takes up.  Files of the following types will probably be too large for the file exchange:  Audio files over a few seconds in length, video files, programs.</li>\r\n<li>This service is in place to advance science.  If too many people abuse it, we will have to restrict access, which would restrict the science.</li>','');
INSERT INTO nuke_faqanswer VALUES (5,3,'Do I need an account to access this web site?','No, but there are some features which are restricted to registered users only.','');
INSERT INTO nuke_faqanswer VALUES (7,3,'Who should be interested in this web site?','This web site is mostly for the scientists and students directly involved in the IDEAS-3 Project.  Other people with an interest in the science may also find this site informative.  ','');
INSERT INTO nuke_faqanswer VALUES (6,4,'What are the dates for the IDEAS-3 Project?','The IDEAS Project begins August 15 and runs until September 22.  A complete list of project-related events is available on the calendar either on the Home page or through the Calendar link on the left-hand side of the web page.','');
INSERT INTO nuke_faqanswer VALUES (8,5,'When I load the chat program, the background is black and the text is hard to read.  What can I do about this?','Right now there is a known bug which causes the chat window to be drawn incorrectly sometimes.   The only solution we have at this time is to log out of the chat, and then log back in.  This should fix the problem.  Hopefully we will have a better solution in the future.\r\n','');
INSERT INTO nuke_faqanswer VALUES (9,5,'The chat program says that I can use a different IRC client to chat, but it is not working.  What gives?','The chat module used on this web site is just a standard IRC chat client.  It connects to an IRC server which does all of the chatting.  However, because the server is on the ATD network, and not directly exposed to the Internet, only people connecting from within the ATD network have the option of using a stand-alone client.  If you are outside the network, but you have a login account at ATD, you may still use a stand-alone client from one on the exposed hosts if it has one installed.  Contact a system administrator if you need these installed.','');
INSERT INTO nuke_faqanswer VALUES (12,6,'I want to post a status update to the Project Status thread.  How can I do that?','First, the Project Status thread is not for regular discussion.  It should only be posted to for updates on the project.  Discussion should be done in separate threads.  If you find that your post is appropriate, you can click on \"Reply\" on the previous message.','');
INSERT INTO nuke_faqanswer VALUES (11,5,'When I type something in the chat window, it does not appear, and I cannot see what other people are typing.  Why?','Make sure you have the chat room selected.  You are probably in the status window, which looks exactly like the chat rooms but does not actually allow chatting.  The top bar of the chat client has a list of the available rooms.  Click on the one that you want to enter.','');
INSERT INTO nuke_faqanswer VALUES (13,7,'What does the Calendar allow me to do?','The Calendar allows events to be posted and shared among users.  You can also post private events.  Any events posted to the calendar will automatically show up on the home page under \"Today\'s Events\" or \"Upcoming Events\" when they are happening within a month.','');
INSERT INTO nuke_faqanswer VALUES (14,7,'How do I post an event to the Calendar?','<li>Click on the <b>Submit Calendar Event</b> on the left side of the web page.\r\n<li>Fill in the <b>Event Title, Event Date, Event Description</b>, at the minimum.  \r\n<li>Make sure the topic is as accurate as possible (if you need a new topic, an administrator will need to add it for you), and specify if the event is <b>Private, Public, Show as Busy</b> or <b>Global</b> (Use <b>Global</b> if you want everyone to see it.)</li>\r\n<li>At the bottom of the page, select whether the message is <b>plain text</b> or <b>HTML</b>.  To see the event before posting it, leave <b>Preview Event</b> selected, or to post the event, you will need to change the value to <b>Submit Event</b>.  If you choose to preview, you will see your event at the top of the screen.  You will still need to <b>Submit</b> the event before it is posted.','');
INSERT INTO nuke_faqanswer VALUES (15,7,'How do I edit or delete an event which I have submitted to the Calendar?','First, you will need to find the event.  You can do this either by clicking on the date in the <b>Today\'s/Upcoming Events</b> or by clicking on the calendar and navigating to the date.  Once you have clicked on the event, you should see the event and links to <b>edit</b> or <b>delete</b> the event.  To edit, click on the <b>edit</b> link, and then you should see the same screen as when you created the event.  You can then modify any of the event\'s properties and <b>preview</b> or <b>submit</b> the changes.','');
INSERT INTO nuke_faqanswer VALUES (16,7,'I know what is happening during an event, but I cannot find it.  How can I search for an event based on what is happening?','You can search the calendar by clicking on the <b>Search the Calendar</b> link on the left side.','');

--
-- Table structure for table 'nuke_faqcategories'
--

CREATE TABLE nuke_faqcategories (
  pn_id_cat int(6) NOT NULL auto_increment,
  pn_categories varchar(255) default NULL,
  pn_language varchar(30) NOT NULL default '',
  pn_parent_id int(6) NOT NULL default '0',
  PRIMARY KEY  (pn_id_cat)
) TYPE=MyISAM;

--
-- Dumping data for table 'nuke_faqcategories'
--


INSERT INTO nuke_faqcategories VALUES (3,'Website Usage','eng',0);
INSERT INTO nuke_faqcategories VALUES (2,'What is the IDEAS Project?','eng',1);
INSERT INTO nuke_faqcategories VALUES (4,'Project Information','eng',0);
INSERT INTO nuke_faqcategories VALUES (5,'The Chat Program','eng',0);
INSERT INTO nuke_faqcategories VALUES (6,'Posting to the Project Status thread','eng',0);
INSERT INTO nuke_faqcategories VALUES (7,'Using the Calendar','eng',0);

--
-- Table structure for table 'nuke_group_membership'
--

CREATE TABLE nuke_group_membership (
  pn_gid int(11) NOT NULL default '0',
  pn_uid int(11) NOT NULL default '0'
) TYPE=MyISAM;

--
-- Dumping data for table 'nuke_group_membership'
--


INSERT INTO nuke_group_membership VALUES (1,1);
INSERT INTO nuke_group_membership VALUES (2,2);
INSERT INTO nuke_group_membership VALUES (1,11);
INSERT INTO nuke_group_membership VALUES (1,10);
INSERT INTO nuke_group_membership VALUES (1,14);
INSERT INTO nuke_group_membership VALUES (1,13);
INSERT INTO nuke_group_membership VALUES (1,46);
INSERT INTO nuke_group_membership VALUES (1,41);
INSERT INTO nuke_group_membership VALUES (1,12);
INSERT INTO nuke_group_membership VALUES (1,15);
INSERT INTO nuke_group_membership VALUES (1,16);
INSERT INTO nuke_group_membership VALUES (1,17);
INSERT INTO nuke_group_membership VALUES (1,18);
INSERT INTO nuke_group_membership VALUES (1,19);
INSERT INTO nuke_group_membership VALUES (1,20);
INSERT INTO nuke_group_membership VALUES (1,21);
INSERT INTO nuke_group_membership VALUES (1,22);
INSERT INTO nuke_group_membership VALUES (2,17);
INSERT INTO nuke_group_membership VALUES (2,16);
INSERT INTO nuke_group_membership VALUES (3,15);
INSERT INTO nuke_group_membership VALUES (1,40);
INSERT INTO nuke_group_membership VALUES (3,21);
INSERT INTO nuke_group_membership VALUES (3,22);
INSERT INTO nuke_group_membership VALUES (2,14);
INSERT INTO nuke_group_membership VALUES (2,13);
INSERT INTO nuke_group_membership VALUES (1,23);
INSERT INTO nuke_group_membership VALUES (1,39);
INSERT INTO nuke_group_membership VALUES (1,25);
INSERT INTO nuke_group_membership VALUES (1,26);
INSERT INTO nuke_group_membership VALUES (1,27);
INSERT INTO nuke_group_membership VALUES (1,28);
INSERT INTO nuke_group_membership VALUES (1,29);
INSERT INTO nuke_group_membership VALUES (1,30);
INSERT INTO nuke_group_membership VALUES (1,31);
INSERT INTO nuke_group_membership VALUES (1,32);
INSERT INTO nuke_group_membership VALUES (1,33);
INSERT INTO nuke_group_membership VALUES (1,34);
INSERT INTO nuke_group_membership VALUES (1,35);
INSERT INTO nuke_group_membership VALUES (1,36);
INSERT INTO nuke_group_membership VALUES (2,11);
INSERT INTO nuke_group_membership VALUES (2,18);
INSERT INTO nuke_group_membership VALUES (2,19);
INSERT INTO nuke_group_membership VALUES (1,37);
INSERT INTO nuke_group_membership VALUES (2,37);
INSERT INTO nuke_group_membership VALUES (1,38);
INSERT INTO nuke_group_membership VALUES (3,25);
INSERT INTO nuke_group_membership VALUES (3,20);
INSERT INTO nuke_group_membership VALUES (3,12);
INSERT INTO nuke_group_membership VALUES (3,29);
INSERT INTO nuke_group_membership VALUES (3,31);
INSERT INTO nuke_group_membership VALUES (3,34);
INSERT INTO nuke_group_membership VALUES (3,35);
INSERT INTO nuke_group_membership VALUES (3,23);
INSERT INTO nuke_group_membership VALUES (3,36);
INSERT INTO nuke_group_membership VALUES (3,30);
INSERT INTO nuke_group_membership VALUES (3,33);
INSERT INTO nuke_group_membership VALUES (3,27);
INSERT INTO nuke_group_membership VALUES (3,28);
INSERT INTO nuke_group_membership VALUES (3,32);
INSERT INTO nuke_group_membership VALUES (3,26);
INSERT INTO nuke_group_membership VALUES (3,38);
INSERT INTO nuke_group_membership VALUES (1,42);
INSERT INTO nuke_group_membership VALUES (3,40);
INSERT INTO nuke_group_membership VALUES (3,42);
INSERT INTO nuke_group_membership VALUES (3,39);
INSERT INTO nuke_group_membership VALUES (3,41);
INSERT INTO nuke_group_membership VALUES (1,43);
INSERT INTO nuke_group_membership VALUES (3,43);
INSERT INTO nuke_group_membership VALUES (2,15);
INSERT INTO nuke_group_membership VALUES (1,44);
INSERT INTO nuke_group_membership VALUES (1,45);
INSERT INTO nuke_group_membership VALUES (3,45);
INSERT INTO nuke_group_membership VALUES (3,17);
INSERT INTO nuke_group_membership VALUES (3,46);
INSERT INTO nuke_group_membership VALUES (1,47);
INSERT INTO nuke_group_membership VALUES (3,47);
INSERT INTO nuke_group_membership VALUES (3,11);
INSERT INTO nuke_group_membership VALUES (3,18);
INSERT INTO nuke_group_membership VALUES (3,37);
INSERT INTO nuke_group_membership VALUES (3,16);
INSERT INTO nuke_group_membership VALUES (3,19);
INSERT INTO nuke_group_membership VALUES (3,44);
INSERT INTO nuke_group_membership VALUES (1,48);
INSERT INTO nuke_group_membership VALUES (3,48);

--
-- Table structure for table 'nuke_group_perms'
--

CREATE TABLE nuke_group_perms (
  pn_pid int(11) NOT NULL auto_increment,
  pn_gid int(11) NOT NULL default '0',
  pn_sequence int(11) NOT NULL default '0',
  pn_realm smallint(4) NOT NULL default '0',
  pn_component varchar(255) NOT NULL default '',
  pn_instance varchar(255) NOT NULL default '',
  pn_level smallint(4) NOT NULL default '0',
  pn_bond int(2) NOT NULL default '0',
  PRIMARY KEY  (pn_pid)
) TYPE=MyISAM;

--
-- Dumping data for table 'nuke_group_perms'
--


INSERT INTO nuke_group_perms VALUES (1,2,1,0,'.*','.*',800,0);
INSERT INTO nuke_group_perms VALUES (2,-1,4,0,'Menublock::','Main Menu:Administration:',0,0);
INSERT INTO nuke_group_perms VALUES (3,1,7,0,'.*','.*',300,0);
INSERT INTO nuke_group_perms VALUES (4,0,8,0,'Menublock::','Main Menu:(My Account|Logout|Submit News|Submit Calendar Event|Discussion Forums|Online Chat):',0,0);
INSERT INTO nuke_group_perms VALUES (5,0,9,0,'.*','.*',200,0);
INSERT INTO nuke_group_perms VALUES (6,3,3,0,'.*','.*',400,0);
INSERT INTO nuke_group_perms VALUES (7,-1,6,0,'ew_filemanager::','.*',600,0);
INSERT INTO nuke_group_perms VALUES (8,3,5,0,'ew_filemanager::','.*',700,0);
INSERT INTO nuke_group_perms VALUES (9,3,2,0,'PostCalendar::','.*',800,0);

--
-- Table structure for table 'nuke_groups'
--

CREATE TABLE nuke_groups (
  pn_gid int(11) NOT NULL auto_increment,
  pn_name varchar(255) NOT NULL default '',
  PRIMARY KEY  (pn_gid)
) TYPE=MyISAM;

--
-- Dumping data for table 'nuke_groups'
--


INSERT INTO nuke_groups VALUES (1,'Users');
INSERT INTO nuke_groups VALUES (2,'Admins');
INSERT INTO nuke_groups VALUES (3,'Participants');

--
-- Table structure for table 'nuke_headlines'
--

CREATE TABLE nuke_headlines (
  pn_id int(11) unsigned NOT NULL auto_increment,
  pn_sitename varchar(255) NOT NULL default '',
  pn_rssuser varchar(10) default NULL,
  pn_rsspasswd varchar(10) default NULL,
  pn_use_proxy tinyint(3) NOT NULL default '0',
  pn_rssurl varchar(255) NOT NULL default '',
  pn_maxrows tinyint(3) NOT NULL default '10',
  pn_siteurl varchar(255) NOT NULL default '',
  pn_options varchar(20) default '',
  PRIMARY KEY  (pn_id)
) TYPE=MyISAM;

--
-- Dumping data for table 'nuke_headlines'
--


INSERT INTO nuke_headlines VALUES (1,'PostNuke',NULL,NULL,0,'http://postnuke.com/backend.php',10,'','');
INSERT INTO nuke_headlines VALUES (2,'LinuxCentral',NULL,NULL,0,'http://linuxcentral.com/backend/lcnew.rdf',10,'','');
INSERT INTO nuke_headlines VALUES (3,'Slashdot',NULL,NULL,0,'http://slashdot.org/slashdot.rdf',10,'','');
INSERT INTO nuke_headlines VALUES (4,'NewsForge',NULL,NULL,0,'http://www.newsforge.com/newsforge.rdf',10,'','');
INSERT INTO nuke_headlines VALUES (5,'PHPBuilder',NULL,NULL,0,'http://phpbuilder.com/rss_feed.php',10,'','');
INSERT INTO nuke_headlines VALUES (6,'Linux.com',NULL,NULL,0,'http://linux.com/mrn/front_page.rss',10,'','');
INSERT INTO nuke_headlines VALUES (7,'Freshmeat',NULL,NULL,0,'http://freshmeat.net/backend/fm.rdf',10,'','');
INSERT INTO nuke_headlines VALUES (9,'LinuxWeeklyNews',NULL,NULL,0,'http://lwn.net/headlines/rss',10,'','');
INSERT INTO nuke_headlines VALUES (11,'Segfault',NULL,NULL,0,'http://segfault.org/stories.xml',10,'','');
INSERT INTO nuke_headlines VALUES (13,'KDE',NULL,NULL,0,'http://www.kde.org/news/kdenews.rdf',10,'','');
INSERT INTO nuke_headlines VALUES (14,'Perl.com',NULL,NULL,0,'http://www.perl.com/pace/perlnews.rdf',10,'','');
INSERT INTO nuke_headlines VALUES (17,'MozillaNewsBot',NULL,NULL,0,'http://www.mozilla.org/newsbot/newsbot.rdf',10,'','');
INSERT INTO nuke_headlines VALUES (21,'SciFi-News',NULL,NULL,0,'http://www.technopagan.org/sf-news/rdf.php',10,'','');
INSERT INTO nuke_headlines VALUES (26,'DrDobbsTechNetCast',NULL,NULL,0,'http://www.technetcast.com/tnc_headlines.rdf',10,'','');
INSERT INTO nuke_headlines VALUES (27,'RivaExtreme',NULL,NULL,0,'http://rivaextreme.com/ssi/rivaextreme.rdf.cdf',10,'','');
INSERT INTO nuke_headlines VALUES (29,'PBSOnline',NULL,NULL,0,'http://cgi.pbs.org/cgi-registry/featuresrdf.pl',10,'','');
INSERT INTO nuke_headlines VALUES (30,'Listology',NULL,NULL,0,'http://listology.com/recent.rdf',10,'','');
INSERT INTO nuke_headlines VALUES (33,'exoScience',NULL,NULL,0,'http://www.exosci.com/exosci.rdf',10,'','');
INSERT INTO nuke_headlines VALUES (39,'DailyDaemonNews',NULL,NULL,0,'http://daily.daemonnews.org/ddn.rdf.php3',10,'','');
INSERT INTO nuke_headlines VALUES (40,'PerlMonks',NULL,NULL,0,'http://www.perlmonks.org/headlines.rdf',10,'','');
INSERT INTO nuke_headlines VALUES (42,'BSDToday',NULL,NULL,0,'http://www.bsdtoday.com/backend/bt.rdf',10,'','');
INSERT INTO nuke_headlines VALUES (45,'HotWired',NULL,NULL,0,'http://www.hotwired.com/webmonkey/meta/headlines.rdf',10,'','');
INSERT INTO nuke_headlines VALUES (52,'SolarisCentral',NULL,NULL,0,'http://www.SolarisCentral.org/news/SolarisCentral.rdf',10,'','');

--
-- Table structure for table 'nuke_hooks'
--

CREATE TABLE nuke_hooks (
  pn_id int(11) unsigned NOT NULL auto_increment,
  pn_object varchar(64) NOT NULL default '',
  pn_action varchar(64) NOT NULL default '',
  pn_smodule varchar(64) default NULL,
  pn_stype varchar(64) default NULL,
  pn_tarea varchar(64) NOT NULL default '',
  pn_tmodule varchar(64) NOT NULL default '',
  pn_ttype varchar(64) NOT NULL default '',
  pn_tfunc varchar(64) NOT NULL default '',
  PRIMARY KEY  (pn_id)
) TYPE=MyISAM;

--
-- Dumping data for table 'nuke_hooks'
--


INSERT INTO nuke_hooks VALUES (1,'item','display',NULL,NULL,'GUI','Ratings','user','display');
INSERT INTO nuke_hooks VALUES (2,'item','transform',NULL,NULL,'API','Wiki','user','transform');
INSERT INTO nuke_hooks VALUES (3,'item','transform','Wiki',NULL,'API','Wiki','user','transform');
INSERT INTO nuke_hooks VALUES (4,'item','transform','AddStory',NULL,'API','Wiki','user','transform');
INSERT INTO nuke_hooks VALUES (5,'item','transform','phpBB_14',NULL,'API','Wiki','user','transform');
INSERT INTO nuke_hooks VALUES (6,'item','transform','Admin',NULL,'API','Wiki','user','transform');
INSERT INTO nuke_hooks VALUES (7,'item','transform','Admin_Messages',NULL,'API','Wiki','user','transform');

--
-- Table structure for table 'nuke_languages_constant'
--

CREATE TABLE nuke_languages_constant (
  pn_constant varchar(32) NOT NULL default '',
  pn_file varchar(64) NOT NULL default '',
  PRIMARY KEY  (pn_constant)
) TYPE=MyISAM;

--
-- Dumping data for table 'nuke_languages_constant'
--



--
-- Table structure for table 'nuke_languages_file'
--

CREATE TABLE nuke_languages_file (
  pn_target varchar(64) NOT NULL default '',
  pn_source varchar(64) NOT NULL default '',
  PRIMARY KEY  (pn_target,pn_source),
  UNIQUE KEY source (pn_source)
) TYPE=MyISAM;

--
-- Dumping data for table 'nuke_languages_file'
--



--
-- Table structure for table 'nuke_languages_translation'
--

CREATE TABLE nuke_languages_translation (
  pn_language varchar(32) NOT NULL default '',
  pn_constant varchar(32) NOT NULL default '',
  pn_translation longblob NOT NULL,
  pn_level tinyint(4) NOT NULL default '0',
  PRIMARY KEY  (pn_constant,pn_language)
) TYPE=MyISAM;

--
-- Dumping data for table 'nuke_languages_translation'
--



--
-- Table structure for table 'nuke_links_categories'
--

CREATE TABLE nuke_links_categories (
  pn_cat_id int(11) NOT NULL auto_increment,
  pn_parent_id int(11) default NULL,
  pn_title varchar(50) NOT NULL default '',
  pn_description text NOT NULL,
  PRIMARY KEY  (pn_cat_id)
) TYPE=MyISAM;

--
-- Dumping data for table 'nuke_links_categories'
--


INSERT INTO nuke_links_categories VALUES (1,0,'IDEAS Project Websites','');
INSERT INTO nuke_links_categories VALUES (2,0,'Information about Airborne Science','');
INSERT INTO nuke_links_categories VALUES (3,0,'Organizations','');
INSERT INTO nuke_links_categories VALUES (4,0,'IDV','Integrated Data Viewers');

--
-- Table structure for table 'nuke_links_editorials'
--

CREATE TABLE nuke_links_editorials (
  pn_linkid int(11) NOT NULL default '0',
  pn_adminid varchar(60) NOT NULL default '',
  pn_timestamp datetime NOT NULL default '0000-00-00 00:00:00',
  pn_text text NOT NULL,
  pn_title varchar(100) NOT NULL default '',
  PRIMARY KEY  (pn_linkid)
) TYPE=MyISAM;

--
-- Dumping data for table 'nuke_links_editorials'
--



--
-- Table structure for table 'nuke_links_links'
--

CREATE TABLE nuke_links_links (
  pn_lid int(11) NOT NULL auto_increment,
  pn_cat_id int(11) NOT NULL default '0',
  pn_title varchar(100) NOT NULL default '',
  pn_url varchar(254) NOT NULL default '',
  pn_description text NOT NULL,
  pn_date datetime default NULL,
  pn_name varchar(100) NOT NULL default '',
  pn_email varchar(100) NOT NULL default '',
  pn_hits int(11) NOT NULL default '0',
  pn_submitter varchar(60) NOT NULL default '',
  pn_ratingsummary double(6,4) NOT NULL default '0.0000',
  pn_totalvotes int(11) NOT NULL default '0',
  pn_totalcomments int(11) NOT NULL default '0',
  PRIMARY KEY  (pn_lid)
) TYPE=MyISAM;

--
-- Dumping data for table 'nuke_links_links'
--


INSERT INTO nuke_links_links VALUES (1,1,'The IDEAS-1 Web Page','http://raf.atd.ucar.edu/Projects/IDEAS/','This is the web page for the first IDEAS project.','2003-07-08 16:46:19','Admin','none@none.com',53,'Admin',0.0000,0,0);
INSERT INTO nuke_links_links VALUES (2,1,'The IDEAS-2 Web Page','http://raf.atd.ucar.edu/Projects/IDEAS-2/','The Web page for the IDEAS2 project.','2003-07-08 16:47:22','Admin','none@none.com',55,'Admin',0.0000,0,0);
INSERT INTO nuke_links_links VALUES (3,3,'UCAR','http://www.ucar.edu','The University Corporation for Atmospheric Research','2003-07-08 16:54:12','Admin','none@none.com',44,'Admin',0.0000,0,0);
INSERT INTO nuke_links_links VALUES (4,3,'NSF','http://www.nsf.gov/','The National Science Foundation','2003-07-08 16:54:21','Admin','none@none.com',40,'Admin',0.0000,0,0);
INSERT INTO nuke_links_links VALUES (6,4,'Sample IDV','http://www.atd.ucar.edu/rdp/proposals/COLT/idv_anim.html','This is a sample IDV for demonstration purposes.','2003-07-09 13:38:58','Admin','none@none.com',44,'Admin',0.0000,0,0);

--
-- Table structure for table 'nuke_links_modrequest'
--

CREATE TABLE nuke_links_modrequest (
  pn_requestid int(11) NOT NULL auto_increment,
  pn_lid int(11) NOT NULL default '0',
  pn_cat_id int(11) NOT NULL default '0',
  pn_sid int(11) NOT NULL default '0',
  pn_title varchar(100) NOT NULL default '',
  pn_url varchar(254) NOT NULL default '',
  pn_description text NOT NULL,
  pn_modifysubmitter varchar(60) NOT NULL default '',
  pn_brokenlink tinyint(3) NOT NULL default '0',
  PRIMARY KEY  (pn_requestid)
) TYPE=MyISAM;

--
-- Dumping data for table 'nuke_links_modrequest'
--


INSERT INTO nuke_links_modrequest VALUES (1,3,0,0,'','','','Admin',1);
INSERT INTO nuke_links_modrequest VALUES (2,4,0,0,'','','','Admin',1);

--
-- Table structure for table 'nuke_links_newlink'
--

CREATE TABLE nuke_links_newlink (
  pn_lid int(11) NOT NULL auto_increment,
  pn_cat_id int(11) NOT NULL default '0',
  pn_title varchar(100) NOT NULL default '',
  pn_url varchar(254) NOT NULL default '',
  pn_description text NOT NULL,
  pn_name varchar(100) NOT NULL default '',
  pn_email varchar(100) NOT NULL default '',
  pn_submitter varchar(60) NOT NULL default '',
  PRIMARY KEY  (pn_lid)
) TYPE=MyISAM;

--
-- Dumping data for table 'nuke_links_newlink'
--



--
-- Table structure for table 'nuke_links_votedata'
--

CREATE TABLE nuke_links_votedata (
  pn_id int(11) NOT NULL auto_increment,
  pn_lid int(11) NOT NULL default '0',
  pn_user varchar(60) NOT NULL default '',
  pn_rating int(11) NOT NULL default '0',
  pn_hostname varchar(60) NOT NULL default '',
  pn_comments text NOT NULL,
  pn_timestamp datetime NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (pn_id)
) TYPE=MyISAM;

--
-- Dumping data for table 'nuke_links_votedata'
--



--
-- Table structure for table 'nuke_me_menuitems'
--

CREATE TABLE nuke_me_menuitems (
  mc_id int(11) NOT NULL auto_increment,
  mc_parent_id int(11) NOT NULL default '-1',
  mc_block_id int(11) NOT NULL default '-1',
  mc_language varchar(30) NOT NULL default '',
  mc_title text NOT NULL,
  mc_type tinyint(4) NOT NULL default '0',
  mc_newwindow tinyint(4) NOT NULL default '0',
  mc_uri text NOT NULL,
  mc_start_date datetime NOT NULL default '2003-07-08 16:19:46',
  mc_end_date datetime NOT NULL default '2038-01-18 00:00:00',
  mc_status tinyint(4) NOT NULL default '1',
  mc_weight float NOT NULL default '0',
  mc_rollover_img1 blob,
  mc_rollover_img2 blob,
  mc_bg_img blob,
  mc_rollover_img1_file text,
  mc_rollover_img2_file text,
  mc_bg_img_file text,
  mc_rollover_img1_size int(11) NOT NULL default '0',
  mc_rollover_img2_size int(11) NOT NULL default '0',
  mc_bg_img_size int(11) NOT NULL default '0',
  mc_rollover_img1_type text,
  mc_rollover_img2_type text,
  mc_bg_img_type text,
  PRIMARY KEY  (mc_id)
) TYPE=MyISAM;

--
-- Dumping data for table 'nuke_me_menuitems'
--


INSERT INTO nuke_me_menuitems VALUES (1,-1,19,'eng','google',4,0,'http://www.google.com','2003-07-09 11:22:23','2038-01-18 00:00:00',1,10,'','','','','','',0,0,0,'','','');

--
-- Table structure for table 'nuke_message'
--

CREATE TABLE nuke_message (
  pn_mid int(11) NOT NULL auto_increment,
  pn_title varchar(100) NOT NULL default '',
  pn_content text NOT NULL,
  pn_date varchar(14) NOT NULL default '',
  pn_expire mediumint(7) NOT NULL default '0',
  pn_active tinyint(4) NOT NULL default '1',
  pn_view tinyint(1) NOT NULL default '1',
  pn_language varchar(30) NOT NULL default '',
  PRIMARY KEY  (pn_mid)
) TYPE=MyISAM;

--
-- Dumping data for table 'nuke_message'
--


INSERT INTO nuke_message VALUES (11,'<center><img src=\"/IDEAS3/filex/med_c130fixa.jpg\" alt=\"C-130 photo (22,397 byte jpg)\"></center>','<center>\r\n<h3>\r\n<font color=\"#0000bb\">I</font>nstrument\r\n<font color=\"#0000bb\">D</font>evelopment and\r\n<font color=\"#0000bb\">E</font>ducation in\r\n<font color=\"#0000bb\">A</font>irborne\r\n<font color=\"#0000bb\">S</font>cience\r\n<br>\r\n<font color=\"#bb0000\">Phase 3</font>\r\n</h3>\r\n<table border=\"2\" width=\"100%\">\r\n <tr>\r\n  <th colspan=\"2\">Project Managers:</th>\r\n </tr>\r\n <tr>\r\n  <th>\r\n  Allen Schanot, (303)497-1063,\r\n  <a href=\"http://raf.atd.ucar.edu/cgi-bin/mail_me1.pl/schanot+From_IDEAS-3_Website\">email</a>\r\n  </th>\r\n  <th>Jorgen Jensen, (303)497-1028,\r\n  <a href=\"http://raf.atd.ucar.edu/cgi-bin/mail_me1.pl/jbj+From_IDEAS-3_Website\">email</a>\r\n  </th>\r\n </tr>\r\n <tr>\r\n  <td colspan=\"2\" align=\"center\"> Contact one of them for anything related to this project.</td>\r\n </tr>\r\n</table>\r\n<hr noshade>\r\n<table width=\"100%\">\r\n <tr align=\"center\">\r\n  <td><a href=\"modules.php?op=modload&name=PostWrap&file=index&page=http://raf.atd.ucar.edu/Projects/IDEAS/description.html\"><b>Project Description</b></a></td>\r\n  <td><a href=\"modules.php?op=modload&name=PostWrap&file=index&page=http://raf.atd.ucar.edu/cgi-bin/ion/ion-p?page=c130.ion\"><b>C-130 Real-Time Data via ION</b></a></td>\r\n </tr>\r\n <tr align=\"center\">\r\n  <td><a href=\"modules.php?op=modload&name=PostWrap&file=index&page=http://raf.atd.ucar.edu/Projects/IDEAS/announce.html\"><b>IDEAS-3 Announcement Web Page</b></a></td>\r\n  <td><a href=\"modules.php?op=modload&name=PostWrap&file=index&page=http://raf.atd.ucar.edu/Projects/IDEAS/data_access.html\"><b>Data Access</b></a></td>\r\n </tr>\r\n <tr align=\"center\">\r\n  <td><a href=\"modules.php?op=modload&amp;name=FAQ&amp;file=index&amp;myfaq=yes&amp;askaquestion=yes&amp;id_cat=0&amp\"><b>Ask A Question</b></a></td>\r\n  <td><a href=\"modules.php?op=modload&name=PostWrap&file=index&page=http://raf.atd.ucar.edu/Projects/IDEAS/flights.html\"><b>Flight Summaries</b></a></td>\r\n </tr>\r\n <tr align=\"center\">\r\n  <td><a href=\"modules.php?op=modload&name=PostWrap&file=index&page=http://raf.atd.ucar.edu/Projects/IDEAS/pics/Hallett_and_student.png\">Prof. Hallett and student</a>\r\n   <br><a href=\"modules.php?op=modload&name=PostWrap&file=index&page=http://raf.atd.ucar.edu/Projects/IDEAS/pics/Shaw_students.png\">Prof. Shaw and students</a>\r\n  <br><a href=\"modules.php?op=modload&name=PostWrap&file=index&page=http://raf.atd.ucar.edu/Projects/IDEAS/pics/Texas_am.png\">Texas A&amp;M student</a></td>\r\n  <td><a href=\"modules.php?op=modload&name=PostWrap&file=index&page=http://raf.atd.ucar.edu/Projects/IDEAS/FltMatrix.html\"><b>Flight Summary Matrix</b></a>\r\n  </td>\r\n </tr>\r\n <tr align=\"center\">\r\n  <td><a href=\"modules.php?op=modload&name=PostWrap&file=index&page=http://raf.atd.ucar.edu/Projects/IDEAS/ac_access.html\"><font color=\"#0000bb\"><b>Access to Aircraft</b></font></a></td>\r\n   <td><font color=\"#0000bb\"><b>C-130Q Safety Briefing</b></font>\r\n   <br><a href=\"http://raf.atd.ucar.edu/safety_brief.ppt\"><b>-</b> Download PowerPoint file (29.3MB)</a>\r\n   <br><a href=\"modules.php?op=modload&name=PostWrap&file=index&page=http://raf.atd.ucar.edu/safety_brief.htm\"><b>-</b> Browser version (MS Internet Explorer recommended)</a>\r\n  </td>\r\n </tr>\r\n</table>\r\n<hr noshade>','1060297730',0,1,1,'eng');

--
-- Table structure for table 'nuke_mme_mediaitems'
--

CREATE TABLE nuke_mme_mediaitems (
  mc_id int(11) NOT NULL auto_increment,
  mc_filename varchar(255) NOT NULL default '',
  mc_filesize int(20) NOT NULL default '0',
  mc_type text NOT NULL,
  PRIMARY KEY  (mc_id),
  UNIQUE KEY mc_filename_2 (mc_filename),
  KEY mc_filename (mc_filename)
) TYPE=MyISAM;

--
-- Dumping data for table 'nuke_mme_mediaitems'
--


INSERT INTO nuke_mme_mediaitems VALUES (1,'',0,'');

--
-- Table structure for table 'nuke_module_vars'
--

CREATE TABLE nuke_module_vars (
  pn_id int(11) unsigned NOT NULL auto_increment,
  pn_modname varchar(64) NOT NULL default '',
  pn_name varchar(64) NOT NULL default '',
  pn_value longtext,
  PRIMARY KEY  (pn_id),
  KEY pn_modname (pn_modname),
  KEY pn_name (pn_name)
) TYPE=MyISAM;

--
-- Dumping data for table 'nuke_module_vars'
--


INSERT INTO nuke_module_vars VALUES (1,'/PNConfig','debug','i:0;');
INSERT INTO nuke_module_vars VALUES (2,'/PNConfig','sitename','s:7:\"IDEAS-3\";');
INSERT INTO nuke_module_vars VALUES (3,'/PNConfig','site_logo','s:17:\"images/raf_n1.png\";');
INSERT INTO nuke_module_vars VALUES (4,'/PNConfig','slogan','s:64:\"Instrument Development and Education in Airborne Science Phase 3\";');
INSERT INTO nuke_module_vars VALUES (5,'/PNConfig','metakeywords','s:88:\"Education, IDEAS, IDEAS1, IDEAS2, IDEAS3, atmosphere, atmospheric, research, environment\";');
INSERT INTO nuke_module_vars VALUES (107,'/PNConfig','censormode','s:1:\"1\";');
INSERT INTO nuke_module_vars VALUES (6,'/PNConfig','dyn_keywords','i:0;');
INSERT INTO nuke_module_vars VALUES (7,'/PNConfig','startdate','s:11:\"August 2003\";');
INSERT INTO nuke_module_vars VALUES (8,'/PNConfig','adminmail','s:16:\"stither@ucar.edu\";');
INSERT INTO nuke_module_vars VALUES (9,'/PNConfig','Default_Theme','s:9:\"IDEASNuke\";');
INSERT INTO nuke_module_vars VALUES (10,'/PNConfig','foot1','s:435:\"<center><b><i>\r\n<a href=\"http://raf.atd.ucar.edu/Projects/IDEAS-1\">Phase&nbsp;1&nbsp;IDEAS&nbsp;Home&nbsp;Page</a> |\r\n<a href=\"http://raf.atd.ucar.edu/Projects/IDEAS-2\">Phase&nbsp;2&nbsp;IDEAS&nbsp;Home&nbsp;Page</a> |\r\n<a href=\"http://raf.atd.ucar.edu/\">RAF&nbsp;Home&nbsp;Page</a> |\r\n<a href=\"http://www.atd.ucar.edu/\">ATD&nbsp;Home&nbsp;Page</a> |\r\n<a href=\"http://www.ncar.ucar.edu/\">NCAR&nbsp;Home&nbsp;Page</a>\r\n</i></b></center>\";');
INSERT INTO nuke_module_vars VALUES (11,'/PNConfig','commentlimit','i:4096;');
INSERT INTO nuke_module_vars VALUES (12,'/PNConfig','anonymous','s:9:\"Anonymous\";');
INSERT INTO nuke_module_vars VALUES (13,'/PNConfig','defaultgroup','s:5:\"Users\";');
INSERT INTO nuke_module_vars VALUES (14,'/PNConfig','timezone_offset','s:1:\"5\";');
INSERT INTO nuke_module_vars VALUES (15,'/PNConfig','nobox','i:0;');
INSERT INTO nuke_module_vars VALUES (16,'/PNConfig','funtext','s:1:\"1\";');
INSERT INTO nuke_module_vars VALUES (17,'/PNConfig','reportlevel','i:0;');
INSERT INTO nuke_module_vars VALUES (18,'/PNConfig','startpage','s:4:\"News\";');
INSERT INTO nuke_module_vars VALUES (19,'/PNConfig','admingraphic','s:1:\"1\";');
INSERT INTO nuke_module_vars VALUES (20,'/PNConfig','admart','s:2:\"10\";');
INSERT INTO nuke_module_vars VALUES (21,'/PNConfig','backend_title','s:21:\"PostNuke Powered Site\";');
INSERT INTO nuke_module_vars VALUES (22,'/PNConfig','backend_language','s:5:\"en-us\";');
INSERT INTO nuke_module_vars VALUES (23,'/PNConfig','seclevel','s:6:\"Medium\";');
INSERT INTO nuke_module_vars VALUES (24,'/PNConfig','secmeddays','i:7;');
INSERT INTO nuke_module_vars VALUES (25,'/PNConfig','secinactivemins','s:2:\"60\";');
INSERT INTO nuke_module_vars VALUES (26,'/PNConfig','Version_Num','s:5:\"0.7.2\";');
INSERT INTO nuke_module_vars VALUES (27,'/PNConfig','Version_ID','s:8:\"PostNuke\";');
INSERT INTO nuke_module_vars VALUES (28,'/PNConfig','Version_Sub','s:5:\"Rogue\";');
INSERT INTO nuke_module_vars VALUES (29,'/PNConfig','debug_sql','i:0;');
INSERT INTO nuke_module_vars VALUES (30,'/PNConfig','anonpost','i:1;');
INSERT INTO nuke_module_vars VALUES (31,'/PNConfig','minpass','i:5;');
INSERT INTO nuke_module_vars VALUES (32,'/PNConfig','pollcomm','i:1;');
INSERT INTO nuke_module_vars VALUES (33,'/PNConfig','minage','s:1:\"0\";');
INSERT INTO nuke_module_vars VALUES (34,'/PNConfig','top','s:1:\"5\";');
INSERT INTO nuke_module_vars VALUES (35,'/PNConfig','storyhome','s:1:\"5\";');
INSERT INTO nuke_module_vars VALUES (36,'/PNConfig','banners','s:1:\"0\";');
INSERT INTO nuke_module_vars VALUES (37,'/PNConfig','myIP','s:12:\"150.10.10.10\";');
INSERT INTO nuke_module_vars VALUES (38,'/PNConfig','language','s:3:\"eng\";');
INSERT INTO nuke_module_vars VALUES (39,'/PNConfig','locale','s:5:\"en_US\";');
INSERT INTO nuke_module_vars VALUES (40,'/PNConfig','multilingual','i:1;');
INSERT INTO nuke_module_vars VALUES (41,'/PNConfig','useflags','i:0;');
INSERT INTO nuke_module_vars VALUES (42,'/PNConfig','perpage','i:10;');
INSERT INTO nuke_module_vars VALUES (43,'/PNConfig','popular','i:500;');
INSERT INTO nuke_module_vars VALUES (44,'/PNConfig','newlinks','i:10;');
INSERT INTO nuke_module_vars VALUES (45,'/PNConfig','toplinks','i:25;');
INSERT INTO nuke_module_vars VALUES (46,'/PNConfig','linksresults','i:10;');
INSERT INTO nuke_module_vars VALUES (47,'/PNConfig','links_anonaddlinklock','i:1;');
INSERT INTO nuke_module_vars VALUES (48,'/PNConfig','anonwaitdays','i:1;');
INSERT INTO nuke_module_vars VALUES (49,'/PNConfig','outsidewaitdays','i:1;');
INSERT INTO nuke_module_vars VALUES (50,'/PNConfig','useoutsidevoting','i:1;');
INSERT INTO nuke_module_vars VALUES (51,'/PNConfig','anonweight','i:10;');
INSERT INTO nuke_module_vars VALUES (52,'/PNConfig','outsideweight','i:20;');
INSERT INTO nuke_module_vars VALUES (53,'/PNConfig','detailvotedecimal','i:2;');
INSERT INTO nuke_module_vars VALUES (54,'/PNConfig','mainvotedecimal','i:1;');
INSERT INTO nuke_module_vars VALUES (55,'/PNConfig','toplinkspercentrigger','i:0;');
INSERT INTO nuke_module_vars VALUES (56,'/PNConfig','mostpoplinkspercentrigger','i:0;');
INSERT INTO nuke_module_vars VALUES (57,'/PNConfig','mostpoplinks','i:25;');
INSERT INTO nuke_module_vars VALUES (58,'/PNConfig','featurebox','i:1;');
INSERT INTO nuke_module_vars VALUES (59,'/PNConfig','linkvotemin','i:5;');
INSERT INTO nuke_module_vars VALUES (60,'/PNConfig','blockunregmodify','i:0;');
INSERT INTO nuke_module_vars VALUES (61,'/PNConfig','newdownloads','i:10;');
INSERT INTO nuke_module_vars VALUES (62,'/PNConfig','topdownloads','i:25;');
INSERT INTO nuke_module_vars VALUES (63,'/PNConfig','downloadsresults','i:10;');
INSERT INTO nuke_module_vars VALUES (64,'/PNConfig','downloads_anonadddownloadlock','i:0;');
INSERT INTO nuke_module_vars VALUES (65,'/PNConfig','topdownloadspercentrigger','i:0;');
INSERT INTO nuke_module_vars VALUES (66,'/PNConfig','mostpopdownloadspercentrigger','i:0;');
INSERT INTO nuke_module_vars VALUES (67,'/PNConfig','mostpopdownloads','i:25;');
INSERT INTO nuke_module_vars VALUES (68,'/PNConfig','downloadvotemin','i:5;');
INSERT INTO nuke_module_vars VALUES (69,'/PNConfig','notify','s:1:\"0\";');
INSERT INTO nuke_module_vars VALUES (70,'/PNConfig','notify_email','s:16:\"stither@ucar.edu\";');
INSERT INTO nuke_module_vars VALUES (71,'/PNConfig','notify_subject','s:16:\"NEWS for my site\";');
INSERT INTO nuke_module_vars VALUES (72,'/PNConfig','notify_message','s:48:\"Hey! You got a new submission for your site.\r\n\r\n\";');
INSERT INTO nuke_module_vars VALUES (73,'/PNConfig','notify_from','s:9:\"webmaster\";');
INSERT INTO nuke_module_vars VALUES (74,'/PNConfig','moderate','i:1;');
INSERT INTO nuke_module_vars VALUES (75,'/PNConfig','BarScale','i:1;');
INSERT INTO nuke_module_vars VALUES (76,'/PNConfig','tipath','s:14:\"images/topics/\";');
INSERT INTO nuke_module_vars VALUES (77,'/PNConfig','userimg','s:11:\"images/menu\";');
INSERT INTO nuke_module_vars VALUES (78,'/PNConfig','usergraphic','i:1;');
INSERT INTO nuke_module_vars VALUES (79,'/PNConfig','topicsinrow','s:1:\"1\";');
INSERT INTO nuke_module_vars VALUES (80,'/PNConfig','httpref','i:1;');
INSERT INTO nuke_module_vars VALUES (81,'/PNConfig','httprefmax','i:1000;');
INSERT INTO nuke_module_vars VALUES (83,'/PNConfig','reasons','a:11:{i:0;s:5:\"As Is\";i:1;s:8:\"Offtopic\";i:2;s:9:\"Flamebait\";i:3;s:5:\"Troll\";i:4;s:9:\"Redundant\";i:5;s:10:\"Insightful\";i:6;s:11:\"Interesting\";i:7;s:11:\"Informative\";i:8;s:5:\"Funny\";i:9;s:9:\"Overrated\";i:10;s:10:\"Underrated\";}');
INSERT INTO nuke_module_vars VALUES (84,'/PNConfig','AllowableHTML','a:83:{s:3:\"!--\";i:0;s:1:\"a\";s:1:\"2\";s:4:\"abbr\";i:0;s:7:\"acronym\";i:0;s:7:\"address\";i:0;s:6:\"applet\";i:0;s:4:\"area\";i:0;s:1:\"b\";s:1:\"2\";s:4:\"base\";i:0;s:8:\"basefont\";i:0;s:3:\"bdo\";i:0;s:3:\"big\";s:1:\"2\";s:10:\"blockquote\";s:1:\"2\";s:2:\"br\";s:1:\"1\";s:6:\"button\";i:0;s:7:\"caption\";i:0;s:6:\"center\";s:1:\"2\";s:4:\"cite\";i:0;s:4:\"code\";i:0;s:3:\"col\";i:0;s:8:\"colgroup\";i:0;s:3:\"del\";i:0;s:3:\"dfn\";i:0;s:3:\"dir\";i:0;s:3:\"div\";s:1:\"2\";s:2:\"dl\";i:0;s:2:\"dd\";i:0;s:2:\"dt\";i:0;s:2:\"em\";s:1:\"2\";s:5:\"embed\";i:0;s:8:\"fieldset\";i:0;s:4:\"font\";s:1:\"2\";s:4:\"form\";i:0;s:2:\"h1\";s:1:\"2\";s:2:\"h2\";s:1:\"2\";s:2:\"h3\";s:1:\"2\";s:2:\"h4\";i:0;s:2:\"h5\";i:0;s:2:\"h6\";i:0;s:2:\"hr\";s:1:\"2\";s:1:\"i\";s:1:\"2\";s:6:\"iframe\";s:1:\"2\";s:3:\"img\";s:1:\"2\";s:5:\"input\";i:0;s:3:\"ins\";i:0;s:3:\"kbd\";i:0;s:5:\"label\";i:0;s:6:\"legend\";i:0;s:2:\"li\";s:1:\"2\";s:3:\"map\";i:0;s:7:\"marquee\";i:0;s:4:\"menu\";i:0;s:4:\"nobr\";i:0;s:6:\"object\";i:0;s:2:\"ol\";s:1:\"2\";s:8:\"optgroup\";i:0;s:6:\"option\";i:0;s:1:\"p\";s:1:\"2\";s:5:\"param\";i:0;s:3:\"pre\";s:1:\"2\";s:1:\"q\";i:0;s:1:\"s\";i:0;s:4:\"samp\";i:0;s:6:\"script\";i:0;s:6:\"select\";i:0;s:5:\"small\";i:0;s:4:\"span\";i:0;s:6:\"strike\";i:0;s:6:\"strong\";s:1:\"2\";s:3:\"sub\";s:1:\"2\";s:3:\"sup\";s:1:\"2\";s:5:\"table\";s:1:\"2\";s:5:\"tbody\";i:0;s:2:\"td\";s:1:\"2\";s:8:\"textarea\";i:0;s:5:\"tfoot\";i:0;s:2:\"th\";s:1:\"2\";s:5:\"thead\";i:0;s:2:\"tr\";s:1:\"2\";s:2:\"tt\";s:1:\"2\";s:1:\"u\";s:1:\"2\";s:2:\"ul\";s:1:\"2\";s:3:\"var\";i:0;}');
INSERT INTO nuke_module_vars VALUES (85,'/PNConfig','CensorList','a:14:{i:0;s:4:\"fuck\";i:1;s:4:\"cunt\";i:2;s:6:\"fucker\";i:3;s:7:\"fucking\";i:4;s:5:\"pussy\";i:5;s:4:\"cock\";i:6;s:4:\"c0ck\";i:7;s:3:\"cum\";i:8;s:4:\"twat\";i:9;s:4:\"clit\";i:10;s:5:\"bitch\";i:11;s:3:\"fuk\";i:12;s:6:\"fuking\";i:13;s:12:\"motherfucker\";}');
INSERT INTO nuke_module_vars VALUES (86,'/PNConfig','CensorMode','i:1;');
INSERT INTO nuke_module_vars VALUES (87,'/PNConfig','CensorReplace','s:5:\"*****\";');
INSERT INTO nuke_module_vars VALUES (90,'/PNConfig','theme_change','s:1:\"1\";');
INSERT INTO nuke_module_vars VALUES (91,'Ratings','defaultstyle','outoffivestars');
INSERT INTO nuke_module_vars VALUES (92,'Ratings','seclevel','medium');
INSERT INTO nuke_module_vars VALUES (93,'/PNConfig','intranet','i:0;');
INSERT INTO nuke_module_vars VALUES (94,'Wiki','AllowedProtocols','http|https|mailto|ftp|news|gopher');
INSERT INTO nuke_module_vars VALUES (95,'Wiki','ExtlinkNewWindow','0');
INSERT INTO nuke_module_vars VALUES (97,'Wiki','IntlinkNewWindow','0');
INSERT INTO nuke_module_vars VALUES (98,'Wiki','FieldSeparator','�');
INSERT INTO nuke_module_vars VALUES (99,'Wiki','InlineImages','png|jpg|gif');
INSERT INTO nuke_module_vars VALUES (100,'Blocks','collapseable','1');
INSERT INTO nuke_module_vars VALUES (101,'/PNConfig','htmlentities','s:1:\"1\";');
INSERT INTO nuke_module_vars VALUES (102,'/PNConfig','UseCompression','s:1:\"1\";');
INSERT INTO nuke_module_vars VALUES (103,'/PNConfig','refereronprint','i:0;');
INSERT INTO nuke_module_vars VALUES (104,'/PNConfig','WYSIWYGEditor','s:1:\"1\";');
INSERT INTO nuke_module_vars VALUES (105,'/PNConfig','storyorder','s:1:\"1\";');
INSERT INTO nuke_module_vars VALUES (106,'/PNConfig','pnAntiCracker','i:0;');
INSERT INTO nuke_module_vars VALUES (108,'ContentExpress','default_cid','-2');
INSERT INTO nuke_module_vars VALUES (109,'ContentExpress','default_url','');
INSERT INTO nuke_module_vars VALUES (110,'ContentExpress','enable_qadmin','1');
INSERT INTO nuke_module_vars VALUES (111,'ContentExpress','enable_aclean','0');
INSERT INTO nuke_module_vars VALUES (112,'ContentExpress','enable_top_print','1');
INSERT INTO nuke_module_vars VALUES (113,'ContentExpress','enable_bottom_print','0');
INSERT INTO nuke_module_vars VALUES (114,'ContentExpress','enable_wysiwyg','ie2');
INSERT INTO nuke_module_vars VALUES (115,'ContentExpress','wysiwyg_height','60');
INSERT INTO nuke_module_vars VALUES (116,'ContentExpress','wysiwyg_width','80');
INSERT INTO nuke_module_vars VALUES (117,'ContentExpress','enable_display_navigation','1');
INSERT INTO nuke_module_vars VALUES (118,'ContentExpress','index_depth','-1');
INSERT INTO nuke_module_vars VALUES (119,'ContentExpress','enable_top_sendfriend','1');
INSERT INTO nuke_module_vars VALUES (120,'ContentExpress','enable_bottom_sendfriend','0');
INSERT INTO nuke_module_vars VALUES (121,'ContentExpress','show_last_updated','1');
INSERT INTO nuke_module_vars VALUES (122,'ContentExpress','show_times_read','1');
INSERT INTO nuke_module_vars VALUES (123,'ContentExpress','timeformat','%Y-%m-%d %H:%M:%S');
INSERT INTO nuke_module_vars VALUES (124,'ContentExpress','show_times_read_index','1');
INSERT INTO nuke_module_vars VALUES (125,'ContentExpress','show_author_index','0');
INSERT INTO nuke_module_vars VALUES (126,'MediaExpress','media_types','application/x-shockwave-flash;application/msword;application/mspowerpoint;application/vnd.ms-project;application/pdf;application/x-pdf;image/jpeg;image/gif;image/pjpeg;image/x-png;image/png');
INSERT INTO nuke_module_vars VALUES (127,'MediaExpress','max_media_size','50000');
INSERT INTO nuke_module_vars VALUES (128,'MediaExpress','media_width','0');
INSERT INTO nuke_module_vars VALUES (129,'MediaExpress','media_height','0');
INSERT INTO nuke_module_vars VALUES (130,'MediaExpress','media_repository','img_repository');
INSERT INTO nuke_module_vars VALUES (131,'MenuExpress','enable_qadmin','1');
INSERT INTO nuke_module_vars VALUES (132,'MenuExpress','pnmenu_style','1');
INSERT INTO nuke_module_vars VALUES (133,'MenuExpress','max_img_size','3000');
INSERT INTO nuke_module_vars VALUES (384,'PostCalendar','pcNotifyEmail','ruth@ucar.edu');
INSERT INTO nuke_module_vars VALUES (383,'PostCalendar','pcNotifyAdmin','0');
INSERT INTO nuke_module_vars VALUES (382,'PostCalendar','pcCacheLifetime','3600');
INSERT INTO nuke_module_vars VALUES (381,'PostCalendar','pcUseCache','0');
INSERT INTO nuke_module_vars VALUES (380,'PostCalendar','pcDefaultView','month');
INSERT INTO nuke_module_vars VALUES (379,'PostCalendar','pcTimeIncrement','15');
INSERT INTO nuke_module_vars VALUES (378,'PostCalendar','pcAllowUserCalendar','1');
INSERT INTO nuke_module_vars VALUES (377,'PostCalendar','pcAllowSiteWide','1');
INSERT INTO nuke_module_vars VALUES (376,'PostCalendar','pcTemplate','default');
INSERT INTO nuke_module_vars VALUES (375,'PostCalendar','pcEventDateFormat','%Y-%m-%d');
INSERT INTO nuke_module_vars VALUES (374,'PostCalendar','pcDisplayTopics','1');
INSERT INTO nuke_module_vars VALUES (373,'PostCalendar','pcListHowManyEvents','15');
INSERT INTO nuke_module_vars VALUES (372,'PostCalendar','pcAllowDirectSubmit','1');
INSERT INTO nuke_module_vars VALUES (371,'PostCalendar','pcUsePopups','1');
INSERT INTO nuke_module_vars VALUES (370,'PostCalendar','pcDayHighlightColor','#8080FF');
INSERT INTO nuke_module_vars VALUES (369,'PostCalendar','pcFirstDayOfWeek','0');
INSERT INTO nuke_module_vars VALUES (368,'PostCalendar','pcUseInternationalDates','0');
INSERT INTO nuke_module_vars VALUES (367,'PostCalendar','pcEventsOpenInNewWindow','0');
INSERT INTO nuke_module_vars VALUES (172,'ew_filemanager','wysiwygeditor','2');
INSERT INTO nuke_module_vars VALUES (173,'ew_filemanager','maxfilesize','1000000');
INSERT INTO nuke_module_vars VALUES (174,'ew_filemanager','hddspace','100000000');
INSERT INTO nuke_module_vars VALUES (175,'ew_filemanager','hiddenfiles','.htaccess');
INSERT INTO nuke_module_vars VALUES (176,'ew_filemanager','hiddendirs','');
INSERT INTO nuke_module_vars VALUES (177,'ew_filemanager','editextensions','htm,html,txt');
INSERT INTO nuke_module_vars VALUES (178,'ew_filemanager','imageextensions','jpg,jpeg,png,bmp,gif');
INSERT INTO nuke_module_vars VALUES (179,'ew_filemanager','pagespath','filex/');
INSERT INTO nuke_module_vars VALUES (180,'ew_filemanager','textareawidth','80');
INSERT INTO nuke_module_vars VALUES (181,'ew_filemanager','textareaheight','40');
INSERT INTO nuke_module_vars VALUES (182,'pnchat','myvar','0');
INSERT INTO nuke_module_vars VALUES (183,'phpBB_14','posts_per_page','15');
INSERT INTO nuke_module_vars VALUES (184,'phpBB_14','topics_per_page','15');
INSERT INTO nuke_module_vars VALUES (185,'phpBB_14','hot_threshold','5');
INSERT INTO nuke_module_vars VALUES (186,'phpBB_14','email_from','');
INSERT INTO nuke_module_vars VALUES (187,'phpBB_14','default_lang','iso-8859-1');
INSERT INTO nuke_module_vars VALUES (188,'phpBB_14','url_smiles','modules/phpBB_14/images/smiles');
INSERT INTO nuke_module_vars VALUES (189,'phpBB_14','url_ranks_images','modules/phpBB_14/images/ranks');
INSERT INTO nuke_module_vars VALUES (190,'phpBB_14','folder_image','modules/phpBB_14/images/folder.gif');
INSERT INTO nuke_module_vars VALUES (191,'phpBB_14','hot_folder_image','modules/phpBB_14/images/hot_folder.gif');
INSERT INTO nuke_module_vars VALUES (192,'phpBB_14','newposts_image','modules/phpBB_14/images/red_folder.gif');
INSERT INTO nuke_module_vars VALUES (193,'phpBB_14','hot_newposts_image','modules/phpBB_14/images/hot_red_folder.gif');
INSERT INTO nuke_module_vars VALUES (194,'phpBB_14','posticon','modules/phpBB_14/images/posticon.gif');
INSERT INTO nuke_module_vars VALUES (195,'phpBB_14','profile_image','');
INSERT INTO nuke_module_vars VALUES (196,'phpBB_14','locked_image','modules/phpBB_14/images/lock.gif');
INSERT INTO nuke_module_vars VALUES (197,'phpBB_14','locktopic_image','modules/phpBB_14/images/lock_topic.gif');
INSERT INTO nuke_module_vars VALUES (198,'phpBB_14','deltopic_image','modules/phpBB_14/images/del_topic.gif');
INSERT INTO nuke_module_vars VALUES (199,'phpBB_14','movetopic_image','modules/phpBB_14/images/move_topic.gif');
INSERT INTO nuke_module_vars VALUES (200,'phpBB_14','unlocktopic_image','modules/phpBB_14/images/unlock_topic.gif');
INSERT INTO nuke_module_vars VALUES (201,'phpBB_14','stickytopic_image','modules/phpBB_14/images/sticky.gif');
INSERT INTO nuke_module_vars VALUES (202,'phpBB_14','unstickytopic_image','modules/phpBB_14/images/unsticky.gif');
INSERT INTO nuke_module_vars VALUES (203,'phpBB_14','firstnew_image','modules/phpBB_14/images/firstnew.gif');
INSERT INTO nuke_module_vars VALUES (204,'phpBB_14','post_sort_order','DESC');
INSERT INTO nuke_module_vars VALUES (205,'phpBB_14','show_html','yes');
INSERT INTO nuke_module_vars VALUES (206,'phpBB_14','show_bbcode','yes');
INSERT INTO nuke_module_vars VALUES (207,'phpBB_14','show_smile','yes');
INSERT INTO nuke_module_vars VALUES (208,'phpBB_14','log_ip','yes');
INSERT INTO nuke_module_vars VALUES (209,'/PNConfig','pncusrmodreg','s:1:\"0\";');
INSERT INTO nuke_module_vars VALUES (210,'/PNConfig','allowuserpass','s:1:\"1\";');
INSERT INTO nuke_module_vars VALUES (211,'/PNConfig','allowuserdelete','s:1:\"1\";');
INSERT INTO nuke_module_vars VALUES (212,'/PNConfig','blkusrreg','s:1:\"0\";');
INSERT INTO nuke_module_vars VALUES (213,'/PNConfig','pncuaadvreg','s:1:\"1\";');
INSERT INTO nuke_module_vars VALUES (214,'/PNConfig','sendaddmail','s:1:\"1\";');
INSERT INTO nuke_module_vars VALUES (215,'/PNConfig','senduserpass','s:1:\"1\";');
INSERT INTO nuke_module_vars VALUES (216,'/PNConfig','senddeletemail','s:1:\"1\";');
INSERT INTO nuke_module_vars VALUES (217,'/PNConfig','pnc_mail_modusrwning','s:1:\"0\";');
INSERT INTO nuke_module_vars VALUES (218,'/PNConfig','pnc_mail_adminwning','s:1:\"1\";');
INSERT INTO nuke_module_vars VALUES (219,'/PNConfig','pnc_mail_usrregok','s:1:\"0\";');
INSERT INTO nuke_module_vars VALUES (220,'/PNConfig','pnc_mail_usrregsorry','s:1:\"0\";');
INSERT INTO nuke_module_vars VALUES (221,'PostWrap','allow_local_only','0');
INSERT INTO nuke_module_vars VALUES (222,'PostWrap','use_buffering','1');
INSERT INTO nuke_module_vars VALUES (223,'PostWrap','use_compression','1');
INSERT INTO nuke_module_vars VALUES (224,'PostWrap','reg_user_only','0');
INSERT INTO nuke_module_vars VALUES (225,'PostWrap','no_user_entry','1');
INSERT INTO nuke_module_vars VALUES (226,'PostWrap','open_direct','1');
INSERT INTO nuke_module_vars VALUES (227,'PostWrap','use_fixed_title','0');
INSERT INTO nuke_module_vars VALUES (228,'PostWrap','auto_resize','0');
INSERT INTO nuke_module_vars VALUES (229,'PostWrap','vsize','95%');
INSERT INTO nuke_module_vars VALUES (230,'PostWrap','hsize','100%');
INSERT INTO nuke_module_vars VALUES (231,'PostWrap','security','0');
INSERT INTO nuke_module_vars VALUES (232,'PostWrap','default_size','');
INSERT INTO nuke_module_vars VALUES (366,'PostCalendar','pcTime24Hours','0');

--
-- Table structure for table 'nuke_modules'
--

CREATE TABLE nuke_modules (
  pn_id int(11) unsigned NOT NULL auto_increment,
  pn_name varchar(64) NOT NULL default '',
  pn_type int(6) NOT NULL default '0',
  pn_displayname varchar(64) NOT NULL default '',
  pn_description varchar(255) NOT NULL default '',
  pn_regid int(11) unsigned NOT NULL default '0',
  pn_directory varchar(64) NOT NULL default '',
  pn_version varchar(10) NOT NULL default '0',
  pn_admin_capable tinyint(1) NOT NULL default '0',
  pn_user_capable tinyint(1) NOT NULL default '0',
  pn_state tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (pn_id)
) TYPE=MyISAM;

--
-- Dumping data for table 'nuke_modules'
--


INSERT INTO nuke_modules VALUES (1,'AvantGo',1,'AvantGo','News for your PDA',2,'AvantGo','1.3',0,1,2);
INSERT INTO nuke_modules VALUES (2,'Downloads',1,'Downloads','Files to download',3,'Downloads','1.3',1,1,5);
INSERT INTO nuke_modules VALUES (3,'FAQ',1,'FAQ','Frequently Asked Questions',4,'FAQ','1.11',1,1,3);
INSERT INTO nuke_modules VALUES (4,'Members_List',1,'Members List','Information on users of this site',5,'Members_List','1.0',0,1,5);
INSERT INTO nuke_modules VALUES (5,'Messages',1,'Messages','Private messages to users of this site',6,'Messages','1.0',0,1,3);
INSERT INTO nuke_modules VALUES (6,'AddStory',1,'AddStory','Add a story',8,'NS-AddStory','1.0',1,0,3);
INSERT INTO nuke_modules VALUES (7,'Admin',1,'Admin','Administration',9,'NS-Admin','0.1',1,0,3);
INSERT INTO nuke_modules VALUES (8,'Admin_Messages',1,'Admin Messages','Banner messages',10,'NS-Admin_Messages','1.2',1,0,3);
INSERT INTO nuke_modules VALUES (9,'Autolinks',1,'Autolinks','Automatically add links to text',11,'Autolinks','1.0',1,0,1);
INSERT INTO nuke_modules VALUES (10,'Banners',1,'Banners','Banners',12,'NS-Banners','1.0',1,0,2);
INSERT INTO nuke_modules VALUES (11,'Blocks',2,'Blocks','Side blocks',13,'Blocks','2.0',1,0,3);
INSERT INTO nuke_modules VALUES (12,'Comments',1,'Comments','Comment on articles',14,'NS-Comments','1.1',1,1,3);
INSERT INTO nuke_modules VALUES (13,'Ephemerids',1,'Ephemerids','Daily events',15,'NS-Ephemerids','1.2',1,0,2);
INSERT INTO nuke_modules VALUES (14,'Groups',1,'Groups','Set up administrative groups',16,'NS-Groups','0.1',1,0,3);
INSERT INTO nuke_modules VALUES (15,'Languages',1,'Languages','Multi-language functions',17,'NS-Languages','1.2',1,0,3);
INSERT INTO nuke_modules VALUES (16,'MailUsers',1,'MailUsers','Mail your users',19,'NS-MailUsers','1.3',1,0,3);
INSERT INTO nuke_modules VALUES (17,'Modules',2,'Modules','Module configuration',1,'Modules','2.0',1,0,3);
INSERT INTO nuke_modules VALUES (18,'Permissions',2,'Permissions','Configure permissions',22,'Permissions','0.1',1,0,3);
INSERT INTO nuke_modules VALUES (19,'Polls',1,'Polls','Polls and surveys',23,'NS-Polls','1.1',1,1,2);
INSERT INTO nuke_modules VALUES (20,'Quotes',2,'Quotes','Quotes and sayings',24,'Quotes','1.3',1,0,2);
INSERT INTO nuke_modules VALUES (21,'Referers',1,'Referers','Referers',25,'NS-Referers','1.2',1,0,3);
INSERT INTO nuke_modules VALUES (22,'Settings',1,'Settings','Settings',26,'NS-Settings','1.2',1,0,3);
INSERT INTO nuke_modules VALUES (23,'News',1,'News','News items',7,'News','1.3',0,1,3);
INSERT INTO nuke_modules VALUES (24,'Recommend_Us',1,'Recommend Us','Recommend us to a friend',30,'Recommend_Us','1.0',0,1,2);
INSERT INTO nuke_modules VALUES (25,'Reviews',1,'Reviews','Reviews',31,'Reviews','1.0',1,1,2);
INSERT INTO nuke_modules VALUES (26,'Search',1,'Search','Search this site',32,'Search','1.0',0,1,3);
INSERT INTO nuke_modules VALUES (27,'Sections',1,'Sections','Sections',33,'Sections','1.0',1,1,3);
INSERT INTO nuke_modules VALUES (28,'Stats',1,'Stats','Site statistics',34,'Stats','1.12',0,1,5);
INSERT INTO nuke_modules VALUES (29,'Submit_News',1,'Submit News','Contribute a story',35,'Submit_News','1.13',1,1,3);
INSERT INTO nuke_modules VALUES (30,'Top_List',1,'Top List','Top 10 listings',38,'Top_List','1.0',1,1,3);
INSERT INTO nuke_modules VALUES (31,'Topics',1,'Topics','Article topics',37,'Topics','1.0',1,1,3);
INSERT INTO nuke_modules VALUES (32,'User',1,'Users','User Administration',27,'NS-User','0.1',1,1,3);
INSERT INTO nuke_modules VALUES (33,'Web_Links',1,'Web Links','Links to other sites',39,'Web_Links','1.0',1,1,3);
INSERT INTO nuke_modules VALUES (34,'Ratings',2,'Ratings','Ratings utility',41,'Ratings','1.1',0,0,3);
INSERT INTO nuke_modules VALUES (35,'Wiki',2,'Wiki','Wiki encoding',28,'Wiki','1.0',0,0,3);
INSERT INTO nuke_modules VALUES (36,'xmlrpc',2,'xmlrpc','XML-RPC utility module',42,'xmlrpc','1.0',0,0,5);
INSERT INTO nuke_modules VALUES (37,'legal',1,'Legal Documents','Generic Privacy Statement and Terms of Use',43,'legal','1.0',0,1,3);
INSERT INTO nuke_modules VALUES (38,'Censor',2,'Censor','Site Censorship Control',0,'Censor','1.0',1,0,1);
INSERT INTO nuke_modules VALUES (39,'Credits',2,'Credits','Display Module credits, license, help and contact information',0,'Credits','1.1',0,1,1);
INSERT INTO nuke_modules VALUES (40,'LostPassword',1,'LostPassword','Retrive lost password of a user.',18,'NS-LostPassword','0,5',0,0,1);
INSERT INTO nuke_modules VALUES (41,'Multisites',1,'Multisites','',20,'NS-Multisites','0',0,0,1);
INSERT INTO nuke_modules VALUES (42,'NewUser',1,'NewUser','New User for postnuke.',21,'NS-NewUser','0,5',0,0,1);
INSERT INTO nuke_modules VALUES (68,'Kalender',1,'Kalender','',0,'Kalender','0',0,0,1);
INSERT INTO nuke_modules VALUES (44,'Your_Account',1,'Your Account','User options',0,'NS-Your_Account','0.8',0,0,5);
INSERT INTO nuke_modules VALUES (45,'Template',2,'Template','Template for new modules',0,'Template','1.0',1,1,1);
INSERT INTO nuke_modules VALUES (47,'ContentExpress',2,'ContentExpress','Menus/Pages Management Module',0,'ContentExpress','1.2.6.0',1,1,3);
INSERT INTO nuke_modules VALUES (49,'PostCalendar',2,'PostCalendar','PostNuke Calendar Module',0,'PostCalendar','4.0.0',1,1,3);
INSERT INTO nuke_modules VALUES (64,'mac_jIRC',2,'mac jIRC','jIRC Chat Module',0,'mac_jIRC','1.0',0,1,1);
INSERT INTO nuke_modules VALUES (51,'ns-your_account',1,'ns-your account','',0,'ns-your_account','0',0,0,1);
INSERT INTO nuke_modules VALUES (63,'Past_Nuke',1,'Past Nuke','Old Post-Nuke admin compatibility',0,'NS-Past_Nuke','1.0',1,0,1);
INSERT INTO nuke_modules VALUES (52,'ew_filemanager',2,'ew filemanager','File Manager for PN',0,'ew_filemanager','1.0',1,1,3);
INSERT INTO nuke_modules VALUES (58,'phpBB_14',1,'phpBB 14','phpBB-style Bulletin Board',0,'phpBB_14','1.7.5',1,1,3);
INSERT INTO nuke_modules VALUES (55,'pnCGIIRC',1,'pnCGIIRC','Wrapper for the CGI::IRC cgi webchat',0,'pnCGIIRC','0.4 beta 2',0,1,3);
INSERT INTO nuke_modules VALUES (61,'PostWrap',2,'PostWrap','Incorporate external sites or apps',0,'PostWrap','2.1',1,1,3);
INSERT INTO nuke_modules VALUES (67,'wb3',1,'wb3','',0,'wb3','0',0,0,1);

--
-- Table structure for table 'nuke_phpbb14_categories'
--

CREATE TABLE nuke_phpbb14_categories (
  cat_id int(10) NOT NULL auto_increment,
  cat_title varchar(100) default NULL,
  cat_order varchar(10) default NULL,
  PRIMARY KEY  (cat_id)
) TYPE=MyISAM;

--
-- Dumping data for table 'nuke_phpbb14_categories'
--


INSERT INTO nuke_phpbb14_categories VALUES (3,'IDEAS','1');
INSERT INTO nuke_phpbb14_categories VALUES (5,'This Website','2');
INSERT INTO nuke_phpbb14_categories VALUES (6,'Project Status','3');

--
-- Table structure for table 'nuke_phpbb14_forum_mods'
--

CREATE TABLE nuke_phpbb14_forum_mods (
  forum_id int(10) NOT NULL default '0',
  user_id int(10) NOT NULL default '0'
) TYPE=MyISAM;

--
-- Dumping data for table 'nuke_phpbb14_forum_mods'
--


INSERT INTO nuke_phpbb14_forum_mods VALUES (1,18);
INSERT INTO nuke_phpbb14_forum_mods VALUES (2,18);
INSERT INTO nuke_phpbb14_forum_mods VALUES (3,16);
INSERT INTO nuke_phpbb14_forum_mods VALUES (3,17);
INSERT INTO nuke_phpbb14_forum_mods VALUES (4,16);
INSERT INTO nuke_phpbb14_forum_mods VALUES (4,17);
INSERT INTO nuke_phpbb14_forum_mods VALUES (5,17);
INSERT INTO nuke_phpbb14_forum_mods VALUES (1,17);
INSERT INTO nuke_phpbb14_forum_mods VALUES (1,19);
INSERT INTO nuke_phpbb14_forum_mods VALUES (2,17);
INSERT INTO nuke_phpbb14_forum_mods VALUES (2,19);
INSERT INTO nuke_phpbb14_forum_mods VALUES (5,18);
INSERT INTO nuke_phpbb14_forum_mods VALUES (5,19);
INSERT INTO nuke_phpbb14_forum_mods VALUES (6,18);
INSERT INTO nuke_phpbb14_forum_mods VALUES (6,19);
INSERT INTO nuke_phpbb14_forum_mods VALUES (6,17);
INSERT INTO nuke_phpbb14_forum_mods VALUES (7,18);
INSERT INTO nuke_phpbb14_forum_mods VALUES (7,19);
INSERT INTO nuke_phpbb14_forum_mods VALUES (7,17);
INSERT INTO nuke_phpbb14_forum_mods VALUES (6,37);
INSERT INTO nuke_phpbb14_forum_mods VALUES (8,17);
INSERT INTO nuke_phpbb14_forum_mods VALUES (8,19);
INSERT INTO nuke_phpbb14_forum_mods VALUES (8,18);
INSERT INTO nuke_phpbb14_forum_mods VALUES (8,37);

--
-- Table structure for table 'nuke_phpbb14_forums'
--

CREATE TABLE nuke_phpbb14_forums (
  forum_id int(10) NOT NULL auto_increment,
  forum_name varchar(150) default NULL,
  forum_desc text,
  forum_access int(10) default '1',
  forum_topics int(10) unsigned NOT NULL default '0',
  forum_posts int(10) unsigned NOT NULL default '0',
  forum_last_post_id int(10) unsigned NOT NULL default '0',
  cat_id int(10) default NULL,
  forum_type int(10) default '0',
  forum_order mediumint(8) unsigned default NULL,
  PRIMARY KEY  (forum_id),
  KEY forum_last_post_id (forum_last_post_id)
) TYPE=MyISAM;

--
-- Dumping data for table 'nuke_phpbb14_forums'
--


INSERT INTO nuke_phpbb14_forums VALUES (1,'Students','This is a forum for students to discuss the IDEAS project.',1,3,6,16,3,0,5);
INSERT INTO nuke_phpbb14_forums VALUES (2,'Scientists','This is a forum for scientists to discuss the IDEAS-3 Project.',1,1,1,6,3,0,6);
INSERT INTO nuke_phpbb14_forums VALUES (3,'Comments on this web site.','This is a forum to discuss the web site for the IDEAS3 project.  Any input is welcome.  The idea is for people to be able to suggest things and discuss things among themselves, and then to bring these things to the meetings.',1,3,4,20,5,0,5);
INSERT INTO nuke_phpbb14_forums VALUES (4,'Current Project Status','This is a place for updates to the project status.  Please only post status updates here, not discussion.   General discussion about the project can be conducted on other forums.',1,1,1,17,6,0,5);
INSERT INTO nuke_phpbb14_forums VALUES (5,'RF01','',1,1,1,19,3,0,3);
INSERT INTO nuke_phpbb14_forums VALUES (6,'RF02','',1,0,0,0,3,0,2);
INSERT INTO nuke_phpbb14_forums VALUES (7,'TF01','',1,0,0,0,3,0,4);
INSERT INTO nuke_phpbb14_forums VALUES (8,'RF03','Discuss Research Flight 3 (08/26/2003)',1,0,0,0,3,0,1);

--
-- Table structure for table 'nuke_phpbb14_posts'
--

CREATE TABLE nuke_phpbb14_posts (
  post_id int(10) NOT NULL auto_increment,
  topic_id int(10) NOT NULL default '0',
  forum_id int(10) NOT NULL default '0',
  poster_id int(10) NOT NULL default '0',
  post_time varchar(20) default NULL,
  poster_ip varchar(16) default NULL,
  PRIMARY KEY  (post_id),
  KEY post_id (post_id),
  KEY forum_id (forum_id),
  KEY topic_id (topic_id),
  KEY poster_id (poster_id)
) TYPE=MyISAM;

--
-- Dumping data for table 'nuke_phpbb14_posts'
--


INSERT INTO nuke_phpbb14_posts VALUES (14,10,3,17,'2003-07-30 11:23','128.117.84.27');
INSERT INTO nuke_phpbb14_posts VALUES (15,9,3,18,'2003-07-31 14:42','128.117.84.153');
INSERT INTO nuke_phpbb14_posts VALUES (3,2,1,2,'2003-07-19 17:56','128.117.80.23');
INSERT INTO nuke_phpbb14_posts VALUES (4,2,1,2,'2003-07-22 09:53','128.117.80.23');
INSERT INTO nuke_phpbb14_posts VALUES (5,2,1,2,'2003-07-22 16:12','128.117.80.23');
INSERT INTO nuke_phpbb14_posts VALUES (6,3,2,2,'2003-07-22 16:47','128.117.80.23');
INSERT INTO nuke_phpbb14_posts VALUES (7,2,1,2,'2003-07-23 14:31','128.117.65.14');
INSERT INTO nuke_phpbb14_posts VALUES (9,5,1,11,'2003-07-24 15:47','128.117.80.60');
INSERT INTO nuke_phpbb14_posts VALUES (13,9,3,16,'2003-07-28 13:06','128.117.80.23');
INSERT INTO nuke_phpbb14_posts VALUES (16,11,1,16,'2003-08-01 14:49','128.117.80.23');
INSERT INTO nuke_phpbb14_posts VALUES (17,12,4,16,'2003-08-05 14:14','128.117.80.23');
INSERT INTO nuke_phpbb14_posts VALUES (19,13,5,18,'2003-08-27 16:20','128.117.84.153');
INSERT INTO nuke_phpbb14_posts VALUES (20,14,3,17,'2003-08-29 12:34','128.117.84.27');

--
-- Table structure for table 'nuke_phpbb14_posts_text'
--

CREATE TABLE nuke_phpbb14_posts_text (
  post_id int(10) NOT NULL default '0',
  post_text text,
  PRIMARY KEY  (post_id)
) TYPE=MyISAM;

--
-- Dumping data for table 'nuke_phpbb14_posts_text'
--


INSERT INTO nuke_phpbb14_posts_text VALUES (14,'Here is a test of posting an image <img src=\"/IDEAS3/filex/BAMEX/BAMEXlogo150.gif\">[addsig]');
INSERT INTO nuke_phpbb14_posts_text VALUES (3,'This is designed to be the first part of an interactive topic site.    Here you can talk, for example, about the results from specific research flights.   [addsig]');
INSERT INTO nuke_phpbb14_posts_text VALUES (4,'[quote]This is designed to be the first part of an interactive topic site.    Here you can talk, for example, about the results from specific research flights.   [/quote]\r\n\r\nOk, here goes.[addsig]');
INSERT INTO nuke_phpbb14_posts_text VALUES (5,'[quote]>>This is designed to be the first part of an interactive topic site.    Here you can talk, for example, about the results from specific research flights.   <<\r\n\r\nOk, here goes.[/quote]\r\n\r\n<img src=\"http://raf.atd.ucar.edu/pics/c130fixa.jpg\">[addsig]');
INSERT INTO nuke_phpbb14_posts_text VALUES (6,'This is a thread for discussing flight data.[addsig]');
INSERT INTO nuke_phpbb14_posts_text VALUES (7,'This is a <b>test</b> post.[addsig]');
INSERT INTO nuke_phpbb14_posts_text VALUES (9,'bla bla bla, here\'s a picture:\r\n\r\n<img src=\"http://www.atd.ucar.edu/rdp/rdp_staff.jpg\" width=267, height=200><!-- editby --><br /><br /><i>edited by: daniels, Jul 24, 2003 - 03:48 PM</i><!-- end editby -->[addsig]');
INSERT INTO nuke_phpbb14_posts_text VALUES (13,'This is a forum to discuss the web site for the IDEAS3 project. Any input is welcome. The idea is for people to be able to suggest things and discuss things among themselves, and then to bring these things to the meetings. So my question is, \'What do you like about this web site, what don\'t you like? What capabilities do we still need here?.\'[addsig]');
INSERT INTO nuke_phpbb14_posts_text VALUES (15,'The general layout is good.&nbsp; With collapsible menus, the page shrinks to o&shy;ne screenful, but can be expanded as needed depending o&shy;n what the user wants to see.<BR><BR>Suggested additions (some mine, some from the discussion yesterday):<BR>1. DATA - major bullet<BR>2. \"Start Here\" = a place for newbies to start, with a brief explanation of the project, what this page is about, how to join, and where to find help o&shy;n using the interface.<BR>3. Current Flight Status - should be a prominent bullet o&shy;n the home page.<BR>4. Warn users to finish and submit their forum composition before clicking o&shy;n a button o&shy;n the main menu -- otherwise the text disappears and you have to start over.<BR>5. Add some version of Jeff&#39;s &lt;a href=\"http://raf.atd.ucar.edu/Projects/IDEAS-1/FltMatrix.html\"&gt;<STRONG>Flight Summary Information Matrix</STRONG>&lt;/a&gt; that Ron created <U>after</U> the other IDEAS projects. <BR>6. So that some organization is imposed o&shy;n the discussion forums, we should generate topic areas, even if there are no postings yet.&nbsp; Topics might include flights (RF01, RF02, ..) and instruments.&nbsp; Special events could be added later (forest fire plume, for example). <BR>7. Couple the discussion forum topics to the flight matrix.<BR><BR>Questions:<BR>&nbsp;- Do we need to post&nbsp;a statement about data ownership?&nbsp; <BR>&nbsp;- Although it would be nice to post photos that include people, there is an &lt;a href=\"<A href=\"http://www.atd.ucar.edu/rdp/photo_policy/ATD_photo_guidelines.html\">http://www.atd.ucar.edu/rdp/photo_policy/ATD_photo_guidelines.html</A>\"&gt;<STRONG>official policy</STRONG> &lt;/a&gt;about such things.[addsig]');
INSERT INTO nuke_phpbb14_posts_text VALUES (16,'I am trying to verify the existence of a security problem here.  Just ignore this thread if you happen to see it.\r\n\r\nHere is the image:  <img type=\"text/plain\" src=\"/IDEAS3/config.php\">.[addsig]');
INSERT INTO nuke_phpbb14_posts_text VALUES (17,'Please do not post here unless you are authorized to do so.  This is an area only for updates to the project status.  Please start another thread if you wish to discuss something you see here.[addsig]');
INSERT INTO nuke_phpbb14_posts_text VALUES (19,'The PowerPoint presentation I gave at the 21 August science meeting is o�n�<a href=\'http://raf.atd.ucar.edu/~dcrogers/IDEAS/Flights-3/rf01/DaveR-scienceMeeting21aug.htm\">my web page</a>. �The topics included are air speed at the Nevzorov probe location and comparisons of FSSP measurements with the RAF and the GKSS probes during RF01.[addsig]');
INSERT INTO nuke_phpbb14_posts_text VALUES (20,'I\'ll be posting forum items to see how easy it is for people to include graphics and other things in a forum message.  For example, can one see the C-130 photo?\r\n<img src=\"filex/med_c130fixa.jpg\">[addsig]');

--
-- Table structure for table 'nuke_phpbb14_ranks'
--

CREATE TABLE nuke_phpbb14_ranks (
  rank_id int(10) NOT NULL auto_increment,
  rank_title varchar(50) NOT NULL default '',
  rank_min int(10) NOT NULL default '0',
  rank_max int(10) NOT NULL default '0',
  rank_special int(2) default '0',
  rank_image varchar(255) default NULL,
  rank_style varchar(255) NOT NULL default '',
  PRIMARY KEY  (rank_id),
  KEY rank_min (rank_min),
  KEY rank_max (rank_max)
) TYPE=MyISAM;

--
-- Dumping data for table 'nuke_phpbb14_ranks'
--



--
-- Table structure for table 'nuke_phpbb14_smiles'
--

CREATE TABLE nuke_phpbb14_smiles (
  id int(10) NOT NULL auto_increment,
  code varchar(50) default NULL,
  smile_url varchar(100) default NULL,
  emotion varchar(75) default NULL,
  PRIMARY KEY  (id)
) TYPE=MyISAM;

--
-- Dumping data for table 'nuke_phpbb14_smiles'
--


INSERT INTO nuke_phpbb14_smiles VALUES (1,':D','icon_biggrin.gif','Very Happy');
INSERT INTO nuke_phpbb14_smiles VALUES (2,':-D','icon_biggrin.gif','Very Happy');
INSERT INTO nuke_phpbb14_smiles VALUES (3,':grin:','icon_biggrin.gif','Very Happy');
INSERT INTO nuke_phpbb14_smiles VALUES (4,':)','icon_smile.gif','Smile');
INSERT INTO nuke_phpbb14_smiles VALUES (5,':-)','icon_smile.gif','Smile');
INSERT INTO nuke_phpbb14_smiles VALUES (6,':smile:','icon_smile.gif','Smile');
INSERT INTO nuke_phpbb14_smiles VALUES (7,':(','icon_frown.gif','Sad');
INSERT INTO nuke_phpbb14_smiles VALUES (8,':-(','icon_frown.gif','Sad');
INSERT INTO nuke_phpbb14_smiles VALUES (9,':sad:','icon_frown.gif','Sad');
INSERT INTO nuke_phpbb14_smiles VALUES (10,':o','icon_eek.gif','Surprised');
INSERT INTO nuke_phpbb14_smiles VALUES (11,':-o','icon_eek.gif','Surprised');
INSERT INTO nuke_phpbb14_smiles VALUES (12,':eek:','icon_eek.gif','Suprised');
INSERT INTO nuke_phpbb14_smiles VALUES (13,':-?','icon_confused.gif','Confused');
INSERT INTO nuke_phpbb14_smiles VALUES (14,':???:','icon_confused.gif','Confused');
INSERT INTO nuke_phpbb14_smiles VALUES (15,'8)','icon_cool.gif','Cool');
INSERT INTO nuke_phpbb14_smiles VALUES (16,'8-)','icon_cool.gif','Cool');
INSERT INTO nuke_phpbb14_smiles VALUES (17,':cool:','icon_cool.gif','Cool');
INSERT INTO nuke_phpbb14_smiles VALUES (18,':lol:','icon_lol.gif','Laughing');
INSERT INTO nuke_phpbb14_smiles VALUES (19,':x','icon_mad.gif','Mad');
INSERT INTO nuke_phpbb14_smiles VALUES (20,':-x','icon_mad.gif','Mad');
INSERT INTO nuke_phpbb14_smiles VALUES (21,':mad:','icon_mad.gif','Mad');
INSERT INTO nuke_phpbb14_smiles VALUES (22,':P','icon_razz.gif','Razz');
INSERT INTO nuke_phpbb14_smiles VALUES (23,':-P','icon_razz.gif','Razz');
INSERT INTO nuke_phpbb14_smiles VALUES (24,':razz:','icon_razz.gif','Razz');
INSERT INTO nuke_phpbb14_smiles VALUES (25,':oops:','icon_redface.gif','Embaressed');
INSERT INTO nuke_phpbb14_smiles VALUES (26,':cry:','icon_cry.gif','Crying (very sad)');
INSERT INTO nuke_phpbb14_smiles VALUES (27,':evil:','icon_evil.gif','Evil or Very Mad');
INSERT INTO nuke_phpbb14_smiles VALUES (28,':roll:','icon_rolleyes.gif','Rolling Eyes');
INSERT INTO nuke_phpbb14_smiles VALUES (29,':wink:','icon_wink.gif','Wink');
INSERT INTO nuke_phpbb14_smiles VALUES (30,';)','icon_wink.gif','Wink');
INSERT INTO nuke_phpbb14_smiles VALUES (31,';-)','icon_wink.gif','Wink');

--
-- Table structure for table 'nuke_phpbb14_subscription'
--

CREATE TABLE nuke_phpbb14_subscription (
  msg_id int(10) NOT NULL auto_increment,
  forum_id int(10) NOT NULL default '0',
  user_id int(10) NOT NULL default '0',
  PRIMARY KEY  (msg_id)
) TYPE=MyISAM;

--
-- Dumping data for table 'nuke_phpbb14_subscription'
--


INSERT INTO nuke_phpbb14_subscription VALUES (1,3,15);
INSERT INTO nuke_phpbb14_subscription VALUES (2,3,17);

--
-- Table structure for table 'nuke_phpbb14_topic_subscription'
--

CREATE TABLE nuke_phpbb14_topic_subscription (
  topic_id int(10) NOT NULL default '0',
  forum_id int(10) NOT NULL default '0',
  user_id int(10) NOT NULL default '0'
) TYPE=MyISAM;

--
-- Dumping data for table 'nuke_phpbb14_topic_subscription'
--



--
-- Table structure for table 'nuke_phpbb14_topics'
--

CREATE TABLE nuke_phpbb14_topics (
  topic_id int(10) NOT NULL auto_increment,
  topic_title varchar(100) default NULL,
  topic_poster int(10) default NULL,
  topic_time varchar(20) default NULL,
  topic_views int(10) NOT NULL default '0',
  topic_replies int(10) unsigned NOT NULL default '0',
  topic_last_post_id int(10) unsigned NOT NULL default '0',
  forum_id int(10) NOT NULL default '0',
  topic_status int(10) NOT NULL default '0',
  topic_notify int(2) default '0',
  sticky tinyint(3) unsigned NOT NULL default '0',
  sticky_label varchar(255) default NULL,
  poll_id int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (topic_id),
  KEY forum_id (forum_id),
  KEY topic_last_post_id (topic_last_post_id)
) TYPE=MyISAM;

--
-- Dumping data for table 'nuke_phpbb14_topics'
--


INSERT INTO nuke_phpbb14_topics VALUES (10,'Testing posted image',17,'2003-07-30 11:23',44,0,14,3,0,0,0,NULL,0);
INSERT INTO nuke_phpbb14_topics VALUES (2,'Test of software',2,'2003-07-23 14:31',56,3,7,1,0,0,0,NULL,0);
INSERT INTO nuke_phpbb14_topics VALUES (3,'Recent Flight Data',2,'2003-07-22 16:47',72,0,6,2,0,0,0,NULL,0);
INSERT INTO nuke_phpbb14_topics VALUES (5,'Mike\'s thread',11,'2003-07-24 15:47',49,0,9,1,0,0,1,NULL,0);
INSERT INTO nuke_phpbb14_topics VALUES (9,'Suggestions on this Website',16,'2003-07-31 14:42',126,1,15,3,0,0,0,NULL,0);
INSERT INTO nuke_phpbb14_topics VALUES (11,'Security Test',16,'2003-08-01 14:49',114,0,16,1,0,0,0,NULL,0);
INSERT INTO nuke_phpbb14_topics VALUES (12,'On this forum, you can view the current status of the project.',16,'2003-08-05 14:14',135,0,17,4,0,0,0,NULL,0);
INSERT INTO nuke_phpbb14_topics VALUES (13,'science meeting 21 August presentation',18,'2003-08-27 16:20',118,0,19,5,0,0,0,NULL,0);
INSERT INTO nuke_phpbb14_topics VALUES (14,'Testing',17,'2003-08-29 12:34',111,0,20,3,0,0,0,NULL,0);

--
-- Table structure for table 'nuke_phpbb14_users'
--

CREATE TABLE nuke_phpbb14_users (
  user_id int(10) unsigned NOT NULL default '0',
  user_posts int(10) unsigned NOT NULL default '0',
  user_rank int(10) unsigned NOT NULL default '0',
  user_level int(10) unsigned NOT NULL default '1',
  user_lastvisit timestamp(14) NOT NULL,
  PRIMARY KEY  (user_id)
) TYPE=MyISAM;

--
-- Dumping data for table 'nuke_phpbb14_users'
--


INSERT INTO nuke_phpbb14_users VALUES (2,7,0,1,20030728125256);
INSERT INTO nuke_phpbb14_users VALUES (11,1,0,1,20030724154729);
INSERT INTO nuke_phpbb14_users VALUES (16,2,0,1,20030805141502);
INSERT INTO nuke_phpbb14_users VALUES (17,2,0,1,20030829123425);
INSERT INTO nuke_phpbb14_users VALUES (18,2,0,1,20030827162059);

--
-- Table structure for table 'nuke_phpbb14_words'
--

CREATE TABLE nuke_phpbb14_words (
  word_id int(10) NOT NULL auto_increment,
  word varchar(255) NOT NULL default '',
  replacement varchar(255) NOT NULL default '',
  PRIMARY KEY  (word_id)
) TYPE=MyISAM;

--
-- Dumping data for table 'nuke_phpbb14_words'
--



--
-- Table structure for table 'nuke_pnchat'
--

CREATE TABLE nuke_pnchat (
  pn_id bigint(20) unsigned NOT NULL auto_increment,
  pn_from_userid varchar(50) NOT NULL default '0',
  pn_to_userid varchar(50) NOT NULL default '0',
  pn_text text NOT NULL,
  pn_systemtext text NOT NULL,
  pn_timestamp datetime NOT NULL default '0000-00-00 00:00:00',
  pn_chatroom bigint(20) NOT NULL default '0',
  pn_color varchar(7) NOT NULL default '',
  PRIMARY KEY  (pn_id)
) TYPE=MyISAM;

--
-- Dumping data for table 'nuke_pnchat'
--


INSERT INTO nuke_pnchat VALUES (1,'System','','','<i><b>Guest1</b> just entered the chat.</i><br>','2003-07-11 10:20:42',1,'');
INSERT INTO nuke_pnchat VALUES (2,'System','Guest1','','<b>Welcome Guest1! Users in this room:</b>  <font color=#0c0b70>Guest1</font> ','2003-07-11 10:20:42',1,'');
INSERT INTO nuke_pnchat VALUES (3,'Guest1','','','','2003-07-11 10:21:39',1,'#0c0b70');
INSERT INTO nuke_pnchat VALUES (4,'Guest1','','','','2003-07-11 10:21:52',1,'#0c0b70');
INSERT INTO nuke_pnchat VALUES (5,'Guest1','','','','2003-07-11 10:22:04',1,'#0c0b70');
INSERT INTO nuke_pnchat VALUES (6,'Guest1','','','','2003-07-11 10:22:31',1,'#0c0b70');
INSERT INTO nuke_pnchat VALUES (7,'Guest1','','','','2003-07-11 10:22:57',1,'#0c0b70');
INSERT INTO nuke_pnchat VALUES (8,'Guest1','','','','2003-07-11 10:23:03',1,'#0c0b70');
INSERT INTO nuke_pnchat VALUES (9,'Guest1','','','','2003-07-11 10:23:05',1,'#0c0b70');
INSERT INTO nuke_pnchat VALUES (10,'Guest1','','','','2003-07-11 10:23:31',1,'#0c0b70');
INSERT INTO nuke_pnchat VALUES (11,'Guest1','','','','2003-07-11 10:25:04',1,'#0c0b70');
INSERT INTO nuke_pnchat VALUES (12,'Guest1','','','','2003-07-11 10:25:39',1,'#0c0b70');
INSERT INTO nuke_pnchat VALUES (13,'System','','','<i><b>Guest1</b> just entered the chat.</i><br>','2003-07-11 10:27:18',1,'');
INSERT INTO nuke_pnchat VALUES (14,'System','Guest1','','<b>Welcome Guest1! Users in this room:</b>  <font color=#0c0b70>Guest1</font> ','2003-07-11 10:27:18',1,'');
INSERT INTO nuke_pnchat VALUES (15,'Guest1','','','','2003-07-11 10:27:26',1,'#0c0b70');
INSERT INTO nuke_pnchat VALUES (16,'Guest1','','','','2003-07-11 10:27:29',1,'#0c0b70');
INSERT INTO nuke_pnchat VALUES (17,'Guest1','','','','2003-07-11 10:27:31',1,'#0c0b70');
INSERT INTO nuke_pnchat VALUES (18,'System','','','<i><b>Guest1</b> just left the chat.</i><br>','2003-07-11 10:28:18',1,'');
INSERT INTO nuke_pnchat VALUES (19,'System','','','<i><b>Guest1</b> just left the chat.</i><br>','2003-07-11 10:28:18',1,'');
INSERT INTO nuke_pnchat VALUES (20,'System','','','<i><b>Guest1</b> just entered the chat.</i><br>','2003-07-11 10:29:24',1,'');
INSERT INTO nuke_pnchat VALUES (21,'System','Guest1','','<b>Welcome Guest1! Users in this room:</b>  <font color=#0c0b70>Guest1</font> ','2003-07-11 10:29:24',1,'');
INSERT INTO nuke_pnchat VALUES (22,'Guest1','','','','2003-07-11 10:29:35',1,'#0c0b70');
INSERT INTO nuke_pnchat VALUES (23,'Guest1','','','','2003-07-11 10:29:37',1,'#0c0b70');
INSERT INTO nuke_pnchat VALUES (24,'Guest1','','','','2003-07-11 10:29:37',1,'#0c0b70');
INSERT INTO nuke_pnchat VALUES (25,'Guest1','','','','2003-07-11 10:29:37',1,'#0c0b70');
INSERT INTO nuke_pnchat VALUES (26,'Guest1','','','','2003-07-11 10:30:00',1,'#0c0b70');
INSERT INTO nuke_pnchat VALUES (27,'System','','','<i><b>Guest1</b> just left the chat.</i><br>','2003-07-11 10:30:50',1,'');
INSERT INTO nuke_pnchat VALUES (28,'System','','','<i><b>Guest1</b> just entered the chat.</i><br>','2003-07-11 11:16:48',1,'');
INSERT INTO nuke_pnchat VALUES (29,'System','Guest1','','<b>Welcome Guest1! Users in this room:</b>  <font color=#0c0b70>Guest1</font> ','2003-07-11 11:16:48',1,'');
INSERT INTO nuke_pnchat VALUES (30,'System','','','<i><b>Guest1</b> just entered the chat.</i><br>','2003-07-11 11:17:13',1,'');
INSERT INTO nuke_pnchat VALUES (31,'System','Guest1','','<b>Welcome Guest1! Users in this room:</b>  <font color=#0c0b70>Guest1</font> ','2003-07-11 11:17:13',1,'');
INSERT INTO nuke_pnchat VALUES (32,'Guest1','','','','2003-07-11 11:17:28',1,'#0c0b70');
INSERT INTO nuke_pnchat VALUES (33,'System','','','<i><b>Guest1</b> has changed <font color=#>color</font></i><br>','2003-07-11 11:17:37',1,'');
INSERT INTO nuke_pnchat VALUES (34,'Guest1','','','','2003-07-11 11:17:43',1,'#');
INSERT INTO nuke_pnchat VALUES (35,'System','','','<i><b>Guest1</b> has changed <font color=#4c0707>color</font></i><br>','2003-07-11 11:17:54',1,'');
INSERT INTO nuke_pnchat VALUES (36,'System','','','<i><b>Guest1</b> has changed <font color=#>color</font></i><br>','2003-07-11 11:17:56',1,'');
INSERT INTO nuke_pnchat VALUES (37,'Guest1','','','','2003-07-11 11:17:59',1,'#');
INSERT INTO nuke_pnchat VALUES (38,'Guest1','','','','2003-07-11 11:18:20',1,'#');
INSERT INTO nuke_pnchat VALUES (39,'Guest1','','','','2003-07-11 11:18:21',1,'#');
INSERT INTO nuke_pnchat VALUES (40,'Guest1','','','','2003-07-11 11:18:21',1,'#');
INSERT INTO nuke_pnchat VALUES (41,'System','','','<i><b>Guest1</b> has changed <font color=#4c0707>color</font></i><br>','2003-07-11 11:18:25',1,'');
INSERT INTO nuke_pnchat VALUES (42,'Guest1','','','','2003-07-11 11:18:35',1,'#4c0707');
INSERT INTO nuke_pnchat VALUES (43,'Guest1','','','','2003-07-11 11:18:36',1,'#4c0707');
INSERT INTO nuke_pnchat VALUES (44,'Guest1','','','','2003-07-11 11:18:36',1,'#4c0707');
INSERT INTO nuke_pnchat VALUES (45,'Guest1','','','','2003-07-11 11:18:37',1,'#4c0707');
INSERT INTO nuke_pnchat VALUES (46,'Guest1','','','','2003-07-11 11:18:37',1,'#4c0707');
INSERT INTO nuke_pnchat VALUES (47,'Guest1','','','','2003-07-11 11:18:38',1,'#4c0707');
INSERT INTO nuke_pnchat VALUES (48,'System','','','<i><b>Guest1</b> just entered the chat.</i><br>','2003-07-11 11:27:07',1,'');
INSERT INTO nuke_pnchat VALUES (49,'System','Guest1','','<b>Welcome Guest1! Users in this room:</b>  <font color=#4c0707>Guest1</font> ','2003-07-11 11:27:07',1,'');
INSERT INTO nuke_pnchat VALUES (50,'Guest1','','','','2003-07-11 11:27:14',1,'#4c0707');
INSERT INTO nuke_pnchat VALUES (51,'Guest1','','','','2003-07-11 11:27:29',1,'#4c0707');
INSERT INTO nuke_pnchat VALUES (52,'Guest1','','','','2003-07-11 11:30:54',1,'#4c0707');
INSERT INTO nuke_pnchat VALUES (53,'Guest1','','','','2003-07-11 11:31:06',1,'#4c0707');
INSERT INTO nuke_pnchat VALUES (54,'System','','','<i><b>Guest1</b> just entered the chat.</i><br>','2003-07-11 11:31:51',1,'');
INSERT INTO nuke_pnchat VALUES (55,'System','Guest1','','<b>Welcome Guest1! Users in this room:</b>  <font color=#4c0707>Guest1</font> ','2003-07-11 11:31:51',1,'');
INSERT INTO nuke_pnchat VALUES (56,'Guest1','','','','2003-07-11 11:32:01',1,'#4c0707');
INSERT INTO nuke_pnchat VALUES (57,'Guest1','','','','2003-07-11 11:32:06',1,'#4c0707');
INSERT INTO nuke_pnchat VALUES (58,'Guest1','','','','2003-07-11 11:32:12',1,'#4c0707');
INSERT INTO nuke_pnchat VALUES (59,'Guest1','','','','2003-07-11 11:32:22',1,'#4c0707');
INSERT INTO nuke_pnchat VALUES (60,'System','','','<i><b>Guest1</b> has changed <font color=#4c0707>color</font></i><br>','2003-07-11 11:32:55',1,'');
INSERT INTO nuke_pnchat VALUES (61,'System','','','<i><b>Guest1</b> has changed <font color=#>color</font></i><br>','2003-07-11 11:32:56',1,'');
INSERT INTO nuke_pnchat VALUES (62,'System','','','<i><b>Guest1</b> has changed <font color=#>color</font></i><br>','2003-07-11 11:32:57',1,'');
INSERT INTO nuke_pnchat VALUES (63,'Guest1','','','','2003-07-11 11:33:03',1,'#');
INSERT INTO nuke_pnchat VALUES (64,'Guest1','','','','2003-07-11 11:33:05',1,'#');
INSERT INTO nuke_pnchat VALUES (65,'Guest1','','','','2003-07-11 11:33:05',1,'#');
INSERT INTO nuke_pnchat VALUES (66,'Guest1','','','','2003-07-11 11:33:05',1,'#');
INSERT INTO nuke_pnchat VALUES (67,'Guest1','','','','2003-07-11 11:35:26',1,'#');
INSERT INTO nuke_pnchat VALUES (68,'Guest1','','','','2003-07-11 11:35:28',1,'#');
INSERT INTO nuke_pnchat VALUES (69,'Guest1','','','','2003-07-11 11:35:28',1,'#');
INSERT INTO nuke_pnchat VALUES (70,'System','','','<i><b>Guest1</b> just left the chat.</i><br>','2003-07-11 11:35:40',1,'');
INSERT INTO nuke_pnchat VALUES (71,'System','','','<i><b>Guest1</b> just entered the chat.</i><br>','2003-07-11 11:36:06',1,'');
INSERT INTO nuke_pnchat VALUES (72,'System','Guest1','','<b>Welcome Guest1! Users in this room:</b>  <font color=#>Guest1</font> ','2003-07-11 11:36:06',1,'');
INSERT INTO nuke_pnchat VALUES (73,'Guest1','','','','2003-07-11 11:36:11',1,'#');
INSERT INTO nuke_pnchat VALUES (74,'Guest1','','','','2003-07-11 11:36:13',1,'#');
INSERT INTO nuke_pnchat VALUES (75,'Guest1','','','','2003-07-11 11:36:14',1,'#');
INSERT INTO nuke_pnchat VALUES (76,'System','','','<i><b>Guest1</b> just left the chat.</i><br>','2003-07-11 11:44:26',1,'');
INSERT INTO nuke_pnchat VALUES (77,'System','','','<i><b>Guest1</b> just entered the chat.</i><br>','2003-07-11 12:25:27',1,'');
INSERT INTO nuke_pnchat VALUES (78,'System','Guest1','','<b>Welcome Guest1! Users in this room:</b>  <font color=#>Guest1</font> ','2003-07-11 12:25:27',1,'');
INSERT INTO nuke_pnchat VALUES (79,'System','','','<i><b>Guest1</b> just entered the chat.</i><br>','2003-07-11 12:25:38',1,'');
INSERT INTO nuke_pnchat VALUES (80,'System','Guest1','','<b>Welcome Guest1! Users in this room:</b>  <font color=#>Guest1</font> ','2003-07-11 12:25:38',1,'');
INSERT INTO nuke_pnchat VALUES (81,'Guest1','','','','2003-07-11 12:25:42',1,'#');
INSERT INTO nuke_pnchat VALUES (82,'System','','','<i><b>Guest1</b> just left the chat.</i><br>','2003-07-11 12:26:49',1,'');
INSERT INTO nuke_pnchat VALUES (83,'System','','','<i><b>Guest1</b> just left the chat.</i><br>','2003-07-11 12:26:49',1,'');
INSERT INTO nuke_pnchat VALUES (84,'System','','','<i><b>Guest1</b> just entered the chat.</i><br>','2003-07-11 12:29:10',1,'');
INSERT INTO nuke_pnchat VALUES (85,'System','Guest1','','<b>Welcome Guest1! Users in this room:</b>  <font color=#>Guest1</font> ','2003-07-11 12:29:10',1,'');
INSERT INTO nuke_pnchat VALUES (86,'Guest1','','','','2003-07-11 12:29:14',1,'#');
INSERT INTO nuke_pnchat VALUES (87,'System','','','<i><b>Guest1</b> just entered the chat.</i><br>','2003-07-11 12:31:36',1,'');
INSERT INTO nuke_pnchat VALUES (88,'System','Guest1','','<b>Welcome Guest1! Users in this room:</b>  <font color=#>Guest1</font> ','2003-07-11 12:31:36',1,'');
INSERT INTO nuke_pnchat VALUES (89,'System','','','<i><b>Guest1</b> just entered the chat.</i><br>','2003-07-11 12:31:49',1,'');
INSERT INTO nuke_pnchat VALUES (90,'System','Guest1','','<b>Welcome Guest1! Users in this room:</b>  <font color=#>Guest1</font> ','2003-07-11 12:31:49',1,'');
INSERT INTO nuke_pnchat VALUES (91,'Guest1','','','','2003-07-11 12:31:53',1,'#');
INSERT INTO nuke_pnchat VALUES (92,'Guest1','','','','2003-07-11 12:31:54',1,'#');
INSERT INTO nuke_pnchat VALUES (93,'Guest1','','','','2003-07-11 12:31:55',1,'#');
INSERT INTO nuke_pnchat VALUES (94,'System','','','<i><b>Guest1</b> just entered the chat.</i><br>','2003-07-11 12:35:37',1,'');
INSERT INTO nuke_pnchat VALUES (95,'System','Guest1','','<b>Welcome Guest1! Users in this room:</b>  <font color=#>Guest1</font> ','2003-07-11 12:35:37',1,'');
INSERT INTO nuke_pnchat VALUES (96,'Guest1','','','','2003-07-11 12:35:45',1,'#');
INSERT INTO nuke_pnchat VALUES (97,'Guest1','','','','2003-07-11 12:35:46',1,'#');
INSERT INTO nuke_pnchat VALUES (98,'Guest1','','','','2003-07-11 12:35:46',1,'#');
INSERT INTO nuke_pnchat VALUES (99,'Guest1','','','','2003-07-11 12:35:46',1,'#');
INSERT INTO nuke_pnchat VALUES (100,'System','','','<i><b>Guest1</b> just entered the chat.</i><br>','2003-07-11 12:35:58',1,'');
INSERT INTO nuke_pnchat VALUES (101,'System','Guest1','','<b>Welcome Guest1! Users in this room:</b>  <font color=#>Guest1</font> ','2003-07-11 12:35:58',1,'');
INSERT INTO nuke_pnchat VALUES (102,'System','','','<i><b>Guest1</b> just left the chat.</i><br>','2003-07-11 12:37:04',1,'');
INSERT INTO nuke_pnchat VALUES (103,'System','','','<i><b>Guest1</b> just left the chat.</i><br>','2003-07-11 12:37:04',1,'');
INSERT INTO nuke_pnchat VALUES (104,'System','','','<i><b>Guest1</b> just left the chat.</i><br>','2003-07-11 12:37:04',1,'');
INSERT INTO nuke_pnchat VALUES (105,'System','','','<i><b>Guest1</b> just left the chat.</i><br>','2003-07-11 12:37:04',1,'');
INSERT INTO nuke_pnchat VALUES (106,'System','','','<i><b>Guest1</b> just left the chat.</i><br>','2003-07-11 12:37:04',1,'');
INSERT INTO nuke_pnchat VALUES (107,'System','','','<i><b>Guest1</b> just entered the chat.</i><br>','2003-07-11 12:38:25',1,'');
INSERT INTO nuke_pnchat VALUES (108,'System','Guest1','','<b>Welcome Guest1! Users in this room:</b>  <font color=#>Guest1</font> ','2003-07-11 12:38:25',1,'');
INSERT INTO nuke_pnchat VALUES (109,'Guest1','','','','2003-07-11 12:38:29',1,'#');
INSERT INTO nuke_pnchat VALUES (110,'Guest1','','','','2003-07-11 12:38:38',1,'#');
INSERT INTO nuke_pnchat VALUES (111,'Guest1','','','','2003-07-11 12:38:44',1,'#');
INSERT INTO nuke_pnchat VALUES (112,'System','','','<i><b>Guest1</b> just left the chat.</i><br>','2003-07-11 12:50:49',1,'');
INSERT INTO nuke_pnchat VALUES (113,'System','','','<i><b>Guest1</b> just entered the chat.</i><br>','2003-07-11 13:01:36',1,'');
INSERT INTO nuke_pnchat VALUES (114,'System','Guest1','','<b>Welcome Guest1! Users in this room:</b>  <font color=#>Guest1</font> ','2003-07-11 13:01:36',1,'');
INSERT INTO nuke_pnchat VALUES (115,'Guest1','','','','2003-07-11 13:01:39',1,'#');
INSERT INTO nuke_pnchat VALUES (116,'Guest1','','','','2003-07-11 13:01:41',1,'#');
INSERT INTO nuke_pnchat VALUES (117,'Guest1','','','','2003-07-11 13:06:16',1,'#');
INSERT INTO nuke_pnchat VALUES (118,'Guest1','','','','2003-07-11 13:06:16',1,'#');
INSERT INTO nuke_pnchat VALUES (119,'Guest1','','','','2003-07-11 15:02:38',1,'#');
INSERT INTO nuke_pnchat VALUES (120,'Guest1','','','','2003-07-11 15:02:44',1,'#');
INSERT INTO nuke_pnchat VALUES (121,'Guest1','','','','2003-07-11 15:02:45',1,'#');
INSERT INTO nuke_pnchat VALUES (122,'Guest1','','','','2003-07-11 15:02:45',1,'#');
INSERT INTO nuke_pnchat VALUES (123,'Guest1','','','','2003-07-11 15:02:45',1,'#');
INSERT INTO nuke_pnchat VALUES (124,'Guest1','','','','2003-07-11 15:02:45',1,'#');
INSERT INTO nuke_pnchat VALUES (125,'Guest1','','','','2003-07-11 15:02:46',1,'#');
INSERT INTO nuke_pnchat VALUES (126,'Guest1','','','','2003-07-11 15:02:46',1,'#');
INSERT INTO nuke_pnchat VALUES (127,'Guest1','','','','2003-07-11 15:02:46',1,'#');
INSERT INTO nuke_pnchat VALUES (128,'Guest1','','','','2003-07-11 15:02:46',1,'#');
INSERT INTO nuke_pnchat VALUES (129,'Guest1','','','','2003-07-11 15:02:46',1,'#');
INSERT INTO nuke_pnchat VALUES (130,'Guest1','','','','2003-07-11 15:02:47',1,'#');
INSERT INTO nuke_pnchat VALUES (131,'Guest1','','','','2003-07-11 15:02:47',1,'#');
INSERT INTO nuke_pnchat VALUES (132,'Guest1','','','','2003-07-11 15:02:47',1,'#');
INSERT INTO nuke_pnchat VALUES (133,'Guest1','','','','2003-07-11 15:02:47',1,'#');
INSERT INTO nuke_pnchat VALUES (134,'Guest1','','','','2003-07-11 15:02:47',1,'#');
INSERT INTO nuke_pnchat VALUES (135,'Guest1','','','','2003-07-11 15:02:47',1,'#');
INSERT INTO nuke_pnchat VALUES (136,'Guest1','','','','2003-07-11 15:02:47',1,'#');
INSERT INTO nuke_pnchat VALUES (137,'Guest1','','','','2003-07-11 15:02:47',1,'#');
INSERT INTO nuke_pnchat VALUES (138,'Guest1','','','','2003-07-11 15:02:47',1,'#');
INSERT INTO nuke_pnchat VALUES (139,'Guest1','','','','2003-07-11 15:02:47',1,'#');
INSERT INTO nuke_pnchat VALUES (140,'Guest1','','','','2003-07-11 15:02:48',1,'#');
INSERT INTO nuke_pnchat VALUES (141,'System','','','<i><b>Guest1</b> just entered the chat.</i><br>','2003-07-11 15:02:57',1,'');
INSERT INTO nuke_pnchat VALUES (142,'System','Guest1','','<b>Welcome Guest1! Users in this room:</b>  <font color=#>Guest1</font> ','2003-07-11 15:02:57',1,'');
INSERT INTO nuke_pnchat VALUES (143,'System','','','<i><b>Guest1</b> just entered the chat.</i><br>','2003-07-11 15:03:27',1,'');
INSERT INTO nuke_pnchat VALUES (144,'System','Guest1','','<b>Welcome Guest1! Users in this room:</b>  <font color=#>Guest1</font> ','2003-07-11 15:03:27',1,'');
INSERT INTO nuke_pnchat VALUES (145,'System','','','<i><b>Guest1</b> just left the chat.</i><br>','2003-07-11 15:03:32',1,'');
INSERT INTO nuke_pnchat VALUES (146,'System','','','<i><b>Guest1</b> just left the chat.</i><br>','2003-07-11 15:03:32',1,'');
INSERT INTO nuke_pnchat VALUES (147,'System','','','<i><b>Guest1</b> just left the chat.</i><br>','2003-07-11 15:03:32',1,'');
INSERT INTO nuke_pnchat VALUES (148,'System','','','<i><b>Guest1</b> just entered the chat.</i><br>','2003-07-11 15:04:53',1,'');
INSERT INTO nuke_pnchat VALUES (149,'System','Guest1','','<b>Welcome Guest1! Users in this room:</b>  <font color=#>Guest1</font> ','2003-07-11 15:04:53',1,'');
INSERT INTO nuke_pnchat VALUES (150,'Guest1','','','','2003-07-11 15:05:06',1,'#');
INSERT INTO nuke_pnchat VALUES (151,'Guest1','','','','2003-07-11 15:05:12',1,'#');
INSERT INTO nuke_pnchat VALUES (152,'Guest1','','','','2003-07-11 15:05:14',1,'#');
INSERT INTO nuke_pnchat VALUES (153,'Guest1','','','','2003-07-11 15:05:15',1,'#');
INSERT INTO nuke_pnchat VALUES (154,'Guest1','','','','2003-07-11 15:05:16',1,'#');
INSERT INTO nuke_pnchat VALUES (155,'System','','','<i><b>Guest1</b> just left the chat.</i><br>','2003-07-11 15:05:33',1,'');
INSERT INTO nuke_pnchat VALUES (156,'System','','','<i><b>Guest1</b> just entered the chat.</i><br>','2003-07-11 15:13:11',1,'');
INSERT INTO nuke_pnchat VALUES (157,'System','Guest1','','<b>Welcome Guest1! Users in this room:</b> ','2003-07-11 15:13:11',1,'');
INSERT INTO nuke_pnchat VALUES (158,'System','','','<i><b>Guest1</b> just entered the chat.</i><br>','2003-07-11 15:13:16',1,'');
INSERT INTO nuke_pnchat VALUES (159,'System','Guest1','','<b>Welcome Guest1! Users in this room:</b> ','2003-07-11 15:13:16',1,'');
INSERT INTO nuke_pnchat VALUES (160,'System','','','<i><b>Guest1</b> just entered the chat.</i><br>','2003-07-11 15:13:22',1,'');
INSERT INTO nuke_pnchat VALUES (161,'System','Guest1','','<b>Welcome Guest1! Users in this room:</b>  <font color=#>Guest1</font> ','2003-07-11 15:13:22',1,'');
INSERT INTO nuke_pnchat VALUES (162,'System','','','<i><b>Guest1</b> just entered the chat.</i><br>','2003-07-11 15:13:33',1,'');
INSERT INTO nuke_pnchat VALUES (163,'System','Guest1','','<b>Welcome Guest1! Users in this room:</b>  <font color=#>Guest1</font> ','2003-07-11 15:13:33',1,'');
INSERT INTO nuke_pnchat VALUES (164,'System','','','<i><b>Guest1</b> just entered the chat.</i><br>','2003-07-11 15:13:39',1,'');
INSERT INTO nuke_pnchat VALUES (165,'System','Guest1','','<b>Welcome Guest1! Users in this room:</b>  <font color=#>Guest1</font> ','2003-07-11 15:13:39',1,'');
INSERT INTO nuke_pnchat VALUES (166,'System','','','<i><b>Guest1</b> just entered the chat.</i><br>','2003-07-11 15:13:43',1,'');
INSERT INTO nuke_pnchat VALUES (167,'System','Guest1','','<b>Welcome Guest1! Users in this room:</b>  <font color=#>Guest1</font> ','2003-07-11 15:13:43',1,'');
INSERT INTO nuke_pnchat VALUES (168,'System','','','<i><b>Guest1</b> just entered the chat.</i><br>','2003-07-11 15:18:01',1,'');
INSERT INTO nuke_pnchat VALUES (169,'System','Guest1','','<b>Welcome Guest1! Users in this room:</b>  <font color=#>Guest1</font> ','2003-07-11 15:18:01',1,'');
INSERT INTO nuke_pnchat VALUES (170,'System','','','<i><b>Guest1</b> just entered the chat.</i><br>','2003-07-11 15:18:08',1,'');
INSERT INTO nuke_pnchat VALUES (171,'System','Guest1','','<b>Welcome Guest1! Users in this room:</b>  <font color=#>Guest1</font> ','2003-07-11 15:18:08',1,'');
INSERT INTO nuke_pnchat VALUES (172,'Guest1','','','','2003-07-11 15:18:12',1,'#');
INSERT INTO nuke_pnchat VALUES (173,'System','','','<i><b>Guest1</b> just jumped to room <b>\'\'</b>.</i><br>','2003-07-11 15:18:23',1,'');
INSERT INTO nuke_pnchat VALUES (174,'System','','','<i><b>Guest1</b> just entered this room.</i><br>','2003-07-11 15:18:23',0,'');
INSERT INTO nuke_pnchat VALUES (175,'System','Guest1','','<b>Users in this room:</b>  <font color=#>Guest1</font> ','2003-07-11 15:18:23',0,'');
INSERT INTO nuke_pnchat VALUES (176,'System','','','<i><b>Guest1</b> just jumped to room <b>\'\'</b>.</i><br>','2003-07-11 15:18:25',0,'');
INSERT INTO nuke_pnchat VALUES (177,'System','','','<i><b>Guest1</b> just entered this room.</i><br>','2003-07-11 15:18:25',0,'');
INSERT INTO nuke_pnchat VALUES (178,'System','Guest1','','<b>Users in this room:</b>  <font color=#>Guest1</font> ','2003-07-11 15:18:25',0,'');
INSERT INTO nuke_pnchat VALUES (179,'System','','','<i><b>Guest1</b> just jumped to room <b>\'\'</b>.</i><br>','2003-07-11 15:18:26',0,'');
INSERT INTO nuke_pnchat VALUES (180,'System','','','<i><b>Guest1</b> just entered this room.</i><br>','2003-07-11 15:18:26',0,'');
INSERT INTO nuke_pnchat VALUES (181,'System','Guest1','','<b>Users in this room:</b>  <font color=#>Guest1</font> ','2003-07-11 15:18:26',0,'');
INSERT INTO nuke_pnchat VALUES (182,'System','','','<i><b>Guest1</b> just entered the chat.</i><br>','2003-07-11 15:18:36',0,'');
INSERT INTO nuke_pnchat VALUES (183,'System','Guest1','','<b>Welcome Guest1! Users in this room:</b>  <font color=#>Guest1</font> ','2003-07-11 15:18:36',0,'');
INSERT INTO nuke_pnchat VALUES (184,'System','','','<i><b>Guest1</b> just jumped to room <b>\'\'</b>.</i><br>','2003-07-11 15:18:42',0,'');
INSERT INTO nuke_pnchat VALUES (185,'System','','','<i><b>Guest1</b> just entered this room.</i><br>','2003-07-11 15:18:42',0,'');
INSERT INTO nuke_pnchat VALUES (186,'System','Guest1','','<b>Users in this room:</b>  <font color=#>Guest1</font> ','2003-07-11 15:18:42',0,'');
INSERT INTO nuke_pnchat VALUES (187,'System','','','<i><b>Guest1</b> just jumped to room <b>\'\'</b>.</i><br>','2003-07-11 15:18:53',0,'');
INSERT INTO nuke_pnchat VALUES (188,'System','','','<i><b>Guest1</b> just entered this room.</i><br>','2003-07-11 15:18:53',0,'');
INSERT INTO nuke_pnchat VALUES (189,'System','Guest1','','<b>Users in this room:</b>  <font color=#>Guest1</font> ','2003-07-11 15:18:53',0,'');
INSERT INTO nuke_pnchat VALUES (190,'Guest1','','','','2003-07-11 15:19:15',0,'#');
INSERT INTO nuke_pnchat VALUES (191,'Guest1','','','','2003-07-11 15:19:16',0,'#');
INSERT INTO nuke_pnchat VALUES (192,'Guest1','','','','2003-07-11 15:19:16',0,'#');
INSERT INTO nuke_pnchat VALUES (193,'Guest1','','','','2003-07-11 15:19:17',0,'#');
INSERT INTO nuke_pnchat VALUES (194,'System','','','<i><b>Guest1</b> just jumped to room <b>\'\'</b>.</i><br>','2003-07-11 15:19:22',0,'');
INSERT INTO nuke_pnchat VALUES (195,'System','','','<i><b>Guest1</b> just entered this room.</i><br>','2003-07-11 15:19:22',0,'');
INSERT INTO nuke_pnchat VALUES (196,'System','Guest1','','<b>Users in this room:</b>  <font color=#>Guest1</font> ','2003-07-11 15:19:22',0,'');
INSERT INTO nuke_pnchat VALUES (197,'System','','','<i><b>Guest1</b> just entered the chat.</i><br>','2003-07-11 15:22:56',0,'');
INSERT INTO nuke_pnchat VALUES (198,'System','Guest1','','<b>Welcome Guest1! Users in this room:</b>  <font color=#>Guest1</font> ','2003-07-11 15:22:56',0,'');
INSERT INTO nuke_pnchat VALUES (199,'System','','','<i><b>Guest1</b> just entered the chat.</i><br>','2003-07-11 15:23:01',0,'');
INSERT INTO nuke_pnchat VALUES (200,'System','Guest1','','<b>Welcome Guest1! Users in this room:</b>  <font color=#>Guest1</font> ','2003-07-11 15:23:01',0,'');
INSERT INTO nuke_pnchat VALUES (201,'Guest1','','','','2003-07-11 15:23:05',0,'#');
INSERT INTO nuke_pnchat VALUES (202,'System','','','<i><b>Guest1</b> just entered the chat.</i><br>','2003-07-11 15:29:41',0,'');
INSERT INTO nuke_pnchat VALUES (203,'System','Guest1','','<b>Welcome Guest1! Users in this room:</b>  <font color=#>Guest1</font> ','2003-07-11 15:29:41',0,'');
INSERT INTO nuke_pnchat VALUES (204,'System','','','<i><b>Guest1</b> just entered the chat.</i><br>','2003-07-11 15:30:13',0,'');
INSERT INTO nuke_pnchat VALUES (205,'System','Guest1','','<b>Welcome Guest1! Users in this room:</b>  <font color=#>Guest1</font> ','2003-07-11 15:30:13',0,'');
INSERT INTO nuke_pnchat VALUES (206,'System','','','<i><b>Guest1</b> just entered the chat.</i><br>','2003-07-11 15:30:18',0,'');
INSERT INTO nuke_pnchat VALUES (207,'System','Guest1','','<b>Welcome Guest1! Users in this room:</b>  <font color=#>Guest1</font> ','2003-07-11 15:30:18',0,'');
INSERT INTO nuke_pnchat VALUES (208,'System','','','<i><b>Guest1</b> just entered the chat.</i><br>','2003-07-11 15:31:50',0,'');
INSERT INTO nuke_pnchat VALUES (209,'System','Guest1','','<b>Welcome Guest1! Users in this room:</b>  <font color=#>Guest1</font> ','2003-07-11 15:31:50',0,'');
INSERT INTO nuke_pnchat VALUES (210,'System','','','<i><b>Guest1</b> just entered the chat.</i><br>','2003-07-11 15:31:55',0,'');
INSERT INTO nuke_pnchat VALUES (211,'System','Guest1','','<b>Welcome Guest1! Users in this room:</b>  <font color=#>Guest1</font> ','2003-07-11 15:31:55',0,'');
INSERT INTO nuke_pnchat VALUES (212,'System','','','<i><b>Guest1</b> just left the chat.</i><br>','2003-07-11 15:31:55',0,'');
INSERT INTO nuke_pnchat VALUES (213,'System','','','<i><b>Guest1</b> just entered the chat.</i><br>','2003-07-11 15:34:30',0,'');
INSERT INTO nuke_pnchat VALUES (214,'System','Guest1','','<b>Welcome Guest1! Users in this room:</b>  <font color=#>Guest1</font> ','2003-07-11 15:34:30',0,'');
INSERT INTO nuke_pnchat VALUES (215,'System','','','<i><b>Guest1</b> just left the chat.</i><br>','2003-07-11 15:34:30',0,'');
INSERT INTO nuke_pnchat VALUES (216,'System','','','<i><b>Guest1</b> just entered the chat.</i><br>','2003-07-11 15:43:06',0,'');
INSERT INTO nuke_pnchat VALUES (217,'System','Guest1','','<b>Welcome Guest1! Users in this room:</b>  <font color=#>Guest1</font> ','2003-07-11 15:43:06',0,'');
INSERT INTO nuke_pnchat VALUES (218,'System','','','<i><b>Guest1</b> just left the chat.</i><br>','2003-07-11 15:43:06',0,'');
INSERT INTO nuke_pnchat VALUES (219,'System','','','<i><b>Guest1</b> just entered the chat.</i><br>','2003-07-11 15:43:18',0,'');
INSERT INTO nuke_pnchat VALUES (220,'System','Guest1','','<b>Welcome Guest1! Users in this room:</b>  <font color=#>Guest1</font> ','2003-07-11 15:43:18',0,'');
INSERT INTO nuke_pnchat VALUES (221,'System','','','<i><b>Guest1</b> just left the chat.</i><br>','2003-07-11 15:43:18',0,'');
INSERT INTO nuke_pnchat VALUES (222,'System','','','<i><b>Guest1</b> just entered the chat.</i><br>','2003-07-11 15:43:21',0,'');
INSERT INTO nuke_pnchat VALUES (223,'System','Guest1','','<b>Welcome Guest1! Users in this room:</b>  <font color=#>Guest1</font> ','2003-07-11 15:43:21',0,'');
INSERT INTO nuke_pnchat VALUES (224,'System','','','<i><b>Guest1</b> just left the chat.</i><br>','2003-07-11 15:43:21',0,'');
INSERT INTO nuke_pnchat VALUES (225,'System','','','<i><b>Guest1</b> just left the chat.</i><br>','2003-07-11 15:43:52',0,'');
INSERT INTO nuke_pnchat VALUES (226,'System','','','<i><b>Guest1</b> just entered the chat.</i><br>','2003-07-11 15:43:52',0,'');
INSERT INTO nuke_pnchat VALUES (227,'System','Guest1','','<b>Welcome Guest1! Users in this room:</b> ','2003-07-11 15:43:52',0,'');
INSERT INTO nuke_pnchat VALUES (228,'System','','','<i><b>Guest1</b> just entered the chat.</i><br>','2003-07-11 15:44:23',0,'');
INSERT INTO nuke_pnchat VALUES (229,'System','Guest1','','<b>Welcome Guest1! Users in this room:</b>  <font color=#>Guest1</font> ','2003-07-11 15:44:23',0,'');
INSERT INTO nuke_pnchat VALUES (230,'Guest1','','','','2003-07-11 15:44:27',0,'#');
INSERT INTO nuke_pnchat VALUES (231,'System','','','<i><b>Guest1</b> just entered the chat.</i><br>','2003-07-11 15:47:14',0,'');
INSERT INTO nuke_pnchat VALUES (232,'System','Guest1','','<b>Welcome Guest1! Users in this room:</b>  <font color=#>Guest1</font> ','2003-07-11 15:47:14',0,'');
INSERT INTO nuke_pnchat VALUES (233,'Guest1','','','','2003-07-11 15:54:33',0,'#');
INSERT INTO nuke_pnchat VALUES (234,'Guest1','','','','2003-07-11 15:54:34',0,'#');
INSERT INTO nuke_pnchat VALUES (235,'Guest1','','','','2003-07-11 15:54:35',0,'#');
INSERT INTO nuke_pnchat VALUES (236,'Guest1','','','','2003-07-11 15:54:35',0,'#');
INSERT INTO nuke_pnchat VALUES (237,'Guest1','','','','2003-07-11 15:54:35',0,'#');
INSERT INTO nuke_pnchat VALUES (238,'Guest1','','','','2003-07-11 15:54:37',0,'#');
INSERT INTO nuke_pnchat VALUES (239,'Guest1','','','','2003-07-11 15:54:37',0,'#');
INSERT INTO nuke_pnchat VALUES (240,'Guest1','','','','2003-07-11 15:54:38',0,'#');
INSERT INTO nuke_pnchat VALUES (241,'System','','','<i><b>Guest1</b> just jumped to room <b>\'\'</b>.</i><br>','2003-07-11 15:54:40',0,'');
INSERT INTO nuke_pnchat VALUES (242,'System','','','<i><b>Guest1</b> just entered this room.</i><br>','2003-07-11 15:54:40',0,'');
INSERT INTO nuke_pnchat VALUES (243,'System','Guest1','','<b>Users in this room:</b>  <font color=#>Guest1</font> ','2003-07-11 15:54:40',0,'');
INSERT INTO nuke_pnchat VALUES (244,'Guest1','','','','2003-07-11 15:54:40',0,'#');
INSERT INTO nuke_pnchat VALUES (245,'Guest1','','','','2003-07-11 15:55:25',0,'#');
INSERT INTO nuke_pnchat VALUES (246,'Guest1','','','','2003-07-11 15:55:27',0,'#');
INSERT INTO nuke_pnchat VALUES (247,'Guest1','','','','2003-07-11 15:55:27',0,'#');
INSERT INTO nuke_pnchat VALUES (248,'Guest1','','','','2003-07-11 15:55:28',0,'#');
INSERT INTO nuke_pnchat VALUES (249,'Guest1','','','','2003-07-11 15:55:29',0,'#');
INSERT INTO nuke_pnchat VALUES (250,'Guest1','','','','2003-07-11 15:55:30',0,'#');
INSERT INTO nuke_pnchat VALUES (251,'Guest1','','','','2003-07-11 15:55:31',0,'#');
INSERT INTO nuke_pnchat VALUES (252,'Guest1','','','','2003-07-11 15:55:32',0,'#');
INSERT INTO nuke_pnchat VALUES (253,'Guest1','','','','2003-07-11 15:55:33',0,'#');
INSERT INTO nuke_pnchat VALUES (254,'Guest1','','','','2003-07-11 15:55:33',0,'#');
INSERT INTO nuke_pnchat VALUES (255,'Guest1','','','','2003-07-11 15:55:33',0,'#');
INSERT INTO nuke_pnchat VALUES (256,'Guest1','','','','2003-07-11 15:55:33',0,'#');
INSERT INTO nuke_pnchat VALUES (257,'Guest1','','','','2003-07-11 15:57:50',0,'#');
INSERT INTO nuke_pnchat VALUES (258,'System','','','<i><b>Guest1</b> just entered the chat.</i><br>','2003-07-11 15:57:57',0,'');
INSERT INTO nuke_pnchat VALUES (259,'System','Guest1','','<b>Welcome Guest1! Users in this room:</b>  <font color=#>Guest1</font> ','2003-07-11 15:57:57',0,'');
INSERT INTO nuke_pnchat VALUES (260,'Guest1','','','','2003-07-11 15:58:06',0,'#');
INSERT INTO nuke_pnchat VALUES (261,'Guest1','','','','2003-07-11 15:58:08',0,'#');
INSERT INTO nuke_pnchat VALUES (262,'Guest1','','','','2003-07-11 15:58:09',0,'#');
INSERT INTO nuke_pnchat VALUES (263,'System','','','<i><b>Guest1</b> just entered the chat.</i><br>','2003-07-11 15:58:34',0,'');
INSERT INTO nuke_pnchat VALUES (264,'System','Guest1','','<b>Welcome Guest1! Users in this room:</b>  <font color=#>Guest1</font> ','2003-07-11 15:58:34',0,'');
INSERT INTO nuke_pnchat VALUES (265,'System','','','<i><b>Guest1</b> just entered the chat.</i><br>','2003-07-11 15:58:38',0,'');
INSERT INTO nuke_pnchat VALUES (266,'System','Guest1','','<b>Welcome Guest1! Users in this room:</b>  <font color=#>Guest1</font> ','2003-07-11 15:58:38',0,'');
INSERT INTO nuke_pnchat VALUES (267,'Guest1','','','','2003-07-11 15:58:43',0,'#');
INSERT INTO nuke_pnchat VALUES (268,'Guest1','','','','2003-07-11 15:58:44',0,'#');
INSERT INTO nuke_pnchat VALUES (269,'System','','','<i><b>Guest1</b> just entered the chat.</i><br>','2003-07-11 16:00:55',0,'');
INSERT INTO nuke_pnchat VALUES (270,'System','Guest1','','<b>Welcome Guest1! Users in this room:</b>  <font color=#>Guest1</font> ','2003-07-11 16:00:55',0,'');
INSERT INTO nuke_pnchat VALUES (271,'System','','','<i><b>Guest1</b> just entered the chat.</i><br>','2003-07-11 16:01:50',0,'');
INSERT INTO nuke_pnchat VALUES (272,'System','Guest1','','<b>Welcome Guest1! Users in this room:</b>  <font color=#>Guest1</font> ','2003-07-11 16:01:50',0,'');
INSERT INTO nuke_pnchat VALUES (273,'Guest1','','','','2003-07-11 16:02:28',0,'#');
INSERT INTO nuke_pnchat VALUES (274,'System','','','<i><b>Guest1</b> just entered the chat.</i><br>','2003-07-11 16:03:27',0,'');
INSERT INTO nuke_pnchat VALUES (275,'System','Guest1','','<b>Welcome Guest1! Users in this room:</b>  <font color=#>Guest1</font> ','2003-07-11 16:03:27',0,'');
INSERT INTO nuke_pnchat VALUES (276,'Guest1','','','','2003-07-11 16:03:31',0,'#');
INSERT INTO nuke_pnchat VALUES (277,'System','','','<i><b>Guest1</b> just entered the chat.</i><br>','2003-07-11 16:05:04',0,'');
INSERT INTO nuke_pnchat VALUES (278,'System','Guest1','','<b>Welcome Guest1! Users in this room:</b>  <font color=#>Guest1</font> ','2003-07-11 16:05:04',0,'');
INSERT INTO nuke_pnchat VALUES (279,'Guest1','','','','2003-07-11 16:05:20',0,'#');
INSERT INTO nuke_pnchat VALUES (280,'System','','','<i><b>Guest1</b> just entered the chat.</i><br>','2003-07-11 16:05:43',0,'');
INSERT INTO nuke_pnchat VALUES (281,'System','Guest1','','<b>Welcome Guest1! Users in this room:</b>  <font color=#>Guest1</font> ','2003-07-11 16:05:43',0,'');
INSERT INTO nuke_pnchat VALUES (282,'Guest1','','','','2003-07-11 16:05:47',0,'#');
INSERT INTO nuke_pnchat VALUES (283,'System','','','<i><b>Guest1</b> has changed <font color=#4c0707>color</font></i><br>','2003-07-11 16:05:53',0,'');
INSERT INTO nuke_pnchat VALUES (284,'System','','','<i><b>Guest1</b> has changed <font color=#>color</font></i><br>','2003-07-11 16:05:53',0,'');
INSERT INTO nuke_pnchat VALUES (285,'Guest1','','','','2003-07-11 16:06:02',0,'#');
INSERT INTO nuke_pnchat VALUES (286,'System','','','<i><b>Guest1</b> just entered the chat.</i><br>','2003-07-11 16:06:13',0,'');
INSERT INTO nuke_pnchat VALUES (287,'System','Guest1','','<b>Welcome Guest1! Users in this room:</b>  <font color=#>Guest1</font> ','2003-07-11 16:06:13',0,'');
INSERT INTO nuke_pnchat VALUES (288,'Guest1','','fejwfwe','','2003-07-11 16:06:21',0,'#');
INSERT INTO nuke_pnchat VALUES (289,'Guest1','','fjeifjefi','','2003-07-11 16:06:37',0,'#');
INSERT INTO nuke_pnchat VALUES (290,'Guest1','','ifjeifj','','2003-07-11 16:06:38',0,'#');
INSERT INTO nuke_pnchat VALUES (291,'Guest1','','ifjeif','','2003-07-11 16:06:39',0,'#');
INSERT INTO nuke_pnchat VALUES (292,'Guest1','','jeifje','','2003-07-11 16:06:40',0,'#');
INSERT INTO nuke_pnchat VALUES (293,'Guest1','','jgigehjriureh','','2003-07-11 16:06:41',0,'#');
INSERT INTO nuke_pnchat VALUES (294,'Guest1','','dafjefiejf','','2003-07-11 16:06:53',0,'#');
INSERT INTO nuke_pnchat VALUES (295,'Guest1','','hgrhgrig','','2003-07-11 16:06:54',0,'#');
INSERT INTO nuke_pnchat VALUES (296,'System','','','<i><b>Guest1</b> just entered the chat.</i><br>','2003-07-11 16:07:02',0,'');
INSERT INTO nuke_pnchat VALUES (297,'System','Guest1','','<b>Welcome Guest1! Users in this room:</b>  <font color=#>Guest1</font> ','2003-07-11 16:07:02',0,'');
INSERT INTO nuke_pnchat VALUES (298,'Guest1','','fdkjasfl','','2003-07-11 16:07:03',0,'#');
INSERT INTO nuke_pnchat VALUES (299,'Guest1','','jkldsa','','2003-07-11 16:07:05',0,'#');
INSERT INTO nuke_pnchat VALUES (300,'Guest1','','hello','','2003-07-11 16:07:06',0,'#');
INSERT INTO nuke_pnchat VALUES (301,'Guest1','','I am orc','','2003-07-11 16:07:10',0,'#');
INSERT INTO nuke_pnchat VALUES (302,'Guest1','','You notice how we are both Guest1?','','2003-07-11 16:07:23',0,'#');
INSERT INTO nuke_pnchat VALUES (303,'Guest1','',':-V','','2003-07-11 16:07:33',0,'#');
INSERT INTO nuke_pnchat VALUES (304,'Guest1','',':(','','2003-07-11 16:07:37',0,'#');
INSERT INTO nuke_pnchat VALUES (305,'Guest1','',':-Z','','2003-07-11 16:08:18',0,'#');
INSERT INTO nuke_pnchat VALUES (306,'Guest1','',':-)','','2003-07-11 16:08:36',0,'#');
INSERT INTO nuke_pnchat VALUES (307,'System','','','<i><b>Guest1</b> just entered the chat.</i><br>','2003-07-11 16:08:37',0,'');
INSERT INTO nuke_pnchat VALUES (308,'System','Guest1','','<b>Welcome Guest1! Users in this room:</b>  <font color=#>Guest1</font> ','2003-07-11 16:08:37',0,'');
INSERT INTO nuke_pnchat VALUES (309,'System','','','<i><b>Guest1</b> just entered the chat.</i><br>','2003-07-11 16:08:43',0,'');
INSERT INTO nuke_pnchat VALUES (310,'System','Guest1','','<b>Welcome Guest1! Users in this room:</b>  <font color=#>Guest1</font> ','2003-07-11 16:08:43',0,'');
INSERT INTO nuke_pnchat VALUES (311,'Guest1','','(c)','','2003-07-11 16:08:46',0,'#');
INSERT INTO nuke_pnchat VALUES (312,'Guest1','','(b)','','2003-07-11 16:08:49',0,'#');
INSERT INTO nuke_pnchat VALUES (313,'Guest1','','(w)','','2003-07-11 16:08:52',0,'#');
INSERT INTO nuke_pnchat VALUES (314,'Guest1','','(W)','','2003-07-11 16:08:55',0,'#');
INSERT INTO nuke_pnchat VALUES (315,'Guest1','','n00n','','2003-07-11 16:08:57',0,'#');
INSERT INTO nuke_pnchat VALUES (316,'Guest1','','(b)','','2003-07-11 16:09:00',0,'#');
INSERT INTO nuke_pnchat VALUES (317,'Guest1','',']n00b','','2003-07-11 16:09:00',0,'#');
INSERT INTO nuke_pnchat VALUES (318,'System','','','<i><b>Guest1</b> just entered the chat.</i><br>','2003-07-11 16:09:13',0,'');
INSERT INTO nuke_pnchat VALUES (319,'System','Guest1','','<b>Welcome Guest1! Users in this room:</b>  <font color=#>Guest1</font> ','2003-07-11 16:09:13',0,'');
INSERT INTO nuke_pnchat VALUES (320,'Guest1','',':-[','','2003-07-11 16:09:17',0,'#');
INSERT INTO nuke_pnchat VALUES (321,'Guest1','',':-&lt;','','2003-07-11 16:09:59',0,'#');
INSERT INTO nuke_pnchat VALUES (322,'Guest1','',':-?','','2003-07-11 16:10:05',0,'#');
INSERT INTO nuke_pnchat VALUES (323,'System','','','<i><b>Guest1</b> just entered the chat.</i><br>','2003-07-11 16:10:05',0,'');
INSERT INTO nuke_pnchat VALUES (324,'System','Guest1','','<b>Welcome Guest1! Users in this room:</b>  <font color=#>Guest1</font> ','2003-07-11 16:10:05',0,'');
INSERT INTO nuke_pnchat VALUES (325,'System','','','<i><b>Guest1</b> just entered the chat.</i><br>','2003-07-11 16:10:12',0,'');
INSERT INTO nuke_pnchat VALUES (326,'System','Guest1','','<b>Welcome Guest1! Users in this room:</b>  <font color=#>Guest1</font> ','2003-07-11 16:10:12',0,'');
INSERT INTO nuke_pnchat VALUES (327,'Guest1','','blah','','2003-07-11 16:10:23',0,'#');
INSERT INTO nuke_pnchat VALUES (328,'System','','','<i><b>Guest1</b> just entered the chat.</i><br>','2003-07-11 16:10:57',0,'');
INSERT INTO nuke_pnchat VALUES (329,'System','Guest1','','<b>Welcome Guest1! Users in this room:</b>  <font color=#>Guest1</font> ','2003-07-11 16:10:57',0,'');
INSERT INTO nuke_pnchat VALUES (330,'System','','','<i><b>Guest1</b> just entered the chat.</i><br>','2003-07-11 16:11:05',0,'');
INSERT INTO nuke_pnchat VALUES (331,'System','Guest1','','<b>Welcome Guest1! Users in this room:</b>  <font color=#>Guest1</font> ','2003-07-11 16:11:05',0,'');
INSERT INTO nuke_pnchat VALUES (332,'System','','','<i><b>Guest1</b> has changed <font color=#4c0707>color</font></i><br>','2003-07-11 16:11:25',0,'');
INSERT INTO nuke_pnchat VALUES (333,'Guest1','','dfsa','','2003-07-11 16:11:28',0,'#4c0707');
INSERT INTO nuke_pnchat VALUES (334,'Guest1','','fdsafsdaf','','2003-07-11 16:11:30',0,'#4c0707');
INSERT INTO nuke_pnchat VALUES (335,'Guest1','','fdasfdsafsdf','','2003-07-11 16:12:08',0,'#4c0707');
INSERT INTO nuke_pnchat VALUES (336,'Guest1','',':-[','','2003-07-11 16:12:14',0,'#4c0707');
INSERT INTO nuke_pnchat VALUES (337,'Guest1','','blah','','2003-07-11 16:12:47',0,'#4c0707');
INSERT INTO nuke_pnchat VALUES (338,'Guest1','','http://trouble/modules/pnchat/pnimages/spectrum2.png','','2003-07-11 16:12:53',0,'#4c0707');
INSERT INTO nuke_pnchat VALUES (339,'Guest1','','wefwe','','2003-07-11 16:13:12',0,'#4c0707');
INSERT INTO nuke_pnchat VALUES (340,'System','','','<i><b>Guest1</b> has changed <font color=#4c0707>color</font></i><br>','2003-07-11 16:13:17',0,'');
INSERT INTO nuke_pnchat VALUES (341,'System','','','<i><b>Guest1</b> has changed <font color=#4c0707>color</font></i><br>','2003-07-11 16:13:21',0,'');
INSERT INTO nuke_pnchat VALUES (342,'System','','','<i><b>Guest1</b> has changed <font color=#4c0707>color</font></i><br>','2003-07-11 16:13:25',0,'');
INSERT INTO nuke_pnchat VALUES (343,'Guest1','','','','2003-07-11 16:13:25',0,'#4c0707');
INSERT INTO nuke_pnchat VALUES (344,'Guest1','','jeife','','2003-07-11 16:13:27',0,'#4c0707');
INSERT INTO nuke_pnchat VALUES (345,'System','','','<i><b>Guest1</b> has changed <font color=#4c0707>color</font></i><br>','2003-07-11 16:13:29',0,'');
INSERT INTO nuke_pnchat VALUES (346,'System','','','<i><b>Guest1</b> has changed <font color=#>color</font></i><br>','2003-07-11 16:13:30',0,'');
INSERT INTO nuke_pnchat VALUES (347,'System','','','<i><b>Guest1</b> has changed <font color=#4c0707>color</font></i><br>','2003-07-11 16:13:30',0,'');
INSERT INTO nuke_pnchat VALUES (348,'System','','','<i><b>Guest1</b> has changed <font color=#4c0707>color</font></i><br>','2003-07-11 16:13:33',0,'');
INSERT INTO nuke_pnchat VALUES (349,'Guest1','','jieefji','','2003-07-11 16:13:36',0,'#4c0707');
INSERT INTO nuke_pnchat VALUES (350,'System','','','<i><b>Guest1</b> has changed <font color=#4c0707>color</font></i><br>','2003-07-11 16:13:39',0,'');
INSERT INTO nuke_pnchat VALUES (351,'Guest1','','iejfwie','','2003-07-11 16:13:39',0,'#4c0707');
INSERT INTO nuke_pnchat VALUES (352,'System','','','<i><b>Guest1</b> has changed <font color=#4c0707>color</font></i><br>','2003-07-11 16:13:41',0,'');
INSERT INTO nuke_pnchat VALUES (353,'System','','','<i><b>Guest1</b> has changed <font color=#4c0707>color</font></i><br>','2003-07-11 16:13:43',0,'');
INSERT INTO nuke_pnchat VALUES (354,'System','','','<i><b>Guest1</b> has changed <font color=#4c0707>color</font></i><br>','2003-07-11 16:13:45',0,'');
INSERT INTO nuke_pnchat VALUES (355,'System','','','<i><b>Guest1</b> has changed <font color=#>color</font></i><br>','2003-07-11 16:13:45',0,'');
INSERT INTO nuke_pnchat VALUES (356,'System','','','<i><b>Guest1</b> has changed <font color=#>color</font></i><br>','2003-07-11 16:13:46',0,'');
INSERT INTO nuke_pnchat VALUES (357,'Guest1','','klfjdlsa','','2003-07-11 16:13:49',0,'#');
INSERT INTO nuke_pnchat VALUES (358,'System','','','<i><b>Guest1</b> has changed <font color=#>color</font></i><br>','2003-07-11 16:13:51',0,'');
INSERT INTO nuke_pnchat VALUES (359,'System','','','<i><b>Guest1</b> has changed <font color=#4c0707>color</font></i><br>','2003-07-11 16:13:54',0,'');
INSERT INTO nuke_pnchat VALUES (360,'System','','','<i><b>Guest1</b> has changed <font color=#4c0707>color</font></i><br>','2003-07-11 16:13:55',0,'');
INSERT INTO nuke_pnchat VALUES (361,'System','','','<i><b>Guest1</b> has changed <font color=#4c0707>color</font></i><br>','2003-07-11 16:13:56',0,'');
INSERT INTO nuke_pnchat VALUES (362,'System','','','<i><b>Guest1</b> has changed <font color=#4c0707>color</font></i><br>','2003-07-11 16:13:57',0,'');
INSERT INTO nuke_pnchat VALUES (363,'System','','','<i><b>Guest1</b> has changed <font color=#4c0707>color</font></i><br>','2003-07-11 16:14:00',0,'');
INSERT INTO nuke_pnchat VALUES (364,'System','','','<i><b>Guest1</b> has changed <font color=#4c0707>color</font></i><br>','2003-07-11 16:14:00',0,'');
INSERT INTO nuke_pnchat VALUES (365,'System','','','<i><b>Guest1</b> has changed <font color=#4c0707>color</font></i><br>','2003-07-11 16:14:02',0,'');
INSERT INTO nuke_pnchat VALUES (366,'System','','','<i><b>Guest1</b> has changed <font color=#4c0707>color</font></i><br>','2003-07-11 16:14:03',0,'');
INSERT INTO nuke_pnchat VALUES (367,'System','','','<i><b>Guest1</b> has changed <font color=#4c0707>color</font></i><br>','2003-07-11 16:14:04',0,'');
INSERT INTO nuke_pnchat VALUES (368,'System','','','<i><b>Guest1</b> has changed <font color=#>color</font></i><br>','2003-07-11 16:14:05',0,'');
INSERT INTO nuke_pnchat VALUES (369,'System','','','<i><b>Guest1</b> has changed <font color=#>color</font></i><br>','2003-07-11 16:14:06',0,'');
INSERT INTO nuke_pnchat VALUES (370,'System','','','<i><b>Guest1</b> has changed <font color=#4c0707>color</font></i><br>','2003-07-11 16:14:06',0,'');
INSERT INTO nuke_pnchat VALUES (371,'System','','','<i><b>Guest1</b> has changed <font color=#4c0707>color</font></i><br>','2003-07-11 16:14:07',0,'');
INSERT INTO nuke_pnchat VALUES (372,'System','','','<i><b>Guest1</b> has changed <font color=#4c0707>color</font></i><br>','2003-07-11 16:14:08',0,'');
INSERT INTO nuke_pnchat VALUES (373,'System','','','<i><b>Guest1</b> has changed <font color=#4c0707>color</font></i><br>','2003-07-11 16:14:09',0,'');
INSERT INTO nuke_pnchat VALUES (374,'System','','','<i><b>Guest1</b> has changed <font color=#>color</font></i><br>','2003-07-11 16:14:11',0,'');
INSERT INTO nuke_pnchat VALUES (375,'Guest1','','','','2003-07-11 16:14:12',0,'#');
INSERT INTO nuke_pnchat VALUES (376,'System','Guest1','','Username rexlunae is used by a registered user. Please register to reserve your own nickname.<br>','2003-07-11 16:14:26',0,'');
INSERT INTO nuke_pnchat VALUES (377,'Guest1','',':-[','','2003-07-11 16:14:26',0,'#');
INSERT INTO nuke_pnchat VALUES (378,'Guest1','',':-[','','2003-07-11 16:14:32',0,'#');
INSERT INTO nuke_pnchat VALUES (379,'System','','','<i><b>Guest1</b> changed the nickname to <b>\'foobar\'</b></i><br>','2003-07-11 16:14:37',0,'');
INSERT INTO nuke_pnchat VALUES (380,'foobar','','asdf','','2003-07-11 16:14:41',0,'#');
INSERT INTO nuke_pnchat VALUES (381,'foobar','','[Guest1]: ','','2003-07-11 16:14:42',0,'#');
INSERT INTO nuke_pnchat VALUES (382,'foobar','','fdsaf','','2003-07-11 16:14:45',0,'#');
INSERT INTO nuke_pnchat VALUES (383,'foobar','','ejfie','','2003-07-11 16:14:46',0,'#');
INSERT INTO nuke_pnchat VALUES (384,'foobar','','I am foobar','','2003-07-11 16:14:51',0,'#');
INSERT INTO nuke_pnchat VALUES (385,'foobar','',':-[','','2003-07-11 16:14:59',0,'#');
INSERT INTO nuke_pnchat VALUES (386,'foobar','',':-[','','2003-07-11 16:15:03',0,'#');
INSERT INTO nuke_pnchat VALUES (387,'System','','','<i><b>foobar</b> just entered the chat.</i><br>','2003-07-11 16:15:03',0,'');
INSERT INTO nuke_pnchat VALUES (388,'System','foobar','','<b>Welcome foobar! Users in this room:</b>  <font color=#>foobar</font> ','2003-07-11 16:15:03',0,'');
INSERT INTO nuke_pnchat VALUES (389,'foobar','',':-[','','2003-07-11 16:15:04',0,'#');
INSERT INTO nuke_pnchat VALUES (390,'foobar','',':-[','','2003-07-11 16:15:05',0,'#');
INSERT INTO nuke_pnchat VALUES (391,'foobar','',':-[','','2003-07-11 16:15:06',0,'#');
INSERT INTO nuke_pnchat VALUES (392,'foobar','',':-[','','2003-07-11 16:15:07',0,'#');
INSERT INTO nuke_pnchat VALUES (393,'foobar','',':-[','','2003-07-11 16:15:08',0,'#');
INSERT INTO nuke_pnchat VALUES (394,'foobar','',':-[','','2003-07-11 16:15:08',0,'#');
INSERT INTO nuke_pnchat VALUES (395,'foobar','',':-[','','2003-07-11 16:15:09',0,'#');
INSERT INTO nuke_pnchat VALUES (396,'foobar','',':-[','','2003-07-11 16:15:10',0,'#');
INSERT INTO nuke_pnchat VALUES (397,'System','','','<i><b>foobar</b> just entered the chat.</i><br>','2003-07-11 16:15:11',0,'');
INSERT INTO nuke_pnchat VALUES (398,'System','foobar','','<b>Welcome foobar! Users in this room:</b>  <font color=#>foobar</font> ','2003-07-11 16:15:11',0,'');
INSERT INTO nuke_pnchat VALUES (399,'foobar','',':-[','','2003-07-11 16:15:11',0,'#');
INSERT INTO nuke_pnchat VALUES (400,'foobar','',':-[','','2003-07-11 16:15:12',0,'#');
INSERT INTO nuke_pnchat VALUES (401,'foobar','',':-[','','2003-07-11 16:15:13',0,'#');
INSERT INTO nuke_pnchat VALUES (402,'foobar','',':-[','','2003-07-11 16:15:14',0,'#');
INSERT INTO nuke_pnchat VALUES (403,'foobar','',':-[','','2003-07-11 16:15:15',0,'#');
INSERT INTO nuke_pnchat VALUES (404,'System','','','<i><b>foobar</b> just entered the chat.</i><br>','2003-07-11 16:15:15',0,'');
INSERT INTO nuke_pnchat VALUES (405,'System','foobar','','<b>Welcome foobar! Users in this room:</b>  <font color=#>foobar</font> ','2003-07-11 16:15:15',0,'');
INSERT INTO nuke_pnchat VALUES (406,'foobar','',':-[','','2003-07-11 16:15:16',0,'#');
INSERT INTO nuke_pnchat VALUES (407,'foobar','',':-[','','2003-07-11 16:15:17',0,'#');
INSERT INTO nuke_pnchat VALUES (408,'foobar','',':-[','','2003-07-11 16:15:17',0,'#');
INSERT INTO nuke_pnchat VALUES (409,'foobar','','(c)','','2003-07-11 16:15:18',0,'#');
INSERT INTO nuke_pnchat VALUES (410,'foobar','',':-[','','2003-07-11 16:15:18',0,'#');
INSERT INTO nuke_pnchat VALUES (411,'foobar','',':-[','','2003-07-11 16:15:19',0,'#');
INSERT INTO nuke_pnchat VALUES (412,'foobar','',':-[','','2003-07-11 16:15:20',0,'#');
INSERT INTO nuke_pnchat VALUES (413,'foobar','',':-[','','2003-07-11 16:15:21',0,'#');
INSERT INTO nuke_pnchat VALUES (414,'foobar','',':-[','','2003-07-11 16:15:22',0,'#');
INSERT INTO nuke_pnchat VALUES (415,'foobar','',':-[','','2003-07-11 16:15:23',0,'#');
INSERT INTO nuke_pnchat VALUES (416,'foobar','',':-[','','2003-07-11 16:15:23',0,'#');
INSERT INTO nuke_pnchat VALUES (417,'foobar','',':-[','','2003-07-11 16:15:24',0,'#');
INSERT INTO nuke_pnchat VALUES (418,'foobar','',':-[','','2003-07-11 16:15:25',0,'#');
INSERT INTO nuke_pnchat VALUES (419,'foobar','',':-[','','2003-07-11 16:15:26',0,'#');
INSERT INTO nuke_pnchat VALUES (420,'foobar','',':-[','','2003-07-11 16:15:27',0,'#');
INSERT INTO nuke_pnchat VALUES (421,'foobar','',':-[','','2003-07-11 16:15:28',0,'#');
INSERT INTO nuke_pnchat VALUES (422,'foobar','',':-[','','2003-07-11 16:15:29',0,'#');
INSERT INTO nuke_pnchat VALUES (423,'foobar','',':-[','','2003-07-11 16:15:30',0,'#');
INSERT INTO nuke_pnchat VALUES (424,'foobar','',':-(:-(:-(:-(:-(:-(:-(:-(:-(:-(:-(:-(:-(:-(:-(:-(:-(:-(:-(:-(:-(:-(:-(:-(:-(:-(:-(:-(','','2003-07-11 16:15:39',0,'#');
INSERT INTO nuke_pnchat VALUES (425,'foobar','',':-[','','2003-07-11 16:15:48',0,'#');
INSERT INTO nuke_pnchat VALUES (426,'System','','','<i><b>foobar</b> just entered the chat.</i><br>','2003-07-11 16:15:50',0,'');
INSERT INTO nuke_pnchat VALUES (427,'System','foobar','','<b>Welcome foobar! Users in this room:</b>  <font color=#>foobar</font> ','2003-07-11 16:15:50',0,'');
INSERT INTO nuke_pnchat VALUES (428,'System','','','<i><b>foobar</b> just entered the chat.</i><br>','2003-07-11 16:15:59',0,'');
INSERT INTO nuke_pnchat VALUES (429,'System','foobar','','<b>Welcome foobar! Users in this room:</b>  <font color=#>foobar</font> ','2003-07-11 16:15:59',0,'');
INSERT INTO nuke_pnchat VALUES (430,'foobar','',':-[:-[:-[:-[:-[:-[:-[:-[:-[:-[:-[:-[:-[:-[:-[:-[:-[:-[:-[:-[:-[:-[:-[:-[:-[:-[:-[:-[:-[:-[:-[:-[:-[:-[:-[:-[:-[:-[:-[:-[:-[:-[:-[','','2003-07-11 16:16:02',0,'#');
INSERT INTO nuke_pnchat VALUES (431,'foobar','',':-|','','2003-07-11 16:16:04',0,'#');
INSERT INTO nuke_pnchat VALUES (432,'foobar','','','','2003-07-11 16:16:07',0,'#');
INSERT INTO nuke_pnchat VALUES (433,'foobar','','','','2003-07-11 16:16:12',0,'#');
INSERT INTO nuke_pnchat VALUES (434,'foobar','','iefjeief','','2003-07-11 16:16:14',0,'#');
INSERT INTO nuke_pnchat VALUES (435,'foobar','','djkflasdjfkljdsafkldsjfkljdskljfklsdajfkljdsklfjkldsjfkldsjklfjdslkjfklsdjfkl;jsdklf;klsdjafklsdjklfjdsafklsdjfklsdjfkljdsklfjklsdjfklsdjfkljsdklfjdskljfklsdjfklsdjafkl;jdsklfjkldsjflksdjfkl;sdj','','2003-07-11 16:16:27',0,'#');
INSERT INTO nuke_pnchat VALUES (436,'System','foobar','','Username Admin is used by a registered user. Please register to reserve your own nickname.<br>','2003-07-11 16:16:44',0,'');
INSERT INTO nuke_pnchat VALUES (437,'foobar','guest1','foo bar','','2003-07-11 16:17:31',0,'#');
INSERT INTO nuke_pnchat VALUES (438,'System','','','<i><b>foobar</b> just left the chat.</i><br>','2003-07-11 16:18:48',0,'');
INSERT INTO nuke_pnchat VALUES (439,'System','','','<i><b>foobar</b> just left the chat.</i><br>','2003-07-11 16:18:48',0,'');
INSERT INTO nuke_pnchat VALUES (440,'System','','','<i><b>foobar</b> just left the chat.</i><br>','2003-07-11 16:18:48',0,'');
INSERT INTO nuke_pnchat VALUES (441,'System','','','<i><b>foobar</b> just left the chat.</i><br>','2003-07-11 16:18:48',0,'');
INSERT INTO nuke_pnchat VALUES (442,'System','','','<i><b>foobar</b> just left the chat.</i><br>','2003-07-11 16:18:48',0,'');
INSERT INTO nuke_pnchat VALUES (443,'System','','','<i><b>foobar</b> just left the chat.</i><br>','2003-07-11 16:18:48',0,'');
INSERT INTO nuke_pnchat VALUES (444,'System','','','<i><b>foobar</b> just left the chat.</i><br>','2003-07-11 16:18:48',0,'');
INSERT INTO nuke_pnchat VALUES (445,'System','','','<i><b>foobar</b> just left the chat.</i><br>','2003-07-11 16:18:48',0,'');
INSERT INTO nuke_pnchat VALUES (446,'System','','','<i><b>foobar</b> just left the chat.</i><br>','2003-07-11 16:18:48',0,'');
INSERT INTO nuke_pnchat VALUES (447,'System','','','<i><b>foobar</b> just left the chat.</i><br>','2003-07-11 16:18:48',0,'');
INSERT INTO nuke_pnchat VALUES (448,'System','','','<i><b>foobar</b> just left the chat.</i><br>','2003-07-11 16:18:48',0,'');
INSERT INTO nuke_pnchat VALUES (449,'System','','','<i><b>foobar</b> just left the chat.</i><br>','2003-07-11 16:18:48',0,'');
INSERT INTO nuke_pnchat VALUES (450,'System','','','<i><b>foobar</b> just left the chat.</i><br>','2003-07-11 16:18:48',0,'');
INSERT INTO nuke_pnchat VALUES (451,'System','','','<i><b>foobar</b> just left the chat.</i><br>','2003-07-11 16:18:48',0,'');
INSERT INTO nuke_pnchat VALUES (452,'System','','','<i><b>foobar</b> just left the chat.</i><br>','2003-07-11 16:18:48',0,'');
INSERT INTO nuke_pnchat VALUES (453,'System','','','<i><b>foobar</b> just left the chat.</i><br>','2003-07-11 16:18:48',0,'');
INSERT INTO nuke_pnchat VALUES (454,'System','','','<i><b>foobar</b> just left the chat.</i><br>','2003-07-11 16:18:48',0,'');
INSERT INTO nuke_pnchat VALUES (455,'System','','','<i><b>foobar</b> just left the chat.</i><br>','2003-07-11 16:18:48',0,'');
INSERT INTO nuke_pnchat VALUES (456,'System','','','<i><b>foobar</b> just left the chat.</i><br>','2003-07-11 16:18:48',0,'');
INSERT INTO nuke_pnchat VALUES (457,'System','','','<i><b>foobar</b> just left the chat.</i><br>','2003-07-11 16:18:48',0,'');
INSERT INTO nuke_pnchat VALUES (458,'System','','','<i><b>foobar</b> just left the chat.</i><br>','2003-07-11 16:18:48',0,'');
INSERT INTO nuke_pnchat VALUES (459,'System','','','<i><b>foobar</b> just left the chat.</i><br>','2003-07-11 16:18:48',0,'');
INSERT INTO nuke_pnchat VALUES (460,'System','','','<i><b>foobar</b> just left the chat.</i><br>','2003-07-11 16:18:48',0,'');
INSERT INTO nuke_pnchat VALUES (461,'System','','','<i><b>foobar</b> just left the chat.</i><br>','2003-07-11 16:18:48',0,'');
INSERT INTO nuke_pnchat VALUES (462,'System','','','<i><b>foobar</b> just entered the chat.</i><br>','2003-07-11 16:19:02',0,'');
INSERT INTO nuke_pnchat VALUES (463,'System','foobar','','<b>Welcome foobar! Users in this room:</b>  <font color=#>foobar</font> ','2003-07-11 16:19:02',0,'');
INSERT INTO nuke_pnchat VALUES (464,'System','','','<i><b>foobar</b> just entered the chat.</i><br>','2003-07-11 16:19:15',0,'');
INSERT INTO nuke_pnchat VALUES (465,'System','foobar','','<b>Welcome foobar! Users in this room:</b>  <font color=#>foobar</font> ','2003-07-11 16:19:15',0,'');
INSERT INTO nuke_pnchat VALUES (466,'System','','','<i><b>foobar</b> just entered the chat.</i><br>','2003-07-11 16:19:37',0,'');
INSERT INTO nuke_pnchat VALUES (467,'System','foobar','','<b>Welcome foobar! Users in this room:</b>  <font color=#>foobar</font> ','2003-07-11 16:19:37',0,'');
INSERT INTO nuke_pnchat VALUES (468,'foobar','','hello','','2003-07-11 16:19:42',0,'#');
INSERT INTO nuke_pnchat VALUES (469,'System','','','<i><b>foobar</b> just entered the chat.</i><br>','2003-07-11 16:19:46',0,'');
INSERT INTO nuke_pnchat VALUES (470,'System','foobar','','<b>Welcome foobar! Users in this room:</b>  <font color=#>foobar</font> ','2003-07-11 16:19:46',0,'');
INSERT INTO nuke_pnchat VALUES (471,'System','foobar','','Username n00b is used by a registered user. Please register to reserve your own nickname.<br>','2003-07-11 16:19:53',0,'');
INSERT INTO nuke_pnchat VALUES (472,'System','','','<i><b>foobar</b> just entered the chat.</i><br>','2003-07-11 16:21:22',0,'');
INSERT INTO nuke_pnchat VALUES (473,'System','foobar','','<b>Welcome foobar! Users in this room:</b>  <font color=#>foobar</font> ','2003-07-11 16:21:22',0,'');
INSERT INTO nuke_pnchat VALUES (474,'foobar','','fdafadsfdsa','','2003-07-11 16:21:28',0,'#');
INSERT INTO nuke_pnchat VALUES (475,'System','','','<i><b>foobar</b> just entered the chat.</i><br>','2003-07-11 16:21:40',0,'');
INSERT INTO nuke_pnchat VALUES (476,'System','foobar','','<b>Welcome foobar! Users in this room:</b>  <font color=#>foobar</font> ','2003-07-11 16:21:40',0,'');
INSERT INTO nuke_pnchat VALUES (477,'System','','','<i><b>foobar</b> just entered the chat.</i><br>','2003-07-11 16:22:30',0,'');
INSERT INTO nuke_pnchat VALUES (478,'System','foobar','','<b>Welcome foobar! Users in this room:</b>  <font color=#>foobar</font> ','2003-07-11 16:22:30',0,'');
INSERT INTO nuke_pnchat VALUES (479,'foobar','','Smiles','','2003-07-11 16:23:42',0,'#');
INSERT INTO nuke_pnchat VALUES (480,'System','foobar','','<BR><BR><FONT FACE=VERDANA,HELVETICA SIZE=1 COLOR=#000000><B>Latest Linux kernel versions:<br>-----------------------------------<br><br>The latest stable version of the Linux kernel is:           2.4.21<br />\r\nThe latest prepatch for the stable Linux kernel tree is:    2.4.22-pre5<br />\r\nThe latest snapshot for the stable Linux kernel tree is:    2.4.21-bk7<br />\r\nThe latest beta version of the Linux kernel is:             2.5.75<br />\r\nThe latest snapshot for the beta Linux kernel tree is:      2.5.75-bk1<br />\r\nThe latest 2.2 version of the Linux kernel is:              2.2.25<br />\r\nThe latest 2.0 version of the Linux kernel is:              2.0.39<br />\r\nThe latest prepatch for the 2.0 Linux kernel tree is:       2.0.40-rc6<br />\r\nThe latest -ac patch to the stable Linux kernels is:        2.4.22-pre3-ac1<br />\r\nThe latest -ac patch to the beta Linux kernels is:          2.5.69-ac1<br />\r\nThe latest -dj patch to the beta Linux kernels is:          2.5.69-dj1<br />\r\n</b></font>','2003-07-11 16:23:44',0,'');
INSERT INTO nuke_pnchat VALUES (481,'System','','','<b>foobar n00b</b>','2003-07-11 16:23:55',0,'');
INSERT INTO nuke_pnchat VALUES (482,'System','','','<b>foobar n00b hello world</b>','2003-07-11 16:24:09',0,'');
INSERT INTO nuke_pnchat VALUES (483,'System','','','<b>foobar hello world</b>','2003-07-11 16:24:21',0,'');
INSERT INTO nuke_pnchat VALUES (484,'System','foobar','','Username n00b is used by a registered user. Please register to reserve your own nickname.<br>','2003-07-11 16:24:35',0,'');
INSERT INTO nuke_pnchat VALUES (485,'System','','','<i><b>foobar</b> has changed <font color=#222222>color</font></i><br>','2003-07-11 16:25:06',0,'');
INSERT INTO nuke_pnchat VALUES (486,'foobar','','hello','','2003-07-11 16:25:10',0,'#222222');
INSERT INTO nuke_pnchat VALUES (487,'System','foobar','','<i>Usage:</i> /color #xxxxxx<br>','2003-07-11 16:25:18',0,'');
INSERT INTO nuke_pnchat VALUES (488,'System','','','<i><b>foobar</b> has changed <font color=#000222>color</font></i><br>','2003-07-11 16:25:27',0,'');
INSERT INTO nuke_pnchat VALUES (489,'foobar','','hello','','2003-07-11 16:25:29',0,'#000222');
INSERT INTO nuke_pnchat VALUES (490,'foobar','','hello mcfly','','2003-07-11 16:25:37',0,'#000222');
INSERT INTO nuke_pnchat VALUES (491,'System','','','<i><b>foobar</b> just left the chat.</i><br>','2003-07-11 16:26:26',0,'');
INSERT INTO nuke_pnchat VALUES (492,'System','','','<i><b>foobar</b> just left the chat.</i><br>','2003-07-11 16:26:26',0,'');
INSERT INTO nuke_pnchat VALUES (493,'System','','','<i><b>foobar</b> just left the chat.</i><br>','2003-07-11 16:26:26',0,'');
INSERT INTO nuke_pnchat VALUES (494,'System','','','<i><b>foobar</b> just left the chat.</i><br>','2003-07-11 16:26:26',0,'');
INSERT INTO nuke_pnchat VALUES (495,'System','','','<i><b>foobar</b> just left the chat.</i><br>','2003-07-11 16:26:26',0,'');
INSERT INTO nuke_pnchat VALUES (496,'System','','','<i><b>foobar</b> just left the chat.</i><br>','2003-07-11 16:26:26',0,'');
INSERT INTO nuke_pnchat VALUES (497,'System','','','<i><b>foobar</b> just left the chat.</i><br>','2003-07-11 16:26:26',0,'');
INSERT INTO nuke_pnchat VALUES (498,'System','','','<i><b>foobar</b> just entered the chat.</i><br>','2003-07-11 16:33:39',0,'');
INSERT INTO nuke_pnchat VALUES (499,'System','foobar','','<b>Welcome foobar! Users in this room:</b>  <font color=#000222>foobar</font> ','2003-07-11 16:33:39',0,'');
INSERT INTO nuke_pnchat VALUES (500,'System','','','<i><b>foobar</b> just left the chat.</i><br>','2003-07-11 16:34:19',0,'');
INSERT INTO nuke_pnchat VALUES (501,'System','','','<i><b>foobar</b> just entered the chat.</i><br>','2003-07-11 16:40:54',0,'');
INSERT INTO nuke_pnchat VALUES (502,'System','foobar','','<b>Welcome foobar! Users in this room:</b>  <font color=#000222>foobar</font> ','2003-07-11 16:40:54',0,'');
INSERT INTO nuke_pnchat VALUES (503,'System','','','<i><b>foobar</b> just entered the chat.</i><br>','2003-07-11 16:46:56',0,'');
INSERT INTO nuke_pnchat VALUES (504,'System','foobar','','<b>Welcome foobar! Users in this room:</b>  <font color=#000222>foobar</font> ','2003-07-11 16:46:56',0,'');
INSERT INTO nuke_pnchat VALUES (505,'System','','','<i><b>foobar</b> just entered the chat.</i><br>','2003-07-11 16:49:05',0,'');
INSERT INTO nuke_pnchat VALUES (506,'System','foobar','','<b>Welcome foobar! Users in this room:</b>  <font color=#000222>foobar</font> ','2003-07-11 16:49:05',0,'');
INSERT INTO nuke_pnchat VALUES (507,'foobar','','foo','','2003-07-11 16:49:11',0,'#000222');
INSERT INTO nuke_pnchat VALUES (508,'System','','','<i><b>foobar</b> changed the nickname to <b>\'asdffdsa\'</b></i><br>','2003-07-11 16:49:21',0,'');
INSERT INTO nuke_pnchat VALUES (509,'System','','','<i><b>asdffdsa</b> just entered the chat.</i><br>','2003-07-11 16:50:52',0,'');
INSERT INTO nuke_pnchat VALUES (510,'System','asdffdsa','','<b>Welcome asdffdsa! Users in this room:</b>  <font color=#000222>asdffdsa</font> ','2003-07-11 16:50:52',0,'');
INSERT INTO nuke_pnchat VALUES (511,'System','','','<i><b>asdffdsa</b> just entered the chat.</i><br>','2003-07-11 16:51:57',0,'');
INSERT INTO nuke_pnchat VALUES (512,'System','asdffdsa','','<b>Welcome asdffdsa! Users in this room:</b>  <font color=#000222>asdffdsa</font> ','2003-07-11 16:51:57',0,'');
INSERT INTO nuke_pnchat VALUES (513,'asdffdsa','','','','2003-07-11 16:52:18',0,'#000222');
INSERT INTO nuke_pnchat VALUES (514,'asdffdsa','','jfiefe','','2003-07-11 16:52:19',0,'#000222');
INSERT INTO nuke_pnchat VALUES (515,'System','','','<i><b>asdffdsa</b> just entered the chat.</i><br>','2003-07-11 16:52:25',0,'');
INSERT INTO nuke_pnchat VALUES (516,'System','asdffdsa','','<b>Welcome asdffdsa! Users in this room:</b>  <font color=#000222>asdffdsa</font> ','2003-07-11 16:52:25',0,'');
INSERT INTO nuke_pnchat VALUES (517,'System','','','<i><b>asdffdsa</b> just entered the chat.</i><br>','2003-07-11 16:52:30',0,'');
INSERT INTO nuke_pnchat VALUES (518,'System','asdffdsa','','<b>Welcome asdffdsa! Users in this room:</b>  <font color=#000222>asdffdsa</font> ','2003-07-11 16:52:30',0,'');
INSERT INTO nuke_pnchat VALUES (519,'System','','','<i><b>asdffdsa</b> just entered the chat.</i><br>','2003-07-11 16:52:55',0,'');
INSERT INTO nuke_pnchat VALUES (520,'System','asdffdsa','','<b>Welcome asdffdsa! Users in this room:</b>  <font color=#000222>asdffdsa</font> ','2003-07-11 16:52:55',0,'');
INSERT INTO nuke_pnchat VALUES (521,'System','','','<i><b>asdffdsa</b> just entered the chat.</i><br>','2003-07-11 16:53:18',0,'');
INSERT INTO nuke_pnchat VALUES (522,'System','asdffdsa','','<b>Welcome asdffdsa! Users in this room:</b>  <font color=#000222>asdffdsa</font> ','2003-07-11 16:53:18',0,'');
INSERT INTO nuke_pnchat VALUES (523,'System','','','<i><b>asdffdsa</b> just entered the chat.</i><br>','2003-07-11 16:53:51',0,'');
INSERT INTO nuke_pnchat VALUES (524,'System','asdffdsa','','<b>Welcome asdffdsa! Users in this room:</b>  <font color=#000222>asdffdsa</font> ','2003-07-11 16:53:51',0,'');
INSERT INTO nuke_pnchat VALUES (525,'System','','','<i><b>asdffdsa</b> just entered the chat.</i><br>','2003-07-11 16:54:22',0,'');
INSERT INTO nuke_pnchat VALUES (526,'System','asdffdsa','','<b>Welcome asdffdsa! Users in this room:</b>  <font color=#000222>asdffdsa</font> ','2003-07-11 16:54:22',0,'');
INSERT INTO nuke_pnchat VALUES (527,'System','','','<i><b>asdffdsa</b> just entered the chat.</i><br>','2003-07-11 16:54:25',0,'');
INSERT INTO nuke_pnchat VALUES (528,'System','asdffdsa','','<b>Welcome asdffdsa! Users in this room:</b>  <font color=#000222>asdffdsa</font> ','2003-07-11 16:54:25',0,'');
INSERT INTO nuke_pnchat VALUES (529,'asdffdsa','','(c)(b)','','2003-07-11 16:55:11',0,'#000222');
INSERT INTO nuke_pnchat VALUES (530,'System','asdffdsa','','<BR><BR><FONT FACE=VERDANA,HELVETICA SIZE=1 COLOR=#000000><B>Available Commands:<br>----------------------------<br>/color #xxxxxx (HEX)<br>/me [action] (i.e. \'/me is sick\' would be \'username is sick\')<br>/linux (Shows latest kernel versions)<br>/date (Shows our server\'s date and time)<br>/msg [username] [message] (send a private message to a user)<br>/userlist (Shows a list of all users currently in your chatroom)<br>/tech (Gives you details on the basic technology I use here!)<br>/roomlist (Shows a list of all available chatrooms)<br>/room [roomname] (Jump to another room or create a new one)<br>/roomdescription [description] (Change the room description (Admin ONLY))<br>/fortune (Shows a random fortune cookie)<br>/nick [nickname] (Change your nickname)<br></B></FONT>','2003-07-11 16:55:21',0,'');
INSERT INTO nuke_pnchat VALUES (531,'System','','','<i><b>asdffdsa</b> has changed <font color=#bedead>color</font></i><br>','2003-07-11 16:55:33',0,'');
INSERT INTO nuke_pnchat VALUES (532,'asdffdsa','','asdf','','2003-07-11 16:55:40',0,'#bedead');
INSERT INTO nuke_pnchat VALUES (533,'System','','','<i><b>asdffdsa</b> has changed <font color=#123456>color</font></i><br>','2003-07-11 16:56:06',0,'');
INSERT INTO nuke_pnchat VALUES (534,'asdffdsa','','adsf','','2003-07-11 16:56:09',0,'#123456');
INSERT INTO nuke_pnchat VALUES (535,'asdffdsa','','iwejiewf','','2003-07-11 16:56:11',0,'#123456');
INSERT INTO nuke_pnchat VALUES (536,'System','asdffdsa','','<BR><BR><FONT FACE=VERDANA,HELVETICA SIZE=1 COLOR=#000000><B>Latest Linux kernel versions:<br>-----------------------------------<br><br>The latest stable version of the Linux kernel is:           2.4.21<br />\r\nThe latest prepatch for the stable Linux kernel tree is:    2.4.22-pre5<br />\r\nThe latest snapshot for the stable Linux kernel tree is:    2.4.21-bk7<br />\r\nThe latest beta version of the Linux kernel is:             2.5.75<br />\r\nThe latest snapshot for the beta Linux kernel tree is:      2.5.75-bk1<br />\r\nThe latest 2.2 version of the Linux kernel is:              2.2.25<br />\r\nThe latest 2.0 version of the Linux kernel is:              2.0.39<br />\r\nThe latest prepatch for the 2.0 Linux kernel tree is:       2.0.40-rc6<br />\r\nThe latest -ac patch to the stable Linux kernels is:        2.4.22-pre3-ac1<br />\r\nThe latest -ac patch to the beta Linux kernels is:          2.5.69-ac1<br />\r\nThe latest -dj patch to the beta Linux kernels is:          2.5.69-dj1<br />\r\n</b></font>','2003-07-11 16:56:21',0,'');
INSERT INTO nuke_pnchat VALUES (537,'System','','','<b>asdffdsa sleeps</b>','2003-07-11 16:56:53',0,'');
INSERT INTO nuke_pnchat VALUES (538,'asdffdsa','','sdaflj','','2003-07-11 16:57:21',0,'#123456');
INSERT INTO nuke_pnchat VALUES (539,'System','','','<i><b>asdffdsa</b> just left the chat.</i><br>','2003-07-11 16:58:18',0,'');
INSERT INTO nuke_pnchat VALUES (540,'System','','','<i><b>asdffdsa</b> just left the chat.</i><br>','2003-07-11 16:58:18',0,'');
INSERT INTO nuke_pnchat VALUES (541,'System','','','<i><b>asdffdsa</b> just left the chat.</i><br>','2003-07-11 16:58:18',0,'');
INSERT INTO nuke_pnchat VALUES (542,'System','','','<i><b>asdffdsa</b> just left the chat.</i><br>','2003-07-11 16:58:18',0,'');
INSERT INTO nuke_pnchat VALUES (543,'System','','','<i><b>asdffdsa</b> just left the chat.</i><br>','2003-07-11 16:58:18',0,'');
INSERT INTO nuke_pnchat VALUES (544,'System','','','<i><b>asdffdsa</b> just left the chat.</i><br>','2003-07-11 16:58:18',0,'');
INSERT INTO nuke_pnchat VALUES (545,'System','','','<i><b>asdffdsa</b> just left the chat.</i><br>','2003-07-11 16:58:18',0,'');
INSERT INTO nuke_pnchat VALUES (546,'System','','','<i><b>asdffdsa</b> just left the chat.</i><br>','2003-07-11 16:58:18',0,'');
INSERT INTO nuke_pnchat VALUES (547,'System','','','<i><b>asdffdsa</b> just left the chat.</i><br>','2003-07-11 16:58:18',0,'');
INSERT INTO nuke_pnchat VALUES (548,'System','','','<i><b>asdffdsa</b> just left the chat.</i><br>','2003-07-11 16:58:18',0,'');
INSERT INTO nuke_pnchat VALUES (549,'System','','','<i><b>asdffdsa</b> just left the chat.</i><br>','2003-07-11 16:58:18',0,'');
INSERT INTO nuke_pnchat VALUES (550,'System','','','<i><b>asdffdsa</b> just left the chat.</i><br>','2003-07-11 16:58:18',0,'');
INSERT INTO nuke_pnchat VALUES (551,'System','','','<i><b>asdffdsa</b> just entered the chat.</i><br>','2003-07-11 17:09:01',0,'');
INSERT INTO nuke_pnchat VALUES (552,'System','asdffdsa','','<b>Welcome asdffdsa! Users in this room:</b>  <font color=#123456>asdffdsa</font> ','2003-07-11 17:09:01',0,'');
INSERT INTO nuke_pnchat VALUES (553,'System','asdffdsa','','<BR><BR><FONT FACE=VERDANA,HELVETICA SIZE=1 COLOR=#000000><B>Available Commands:<br>----------------------------<br>/color #xxxxxx (HEX)<br>/me [action] (i.e. \'/me is sick\' would be \'username is sick\')<br>/linux (Shows latest kernel versions)<br>/date (Shows our server\'s date and time)<br>/msg [username] [message] (send a private message to a user)<br>/userlist (Shows a list of all users currently in your chatroom)<br>/tech (Gives you details on the basic technology I use here!)<br>/roomlist (Shows a list of all available chatrooms)<br>/room [roomname] (Jump to another room or create a new one)<br>/roomdescription [description] (Change the room description (Admin ONLY))<br>/fortune (Shows a random fortune cookie)<br>/nick [nickname] (Change your nickname)<br></B></FONT>','2003-07-11 17:09:25',0,'');
INSERT INTO nuke_pnchat VALUES (554,'System','asdffdsa','','<BR><BR><FONT FACE=VERDANA,HELVETICA SIZE=1 COLOR=#000000><B>Available Chatrooms:<br>----------------------------------<br><TABLE BORDER=0 CELLSPACING=5 CELLPADDING=1><TD BGCOLOR=><FONT FACE=VERDANA,HELVETICA SIZE=1 COLOR=#000000>Room</TD><TD BGCOLOR=><FONT FACE=VERDANA,HELVETICA SIZE=1 COLOR=#000000>Description</TD><TD BGCOLOR=><FONT FACE=VERDANA,HELVETICA SIZE=1 COLOR=#000000>Users</TD><TD BGCOLOR=><FONT FACE=VERDANA,HELVETICA SIZE=1 COLOR=#000000>Created by</TD><TR><TD><FONT FACE=VERDANA,HELVETICA SIZE=1 COLOR=#000000>Lobby</font></TD><TD><FONT FACE=VERDANA,HELVETICA SIZE=1 COLOR=#000000>Main chat room</font></TD><TD ALIGN=RIGHT><FONT FACE=VERDANA,HELVETICA SIZE=1 COLOR=#000000>0</font></TD><TD><FONT FACE=VERDANA,HELVETICA SIZE=1 COLOR=#000000></font></TD><TR></TABLE></B></FONT>','2003-07-11 17:09:32',0,'');
INSERT INTO nuke_pnchat VALUES (555,'System','asdffdsa','','<BR><BR><FONT FACE=VERDANA,HELVETICA SIZE=1 COLOR=#000000><B>Available Commands:<br>----------------------------<br>/color #xxxxxx (HEX)<br>/me [action] (i.e. \'/me is sick\' would be \'username is sick\')<br>/linux (Shows latest kernel versions)<br>/date (Shows our server\'s date and time)<br>/msg [username] [message] (send a private message to a user)<br>/userlist (Shows a list of all users currently in your chatroom)<br>/tech (Gives you details on the basic technology I use here!)<br>/roomlist (Shows a list of all available chatrooms)<br>/room [roomname] (Jump to another room or create a new one)<br>/roomdescription [description] (Change the room description (Admin ONLY))<br>/fortune (Shows a random fortune cookie)<br>/nick [nickname] (Change your nickname)<br></B></FONT>','2003-07-11 17:09:42',0,'');
INSERT INTO nuke_pnchat VALUES (556,'System','asdffdsa','','<i><b>ONLY</b> registered users may create rooms!</i><br>','2003-07-11 17:09:57',0,'');
INSERT INTO nuke_pnchat VALUES (557,'System','','','<i><b>asdffdsa</b> just left the chat.</i><br>','2003-07-11 17:10:52',0,'');
INSERT INTO nuke_pnchat VALUES (558,'asdffdsa','','fewij','','2003-07-14 09:46:22',0,'#123456');
INSERT INTO nuke_pnchat VALUES (559,'System','','','<i><b>asdffdsa</b> just entered the chat.</i><br>','2003-07-14 09:46:31',0,'');
INSERT INTO nuke_pnchat VALUES (560,'System','asdffdsa','','<b>Welcome asdffdsa! Users in this room:</b>  <font color=#123456>asdffdsa</font> ','2003-07-14 09:46:31',0,'');
INSERT INTO nuke_pnchat VALUES (561,'asdffdsa','',':-)','','2003-07-14 09:46:40',0,'#123456');
INSERT INTO nuke_pnchat VALUES (562,'asdffdsa','','(b)(b)','','2003-07-14 09:46:45',0,'#123456');
INSERT INTO nuke_pnchat VALUES (563,'asdffdsa','','(b)(c)','','2003-07-14 09:46:50',0,'#123456');
INSERT INTO nuke_pnchat VALUES (564,'asdffdsa','','','','2003-07-14 09:46:54',0,'#123456');
INSERT INTO nuke_pnchat VALUES (565,'System','','','<b>asdffdsa faints</b>','2003-07-14 09:47:01',0,'');
INSERT INTO nuke_pnchat VALUES (566,'System','','','<i><b>asdffdsa</b> changed the nickname to <b>\'adsfew\'</b></i><br>','2003-07-14 09:47:08',0,'');
INSERT INTO nuke_pnchat VALUES (567,'System','','','<i><b>adsfew</b> just left the chat.</i><br>','2003-07-14 09:48:22',0,'');
INSERT INTO nuke_pnchat VALUES (568,'System','','','<i><b>adsfew</b> just entered the chat.</i><br>','2003-07-14 09:48:39',0,'');
INSERT INTO nuke_pnchat VALUES (569,'System','adsfew','','<b>Welcome adsfew! Users in this room:</b>  <font color=#123456>adsfew</font> ','2003-07-14 09:48:39',0,'');
INSERT INTO nuke_pnchat VALUES (570,'System','','','<i><b>adsfew</b> just entered the chat.</i><br>','2003-07-14 09:48:49',0,'');
INSERT INTO nuke_pnchat VALUES (571,'System','adsfew','','<b>Welcome adsfew! Users in this room:</b>  <font color=#123456>adsfew</font> ','2003-07-14 09:48:49',0,'');
INSERT INTO nuke_pnchat VALUES (572,'adsfew','','asdfe','','2003-07-14 09:48:54',0,'#123456');
INSERT INTO nuke_pnchat VALUES (573,'System','','','<i><b>adsfew</b> changed the nickname to <b>\'foobar\'</b></i><br>','2003-07-14 09:49:01',0,'');
INSERT INTO nuke_pnchat VALUES (574,'System','','','<i><b>foobar</b> just entered the chat.</i><br>','2003-07-14 09:49:10',0,'');
INSERT INTO nuke_pnchat VALUES (575,'System','foobar','','<b>Welcome foobar! Users in this room:</b>  <font color=#123456>foobar</font> ','2003-07-14 09:49:10',0,'');
INSERT INTO nuke_pnchat VALUES (576,'foobar','','asdfe','','2003-07-14 09:49:16',0,'#123456');
INSERT INTO nuke_pnchat VALUES (577,'System','','','<i><b>foobar</b> just left the chat.</i><br>','2003-07-14 09:50:06',0,'');
INSERT INTO nuke_pnchat VALUES (578,'System','','','<i><b>foobar</b> just left the chat.</i><br>','2003-07-14 09:50:06',0,'');
INSERT INTO nuke_pnchat VALUES (579,'System','','','<i><b>foobar</b> just left the chat.</i><br>','2003-07-14 09:50:06',0,'');
INSERT INTO nuke_pnchat VALUES (580,'System','','','<i><b>foobar</b> just entered the chat.</i><br>','2003-07-14 09:50:14',0,'');
INSERT INTO nuke_pnchat VALUES (581,'System','foobar','','<b>Welcome foobar! Users in this room:</b>  <font color=#123456>foobar</font> ','2003-07-14 09:50:14',0,'');
INSERT INTO nuke_pnchat VALUES (582,'System','','','<i><b>foobar</b> just entered the chat.</i><br>','2003-07-14 09:51:13',0,'');
INSERT INTO nuke_pnchat VALUES (583,'System','foobar','','<b>Welcome foobar! Users in this room:</b>  <font color=#123456>foobar</font> ','2003-07-14 09:51:13',0,'');
INSERT INTO nuke_pnchat VALUES (584,'System','','','<i><b>foobar</b> just left the chat.</i><br>','2003-07-14 09:51:17',0,'');
INSERT INTO nuke_pnchat VALUES (585,'System','','','<i><b>foobar</b> just entered the chat.</i><br>','2003-07-14 09:51:19',0,'');
INSERT INTO nuke_pnchat VALUES (586,'System','foobar','','<b>Welcome foobar! Users in this room:</b>  <font color=#123456>foobar</font> ','2003-07-14 09:51:19',0,'');
INSERT INTO nuke_pnchat VALUES (587,'foobar','','rrh','','2003-07-14 09:51:24',0,'#123456');
INSERT INTO nuke_pnchat VALUES (588,'System','','','<i><b>foobar</b> just left the chat.</i><br>','2003-07-14 09:52:15',0,'');
INSERT INTO nuke_pnchat VALUES (589,'System','','','<i><b>foobar</b> just entered the chat.</i><br>','2003-07-14 09:57:26',0,'');
INSERT INTO nuke_pnchat VALUES (590,'System','foobar','','<b>Welcome foobar! Users in this room:</b>  <font color=#123456>foobar</font> ','2003-07-14 09:57:26',0,'');
INSERT INTO nuke_pnchat VALUES (591,'foobar','','wef','','2003-07-14 09:57:32',0,'#123456');
INSERT INTO nuke_pnchat VALUES (592,'foobar','','fafe','','2003-07-14 09:59:02',0,'#123456');
INSERT INTO nuke_pnchat VALUES (593,'System','','','<i><b>foobar</b> just entered the chat.</i><br>','2003-07-14 10:00:20',0,'');
INSERT INTO nuke_pnchat VALUES (594,'System','foobar','','<b>Welcome foobar! Users in this room:</b>  <font color=#123456>foobar</font> ','2003-07-14 10:00:20',0,'');
INSERT INTO nuke_pnchat VALUES (595,'System','','','<i><b>foobar</b> just entered the chat.</i><br>','2003-07-14 10:05:00',0,'');
INSERT INTO nuke_pnchat VALUES (596,'System','foobar','','<b>Welcome foobar! Users in this room:</b>  <font color=#123456>foobar</font> ','2003-07-14 10:05:00',0,'');
INSERT INTO nuke_pnchat VALUES (597,'System','','','<i><b>foobar</b> just left the chat.</i><br>','2003-07-14 10:05:33',0,'');
INSERT INTO nuke_pnchat VALUES (598,'System','','','<i><b>foobar</b> just left the chat.</i><br>','2003-07-14 10:05:33',0,'');
INSERT INTO nuke_pnchat VALUES (599,'System','','','<i><b>foobar</b> just left the chat.</i><br>','2003-07-14 10:05:33',0,'');
INSERT INTO nuke_pnchat VALUES (600,'System','','','<i><b>foobar</b> just entered the chat.</i><br>','2003-07-14 10:05:45',0,'');
INSERT INTO nuke_pnchat VALUES (601,'System','foobar','','<b>Welcome foobar! Users in this room:</b>  <font color=#123456>foobar</font> ','2003-07-14 10:05:45',0,'');
INSERT INTO nuke_pnchat VALUES (602,'System','','','<i><b>foobar</b> just entered the chat.</i><br>','2003-07-14 10:06:11',0,'');
INSERT INTO nuke_pnchat VALUES (603,'System','foobar','','<b>Welcome foobar! Users in this room:</b>  <font color=#123456>foobar</font> ','2003-07-14 10:06:11',0,'');
INSERT INTO nuke_pnchat VALUES (604,'System','','','<i><b>foobar</b> just entered the chat.</i><br>','2003-07-14 10:06:18',0,'');
INSERT INTO nuke_pnchat VALUES (605,'System','foobar','','<b>Welcome foobar! Users in this room:</b>  <font color=#123456>foobar</font> ','2003-07-14 10:06:18',0,'');
INSERT INTO nuke_pnchat VALUES (606,'System','foobar','','Username Admin is used by a registered user. Please register to reserve your own nickname.<br>','2003-07-14 10:06:57',0,'');
INSERT INTO nuke_pnchat VALUES (607,'System','','','<i><b>foobar</b> just entered the chat.</i><br>','2003-07-14 10:07:54',0,'');
INSERT INTO nuke_pnchat VALUES (608,'System','foobar','','<b>Welcome foobar! Users in this room:</b>  <font color=#123456>foobar</font> ','2003-07-14 10:07:54',0,'');
INSERT INTO nuke_pnchat VALUES (609,'System','','','<i><b>foobar</b> just entered the chat.</i><br>','2003-07-14 10:08:26',0,'');
INSERT INTO nuke_pnchat VALUES (610,'System','foobar','','<b>Welcome foobar! Users in this room:</b>  <font color=#123456>foobar</font> ','2003-07-14 10:08:26',0,'');
INSERT INTO nuke_pnchat VALUES (611,'System','','','<i><b>foobar</b> just left the chat.</i><br>','2003-07-14 10:08:34',0,'');
INSERT INTO nuke_pnchat VALUES (612,'System','','','<i><b>foobar</b> just left the chat.</i><br>','2003-07-14 10:08:34',0,'');
INSERT INTO nuke_pnchat VALUES (613,'System','','','<i><b>foobar</b> just left the chat.</i><br>','2003-07-14 10:08:34',0,'');
INSERT INTO nuke_pnchat VALUES (614,'System','','','<i><b>foobar</b> just left the chat.</i><br>','2003-07-14 10:08:34',0,'');
INSERT INTO nuke_pnchat VALUES (615,'System','','','<i><b>foobar</b> just left the chat.</i><br>','2003-07-14 10:08:34',0,'');
INSERT INTO nuke_pnchat VALUES (616,'System','','','<i><b>foobar</b> just entered the chat.</i><br>','2003-07-14 10:20:44',0,'');
INSERT INTO nuke_pnchat VALUES (617,'System','foobar','','<b>Welcome foobar! Users in this room:</b>  <font color=#123456>foobar</font> ','2003-07-14 10:20:44',0,'');
INSERT INTO nuke_pnchat VALUES (618,'System','','','<i><b>foobar</b> just entered the chat.</i><br>','2003-07-14 10:20:58',0,'');
INSERT INTO nuke_pnchat VALUES (619,'System','foobar','','<b>Welcome foobar! Users in this room:</b>  <font color=#123456>foobar</font> ','2003-07-14 10:20:58',0,'');
INSERT INTO nuke_pnchat VALUES (620,'System','','','<i><b>foobar</b> just left the chat.</i><br>','2003-07-14 10:21:38',0,'');
INSERT INTO nuke_pnchat VALUES (621,'System','','','<i><b>foobar</b> just left the chat.</i><br>','2003-07-14 10:21:38',0,'');
INSERT INTO nuke_pnchat VALUES (622,'System','','','<i><b>foobar</b> just entered the chat.</i><br>','2003-07-14 10:30:10',0,'');
INSERT INTO nuke_pnchat VALUES (623,'System','foobar','','<b>Welcome foobar! Users in this room:</b>  <font color=#123456>foobar</font> ','2003-07-14 10:30:10',0,'');
INSERT INTO nuke_pnchat VALUES (624,'foobar','','foo','','2003-07-14 10:30:25',0,'#123456');
INSERT INTO nuke_pnchat VALUES (625,'foobar','','bar','','2003-07-14 10:30:28',0,'#123456');
INSERT INTO nuke_pnchat VALUES (626,'System','','','<i><b>foobar</b> has changed <font color=#ff00ff>color</font></i><br>','2003-07-14 10:30:46',0,'');
INSERT INTO nuke_pnchat VALUES (627,'foobar','','adfw','','2003-07-14 10:30:48',0,'#ff00ff');
INSERT INTO nuke_pnchat VALUES (628,'System','','','<i><b>foobar</b> just entered the chat.</i><br>','2003-07-14 10:32:02',0,'');
INSERT INTO nuke_pnchat VALUES (629,'System','foobar','','<b>Welcome foobar! Users in this room:</b>  <font color=#ff00ff>foobar</font> ','2003-07-14 10:32:02',0,'');
INSERT INTO nuke_pnchat VALUES (630,'foobar','','foobar','','2003-07-14 10:33:40',0,'#ff00ff');
INSERT INTO nuke_pnchat VALUES (631,'foobar','','boofar','','2003-07-14 10:33:46',0,'#ff00ff');
INSERT INTO nuke_pnchat VALUES (632,'System','','','<i><b>foobar</b> just entered the chat.</i><br>','2003-07-14 10:34:34',0,'');
INSERT INTO nuke_pnchat VALUES (633,'System','foobar','','<b>Welcome foobar! Users in this room:</b>  <font color=#ff00ff>foobar</font> ','2003-07-14 10:34:34',0,'');
INSERT INTO nuke_pnchat VALUES (634,'System','','','<i><b>foobar</b> just entered the chat.</i><br>','2003-07-14 10:36:08',0,'');
INSERT INTO nuke_pnchat VALUES (635,'System','foobar','','<b>Welcome foobar! Users in this room:</b>  <font color=#ff00ff>foobar</font> ','2003-07-14 10:36:08',0,'');
INSERT INTO nuke_pnchat VALUES (636,'System','','','<i><b>foobar</b> just entered the chat.</i><br>','2003-07-14 10:36:28',0,'');
INSERT INTO nuke_pnchat VALUES (637,'System','foobar','','<b>Welcome foobar! Users in this room:</b>  <font color=#ff00ff>foobar</font> ','2003-07-14 10:36:28',0,'');
INSERT INTO nuke_pnchat VALUES (638,'System','','','<i><b>foobar</b> just left the chat.</i><br>','2003-07-14 10:37:13',0,'');
INSERT INTO nuke_pnchat VALUES (639,'System','','','<i><b>foobar</b> just left the chat.</i><br>','2003-07-14 10:37:13',0,'');
INSERT INTO nuke_pnchat VALUES (640,'System','','','<i><b>foobar</b> just left the chat.</i><br>','2003-07-14 10:37:13',0,'');
INSERT INTO nuke_pnchat VALUES (641,'System','','','<i><b>foobar</b> just left the chat.</i><br>','2003-07-14 10:37:13',0,'');
INSERT INTO nuke_pnchat VALUES (642,'System','','','<i><b>foobar</b> just left the chat.</i><br>','2003-07-14 10:37:13',0,'');
INSERT INTO nuke_pnchat VALUES (643,'System','','','<i><b>foobar</b> just entered the chat.</i><br>','2003-07-14 10:38:32',0,'');
INSERT INTO nuke_pnchat VALUES (644,'System','foobar','','<b>Welcome foobar! Users in this room:</b> ','2003-07-14 10:38:32',0,'');
INSERT INTO nuke_pnchat VALUES (645,'System','','','<i><b>foobar</b> just entered the chat.</i><br>','2003-07-14 10:38:38',0,'');
INSERT INTO nuke_pnchat VALUES (646,'System','foobar','','<b>Welcome foobar! Users in this room:</b>  <font color=#ff00ff>foobar</font> ','2003-07-14 10:38:38',0,'');
INSERT INTO nuke_pnchat VALUES (647,'System','','','<i><b>foobar</b> just entered the chat.</i><br>','2003-07-14 10:38:42',0,'');
INSERT INTO nuke_pnchat VALUES (648,'System','foobar','','<b>Welcome foobar! Users in this room:</b>  <font color=#ff00ff>foobar</font> ','2003-07-14 10:38:42',0,'');
INSERT INTO nuke_pnchat VALUES (649,'System','foobar','','<i>Usage:</i> /color #xxxxxx<br>','2003-07-14 10:38:56',0,'');
INSERT INTO nuke_pnchat VALUES (650,'System','foobar','','<i>Usage:</i> /color #xxxxxx<br>','2003-07-14 10:39:25',0,'');
INSERT INTO nuke_pnchat VALUES (651,'System','','','<i><b>foobar</b> has changed <font color=#00ffff>color</font></i><br>','2003-07-14 10:39:39',0,'');
INSERT INTO nuke_pnchat VALUES (652,'System','','','<i><b>foobar</b> has changed <font color=#ffff00>color</font></i><br>','2003-07-14 10:39:49',0,'');
INSERT INTO nuke_pnchat VALUES (653,'System','','','<i><b>foobar</b> has changed <font color=#0000ff>color</font></i><br>','2003-07-14 10:40:04',0,'');
INSERT INTO nuke_pnchat VALUES (654,'foobar','','ls','','2003-07-14 10:40:07',0,'#0000ff');
INSERT INTO nuke_pnchat VALUES (655,'System','','','<i><b>foobar</b> just entered the chat.</i><br>','2003-07-14 10:44:26',0,'');
INSERT INTO nuke_pnchat VALUES (656,'System','foobar','','<b>Welcome foobar! Users in this room:</b>  <font color=#0000ff>foobar</font> ','2003-07-14 10:44:26',0,'');
INSERT INTO nuke_pnchat VALUES (657,'System','foobar','','Username Admin is used by a registered user. Please register to reserve your own nickname.<br>','2003-07-14 10:45:01',0,'');
INSERT INTO nuke_pnchat VALUES (658,'System','','','<i><b>foobar</b> just entered the chat.</i><br>','2003-07-14 10:45:13',0,'');
INSERT INTO nuke_pnchat VALUES (659,'System','foobar','','<b>Welcome foobar! Users in this room:</b>  <font color=#0000ff>foobar</font> ','2003-07-14 10:45:13',0,'');
INSERT INTO nuke_pnchat VALUES (660,'foobar','','ijfew','','2003-07-14 10:45:47',0,'#0000ff');
INSERT INTO nuke_pnchat VALUES (661,'System','','','<i><b>foobar</b> just entered the chat.</i><br>','2003-07-14 10:48:59',0,'');
INSERT INTO nuke_pnchat VALUES (662,'System','foobar','','<b>Welcome foobar! Users in this room:</b>  <font color=#0000ff>foobar</font> ','2003-07-14 10:48:59',0,'');
INSERT INTO nuke_pnchat VALUES (663,'foobar','','fwefewi','','2003-07-14 10:49:03',0,'#0000ff');
INSERT INTO nuke_pnchat VALUES (664,'System','foobar','','Username Admin is used by a registered user. Please register to reserve your own nickname.<br>','2003-07-14 10:49:07',0,'');
INSERT INTO nuke_pnchat VALUES (665,'foobar','','asdfe','','2003-07-14 10:51:23',0,'#0000ff');
INSERT INTO nuke_pnchat VALUES (666,'foobar','','Foo bar','','2003-07-14 10:53:23',0,'#0000ff');
INSERT INTO nuke_pnchat VALUES (667,'System','','','<i><b>foobar</b> just entered the chat.</i><br>','2003-07-14 10:54:16',0,'');
INSERT INTO nuke_pnchat VALUES (668,'System','foobar','','<b>Welcome foobar! Users in this room:</b>  <font color=#0000ff>foobar</font> ','2003-07-14 10:54:16',0,'');
INSERT INTO nuke_pnchat VALUES (669,'foobar','','Foo bar','','2003-07-14 10:54:34',0,'#0000ff');
INSERT INTO nuke_pnchat VALUES (670,'System','','','<i><b>foobar</b> just entered the chat.</i><br>','2003-07-14 10:56:29',0,'');
INSERT INTO nuke_pnchat VALUES (671,'System','foobar','','<b>Welcome foobar! Users in this room:</b>  <font color=#0000ff>foobar</font> ','2003-07-14 10:56:29',0,'');
INSERT INTO nuke_pnchat VALUES (672,'foobar','','ffewfwf','','2003-07-14 10:56:41',0,'#0000ff');
INSERT INTO nuke_pnchat VALUES (673,'System','','','<i><b>foobar</b> just left the chat.</i><br>','2003-07-14 10:57:50',0,'');
INSERT INTO nuke_pnchat VALUES (674,'System','','','<i><b>foobar</b> just left the chat.</i><br>','2003-07-14 10:57:50',0,'');
INSERT INTO nuke_pnchat VALUES (675,'System','','','<i><b>foobar</b> just left the chat.</i><br>','2003-07-14 10:57:50',0,'');
INSERT INTO nuke_pnchat VALUES (676,'System','','','<i><b>foobar</b> just left the chat.</i><br>','2003-07-14 10:57:50',0,'');
INSERT INTO nuke_pnchat VALUES (677,'System','','','<i><b>foobar</b> just left the chat.</i><br>','2003-07-14 10:57:50',0,'');
INSERT INTO nuke_pnchat VALUES (678,'System','','','<i><b>foobar</b> just left the chat.</i><br>','2003-07-14 10:57:50',0,'');
INSERT INTO nuke_pnchat VALUES (679,'System','','','<i><b>foobar</b> just left the chat.</i><br>','2003-07-14 10:57:50',0,'');
INSERT INTO nuke_pnchat VALUES (680,'System','','','<i><b>foobar</b> just entered the chat.</i><br>','2003-07-14 10:58:34',0,'');
INSERT INTO nuke_pnchat VALUES (681,'System','foobar','','<b>Welcome foobar! Users in this room:</b>  <font color=#0000ff>foobar</font> ','2003-07-14 10:58:34',0,'');
INSERT INTO nuke_pnchat VALUES (682,'foobar','','fewfwej','','2003-07-14 10:58:40',0,'#0000ff');
INSERT INTO nuke_pnchat VALUES (683,'foobar','','fewfjewief','','2003-07-14 10:58:55',0,'#0000ff');
INSERT INTO nuke_pnchat VALUES (684,'System','','','<i><b>foobar</b> just left the chat.</i><br>','2003-07-14 10:59:34',0,'');
INSERT INTO nuke_pnchat VALUES (685,'System','','','<i><b>foobar</b> just entered the chat.</i><br>','2003-07-14 11:00:41',0,'');
INSERT INTO nuke_pnchat VALUES (686,'System','foobar','','<b>Welcome foobar! Users in this room:</b>  <font color=#0000ff>foobar</font> ','2003-07-14 11:00:41',0,'');
INSERT INTO nuke_pnchat VALUES (687,'foobar','','asfe','','2003-07-14 11:00:51',0,'#0000ff');
INSERT INTO nuke_pnchat VALUES (688,'System','','','<i><b>foobar</b> just left the chat.</i><br>','2003-07-14 11:01:56',0,'');
INSERT INTO nuke_pnchat VALUES (689,'System','','','<i><b>foobar</b> just entered the chat.</i><br>','2003-07-14 11:02:58',0,'');
INSERT INTO nuke_pnchat VALUES (690,'System','foobar','','<b>Welcome foobar! Users in this room:</b>  <font color=#0000ff>foobar</font> ','2003-07-14 11:02:58',0,'');
INSERT INTO nuke_pnchat VALUES (691,'System','foobar','','<BR><BR><FONT FACE=VERDANA,HELVETICA SIZE=1 COLOR=#000000><B>Users currently in this room:<br>----------------------------------<br><font color=#0000ff> [foobar]</font></B></FONT>','2003-07-14 11:03:09',0,'');
INSERT INTO nuke_pnchat VALUES (692,'System','foobar','','<FONT FACE=VERDANA,HELVETICA SIZE=1 COLOR=#000000><B>load average: 0.00, 0.04, 0.07</b></font><br>','2003-07-14 11:03:52',0,'');
INSERT INTO nuke_pnchat VALUES (693,'foobar','','asdfe','','2003-07-14 11:04:05',0,'#0000ff');
INSERT INTO nuke_pnchat VALUES (694,'foobar','','|msg foobar boo','','2003-07-14 11:06:49',0,'#0000ff');
INSERT INTO nuke_pnchat VALUES (695,'foobar','foobar','boo','','2003-07-14 11:07:03',0,'#0000ff');
INSERT INTO nuke_pnchat VALUES (696,'foobar','','msg foo bar /','','2003-07-14 11:09:47',0,'#0000ff');
INSERT INTO nuke_pnchat VALUES (697,'System','foobar','','<BR><BR><FONT FACE=VERDANA,HELVETICA SIZE=1 COLOR=#000000><B>Latest Linux kernel versions:<br>-----------------------------------<br><br>The latest stable version of the Linux kernel is:           2.4.21<br />\r\nThe latest prepatch for the stable Linux kernel tree is:    2.4.22-pre5<br />\r\nThe latest snapshot for the stable Linux kernel tree is:    2.4.21-bk9<br />\r\nThe latest beta version of the Linux kernel is:             2.6.0-test1<br />\r\nThe latest 2.2 version of the Linux kernel is:              2.2.25<br />\r\nThe latest 2.0 version of the Linux kernel is:              2.0.39<br />\r\nThe latest prepatch for the 2.0 Linux kernel tree is:       2.0.40-rc6<br />\r\nThe latest -ac patch to the stable Linux kernels is:        2.4.22-pre3-ac1<br />\r\n</b></font>','2003-07-14 11:17:27',0,'');
INSERT INTO nuke_pnchat VALUES (698,'foobar','','/me faints','','2003-07-14 11:18:13',0,'#0000ff');
INSERT INTO nuke_pnchat VALUES (699,'System','','','<b>foobar faints</b>','2003-07-14 11:18:32',0,'');
INSERT INTO nuke_pnchat VALUES (700,'foobar','','adsf','','2003-07-14 11:18:34',0,'#0000ff');
INSERT INTO nuke_pnchat VALUES (701,'foobar','','wewfe','','2003-07-14 11:20:30',0,'#0000ff');
INSERT INTO nuke_pnchat VALUES (702,'foobar','','fel','','2003-07-14 11:20:39',0,'#0000ff');
INSERT INTO nuke_pnchat VALUES (703,'System','','','<p>Unknown command \'\n</p>','2003-07-14 11:20:53',0,'');
INSERT INTO nuke_pnchat VALUES (704,'System','','','<p>Unknown command \'\n</p>','2003-07-14 11:20:58',0,'');
INSERT INTO nuke_pnchat VALUES (705,'System','','','<p>Unknown command \'</p>\n','2003-07-14 11:21:27',0,'');
INSERT INTO nuke_pnchat VALUES (706,'System','','','<p>Unknown command \'</p>\n','2003-07-14 11:21:47',0,'');
INSERT INTO nuke_pnchat VALUES (707,'System','','','<p>Unknown command \'</p>\n','2003-07-14 11:21:50',0,'');
INSERT INTO nuke_pnchat VALUES (708,'foobar','','asdlfkj','','2003-07-14 11:22:18',0,'#0000ff');
INSERT INTO nuke_pnchat VALUES (709,'foobar','','ewjfewj','','2003-07-14 11:22:53',0,'#0000ff');
INSERT INTO nuke_pnchat VALUES (710,'foobar','','ijfewiewf\\\'','','2003-07-14 11:23:00',0,'#0000ff');
INSERT INTO nuke_pnchat VALUES (711,'foobar','foobar','boo','','2003-07-14 11:23:08',0,'#0000ff');
INSERT INTO nuke_pnchat VALUES (712,'foobar','','fjiwefiewfj','','2003-07-14 11:23:34',0,'#0000ff');
INSERT INTO nuke_pnchat VALUES (713,'System','','','<p>Unknown command\n</p>','2003-07-14 11:24:11',0,'');
INSERT INTO nuke_pnchat VALUES (714,'foobar','','jfdskfdsa','','2003-07-14 11:25:01',0,'#0000ff');
INSERT INTO nuke_pnchat VALUES (715,'foobar','','jadsfi','','2003-07-14 11:25:18',0,'#0000ff');
INSERT INTO nuke_pnchat VALUES (716,'foobar','','adfjej','','2003-07-14 11:25:40',0,'#0000ff');
INSERT INTO nuke_pnchat VALUES (717,'System','','','Unknown Command','2003-07-14 11:25:43',0,'');
INSERT INTO nuke_pnchat VALUES (718,'System','','','Unknown Command /rjreiire','2003-07-14 11:26:02',0,'');
INSERT INTO nuke_pnchat VALUES (719,'System','','','Unknown Command /ewiewfjifew','2003-07-14 11:26:25',0,'');
INSERT INTO nuke_pnchat VALUES (720,'foobar','','I am foobar','','2003-07-14 11:27:10',0,'#0000ff');
INSERT INTO nuke_pnchat VALUES (721,'foobar','','I am Admin','','2003-07-14 11:27:20',0,'#0000ff');
INSERT INTO nuke_pnchat VALUES (722,'System','foobar','','Unknown Command /efjweifew','2003-07-14 11:30:19',0,'');
INSERT INTO nuke_pnchat VALUES (723,'System','foobar','','<i>Unknown Command</i> /fweifew','2003-07-14 11:30:36',0,'');
INSERT INTO nuke_pnchat VALUES (724,'System','','','<i><b>foobar</b> just entered the chat.</i><br>','2003-07-14 11:32:43',0,'');
INSERT INTO nuke_pnchat VALUES (725,'System','foobar','','<b>Welcome foobar! Users in this room:</b>  <font color=#0000ff>foobar</font> ','2003-07-14 11:32:43',0,'');
INSERT INTO nuke_pnchat VALUES (726,'System','','','<i><b>foobar</b> just entered the chat.</i><br>','2003-07-14 12:13:05',0,'');
INSERT INTO nuke_pnchat VALUES (727,'System','foobar','','<b>Welcome foobar! Users in this room:</b>  <font color=#0000ff>foobar</font> ','2003-07-14 12:13:05',0,'');
INSERT INTO nuke_pnchat VALUES (728,'System','','','<i><b>foobar</b> just left the chat.</i><br>','2003-07-14 12:13:33',0,'');
INSERT INTO nuke_pnchat VALUES (729,'System','','','<i><b>foobar</b> just left the chat.</i><br>','2003-07-14 12:13:33',0,'');
INSERT INTO nuke_pnchat VALUES (730,'System','','','<i><b>foobar</b> just left the chat.</i><br>','2003-07-14 12:13:33',0,'');
INSERT INTO nuke_pnchat VALUES (731,'System','foobar','','<i><b>ONLY</b> registered users may create rooms!</i><br>','2003-07-14 12:22:07',0,'');
INSERT INTO nuke_pnchat VALUES (732,'foobar','foobar','foo bar','','2003-07-14 12:23:37',0,'#0000ff');
INSERT INTO nuke_pnchat VALUES (733,'System','foobar','','<i><b>ONLY</b> registered users may create rooms!</i><br>','2003-07-14 12:23:49',0,'');
INSERT INTO nuke_pnchat VALUES (734,'System','','','<i><b>foobar</b> just entered the chat.</i><br>','2003-07-14 12:23:55',0,'');
INSERT INTO nuke_pnchat VALUES (735,'System','foobar','','<b>Welcome foobar! Users in this room:</b>  <font color=#0000ff>foobar</font> ','2003-07-14 12:23:55',0,'');
INSERT INTO nuke_pnchat VALUES (736,'System','foobar','','<i>Unknown Command</i> /few','2003-07-14 12:24:00',0,'');
INSERT INTO nuke_pnchat VALUES (737,'System','foobar','','Username Admin is used by a registered user. Please register to reserve your own nickname.<br>','2003-07-14 12:24:06',0,'');
INSERT INTO nuke_pnchat VALUES (738,'foobar','','fijewfijfew','','2003-07-14 12:24:12',0,'#0000ff');
INSERT INTO nuke_pnchat VALUES (739,'System','foobar','','<i><b>ONLY</b> registered users may create rooms!</i><br>','2003-07-14 12:24:24',0,'');
INSERT INTO nuke_pnchat VALUES (740,'System','','','<i><b>foobar</b> just left the chat.</i><br>','2003-07-14 12:29:18',0,'');
INSERT INTO nuke_pnchat VALUES (741,'System','','','<i><b>foobar</b> just entered the chat.</i><br>','2003-07-14 12:30:27',0,'');
INSERT INTO nuke_pnchat VALUES (742,'System','foobar','','<b>Welcome foobar! Users in this room:</b>  <font color=#0000ff>foobar</font> ','2003-07-14 12:30:27',0,'');
INSERT INTO nuke_pnchat VALUES (743,'System','','','<i><b>foobar</b> just left the chat.</i><br>','2003-07-14 12:32:48',0,'');
INSERT INTO nuke_pnchat VALUES (744,'System','','','<i><b>foobar</b> just entered the chat.</i><br>','2003-07-14 12:35:45',0,'');
INSERT INTO nuke_pnchat VALUES (745,'System','foobar','','<b>Welcome foobar! Users in this room:</b>  <font color=#0000ff>foobar</font> ','2003-07-14 12:35:45',0,'');
INSERT INTO nuke_pnchat VALUES (746,'System','','','<i><b>foobar</b> just entered the chat.</i><br>','2003-07-14 12:35:47',0,'');
INSERT INTO nuke_pnchat VALUES (747,'System','foobar','','<b>Welcome foobar! Users in this room:</b>  <font color=#0000ff>foobar</font> ','2003-07-14 12:35:47',0,'');
INSERT INTO nuke_pnchat VALUES (748,'System','','','<i><b>foobar</b> changed the nickname to <b>\'lloyd\'</b></i><br>','2003-07-14 12:35:55',0,'');
INSERT INTO nuke_pnchat VALUES (749,'lloyd','','hello','','2003-07-14 12:35:58',0,'#0000ff');
INSERT INTO nuke_pnchat VALUES (750,'lloyd','','hi','','2003-07-14 12:36:03',0,'#0000ff');
INSERT INTO nuke_pnchat VALUES (751,'lloyd','','adsf','','2003-07-14 12:36:05',0,'#0000ff');
INSERT INTO nuke_pnchat VALUES (752,'System','lloyd','','<i>Unknown Command</i> /session','2003-07-14 12:39:36',0,'');
INSERT INTO nuke_pnchat VALUES (753,'System','lloyd','','<i>Unknown Command</i> /session','2003-07-14 12:39:42',0,'');
INSERT INTO nuke_pnchat VALUES (754,'System','lloyd','','<font face=verdana,arial size=1><b>\n\"But the most reliable indication of the future of Open Source is its\npast: in just a few years, we have gone from nothing to a robust body\nof software that solves many different problems and is reaching the\nmillion-user count. There\'s no reason for us to slow down now.\"\n\n  -- Bruce Perens, on the future of Open Source software.\n (Open Sources, 1999 O\'Reilly and Associates)\n</b></font>','2003-07-14 12:40:04',0,'');
INSERT INTO nuke_pnchat VALUES (755,'System','lloyd','','<i>Unknown Command</i> /session','2003-07-14 12:40:17',0,'');
INSERT INTO nuke_pnchat VALUES (756,'System','lloyd','','<i>Unknown Command</i> /session','2003-07-14 12:41:23',0,'');
INSERT INTO nuke_pnchat VALUES (757,'System','lloyd','','<i>Unknown Command</i> /session','2003-07-14 12:42:00',0,'');
INSERT INTO nuke_pnchat VALUES (758,'System','lloyd','','<i>Unknown Command</i> /session','2003-07-14 12:42:03',0,'');
INSERT INTO nuke_pnchat VALUES (759,'System','','','<i><b>lloyd</b> just entered the chat.</i><br>','2003-07-14 12:42:06',0,'');
INSERT INTO nuke_pnchat VALUES (760,'System','lloyd','','<b>Welcome lloyd! Users in this room:</b>  <font color=#0000ff>lloyd</font> ','2003-07-14 12:42:06',0,'');
INSERT INTO nuke_pnchat VALUES (761,'System','','','<i><b>lloyd</b> just entered the chat.</i><br>','2003-07-14 12:42:10',0,'');
INSERT INTO nuke_pnchat VALUES (762,'System','lloyd','','<b>Welcome lloyd! Users in this room:</b>  <font color=#0000ff>lloyd</font> ','2003-07-14 12:42:10',0,'');
INSERT INTO nuke_pnchat VALUES (763,'System','lloyd','','<i>Unknown Command</i> /session','2003-07-14 12:42:12',0,'');
INSERT INTO nuke_pnchat VALUES (764,'System','lloyd','','<font face=verdana,arial size=1><b>\nPower is danger.\n		-- The Centurion, \"Balance of Terror\", stardate 1709.2\n</b></font>','2003-07-14 12:42:39',0,'');
INSERT INTO nuke_pnchat VALUES (765,'System','lloyd','','<font face=verdana,arial size=1><b>\nI\'ve already got a female to worry about.  Her name is the Enterprise.\n		-- Kirk, \"The Corbomite Maneuver\", stardate 1514.0\n</b></font>','2003-07-14 12:42:52',0,'');
INSERT INTO nuke_pnchat VALUES (766,'System','lloyd','','<i>Unknown Command</i> /session','2003-07-14 12:43:36',0,'');
INSERT INTO nuke_pnchat VALUES (767,'System','lloyd','','<i>Unknown Command</i> /session ','2003-07-14 12:44:35',0,'');
INSERT INTO nuke_pnchat VALUES (768,'System','lloyd','','<i>Unknown Command</i> /roomdescription','2003-07-14 12:47:35',0,'');
INSERT INTO nuke_pnchat VALUES (769,'System','','','<i><b>lloyd</b> just entered the chat.</i><br>','2003-07-14 12:50:17',0,'');
INSERT INTO nuke_pnchat VALUES (770,'System','lloyd','','<b>Welcome lloyd! Users in this room:</b>  <font color=#0000ff>lloyd</font> ','2003-07-14 12:50:17',0,'');
INSERT INTO nuke_pnchat VALUES (771,'System','','','<i><b>lloyd</b> just entered the chat.</i><br>','2003-07-14 12:50:48',0,'');
INSERT INTO nuke_pnchat VALUES (772,'System','lloyd','','<b>Welcome lloyd! Users in this room:</b>  <font color=#0000ff>lloyd</font> ','2003-07-14 12:50:48',0,'');
INSERT INTO nuke_pnchat VALUES (773,'System','','','<i><b>lloyd</b> just entered the chat.</i><br>','2003-07-14 12:50:51',0,'');
INSERT INTO nuke_pnchat VALUES (774,'System','lloyd','','<b>Welcome lloyd! Users in this room:</b>  <font color=#0000ff>lloyd</font> ','2003-07-14 12:50:51',0,'');
INSERT INTO nuke_pnchat VALUES (775,'System','','','<b>lloyd here</b>','2003-07-14 12:50:56',0,'');
INSERT INTO nuke_pnchat VALUES (776,'lloyd','','ewfewfew','','2003-07-14 12:51:01',0,'#0000ff');
INSERT INTO nuke_pnchat VALUES (777,'System','lloyd','','<i>Unknown Command</i> /session','2003-07-14 12:51:11',0,'');
INSERT INTO nuke_pnchat VALUES (778,'System','lloyd','','<BR><BR><FONT FACE=VERDANA,HELVETICA SIZE=1 COLOR=#000000><B>Latest Linux kernel versions:<br>-----------------------------------<br><br>The latest stable version of the Linux kernel is:           2.4.21<br />\r\nThe latest prepatch for the stable Linux kernel tree is:    2.4.22-pre5<br />\r\nThe latest snapshot for the stable Linux kernel tree is:    2.4.21-bk9<br />\r\nThe latest beta version of the Linux kernel is:             2.6.0-test1<br />\r\nThe latest 2.2 version of the Linux kernel is:              2.2.25<br />\r\nThe latest 2.0 version of the Linux kernel is:              2.0.39<br />\r\nThe latest prepatch for the 2.0 Linux kernel tree is:       2.0.40-rc6<br />\r\nThe latest -ac patch to the stable Linux kernels is:        2.4.22-pre3-ac1<br />\r\n</b></font>','2003-07-14 12:51:50',0,'');
INSERT INTO nuke_pnchat VALUES (779,'System','lloyd','','<i>Unknown Command</i> /linu','2003-07-14 12:51:54',0,'');
INSERT INTO nuke_pnchat VALUES (780,'System','lloyd','','<BR><BR><FONT FACE=VERDANA,HELVETICA SIZE=1 COLOR=#000000><B>Latest Linux kernel versions:<br>-----------------------------------<br><br>The latest stable version of the Linux kernel is:           2.4.21<br />\r\nThe latest prepatch for the stable Linux kernel tree is:    2.4.22-pre5<br />\r\nThe latest snapshot for the stable Linux kernel tree is:    2.4.21-bk9<br />\r\nThe latest beta version of the Linux kernel is:             2.6.0-test1<br />\r\nThe latest 2.2 version of the Linux kernel is:              2.2.25<br />\r\nThe latest 2.0 version of the Linux kernel is:              2.0.39<br />\r\nThe latest prepatch for the 2.0 Linux kernel tree is:       2.0.40-rc6<br />\r\nThe latest -ac patch to the stable Linux kernels is:        2.4.22-pre3-ac1<br />\r\n</b></font>','2003-07-14 12:51:59',0,'');
INSERT INTO nuke_pnchat VALUES (781,'System','lloyd','','<i>Unknown Command</i> /session','2003-07-14 12:52:37',0,'');
INSERT INTO nuke_pnchat VALUES (782,'System','lloyd','','<i>Unknown Command</i> /linux','2003-07-14 12:52:41',0,'');
INSERT INTO nuke_pnchat VALUES (783,'System','lloyd','','<i>Unknown Command</i> /linu','2003-07-14 12:52:45',0,'');
INSERT INTO nuke_pnchat VALUES (784,'lloyd','','asdfjew','','2003-07-14 13:01:44',0,'#0000ff');
INSERT INTO nuke_pnchat VALUES (785,'System','lloyd','','<i>Unknown Command</i> /boo','2003-07-14 13:01:47',0,'');
INSERT INTO nuke_pnchat VALUES (786,'System','lloyd','','<i>Unknown Command</i> /linu','2003-07-14 13:01:51',0,'');
INSERT INTO nuke_pnchat VALUES (787,'System','lloyd','','<i>Unknown Command</i> /linux','2003-07-14 13:01:54',0,'');
INSERT INTO nuke_pnchat VALUES (788,'lloyd','','ewjfi','','2003-07-14 13:02:29',0,'#0000ff');
INSERT INTO nuke_pnchat VALUES (789,'System','','','','2003-07-14 13:02:33',0,'');
INSERT INTO nuke_pnchat VALUES (790,'System','lloyd','','<i>Unknown Command</i> /jiefw','2003-07-14 13:02:33',0,'');
INSERT INTO nuke_pnchat VALUES (791,'System','','','','2003-07-14 13:02:38',0,'');
INSERT INTO nuke_pnchat VALUES (792,'System','lloyd','','<i>Unknown Command</i> /','2003-07-14 13:02:38',0,'');
INSERT INTO nuke_pnchat VALUES (793,'System','','','','2003-07-14 13:02:41',0,'');
INSERT INTO nuke_pnchat VALUES (794,'System','lloyd','','<i>Unknown Command</i> //','2003-07-14 13:02:41',0,'');
INSERT INTO nuke_pnchat VALUES (795,'System','','','foo','2003-07-14 13:02:44',0,'');
INSERT INTO nuke_pnchat VALUES (796,'System','lloyd','','<i>Unknown Command</i> /foo bar','2003-07-14 13:02:44',0,'');
INSERT INTO nuke_pnchat VALUES (797,'System','','','msg','2003-07-14 13:02:54',0,'');
INSERT INTO nuke_pnchat VALUES (798,'lloyd','foobar','boo','','2003-07-14 13:02:54',0,'#0000ff');
INSERT INTO nuke_pnchat VALUES (799,'System','','','linux','2003-07-14 13:03:29',0,'');
INSERT INTO nuke_pnchat VALUES (800,'System','lloyd','','<i>Unknown Command</i> /linux','2003-07-14 13:03:29',0,'');
INSERT INTO nuke_pnchat VALUES (801,'System','','','linu','2003-07-14 13:03:32',0,'');
INSERT INTO nuke_pnchat VALUES (802,'System','lloyd','','<BR><BR><FONT FACE=VERDANA,HELVETICA SIZE=1 COLOR=#000000><B>Latest Linux kernel versions:<br>-----------------------------------<br><br>The latest stable version of the Linux kernel is:           2.4.21<br />\r\nThe latest prepatch for the stable Linux kernel tree is:    2.4.22-pre5<br />\r\nThe latest snapshot for the stable Linux kernel tree is:    2.4.21-bk9<br />\r\nThe latest beta version of the Linux kernel is:             2.6.0-test1<br />\r\nThe latest 2.2 version of the Linux kernel is:              2.2.25<br />\r\nThe latest 2.0 version of the Linux kernel is:              2.0.39<br />\r\nThe latest prepatch for the 2.0 Linux kernel tree is:       2.0.40-rc6<br />\r\nThe latest -ac patch to the stable Linux kernels is:        2.4.22-pre3-ac1<br />\r\n</b></font>','2003-07-14 13:03:32',0,'');
INSERT INTO nuke_pnchat VALUES (803,'System','','','<i><b>lloyd</b> just entered the chat.</i><br>','2003-07-14 13:04:11',0,'');
INSERT INTO nuke_pnchat VALUES (804,'System','lloyd','','<b>Welcome lloyd! Users in this room:</b>  <font color=#0000ff>lloyd</font> ','2003-07-14 13:04:11',0,'');
INSERT INTO nuke_pnchat VALUES (805,'System','lloyd','','<BR><BR><FONT FACE=VERDANA,HELVETICA SIZE=1 COLOR=#000000><B>See www.gamemech.com/guest_test.php<BR>and www.gamemech.com/guest_test.txt<BR><br>for the basic technology I use here!<br>The example should count from 1 to 10 without refreshing the window.</B></FONT>','2003-07-14 13:04:16',0,'');
INSERT INTO nuke_pnchat VALUES (806,'System','lloyd','','<BR><BR><FONT FACE=VERDANA,HELVETICA SIZE=1 COLOR=#000000><B>Users currently in this room:<br>----------------------------------<br><font color=#0000ff> [lloyd]</font></B></FONT>','2003-07-14 13:04:35',0,'');
INSERT INTO nuke_pnchat VALUES (807,'System','lloyd','','Username Admin is used by a registered user. Please register to reserve your own nickname.<br>','2003-07-14 13:04:43',0,'');
INSERT INTO nuke_pnchat VALUES (808,'System','','','<i><b>lloyd</b> changed the nickname to <b>\'foobar\'</b></i><br>','2003-07-14 13:04:48',0,'');
INSERT INTO nuke_pnchat VALUES (809,'System','foobar','','<BR><BR><FONT FACE=VERDANA,HELVETICA SIZE=1 COLOR=#000000><B>Users currently in this room:<br>----------------------------------<br><font color=#0000ff> [foobar]</font></B></FONT>','2003-07-14 13:04:55',0,'');
INSERT INTO nuke_pnchat VALUES (810,'System','foobar','','<i>Unknown Command</i> /sesssion','2003-07-14 13:07:45',0,'');
INSERT INTO nuke_pnchat VALUES (811,'System','foobar','','<font face=verdana,arial size=1><b>\nDo you know about being with somebody?  Wanting to be?  If I had the\nwhole universe, I\'d give it to you, Janice.  When I see you, I feel\nlike I\'m hungry all over.  Do you know how that feels?\n		-- Charlie Evans, \"Charlie X\", stardate 1535.8\n</b></font>','2003-07-14 13:08:25',0,'');
INSERT INTO nuke_pnchat VALUES (812,'System','foobar','','<i>Unknown Command</i> /fortuna','2003-07-14 13:08:29',0,'');
INSERT INTO nuke_pnchat VALUES (813,'foobar','','asd;lkfj','','2003-07-14 13:10:30',0,'#0000ff');
INSERT INTO nuke_pnchat VALUES (814,'System','foobar','','<i>Unknown Command</i> /dsf','2003-07-14 13:10:34',0,'');
INSERT INTO nuke_pnchat VALUES (815,'System','foobar','','<font face=verdana,arial size=1><b>\nThere\'s a way out of any cage.\n		-- Captain Christopher Pike, \"The Menagerie\" (\"The Cage\"),\n		   stardate unknown.\n</b></font>','2003-07-14 13:11:03',0,'');
INSERT INTO nuke_pnchat VALUES (816,'System','foobar','','<p>\nKnowledge, sir, should be free to all!\n		-- Harry Mudd, \"I, Mudd\", stardate 4513.3\n</p>','2003-07-14 13:11:33',0,'');
INSERT INTO nuke_pnchat VALUES (817,'System','foobar','','\nNo problem is insoluble.\n		-- Dr. Janet Wallace, \"The Deadly Years\", stardate 3479.4\n','2003-07-14 13:11:56',0,'');
INSERT INTO nuke_pnchat VALUES (818,'System','foobar','','\n\"No one talks peace unless he\'s ready to back it up with war.\"\n\"He talks of peace if it is the only way to live.\"\n		-- Colonel Green and Surak of Vulcan, \"The Savage Curtain\",\n		   stardate 5906.5.\n','2003-07-14 13:12:23',0,'');
INSERT INTO nuke_pnchat VALUES (819,'System','foobar','','Current Session ID:  ','2003-07-14 13:13:03',0,'');
INSERT INTO nuke_pnchat VALUES (820,'System','foobar','','Current Session ID:  ','2003-07-14 13:13:42',0,'');
INSERT INTO nuke_pnchat VALUES (821,'System','foobar','','Current Session ID:  session_id()','2003-07-14 13:13:58',0,'');
INSERT INTO nuke_pnchat VALUES (822,'System','foobar','','Current Session ID:  ','2003-07-14 13:15:28',0,'');
INSERT INTO nuke_pnchat VALUES (823,'System','foobar','','Current Session ID:  ','2003-07-14 13:20:16',0,'');
INSERT INTO nuke_pnchat VALUES (824,'System','foobar','','Current Session ID:  ','2003-07-14 13:20:26',0,'');
INSERT INTO nuke_pnchat VALUES (825,'System','foobar','','Current Session ID:  ','2003-07-14 13:20:34',0,'');
INSERT INTO nuke_pnchat VALUES (826,'System','foobar','','Current Session ID:  ','2003-07-14 13:21:07',0,'');
INSERT INTO nuke_pnchat VALUES (827,'System','foobar','','Current Session ID:  0','2003-07-14 13:21:50',0,'');
INSERT INTO nuke_pnchat VALUES (828,'System','foobar','','Current Session ID:  0','2003-07-14 13:23:19',0,'');
INSERT INTO nuke_pnchat VALUES (829,'System','foobar','','Current Session ID:  ','2003-07-14 13:24:50',0,'');
INSERT INTO nuke_pnchat VALUES (830,'System','','','<i><b>foobar</b> just entered the chat.</i><br>','2003-07-14 13:28:23',0,'');
INSERT INTO nuke_pnchat VALUES (831,'System','foobar','','<b>Welcome foobar! Users in this room:</b>  <font color=#0000ff>foobar</font> ','2003-07-14 13:28:23',0,'');
INSERT INTO nuke_pnchat VALUES (832,'System','','','<i><b>foobar</b> just entered the chat.</i><br>','2003-07-14 13:28:41',0,'');
INSERT INTO nuke_pnchat VALUES (833,'System','foobar','','<b>Welcome foobar! Users in this room:</b>  <font color=#0000ff>foobar</font> ','2003-07-14 13:28:41',0,'');
INSERT INTO nuke_pnchat VALUES (834,'System','foobar','','<i>Current Session ID:</i>  ','2003-07-14 13:28:46',0,'');
INSERT INTO nuke_pnchat VALUES (835,'foobar','','fwejiwfej','','2003-07-14 13:32:14',0,'#0000ff');
INSERT INTO nuke_pnchat VALUES (836,'foobar','','fewji','','2003-07-14 13:33:10',0,'#0000ff');
INSERT INTO nuke_pnchat VALUES (837,'System','','','<b>foobar faints</b>','2003-07-14 13:34:00',0,'');
INSERT INTO nuke_pnchat VALUES (838,'System','','','<i><b>foobar</b> just entered the chat.</i><br>','2003-07-14 13:36:03',0,'');
INSERT INTO nuke_pnchat VALUES (839,'System','foobar','','<b>Welcome foobar! Users in this room:</b>  <font color=#0000ff>foobar</font> ','2003-07-14 13:36:03',0,'');
INSERT INTO nuke_pnchat VALUES (840,'foobar','','fewjnfew','','2003-07-14 13:36:22',0,'#0000ff');
INSERT INTO nuke_pnchat VALUES (841,'System','','','<i><b>foobar</b> just entered the chat.</i><br>','2003-07-14 13:39:42',0,'');
INSERT INTO nuke_pnchat VALUES (842,'System','foobar','','<b>Welcome foobar! Users in this room:</b>  <font color=#0000ff>foobar</font> ','2003-07-14 13:39:42',0,'');
INSERT INTO nuke_pnchat VALUES (843,'System','foobar','','Username Admin is used by a registered user. Please register to reserve your own nickname.<br>','2003-07-14 13:39:53',0,'');
INSERT INTO nuke_pnchat VALUES (844,'foobar','','adsfj','','2003-07-14 13:39:55',0,'#0000ff');
INSERT INTO nuke_pnchat VALUES (845,'System','','','<i><b>foobar</b> changed the nickname to <b>\'boofar\'</b></i><br>','2003-07-14 13:40:01',0,'');
INSERT INTO nuke_pnchat VALUES (846,'System','','','<i><b>boofar</b> just entered the chat.</i><br>','2003-07-14 13:40:15',0,'');
INSERT INTO nuke_pnchat VALUES (847,'System','boofar','','<b>Welcome boofar! Users in this room:</b>  <font color=#0000ff>boofar</font> ','2003-07-14 13:40:15',0,'');
INSERT INTO nuke_pnchat VALUES (848,'boofar','','fwfewiewf','','2003-07-14 13:40:27',0,'#0000ff');
INSERT INTO nuke_pnchat VALUES (849,'System','','','<i><b>boofar</b> just entered the chat.</i><br>','2003-07-14 13:41:20',0,'');
INSERT INTO nuke_pnchat VALUES (850,'System','boofar','','<b>Welcome boofar! Users in this room:</b>  <font color=#0000ff>boofar</font> ','2003-07-14 13:41:20',0,'');
INSERT INTO nuke_pnchat VALUES (851,'boofar','','fwefewfe','','2003-07-14 13:41:25',0,'#0000ff');
INSERT INTO nuke_pnchat VALUES (852,'boofar','','erfwf','','2003-07-14 13:41:58',0,'#0000ff');
INSERT INTO nuke_pnchat VALUES (853,'boofar','','wfe','','2003-07-14 13:44:13',0,'#0000ff');
INSERT INTO nuke_pnchat VALUES (854,'boofar','','kjfasd','','2003-07-14 13:44:40',0,'#0000ff');
INSERT INTO nuke_pnchat VALUES (855,'System','','','<i><b>boofar</b> changed the nickname to <b>\'foo\'</b></i><br>','2003-07-14 13:44:45',0,'');
INSERT INTO nuke_pnchat VALUES (856,'foo','','aksdf','','2003-07-14 13:44:48',0,'#0000ff');
INSERT INTO nuke_pnchat VALUES (857,'System','','','<i><b>foo</b> just entered the chat.</i><br>','2003-07-14 13:44:56',0,'');
INSERT INTO nuke_pnchat VALUES (858,'System','foo','','<b>Welcome foo! Users in this room:</b>  <font color=#0000ff>foo</font> ','2003-07-14 13:44:56',0,'');
INSERT INTO nuke_pnchat VALUES (859,'foo','','ytj','','2003-07-14 13:45:22',0,'#0000ff');
INSERT INTO nuke_pnchat VALUES (860,'System','','','<i><b>foo</b> just entered the chat.</i><br>','2003-07-14 13:47:34',0,'');
INSERT INTO nuke_pnchat VALUES (861,'System','foo','','<b>Welcome foo! Users in this room:</b>  <font color=#0000ff>foo</font> ','2003-07-14 13:47:34',0,'');
INSERT INTO nuke_pnchat VALUES (862,'foo','','fewfew','','2003-07-14 13:47:37',0,'#0000ff');
INSERT INTO nuke_pnchat VALUES (863,'System','','','<i><b>foo</b> just entered the chat.</i><br>','2003-07-14 13:48:04',0,'');
INSERT INTO nuke_pnchat VALUES (864,'System','foo','','<b>Welcome foo! Users in this room:</b>  <font color=#0000ff>foo</font> ','2003-07-14 13:48:04',0,'');
INSERT INTO nuke_pnchat VALUES (865,'foo','','iewjwfei','','2003-07-14 13:48:17',0,'#0000ff');
INSERT INTO nuke_pnchat VALUES (866,'foo','','','','2003-07-14 13:48:23',0,'#0000ff');
INSERT INTO nuke_pnchat VALUES (867,'System','','','<i><b>foo</b> just entered the chat.</i><br>','2003-07-14 13:49:07',0,'');
INSERT INTO nuke_pnchat VALUES (868,'System','foo','','<b>Welcome foo! Users in this room:</b>  <font color=#0000ff>foo</font> ','2003-07-14 13:49:07',0,'');
INSERT INTO nuke_pnchat VALUES (869,'foo','','weffwe','','2003-07-14 13:49:09',0,'#0000ff');
INSERT INTO nuke_pnchat VALUES (870,'System','','','<i><b>foo</b> just entered the chat.</i><br>','2003-07-14 13:49:23',0,'');
INSERT INTO nuke_pnchat VALUES (871,'System','foo','','<b>Welcome foo! Users in this room:</b>  <font color=#0000ff>foo</font> ','2003-07-14 13:49:23',0,'');
INSERT INTO nuke_pnchat VALUES (872,'System','','','<i><b>foo</b> just entered the chat.</i><br>','2003-07-14 13:50:42',0,'');
INSERT INTO nuke_pnchat VALUES (873,'System','foo','','<b>Welcome foo! Users in this room:</b>  <font color=#0000ff>foo</font> ','2003-07-14 13:50:42',0,'');
INSERT INTO nuke_pnchat VALUES (874,'foo','','ijwefwi','','2003-07-14 13:51:36',0,'#0000ff');
INSERT INTO nuke_pnchat VALUES (875,'System','','','<i><b>foo</b> just entered the chat.</i><br>','2003-07-14 13:51:42',0,'');
INSERT INTO nuke_pnchat VALUES (876,'System','foo','','<b>Welcome foo! Users in this room:</b>  <font color=#0000ff>foo</font> ','2003-07-14 13:51:42',0,'');
INSERT INTO nuke_pnchat VALUES (877,'foo','','koffewk','','2003-07-14 13:51:45',0,'#0000ff');
INSERT INTO nuke_pnchat VALUES (878,'System','','','<i><b>foo</b> changed the nickname to <b>\'bar\'</b></i><br>','2003-07-14 13:51:49',0,'');
INSERT INTO nuke_pnchat VALUES (879,'System','bar','','<i>Current Session ID:</i>  ','2003-07-14 13:51:53',0,'');
INSERT INTO nuke_pnchat VALUES (880,'System','','','<i><b>bar</b> just entered the chat.</i><br>','2003-07-14 13:53:15',0,'');
INSERT INTO nuke_pnchat VALUES (881,'System','bar','','<b>Welcome bar! Users in this room:</b>  <font color=#0000ff>bar</font> ','2003-07-14 13:53:15',0,'');
INSERT INTO nuke_pnchat VALUES (882,'bar','','foobar','','2003-07-14 13:53:19',0,'#0000ff');
INSERT INTO nuke_pnchat VALUES (883,'System','bar','','Username Admin is used by a registered user. Please register to reserve your own nickname.<br>','2003-07-14 13:53:24',0,'');
INSERT INTO nuke_pnchat VALUES (884,'System','bar','','<i>Current Session ID:</i>  ','2003-07-14 13:53:27',0,'');
INSERT INTO nuke_pnchat VALUES (885,'bar','','fads','','2003-07-14 13:55:08',0,'#0000ff');
INSERT INTO nuke_pnchat VALUES (886,'bar','','ds','','2003-07-14 13:55:21',0,'#0000ff');
INSERT INTO nuke_pnchat VALUES (887,'bar','','kjfeiwf','','2003-07-14 13:55:23',0,'#0000ff');
INSERT INTO nuke_pnchat VALUES (888,'bar','','fejk','','2003-07-14 13:55:45',0,'#0000ff');
INSERT INTO nuke_pnchat VALUES (889,'System','','','<i><b>bar</b> just entered the chat.</i><br>','2003-07-14 13:55:57',0,'');
INSERT INTO nuke_pnchat VALUES (890,'System','bar','','<b>Welcome bar! Users in this room:</b>  <font color=#0000ff>bar</font> ','2003-07-14 13:55:57',0,'');
INSERT INTO nuke_pnchat VALUES (891,'System','','','<i><b>bar</b> just entered the chat.</i><br>','2003-07-14 14:00:08',0,'');
INSERT INTO nuke_pnchat VALUES (892,'System','bar','','<b>Welcome bar! Users in this room:</b>  <font color=#0000ff>bar</font> ','2003-07-14 14:00:08',0,'');
INSERT INTO nuke_pnchat VALUES (893,'bar','','fewfew','','2003-07-14 14:00:10',0,'#0000ff');
INSERT INTO nuke_pnchat VALUES (894,'System','','','<i><b>bar</b> changed the nickname to <b>\'nick\'</b></i><br>','2003-07-14 14:00:13',0,'');
INSERT INTO nuke_pnchat VALUES (895,'nick','','asdf','','2003-07-14 14:00:19',0,'#0000ff');
INSERT INTO nuke_pnchat VALUES (896,'System','nick','','Username rexlunae is used by a registered user. Please register to reserve your own nickname.<br>','2003-07-14 14:00:34',0,'');
INSERT INTO nuke_pnchat VALUES (897,'System','','','<i><b>nick</b> changed the nickname to <b>\'boofar\'</b></i><br>','2003-07-14 14:00:40',0,'');
INSERT INTO nuke_pnchat VALUES (898,'System','','','<i><b>boofar</b> just entered the chat.</i><br>','2003-07-14 14:00:49',0,'');
INSERT INTO nuke_pnchat VALUES (899,'System','boofar','','<b>Welcome boofar! Users in this room:</b>  <font color=#0000ff>boofar</font> ','2003-07-14 14:00:49',0,'');
INSERT INTO nuke_pnchat VALUES (900,'System','','','<i><b>boofar</b> changed the nickname to <b>\'l\'</b></i><br>','2003-07-14 14:00:59',0,'');
INSERT INTO nuke_pnchat VALUES (901,'l','','hi','','2003-07-14 14:01:02',0,'#0000ff');
INSERT INTO nuke_pnchat VALUES (902,'l','','jewifewj','','2003-07-14 14:01:08',0,'#0000ff');
INSERT INTO nuke_pnchat VALUES (903,'l','','jew?','','2003-07-14 14:01:12',0,'#0000ff');
INSERT INTO nuke_pnchat VALUES (904,'l','','racist','','2003-07-14 14:01:14',0,'#0000ff');
INSERT INTO nuke_pnchat VALUES (905,'l','','q','','2003-07-14 14:01:20',0,'#0000ff');
INSERT INTO nuke_pnchat VALUES (906,'System','','','<i><b>l</b> changed the nickname to <b>\'nick\'</b></i><br>','2003-07-14 14:01:24',0,'');
INSERT INTO nuke_pnchat VALUES (907,'nick','','hello','','2003-07-14 14:01:27',0,'#0000ff');
INSERT INTO nuke_pnchat VALUES (908,'System','','','<i><b>nick</b> changed the nickname to <b>\'/nick\'</b></i><br>','2003-07-14 14:01:32',0,'');
INSERT INTO nuke_pnchat VALUES (909,'System','','','<i><b>/nick</b> has changed <font color=#000000>color</font></i><br>','2003-07-14 14:01:33',0,'');
INSERT INTO nuke_pnchat VALUES (910,'/nick','','hello','','2003-07-14 14:01:35',0,'#000000');
INSERT INTO nuke_pnchat VALUES (911,'System','','','<i><b>/nick</b> has changed <font color=#ffffff>color</font></i><br>','2003-07-14 14:01:44',0,'');
INSERT INTO nuke_pnchat VALUES (912,'/nick','','jeifjwef','','2003-07-14 14:01:47',0,'#ffffff');
INSERT INTO nuke_pnchat VALUES (913,'System','','','<i><b>/nick</b> changed the nickname to <b>\'/ni@#2:**)/\'</b></i><br>','2003-07-14 14:01:50',0,'');
INSERT INTO nuke_pnchat VALUES (914,'/ni@#2:**)/','','(b)(c)','','2003-07-14 14:01:54',0,'#ffffff');
INSERT INTO nuke_pnchat VALUES (915,'/ni@#2:**)/','','hello','','2003-07-14 14:01:56',0,'#ffffff');
INSERT INTO nuke_pnchat VALUES (916,'/ni@#2:**)/','',':-V','','2003-07-14 14:02:01',0,'#ffffff');
INSERT INTO nuke_pnchat VALUES (917,'/ni@#2:**)/','',':-[','','2003-07-14 14:02:12',0,'#ffffff');
INSERT INTO nuke_pnchat VALUES (918,'/ni@#2:**)/','',':-Y','','2003-07-14 14:02:14',0,'#ffffff');
INSERT INTO nuke_pnchat VALUES (919,'System','','','<i><b>/ni@#2:**)/</b> just left the chat.</i><br>','2003-07-14 14:02:23',0,'');
INSERT INTO nuke_pnchat VALUES (920,'System','','','<i><b>/ni@#2:**)/</b> just entered the chat.</i><br>','2003-07-14 14:02:29',0,'');
INSERT INTO nuke_pnchat VALUES (921,'System','/ni@#2:**)/','','<b>Welcome /ni@#2:**)/! Users in this room:</b>  <font color=#ffffff>/ni@#2:**)/</font> ','2003-07-14 14:02:29',0,'');
INSERT INTO nuke_pnchat VALUES (922,'/ni@#2:**)/','','www.google.com','','2003-07-14 14:02:33',0,'#ffffff');
INSERT INTO nuke_pnchat VALUES (923,'/ni@#2:**)/','','http://google.com','','2003-07-14 14:02:36',0,'#ffffff');
INSERT INTO nuke_pnchat VALUES (924,'/ni@#2:**)/','','','','2003-07-14 14:02:40',0,'#ffffff');
INSERT INTO nuke_pnchat VALUES (925,'/ni@#2:**)/','','','','2003-07-14 14:02:42',0,'#ffffff');
INSERT INTO nuke_pnchat VALUES (926,'/ni@#2:**)/','','www.google.com','','2003-07-14 14:02:46',0,'#ffffff');
INSERT INTO nuke_pnchat VALUES (927,'System','/ni@#2:**)/','','<i>Unknown Command</i> /sesion','2003-07-14 14:02:48',0,'');
INSERT INTO nuke_pnchat VALUES (928,'System','/ni@#2:**)/','','<i>Current Session ID:</i>  ','2003-07-14 14:02:51',0,'');
INSERT INTO nuke_pnchat VALUES (929,'/ni@#2:**)/','','hello','','2003-07-14 14:03:03',0,'#ffffff');
INSERT INTO nuke_pnchat VALUES (930,'/ni@#2:**)/','','www.google.com','','2003-07-14 14:03:09',0,'#ffffff');
INSERT INTO nuke_pnchat VALUES (931,'/ni@#2:**)/','','fasdfsadf','','2003-07-14 14:03:11',0,'#ffffff');
INSERT INTO nuke_pnchat VALUES (932,'/ni@#2:**)/','','fdsafsdaf','','2003-07-14 14:03:17',0,'#ffffff');
INSERT INTO nuke_pnchat VALUES (933,'/ni@#2:**)/','','fdsaf','','2003-07-14 14:03:20',0,'#ffffff');
INSERT INTO nuke_pnchat VALUES (934,'System','','','<i><b>/ni@#2:**)/</b> just entered the chat.</i><br>','2003-07-14 14:03:45',0,'');
INSERT INTO nuke_pnchat VALUES (935,'System','/ni@#2:**)/','','<b>Welcome /ni@#2:**)/! Users in this room:</b>  <font color=#ffffff>/ni@#2:**)/</font> ','2003-07-14 14:03:45',0,'');
INSERT INTO nuke_pnchat VALUES (936,'/ni@#2:**)/','','www.google.com','','2003-07-14 14:03:51',0,'#ffffff');
INSERT INTO nuke_pnchat VALUES (937,'System','','','<i><b>/ni@#2:**)/</b> changed the nickname to <b>\'www.google.com\'</b></i><br>','2003-07-14 14:03:56',0,'');
INSERT INTO nuke_pnchat VALUES (938,'www.google.com','','hello','','2003-07-14 14:04:00',0,'#ffffff');
INSERT INTO nuke_pnchat VALUES (939,'www.google.com','','www.www','','2003-07-14 14:04:01',0,'#ffffff');
INSERT INTO nuke_pnchat VALUES (940,'www.google.com','','www.wwww.wwwwwww.wwwwwwwww','','2003-07-14 14:04:10',0,'#ffffff');
INSERT INTO nuke_pnchat VALUES (941,'www.google.com','','ww','','2003-07-14 14:04:13',0,'#ffffff');
INSERT INTO nuke_pnchat VALUES (942,'www.google.com','','w.w.w','','2003-07-14 14:04:16',0,'#ffffff');
INSERT INTO nuke_pnchat VALUES (943,'www.google.com','','www','','2003-07-14 14:04:18',0,'#ffffff');
INSERT INTO nuke_pnchat VALUES (944,'www.google.com','','www.','','2003-07-14 14:04:21',0,'#ffffff');
INSERT INTO nuke_pnchat VALUES (945,'www.google.com','','www.f','','2003-07-14 14:04:25',0,'#ffffff');
INSERT INTO nuke_pnchat VALUES (946,'www.google.com','','this thing is buggy','','2003-07-14 14:04:28',0,'#ffffff');
INSERT INTO nuke_pnchat VALUES (947,'www.google.com','','ftp.foo.bar','','2003-07-14 14:04:32',0,'#ffffff');
INSERT INTO nuke_pnchat VALUES (948,'www.google.com','','http://http://http://www.google.com','','2003-07-14 14:04:47',0,'#ffffff');
INSERT INTO nuke_pnchat VALUES (949,'www.google.com','','fkejf','','2003-07-14 14:04:52',0,'#ffffff');
INSERT INTO nuke_pnchat VALUES (950,'www.google.com','','Yello','','2003-07-14 14:05:08',0,'#ffffff');
INSERT INTO nuke_pnchat VALUES (951,'www.google.com','',':-Z','','2003-07-14 14:05:11',0,'#ffffff');
INSERT INTO nuke_pnchat VALUES (952,'www.google.com','',':-o','','2003-07-14 14:05:23',0,'#ffffff');
INSERT INTO nuke_pnchat VALUES (953,'www.google.com','','&lt;a href=\\&quot;http://www.google.com\\&quot;&gt;:-Z&lt;/a&gt;','','2003-07-14 14:05:41',0,'#ffffff');
INSERT INTO nuke_pnchat VALUES (954,'System','','','<i><b>www.google.com</b> just entered the chat.</i><br>','2003-07-14 14:09:33',0,'');
INSERT INTO nuke_pnchat VALUES (955,'System','www.google.com','','<b>Welcome www.google.com! Users in this room:</b>  <font color=#ffffff>www.google.com</font> ','2003-07-14 14:09:33',0,'');
INSERT INTO nuke_pnchat VALUES (956,'System','','','<i><b>www.google.com</b> just left the chat.</i><br>','2003-07-14 14:10:08',0,'');
INSERT INTO nuke_pnchat VALUES (957,'System','','','<i><b>www.google.com</b> just left the chat.</i><br>','2003-07-14 14:10:08',0,'');
INSERT INTO nuke_pnchat VALUES (958,'System','','','<i><b>www.google.com</b> just left the chat.</i><br>','2003-07-14 14:10:08',0,'');
INSERT INTO nuke_pnchat VALUES (959,'System','','','<i><b>www.google.com</b> just entered the chat.</i><br>','2003-07-14 14:10:59',0,'');
INSERT INTO nuke_pnchat VALUES (960,'System','www.google.com','','<b>Welcome www.google.com! Users in this room:</b>  <font color=#ffffff>www.google.com</font> ','2003-07-14 14:10:59',0,'');
INSERT INTO nuke_pnchat VALUES (961,'System','','','<i><b>www.google.com</b> changed the nickname to <b>\'nick\'</b></i><br>','2003-07-14 14:11:08',0,'');
INSERT INTO nuke_pnchat VALUES (962,'System','nick','','<i>Current Session ID:</i>  ','2003-07-14 14:11:27',0,'');
INSERT INTO nuke_pnchat VALUES (963,'System','','','<i><b>nick</b> just entered the chat.</i><br>','2003-07-14 14:11:53',0,'');
INSERT INTO nuke_pnchat VALUES (964,'System','nick','','<b>Welcome nick! Users in this room:</b>  <font color=#ffffff>nick</font> ','2003-07-14 14:11:53',0,'');
INSERT INTO nuke_pnchat VALUES (965,'System','','','<i><b>nick</b> changed the nickname to <b>\'www.google.com\'</b></i><br>','2003-07-14 14:12:00',0,'');
INSERT INTO nuke_pnchat VALUES (966,'www.google.com','','hello','','2003-07-14 14:12:03',0,'#ffffff');
INSERT INTO nuke_pnchat VALUES (967,'System','','','<i><b>www.google.com</b> changed the nickname to <b>\'http://www.google.com\'</b></i><br>','2003-07-14 14:12:30',0,'');
INSERT INTO nuke_pnchat VALUES (968,'http://www.google.co','','hello','','2003-07-14 14:12:33',0,'#ffffff');
INSERT INTO nuke_pnchat VALUES (969,'http://www.google.co','','wfew','','2003-07-14 14:12:40',0,'#ffffff');
INSERT INTO nuke_pnchat VALUES (970,'http://www.google.co','','aksdljf','','2003-07-14 14:13:41',0,'#ffffff');
INSERT INTO nuke_pnchat VALUES (971,'System','http://www.google.co','','<i>Current Session ID:</i>  236908759eda1abca0a615540220af6b','2003-07-14 14:13:45',0,'');
INSERT INTO nuke_pnchat VALUES (972,'System','','','<i><b>http://www.google.co</b> changed the nickname to <b>\'foo\'</b></i><br>','2003-07-14 14:13:53',0,'');
INSERT INTO nuke_pnchat VALUES (973,'System','foo','','<i>Current Session ID:</i>  236908759eda1abca0a615540220af6b','2003-07-14 14:14:11',0,'');
INSERT INTO nuke_pnchat VALUES (974,'System','','','<i><b>foo</b> just entered the chat.</i><br>','2003-07-14 14:15:45',0,'');
INSERT INTO nuke_pnchat VALUES (975,'System','foo','','<b>Welcome foo! Users in this room:</b>  <font color=#ffffff>foo</font> ','2003-07-14 14:15:45',0,'');
INSERT INTO nuke_pnchat VALUES (976,'System','','','<i><b>foo</b> changed the nickname to <b>\'raboof\'</b></i><br>','2003-07-14 14:15:58',0,'');
INSERT INTO nuke_pnchat VALUES (977,'System','raboof','','<i>Current Session ID:</i>  e5eb590b4e24d589d36e76de9fcdf958','2003-07-14 14:16:04',0,'');
INSERT INTO nuke_pnchat VALUES (978,'raboof','','','','2003-07-14 14:16:16',0,'#ffffff');
INSERT INTO nuke_pnchat VALUES (979,'System','','','<i><b>raboof</b> has changed <font color=#f00ba7>color</font></i><br>','2003-07-14 14:16:28',0,'');
INSERT INTO nuke_pnchat VALUES (980,'raboof','','dsakf','','2003-07-14 14:16:58',0,'#f00ba7');
INSERT INTO nuke_pnchat VALUES (981,'raboof','','alskd','','2003-07-14 14:17:11',0,'#f00ba7');
INSERT INTO nuke_pnchat VALUES (982,'System','','','<i><b>raboof</b> just entered the chat.</i><br>','2003-07-14 14:19:06',0,'');
INSERT INTO nuke_pnchat VALUES (983,'System','raboof','','<b>Welcome raboof! Users in this room:</b>  <font color=#f00ba7>raboof</font> ','2003-07-14 14:19:06',0,'');
INSERT INTO nuke_pnchat VALUES (984,'System','','','<i><b>raboof</b> changed the nickname to <b>\'foobar\'</b></i><br>','2003-07-14 14:19:13',0,'');
INSERT INTO nuke_pnchat VALUES (985,'System','','','<i><b>foobar</b> just entered the chat.</i><br>','2003-07-14 14:19:24',0,'');
INSERT INTO nuke_pnchat VALUES (986,'System','foobar','','<b>Welcome foobar! Users in this room:</b>  <font color=#f00ba7>foobar</font> ','2003-07-14 14:19:24',0,'');
INSERT INTO nuke_pnchat VALUES (987,'foobar','','asdf','','2003-07-14 14:19:54',0,'#f00ba7');
INSERT INTO nuke_pnchat VALUES (988,'foobar','','fasdew','','2003-07-14 14:19:58',0,'#f00ba7');
INSERT INTO nuke_pnchat VALUES (989,'System','foobar','','<i>Current Session ID:</i>  ','2003-07-14 14:20:03',0,'');
INSERT INTO nuke_pnchat VALUES (990,'System','foobar','','<i>Current Session ID:</i>  ','2003-07-14 14:20:09',0,'');
INSERT INTO nuke_pnchat VALUES (991,'System','','','<i><b>foobar</b> just entered the chat.</i><br>','2003-07-14 14:25:20',0,'');
INSERT INTO nuke_pnchat VALUES (992,'System','foobar','','<b>Welcome foobar! Users in this room:</b>  <font color=#f00ba7>foobar</font> ','2003-07-14 14:25:20',0,'');
INSERT INTO nuke_pnchat VALUES (993,'System','foobar','','<i>Current Session ID:</i>  ','2003-07-14 14:25:23',0,'');
INSERT INTO nuke_pnchat VALUES (994,'System','','','<i><b>foobar</b> just left the chat.</i><br>','2003-07-14 14:26:10',0,'');
INSERT INTO nuke_pnchat VALUES (995,'System','','','<i><b>foobar</b> just left the chat.</i><br>','2003-07-14 14:26:10',0,'');
INSERT INTO nuke_pnchat VALUES (996,'System','','','<i><b>foobar</b> just entered the chat.</i><br>','2003-07-14 14:26:10',0,'');
INSERT INTO nuke_pnchat VALUES (997,'System','foobar','','<b>Welcome foobar! Users in this room:</b>  <font color=#f00ba7>foobar</font> ','2003-07-14 14:26:10',0,'');
INSERT INTO nuke_pnchat VALUES (998,'System','','','<i><b>foobar</b> just left the chat.</i><br>','2003-07-14 14:26:10',0,'');
INSERT INTO nuke_pnchat VALUES (999,'System','','','<i><b>foobar</b> just left the chat.</i><br>','2003-07-14 14:26:10',0,'');
INSERT INTO nuke_pnchat VALUES (1000,'System','','','<i><b>foobar</b> just left the chat.</i><br>','2003-07-14 14:26:10',0,'');
INSERT INTO nuke_pnchat VALUES (1001,'System','','','<i><b>foobar</b> just left the chat.</i><br>','2003-07-14 14:26:10',0,'');
INSERT INTO nuke_pnchat VALUES (1002,'System','foobar','','<i>Current Session ID:</i>  ','2003-07-14 14:26:15',0,'');
INSERT INTO nuke_pnchat VALUES (1003,'System','foobar','','<i>Current Session ID:</i>  ','2003-07-14 14:26:20',0,'');
INSERT INTO nuke_pnchat VALUES (1004,'foobar','','adsf','','2003-07-14 14:26:25',0,'#f00ba7');
INSERT INTO nuke_pnchat VALUES (1005,'System','','','<i><b>foobar</b> just entered the chat.</i><br>','2003-07-14 14:26:48',0,'');
INSERT INTO nuke_pnchat VALUES (1006,'System','foobar','','<b>Welcome foobar! Users in this room:</b>  <font color=#f00ba7>foobar</font> ','2003-07-14 14:26:48',0,'');
INSERT INTO nuke_pnchat VALUES (1007,'foobar','','adsfew','','2003-07-14 14:26:56',0,'#f00ba7');
INSERT INTO nuke_pnchat VALUES (1008,'foobar','','fef','','2003-07-14 14:26:58',0,'#f00ba7');
INSERT INTO nuke_pnchat VALUES (1009,'System','','','<i><b>foobar</b> changed the nickname to <b>\'raboof\'</b></i><br>','2003-07-14 14:27:03',0,'');
INSERT INTO nuke_pnchat VALUES (1010,'System','','','<i><b>raboof</b> just entered the chat.</i><br>','2003-07-14 14:27:18',0,'');
INSERT INTO nuke_pnchat VALUES (1011,'System','raboof','','<b>Welcome raboof! Users in this room:</b>  <font color=#f00ba7>raboof</font> ','2003-07-14 14:27:18',0,'');
INSERT INTO nuke_pnchat VALUES (1012,'raboof','','asdf','','2003-07-14 14:27:30',0,'#f00ba7');
INSERT INTO nuke_pnchat VALUES (1013,'System','','','<i><b>raboof</b> just entered the chat.</i><br>','2003-07-14 14:27:38',0,'');
INSERT INTO nuke_pnchat VALUES (1014,'System','raboof','','<b>Welcome raboof! Users in this room:</b>  <font color=#f00ba7>raboof</font> ','2003-07-14 14:27:38',0,'');
INSERT INTO nuke_pnchat VALUES (1015,'System','raboof','','<i>Current Session ID:</i>  ','2003-07-14 14:28:55',0,'');
INSERT INTO nuke_pnchat VALUES (1016,'System','','','<i><b>raboof</b> just entered the chat.</i><br>','2003-07-14 14:29:05',0,'');
INSERT INTO nuke_pnchat VALUES (1017,'System','raboof','','<b>Welcome raboof! Users in this room:</b>  <font color=#f00ba7>raboof</font> ','2003-07-14 14:29:05',0,'');
INSERT INTO nuke_pnchat VALUES (1018,'System','raboof','','<i>Current Session ID:</i>  ','2003-07-14 14:29:10',0,'');
INSERT INTO nuke_pnchat VALUES (1019,'System','','','<i><b>raboof</b> changed the nickname to <b>\'asdf\'</b></i><br>','2003-07-14 14:29:18',0,'');
INSERT INTO nuke_pnchat VALUES (1020,'asdf','','asdfe','','2003-07-14 14:29:21',0,'#f00ba7');
INSERT INTO nuke_pnchat VALUES (1021,'System','','','<i><b>asdf</b> just entered the chat.</i><br>','2003-07-14 14:29:33',0,'');
INSERT INTO nuke_pnchat VALUES (1022,'System','asdf','','<b>Welcome asdf! Users in this room:</b>  <font color=#f00ba7>asdf</font> ','2003-07-14 14:29:33',0,'');
INSERT INTO nuke_pnchat VALUES (1023,'System','asdf','','<i>Current Session ID:</i>  8474263d0c8003f2bde239800612a228','2003-07-14 14:29:37',0,'');
INSERT INTO nuke_pnchat VALUES (1024,'System','asdf','','<i>Current Session ID:</i>  ','2003-07-14 14:29:47',0,'');
INSERT INTO nuke_pnchat VALUES (1025,'System','','','<i><b>asdf</b> changed the nickname to <b>\'boof\'</b></i><br>','2003-07-14 14:29:59',0,'');
INSERT INTO nuke_pnchat VALUES (1026,'System','boof','','<i>Current Session ID:</i>  ','2003-07-14 14:30:04',0,'');
INSERT INTO nuke_pnchat VALUES (1027,'boof','','asdf','','2003-07-14 14:30:10',0,'#f00ba7');
INSERT INTO nuke_pnchat VALUES (1028,'System','','','<i><b>boof</b> just entered the chat.</i><br>','2003-07-14 14:31:35',0,'');
INSERT INTO nuke_pnchat VALUES (1029,'System','boof','','<b>Welcome boof! Users in this room:</b>  <font color=#f00ba7>boof</font> ','2003-07-14 14:31:35',0,'');
INSERT INTO nuke_pnchat VALUES (1030,'System','','','<i><b>boof</b> just entered the chat.</i><br>','2003-07-14 14:31:39',0,'');
INSERT INTO nuke_pnchat VALUES (1031,'System','boof','','<b>Welcome boof! Users in this room:</b>  <font color=#f00ba7>boof</font> ','2003-07-14 14:31:39',0,'');
INSERT INTO nuke_pnchat VALUES (1032,'System','','','<i><b>boof</b> just entered the chat.</i><br>','2003-07-14 14:33:30',0,'');
INSERT INTO nuke_pnchat VALUES (1033,'System','boof','','<b>Welcome boof! Users in this room:</b>  <font color=#f00ba7>boof</font> ','2003-07-14 14:33:30',0,'');
INSERT INTO nuke_pnchat VALUES (1034,'System','boof','','<i>Current Session ID:</i>  236908759eda1abca0a615540220af6b','2003-07-14 14:33:35',0,'');
INSERT INTO nuke_pnchat VALUES (1035,'System','','','<i><b>boof</b> just entered the chat.</i><br>','2003-07-14 14:33:53',0,'');
INSERT INTO nuke_pnchat VALUES (1036,'System','boof','','<b>Welcome boof! Users in this room:</b>  <font color=#f00ba7>boof</font> ','2003-07-14 14:33:53',0,'');
INSERT INTO nuke_pnchat VALUES (1037,'System','','','<i><b>boof</b> just entered the chat.</i><br>','2003-07-14 14:34:05',0,'');
INSERT INTO nuke_pnchat VALUES (1038,'System','boof','','<b>Welcome boof! Users in this room:</b>  <font color=#f00ba7>boof</font> ','2003-07-14 14:34:05',0,'');
INSERT INTO nuke_pnchat VALUES (1039,'boof','','afewf','','2003-07-14 14:34:07',0,'#f00ba7');
INSERT INTO nuke_pnchat VALUES (1040,'boof','','jewf','','2003-07-14 14:34:10',0,'#f00ba7');
INSERT INTO nuke_pnchat VALUES (1041,'System','boof','','<i>Current Session ID:</i>  236908759eda1abca0a615540220af6b','2003-07-14 14:34:13',0,'');
INSERT INTO nuke_pnchat VALUES (1042,'System','','','<i><b>boof</b> just entered the chat.</i><br>','2003-07-14 14:38:59',0,'');
INSERT INTO nuke_pnchat VALUES (1043,'System','boof','','<b>Welcome boof! Users in this room:</b>  <font color=#f00ba7>boof</font> ','2003-07-14 14:38:59',0,'');
INSERT INTO nuke_pnchat VALUES (1044,'System','boof','','<i>Current Session ID:</i>  236908759eda1abca0a615540220af6b','2003-07-14 14:39:07',0,'');
INSERT INTO nuke_pnchat VALUES (1045,'System','','','<i><b>boof</b> just left the chat.</i><br>','2003-07-14 14:54:20',0,'');
INSERT INTO nuke_pnchat VALUES (1046,'System','','','<i><b>boof</b> just entered the chat.</i><br>','2003-07-14 14:54:58',0,'');
INSERT INTO nuke_pnchat VALUES (1047,'System','boof','','<b>Welcome boof! Users in this room:</b>  <font color=#f00ba7>boof</font> ','2003-07-14 14:54:58',0,'');
INSERT INTO nuke_pnchat VALUES (1048,'System','','','<i><b>boof</b> just left the chat.</i><br>','2003-07-14 14:55:05',0,'');
INSERT INTO nuke_pnchat VALUES (1049,'System','','','<i><b>boof</b> just entered the chat.</i><br>','2003-07-14 14:55:31',0,'');
INSERT INTO nuke_pnchat VALUES (1050,'System','boof','','<b>Welcome boof! Users in this room:</b>  <font color=#f00ba7>boof</font> ','2003-07-14 14:55:31',0,'');
INSERT INTO nuke_pnchat VALUES (1051,'System','','','<i><b>boof</b> just left the chat.</i><br>','2003-07-14 14:56:11',0,'');
INSERT INTO nuke_pnchat VALUES (1052,'System','','','<i><b>boof</b> just entered the chat.</i><br>','2003-07-14 14:56:34',0,'');
INSERT INTO nuke_pnchat VALUES (1053,'System','boof','','<b>Welcome boof! Users in this room:</b>  <font color=#f00ba7>boof</font> ','2003-07-14 14:56:34',0,'');
INSERT INTO nuke_pnchat VALUES (1054,'boof','','efw','','2003-07-14 14:56:38',0,'#f00ba7');
INSERT INTO nuke_pnchat VALUES (1055,'System','','','<i><b>boof</b> just left the chat.</i><br>','2003-07-14 14:56:40',0,'');
INSERT INTO nuke_pnchat VALUES (1056,'System','','','<i><b>boof</b> just entered the chat.</i><br>','2003-07-14 14:56:46',0,'');
INSERT INTO nuke_pnchat VALUES (1057,'System','boof','','<b>Welcome boof! Users in this room:</b>  <font color=#f00ba7>boof</font> ','2003-07-14 14:56:46',0,'');
INSERT INTO nuke_pnchat VALUES (1058,'System','','','<i><b>boof</b> just entered the chat.</i><br>','2003-07-14 14:56:50',0,'');
INSERT INTO nuke_pnchat VALUES (1059,'System','boof','','<b>Welcome boof! Users in this room:</b>  <font color=#f00ba7>boof</font> ','2003-07-14 14:56:50',0,'');
INSERT INTO nuke_pnchat VALUES (1060,'System','','','<i><b>boof</b> just left the chat.</i><br>','2003-07-14 14:57:42',0,'');
INSERT INTO nuke_pnchat VALUES (1061,'System','','','<i><b>boof</b> just left the chat.</i><br>','2003-07-14 14:57:42',0,'');
INSERT INTO nuke_pnchat VALUES (1062,'System','','','<i><b>boof</b> just entered the chat.</i><br>','2003-07-14 15:00:28',0,'');
INSERT INTO nuke_pnchat VALUES (1063,'System','boof','','<b>Welcome boof! Users in this room:</b> ','2003-07-14 15:00:28',0,'');
INSERT INTO nuke_pnchat VALUES (1064,'System','','','<i><b>boof</b> changed the nickname to <b>\'asdf\'</b></i><br>','2003-07-14 15:00:35',0,'');
INSERT INTO nuke_pnchat VALUES (1065,'asdf','','adsfklj','','2003-07-14 15:00:38',0,'#f00ba7');
INSERT INTO nuke_pnchat VALUES (1066,'asdf','','ifewijwfe','','2003-07-14 15:00:39',0,'#f00ba7');
INSERT INTO nuke_pnchat VALUES (1067,'System','','','<i><b>asdf</b> just entered the chat.</i><br>','2003-07-14 15:02:20',0,'');
INSERT INTO nuke_pnchat VALUES (1068,'System','asdf','','<b>Welcome asdf! Users in this room:</b>  <font color=#f00ba7>asdf</font> ','2003-07-14 15:02:20',0,'');
INSERT INTO nuke_pnchat VALUES (1069,'System','','','<i><b>asdf</b> just left the chat.</i><br>','2003-07-14 15:02:21',0,'');
INSERT INTO nuke_pnchat VALUES (1070,'asdf','','wefew','','2003-07-14 15:02:22',0,'#f00ba7');
INSERT INTO nuke_pnchat VALUES (1071,'asdf','','jdfie','','2003-07-14 15:02:24',0,'#f00ba7');
INSERT INTO nuke_pnchat VALUES (1072,'asdf','','dsjif','','2003-07-14 15:02:25',0,'#f00ba7');
INSERT INTO nuke_pnchat VALUES (1073,'System','','','<i><b>asdf</b> changed the nickname to <b>\'foo\'</b></i><br>','2003-07-14 15:02:28',0,'');
INSERT INTO nuke_pnchat VALUES (1074,'System','','','<i><b>foo</b> just entered the chat.</i><br>','2003-07-14 15:02:38',0,'');
INSERT INTO nuke_pnchat VALUES (1075,'System','foo','','<b>Welcome foo! Users in this room:</b>  <font color=#f00ba7>foo</font> ','2003-07-14 15:02:38',0,'');
INSERT INTO nuke_pnchat VALUES (1076,'foo','','asdfe','','2003-07-14 15:02:39',0,'#f00ba7');
INSERT INTO nuke_pnchat VALUES (1077,'foo','','wiefjfe','','2003-07-14 15:02:41',0,'#f00ba7');
INSERT INTO nuke_pnchat VALUES (1078,'System','','','<i><b>foo</b> changed the nickname to <b>\'bar\'</b></i><br>','2003-07-14 15:02:45',0,'');
INSERT INTO nuke_pnchat VALUES (1079,'bar','','adsflkj','','2003-07-14 15:02:48',0,'#f00ba7');
INSERT INTO nuke_pnchat VALUES (1080,'System','bar','','<i>Current Session ID:</i>  8474263d0c8003f2bde239800612a228','2003-07-14 15:02:53',0,'');
INSERT INTO nuke_pnchat VALUES (1081,'System','','','<i><b>bar</b> just left the chat.</i><br>','2003-07-14 15:04:38',0,'');
INSERT INTO nuke_pnchat VALUES (1082,'System','','','<i><b>bar</b> just entered the chat.</i><br>','2003-07-14 15:06:41',0,'');
INSERT INTO nuke_pnchat VALUES (1083,'System','bar','','<b>Welcome bar! Users in this room:</b>  <font color=#f00ba7>bar</font> ','2003-07-14 15:06:41',0,'');
INSERT INTO nuke_pnchat VALUES (1084,'System','','','<i><b>bar</b> just entered the chat.</i><br>','2003-07-14 15:06:49',0,'');
INSERT INTO nuke_pnchat VALUES (1085,'System','bar','','<b>Welcome bar! Users in this room:</b>  <font color=#f00ba7>bar</font> ','2003-07-14 15:06:49',0,'');
INSERT INTO nuke_pnchat VALUES (1086,'System','','','<i><b>bar</b> just entered the chat.</i><br>','2003-07-14 15:06:51',0,'');
INSERT INTO nuke_pnchat VALUES (1087,'System','bar','','<b>Welcome bar! Users in this room:</b>  <font color=#f00ba7>bar</font> ','2003-07-14 15:06:51',0,'');
INSERT INTO nuke_pnchat VALUES (1088,'System','','','<i><b>bar</b> just entered the chat.</i><br>','2003-07-14 15:06:59',0,'');
INSERT INTO nuke_pnchat VALUES (1089,'System','bar','','<b>Welcome bar! Users in this room:</b>  <font color=#f00ba7>bar</font> ','2003-07-14 15:06:59',0,'');
INSERT INTO nuke_pnchat VALUES (1090,'System','','','<i><b>bar</b> just entered the chat.</i><br>','2003-07-14 15:08:53',0,'');
INSERT INTO nuke_pnchat VALUES (1091,'System','bar','','<b>Welcome bar! Users in this room:</b>  <font color=#f00ba7>bar</font> ','2003-07-14 15:08:53',0,'');
INSERT INTO nuke_pnchat VALUES (1092,'System','','','<b>bar dies</b>','2003-07-14 15:09:01',0,'');
INSERT INTO nuke_pnchat VALUES (1093,'System','','','<i><b>bar</b> changed the nickname to <b>\'nick\'</b></i><br>','2003-07-14 15:09:55',0,'');
INSERT INTO nuke_pnchat VALUES (1094,'nick','','fds','','2003-07-14 15:10:14',0,'#f00ba7');
INSERT INTO nuke_pnchat VALUES (1095,'System','','','<i><b>nick</b> changed the nickname to <b>\'Guest1\'</b></i><br>','2003-07-14 15:10:18',0,'');
INSERT INTO nuke_pnchat VALUES (1096,'System','Guest1','','<i>Unknown Command</i> /who','2003-07-14 15:10:26',0,'');
INSERT INTO nuke_pnchat VALUES (1097,'System','Guest1','','<BR><BR><FONT FACE=VERDANA,HELVETICA SIZE=1 COLOR=#000000><B>Users currently in this room:<br>----------------------------------<br><font color=#f00ba7> [Guest1]</font></B></FONT>','2003-07-14 15:10:39',0,'');
INSERT INTO nuke_pnchat VALUES (1098,'System','','','<i><b>Guest1</b> changed the nickname to <b>\'foobar\'</b></i><br>','2003-07-14 15:10:49',0,'');
INSERT INTO nuke_pnchat VALUES (1099,'System','','','<i><b>foobar</b> just entered the chat.</i><br>','2003-07-14 15:11:28',0,'');
INSERT INTO nuke_pnchat VALUES (1100,'System','foobar','','<b>Welcome foobar! Users in this room:</b>  <font color=#f00ba7>foobar</font> ','2003-07-14 15:11:28',0,'');
INSERT INTO nuke_pnchat VALUES (1101,'System','','','<i><b>foobar</b> just entered the chat.</i><br>','2003-07-14 15:11:39',0,'');
INSERT INTO nuke_pnchat VALUES (1102,'System','foobar','','<b>Welcome foobar! Users in this room:</b>  <font color=#f00ba7>foobar</font> ','2003-07-14 15:11:39',0,'');
INSERT INTO nuke_pnchat VALUES (1103,'foobar','','fae','','2003-07-14 15:12:57',0,'#f00ba7');
INSERT INTO nuke_pnchat VALUES (1104,'System','','','<i><b>foobar</b> just entered the chat.</i><br>','2003-07-14 15:13:01',0,'');
INSERT INTO nuke_pnchat VALUES (1105,'System','foobar','','<b>Welcome foobar! Users in this room:</b>  <font color=#f00ba7>foobar</font> ','2003-07-14 15:13:01',0,'');
INSERT INTO nuke_pnchat VALUES (1106,'System','','','<i><b>foobar</b> just entered the chat.</i><br>','2003-07-14 15:13:05',0,'');
INSERT INTO nuke_pnchat VALUES (1107,'System','foobar','','<b>Welcome foobar! Users in this room:</b>  <font color=#f00ba7>foobar</font> ','2003-07-14 15:13:05',0,'');
INSERT INTO nuke_pnchat VALUES (1108,'System','','','<i><b>foobar</b> just left the chat.</i><br>','2003-07-14 15:14:05',0,'');
INSERT INTO nuke_pnchat VALUES (1109,'System','','','<i><b>foobar</b> just left the chat.</i><br>','2003-07-14 15:14:05',0,'');
INSERT INTO nuke_pnchat VALUES (1110,'System','','','<i><b>foobar</b> just left the chat.</i><br>','2003-07-14 15:14:05',0,'');
INSERT INTO nuke_pnchat VALUES (1111,'System','','','<i><b>foobar</b> just left the chat.</i><br>','2003-07-14 15:14:05',0,'');
INSERT INTO nuke_pnchat VALUES (1112,'System','','','<i><b>foobar</b> just left the chat.</i><br>','2003-07-14 15:14:05',0,'');
INSERT INTO nuke_pnchat VALUES (1113,'System','','','<i><b>foobar</b> just left the chat.</i><br>','2003-07-14 15:14:05',0,'');
INSERT INTO nuke_pnchat VALUES (1114,'System','','','<i><b>foobar</b> just left the chat.</i><br>','2003-07-14 15:14:05',0,'');
INSERT INTO nuke_pnchat VALUES (1115,'System','','','<i><b>foobar</b> just left the chat.</i><br>','2003-07-14 15:14:05',0,'');
INSERT INTO nuke_pnchat VALUES (1116,'System','','','<i><b>foobar</b> just left the chat.</i><br>','2003-07-14 15:14:05',0,'');
INSERT INTO nuke_pnchat VALUES (1117,'System','','','<i><b>foobar</b> just entered the chat.</i><br>','2003-07-14 15:15:01',0,'');
INSERT INTO nuke_pnchat VALUES (1118,'System','foobar','','<b>Welcome foobar! Users in this room:</b> ','2003-07-14 15:15:01',0,'');
INSERT INTO nuke_pnchat VALUES (1119,'System','foobar','','Username Admin is used by a registered user. Please register to reserve your own nickname.<br>','2003-07-14 15:15:15',0,'');
INSERT INTO nuke_pnchat VALUES (1120,'foobar','','asdf','','2003-07-14 15:15:21',0,'#f00ba7');
INSERT INTO nuke_pnchat VALUES (1121,'System','','','<i><b>foobar</b> just left the chat.</i><br>','2003-07-14 15:15:25',0,'');
INSERT INTO nuke_pnchat VALUES (1122,'System','','','<i><b>foobar</b> just entered the chat.</i><br>','2003-07-14 15:15:34',0,'');
INSERT INTO nuke_pnchat VALUES (1123,'System','foobar','','<b>Welcome foobar! Users in this room:</b> ','2003-07-14 15:15:34',0,'');
INSERT INTO nuke_pnchat VALUES (1124,'foobar','','fewjewfi','','2003-07-14 15:16:16',0,'#f00ba7');
INSERT INTO nuke_pnchat VALUES (1125,'System','','','<i><b>foobar</b> changed the nickname to <b>\'bar\'</b></i><br>','2003-07-14 15:16:23',0,'');
INSERT INTO nuke_pnchat VALUES (1126,'System','','','<i><b>bar</b> just entered the chat.</i><br>','2003-07-14 15:35:53',0,'');
INSERT INTO nuke_pnchat VALUES (1127,'System','bar','','<b>Welcome bar! Users in this room:</b> ','2003-07-14 15:35:53',0,'');
INSERT INTO nuke_pnchat VALUES (1128,'System','bar','','<i>Current Session ID:</i>  8474263d0c8003f2bde239800612a228','2003-07-14 15:36:01',0,'');
INSERT INTO nuke_pnchat VALUES (1129,'bar','','adsfew','','2003-07-14 15:36:08',0,'#f00ba7');
INSERT INTO nuke_pnchat VALUES (1130,'System','','','<i><b>bar</b> changed the nickname to <b>\'nick\'</b></i><br>','2003-07-14 15:36:27',0,'');
INSERT INTO nuke_pnchat VALUES (1131,'System','','','<i><b>nick</b> just entered the chat.</i><br>','2003-07-14 15:41:31',0,'');
INSERT INTO nuke_pnchat VALUES (1132,'System','nick','','<b>Welcome nick! Users in this room:</b>  <font color=#f00ba7>nick</font> ','2003-07-14 15:41:31',0,'');
INSERT INTO nuke_pnchat VALUES (1133,'nick','','','','2003-07-14 15:41:43',0,'#f00ba7');
INSERT INTO nuke_pnchat VALUES (1134,'nick','','','','2003-07-14 15:41:47',0,'#f00ba7');
INSERT INTO nuke_pnchat VALUES (1135,'nick','','','','2003-07-14 15:41:51',0,'#f00ba7');
INSERT INTO nuke_pnchat VALUES (1136,'System','','','<i><b>nick</b> just entered the chat.</i><br>','2003-07-14 15:43:22',0,'');
INSERT INTO nuke_pnchat VALUES (1137,'System','nick','','<b>Welcome nick! Users in this room:</b>  <font color=#f00ba7>nick</font> ','2003-07-14 15:43:22',0,'');
INSERT INTO nuke_pnchat VALUES (1138,'nick','','safew','','2003-07-14 15:43:25',0,'#f00ba7');
INSERT INTO nuke_pnchat VALUES (1139,'System','nick','','Username Admin is used by a registered user. Please register to reserve your own nickname.<br>','2003-07-14 15:43:30',0,'');
INSERT INTO nuke_pnchat VALUES (1140,'System','','','<i><b>nick</b> has changed <font color=#f00f00>color</font></i><br>','2003-07-14 15:44:05',0,'');
INSERT INTO nuke_pnchat VALUES (1141,'System','nick','','<i><b>ONLY</b> registered users may create rooms!</i><br>','2003-07-14 15:44:27',0,'');
INSERT INTO nuke_pnchat VALUES (1142,'System','','','<i><b>nick</b> just left the chat.</i><br>','2003-07-14 15:44:39',0,'');
INSERT INTO nuke_pnchat VALUES (1143,'System','','','<i><b>nick</b> just entered the chat.</i><br>','2003-07-14 15:44:44',0,'');
INSERT INTO nuke_pnchat VALUES (1144,'System','nick','','<b>Welcome nick! Users in this room:</b> ','2003-07-14 15:44:44',0,'');
INSERT INTO nuke_pnchat VALUES (1145,'System','','','<i><b>nick</b> changed the nickname to <b>\'raboof\'</b></i><br>','2003-07-14 15:44:50',0,'');
INSERT INTO nuke_pnchat VALUES (1146,'raboof','','askdfj','','2003-07-14 15:44:54',0,'#f00f00');
INSERT INTO nuke_pnchat VALUES (1147,'raboof','','','','2003-07-14 15:44:56',0,'#f00f00');
INSERT INTO nuke_pnchat VALUES (1148,'raboof','','','','2003-07-14 15:44:57',0,'#f00f00');
INSERT INTO nuke_pnchat VALUES (1149,'System','','','<i><b>raboof</b> just entered the chat.</i><br>','2003-07-14 15:45:26',0,'');
INSERT INTO nuke_pnchat VALUES (1150,'System','raboof','','<b>Welcome raboof! Users in this room:</b> ','2003-07-14 15:45:26',0,'');
INSERT INTO nuke_pnchat VALUES (1151,'raboof','','jwfef','','2003-07-14 15:45:30',0,'#f00f00');
INSERT INTO nuke_pnchat VALUES (1152,'System','raboof','','Username Admin is used by a registered user. Please register to reserve your own nickname.<br>','2003-07-14 15:45:48',0,'');
INSERT INTO nuke_pnchat VALUES (1153,'System','','','<i><b>raboof</b> just entered the chat.</i><br>','2003-07-14 15:45:54',0,'');
INSERT INTO nuke_pnchat VALUES (1154,'System','raboof','','<b>Welcome raboof! Users in this room:</b> ','2003-07-14 15:45:54',0,'');
INSERT INTO nuke_pnchat VALUES (1155,'System','','','<i><b>raboof</b> just entered the chat.</i><br>','2003-07-14 15:46:55',0,'');
INSERT INTO nuke_pnchat VALUES (1156,'System','raboof','','<b>Welcome raboof! Users in this room:</b> ','2003-07-14 15:46:55',0,'');
INSERT INTO nuke_pnchat VALUES (1157,'raboof','','fweh','','2003-07-14 15:47:00',0,'#f00f00');
INSERT INTO nuke_pnchat VALUES (1158,'System','','','<i><b>raboof</b> just entered the chat.</i><br>','2003-07-14 15:47:05',0,'');
INSERT INTO nuke_pnchat VALUES (1159,'System','raboof','','<b>Welcome raboof! Users in this room:</b> ','2003-07-14 15:47:05',0,'');
INSERT INTO nuke_pnchat VALUES (1160,'System','','','<i><b>raboof</b> changed the nickname to <b>\'foobar\'</b></i><br>','2003-07-14 15:47:13',0,'');
INSERT INTO nuke_pnchat VALUES (1161,'System','','','<i><b>foobar</b> just entered the chat.</i><br>','2003-07-14 15:47:19',0,'');
INSERT INTO nuke_pnchat VALUES (1162,'System','foobar','','<b>Welcome foobar! Users in this room:</b> ','2003-07-14 15:47:19',0,'');
INSERT INTO nuke_pnchat VALUES (1163,'System','','','<i><b>foobar</b> just entered the chat.</i><br>','2003-07-14 15:51:37',0,'');
INSERT INTO nuke_pnchat VALUES (1164,'System','foobar','','<b>Welcome foobar! Users in this room:</b> ','2003-07-14 15:51:37',0,'');
INSERT INTO nuke_pnchat VALUES (1165,'foobar','','','','2003-07-14 15:51:42',0,'#f00f00');
INSERT INTO nuke_pnchat VALUES (1166,'foobar','','','','2003-07-14 15:51:44',0,'#f00f00');
INSERT INTO nuke_pnchat VALUES (1167,'foobar','','','','2003-07-14 15:51:49',0,'#f00f00');
INSERT INTO nuke_pnchat VALUES (1168,'System','','','<i><b>foobar</b> just entered the chat.</i><br>','2003-07-14 15:51:56',0,'');
INSERT INTO nuke_pnchat VALUES (1169,'System','foobar','','<b>Welcome foobar! Users in this room:</b> ','2003-07-14 15:51:56',0,'');
INSERT INTO nuke_pnchat VALUES (1170,'foobar','','','','2003-07-14 15:52:08',0,'#f00f00');
INSERT INTO nuke_pnchat VALUES (1171,'System','','','<i><b>foobar</b> just entered the chat.</i><br>','2003-07-14 15:52:13',0,'');
INSERT INTO nuke_pnchat VALUES (1172,'System','foobar','','<b>Welcome foobar! Users in this room:</b> ','2003-07-14 15:52:13',0,'');
INSERT INTO nuke_pnchat VALUES (1173,'System','','','<i><b>foobar</b> just entered the chat.</i><br>','2003-07-14 15:52:35',0,'');
INSERT INTO nuke_pnchat VALUES (1174,'System','foobar','','<b>Welcome foobar! Users in this room:</b> ','2003-07-14 15:52:35',0,'');
INSERT INTO nuke_pnchat VALUES (1175,'foobar','','','','2003-07-14 15:52:42',0,'#f00f00');
INSERT INTO nuke_pnchat VALUES (1176,'foobar','','','','2003-07-14 15:52:49',0,'#f00f00');
INSERT INTO nuke_pnchat VALUES (1177,'System','','','<i><b>foobar</b> just entered the chat.</i><br>','2003-07-14 15:52:52',0,'');
INSERT INTO nuke_pnchat VALUES (1178,'System','foobar','','<b>Welcome foobar! Users in this room:</b> ','2003-07-14 15:52:52',0,'');
INSERT INTO nuke_pnchat VALUES (1179,'System','','','<i><b>foobar</b> just entered the chat.</i><br>','2003-07-14 15:53:40',0,'');
INSERT INTO nuke_pnchat VALUES (1180,'System','foobar','','<b>Welcome foobar! Users in this room:</b> ','2003-07-14 15:53:40',0,'');
INSERT INTO nuke_pnchat VALUES (1181,'System','','','<i><b>foobar</b> changed the nickname to <b>\'raboof\'</b></i><br>','2003-07-14 15:53:45',0,'');
INSERT INTO nuke_pnchat VALUES (1182,'System','','','<i><b>raboof</b> just entered the chat.</i><br>','2003-07-14 15:54:14',0,'');
INSERT INTO nuke_pnchat VALUES (1183,'System','raboof','','<b>Welcome raboof! Users in this room:</b> ','2003-07-14 15:54:14',0,'');
INSERT INTO nuke_pnchat VALUES (1184,'System','raboof','','Username Admin is used by a registered user. Please register to reserve your own nickname.<br>','2003-07-14 15:54:23',0,'');
INSERT INTO nuke_pnchat VALUES (1185,'System','','','<i><b>raboof</b> just entered the chat.</i><br>','2003-07-14 15:54:28',0,'');
INSERT INTO nuke_pnchat VALUES (1186,'System','raboof','','<b>Welcome raboof! Users in this room:</b> ','2003-07-14 15:54:28',0,'');
INSERT INTO nuke_pnchat VALUES (1187,'raboof','','afe','','2003-07-14 15:55:02',0,'#f00f00');
INSERT INTO nuke_pnchat VALUES (1188,'System','','','<i><b>raboof</b> just entered the chat.</i><br>','2003-07-14 15:55:06',0,'');
INSERT INTO nuke_pnchat VALUES (1189,'System','raboof','','<b>Welcome raboof! Users in this room:</b> ','2003-07-14 15:55:06',0,'');
INSERT INTO nuke_pnchat VALUES (1190,'System','','','<i><b>raboof</b> has changed <font color=#0000ff>color</font></i><br>','2003-07-14 15:55:15',0,'');
INSERT INTO nuke_pnchat VALUES (1191,'System','','','<i><b>raboof</b> just entered the chat.</i><br>','2003-07-14 15:55:19',0,'');
INSERT INTO nuke_pnchat VALUES (1192,'System','raboof','','<b>Welcome raboof! Users in this room:</b> ','2003-07-14 15:55:19',0,'');
INSERT INTO nuke_pnchat VALUES (1193,'System','','','<i><b>raboof</b> just entered the chat.</i><br>','2003-07-14 15:55:27',0,'');
INSERT INTO nuke_pnchat VALUES (1194,'System','raboof','','<b>Welcome raboof! Users in this room:</b> ','2003-07-14 15:55:27',0,'');
INSERT INTO nuke_pnchat VALUES (1195,'System','','','<i><b>raboof</b> just entered the chat.</i><br>','2003-07-14 15:57:31',0,'');
INSERT INTO nuke_pnchat VALUES (1196,'System','raboof','','<b>Welcome raboof! Users in this room:</b> ','2003-07-14 15:57:31',0,'');
INSERT INTO nuke_pnchat VALUES (1197,'raboof','','jiew','','2003-07-14 15:57:35',0,'#0000ff');
INSERT INTO nuke_pnchat VALUES (1198,'raboof','','ifje','','2003-07-14 15:57:36',0,'#0000ff');
INSERT INTO nuke_pnchat VALUES (1199,'System','','','<i><b>raboof</b> just entered the chat.</i><br>','2003-07-14 16:00:43',0,'');
INSERT INTO nuke_pnchat VALUES (1200,'System','raboof','','<b>Welcome raboof! Users in this room:</b> ','2003-07-14 16:00:43',0,'');
INSERT INTO nuke_pnchat VALUES (1201,'raboof','','asdfe','','2003-07-14 16:00:47',0,'#0000ff');
INSERT INTO nuke_pnchat VALUES (1202,'System','','','<i><b>raboof</b> just entered the chat.</i><br>','2003-07-14 16:00:52',0,'');
INSERT INTO nuke_pnchat VALUES (1203,'System','raboof','','<b>Welcome raboof! Users in this room:</b> ','2003-07-14 16:00:52',0,'');
INSERT INTO nuke_pnchat VALUES (1204,'raboof','','fewfwe','','2003-07-14 16:08:48',0,'#0000ff');
INSERT INTO nuke_pnchat VALUES (1205,'raboof','','','','2003-07-14 16:08:49',0,'#0000ff');
INSERT INTO nuke_pnchat VALUES (1206,'raboof','','fj','','2003-07-14 16:08:50',0,'#0000ff');
INSERT INTO nuke_pnchat VALUES (1207,'raboof','','fwe','','2003-07-14 16:10:11',0,'#0000ff');
INSERT INTO nuke_pnchat VALUES (1208,'System','','','<i><b>raboof</b> just entered the chat.</i><br>','2003-07-14 16:10:15',0,'');
INSERT INTO nuke_pnchat VALUES (1209,'System','raboof','','<b>Welcome raboof! Users in this room:</b> ','2003-07-14 16:10:15',0,'');
INSERT INTO nuke_pnchat VALUES (1210,'raboof','','jiwefl','','2003-07-14 16:10:19',0,'#0000ff');
INSERT INTO nuke_pnchat VALUES (1211,'raboof','','itigrt','','2003-07-14 16:10:20',0,'#0000ff');
INSERT INTO nuke_pnchat VALUES (1212,'raboof','','ieje','','2003-07-14 16:10:21',0,'#0000ff');
INSERT INTO nuke_pnchat VALUES (1213,'System','raboof','','Username Admin is used by a registered user. Please register to reserve your own nickname.<br>','2003-07-14 16:10:25',0,'');
INSERT INTO nuke_pnchat VALUES (1214,'raboof','','jie','','2003-07-14 16:10:28',0,'#0000ff');
INSERT INTO nuke_pnchat VALUES (1215,'raboof','','iego4e','','2003-07-14 16:10:30',0,'#0000ff');
INSERT INTO nuke_pnchat VALUES (1216,'raboof','','jire','','2003-07-14 16:10:31',0,'#0000ff');
INSERT INTO nuke_pnchat VALUES (1217,'raboof','','hfweu','','2003-07-14 16:10:40',0,'#0000ff');
INSERT INTO nuke_pnchat VALUES (1218,'System','','','<i><b>raboof</b> just entered the chat.</i><br>','2003-07-14 16:11:43',0,'');
INSERT INTO nuke_pnchat VALUES (1219,'System','raboof','','<b>Welcome raboof! Users in this room:</b> ','2003-07-14 16:11:43',0,'');
INSERT INTO nuke_pnchat VALUES (1220,'raboof','','fwefewf','','2003-07-14 16:11:45',0,'#0000ff');
INSERT INTO nuke_pnchat VALUES (1221,'raboof','','jie','','2003-07-14 16:11:47',0,'#0000ff');
INSERT INTO nuke_pnchat VALUES (1222,'System','','','<i><b>raboof</b> just entered the chat.</i><br>','2003-07-14 16:12:19',0,'');
INSERT INTO nuke_pnchat VALUES (1223,'System','raboof','','<b>Welcome raboof! Users in this room:</b> ','2003-07-14 16:12:19',0,'');
INSERT INTO nuke_pnchat VALUES (1224,'raboof','','wef','','2003-07-14 16:12:22',0,'#0000ff');
INSERT INTO nuke_pnchat VALUES (1225,'System','','','<i><b>raboof</b> just entered the chat.</i><br>','2003-07-14 16:12:28',0,'');
INSERT INTO nuke_pnchat VALUES (1226,'System','raboof','','<b>Welcome raboof! Users in this room:</b> ','2003-07-14 16:12:28',0,'');
INSERT INTO nuke_pnchat VALUES (1227,'raboof','','trhrth','','2003-07-14 16:12:34',0,'#0000ff');
INSERT INTO nuke_pnchat VALUES (1228,'System','','','<i><b>raboof</b> just entered the chat.</i><br>','2003-07-14 16:12:37',0,'');
INSERT INTO nuke_pnchat VALUES (1229,'System','raboof','','<b>Welcome raboof! Users in this room:</b> ','2003-07-14 16:12:37',0,'');
INSERT INTO nuke_pnchat VALUES (1230,'System','','','<b>raboof (b)</b>','2003-07-14 16:14:54',0,'');
INSERT INTO nuke_pnchat VALUES (1231,'System','','','<i><b>raboof</b> just entered the chat.</i><br>','2003-07-14 16:14:59',0,'');
INSERT INTO nuke_pnchat VALUES (1232,'System','raboof','','<b>Welcome raboof! Users in this room:</b> ','2003-07-14 16:14:59',0,'');
INSERT INTO nuke_pnchat VALUES (1233,'System','','','<i><b>raboof</b> just entered the chat.</i><br>','2003-07-14 16:17:45',0,'');
INSERT INTO nuke_pnchat VALUES (1234,'System','raboof','','<b>Welcome raboof! Users in this room:</b> ','2003-07-14 16:17:45',0,'');
INSERT INTO nuke_pnchat VALUES (1235,'raboof','','kjfewiwefj','','2003-07-14 16:17:55',0,'#0000ff');
INSERT INTO nuke_pnchat VALUES (1236,'System','','','<i><b>raboof</b> changed the nickname to <b>\'money\'</b></i><br>','2003-07-14 16:18:02',0,'');
INSERT INTO nuke_pnchat VALUES (1237,'System','','','<i><b>money</b> just entered the chat.</i><br>','2003-07-14 16:18:12',0,'');
INSERT INTO nuke_pnchat VALUES (1238,'System','money','','<b>Welcome money! Users in this room:</b> ','2003-07-14 16:18:13',0,'');
INSERT INTO nuke_pnchat VALUES (1239,'money','','(b)(c)','','2003-07-14 16:19:44',0,'#0000ff');
INSERT INTO nuke_pnchat VALUES (1240,'System','','','<i><b>money</b> just entered the chat.</i><br>','2003-07-14 16:19:49',0,'');
INSERT INTO nuke_pnchat VALUES (1241,'System','money','','<b>Welcome money! Users in this room:</b> ','2003-07-14 16:19:49',0,'');
INSERT INTO nuke_pnchat VALUES (1242,'System','','','<i><b>money</b> just entered the chat.</i><br>','2003-07-14 16:20:46',0,'');
INSERT INTO nuke_pnchat VALUES (1243,'System','money','','<b>Welcome money! Users in this room:</b> ','2003-07-14 16:20:46',0,'');
INSERT INTO nuke_pnchat VALUES (1244,'System','','','<i><b>money</b> just entered the chat.</i><br>','2003-07-14 16:22:12',0,'');
INSERT INTO nuke_pnchat VALUES (1245,'System','money','','<b>Welcome money! Users in this room:</b>  <font color=#0000ff>money</font> ','2003-07-14 16:22:12',0,'');
INSERT INTO nuke_pnchat VALUES (1246,'money','','hi there','','2003-07-14 16:22:16',0,'#0000ff');
INSERT INTO nuke_pnchat VALUES (1247,'money','','fjewif','','2003-07-14 16:22:29',0,'#0000ff');
INSERT INTO nuke_pnchat VALUES (1248,'System','','','<i><b>money</b> just entered the chat.</i><br>','2003-07-14 16:22:34',0,'');
INSERT INTO nuke_pnchat VALUES (1249,'System','money','','<b>Welcome money! Users in this room:</b>  <font color=#0000ff>money</font> ','2003-07-14 16:22:34',0,'');
INSERT INTO nuke_pnchat VALUES (1250,'money','','ewffewj','','2003-07-14 16:22:38',0,'#0000ff');
INSERT INTO nuke_pnchat VALUES (1251,'money','','kdjfei','','2003-07-14 16:22:40',0,'#0000ff');
INSERT INTO nuke_pnchat VALUES (1252,'System','','','<i><b>money</b> changed the nickname to <b>\'raboof\'</b></i><br>','2003-07-14 16:22:48',0,'');
INSERT INTO nuke_pnchat VALUES (1253,'raboof','','I am alive','','2003-07-14 16:22:52',0,'#0000ff');
INSERT INTO nuke_pnchat VALUES (1254,'raboof','','NOT','','2003-07-14 16:22:56',0,'#0000ff');
INSERT INTO nuke_pnchat VALUES (1255,'raboof','','MONEEE','','2003-07-14 16:23:10',0,'#0000ff');
INSERT INTO nuke_pnchat VALUES (1256,'System','','','<i><b>raboof</b> just entered the chat.</i><br>','2003-07-14 16:23:15',0,'');
INSERT INTO nuke_pnchat VALUES (1257,'System','raboof','','<b>Welcome raboof! Users in this room:</b>  <font color=#0000ff>raboof</font> ','2003-07-14 16:23:15',0,'');
INSERT INTO nuke_pnchat VALUES (1258,'raboof','','I am not a llama','','2003-07-14 16:23:20',0,'#0000ff');
INSERT INTO nuke_pnchat VALUES (1259,'raboof','','I kill bugs.','','2003-07-14 16:23:54',0,'#0000ff');
INSERT INTO nuke_pnchat VALUES (1260,'raboof','','I am here.','','2003-07-14 16:24:29',0,'#0000ff');
INSERT INTO nuke_pnchat VALUES (1261,'System','','','<i><b>raboof</b> has changed <font color=#f00f00>color</font></i><br>','2003-07-14 16:24:39',0,'');
INSERT INTO nuke_pnchat VALUES (1262,'raboof','','adsf','','2003-07-14 16:24:41',0,'#f00f00');
INSERT INTO nuke_pnchat VALUES (1263,'System','','','<i><b>raboof</b> just entered the chat.</i><br>','2003-07-14 16:25:48',0,'');
INSERT INTO nuke_pnchat VALUES (1264,'System','raboof','','<b>Welcome raboof! Users in this room:</b>  <font color=#f00f00>raboof</font> ','2003-07-14 16:25:48',0,'');
INSERT INTO nuke_pnchat VALUES (1265,'raboof','','fewef','','2003-07-14 16:26:09',0,'#f00f00');
INSERT INTO nuke_pnchat VALUES (1266,'System','','','<i><b>raboof</b> just entered the chat.</i><br>','2003-07-14 16:27:16',0,'');
INSERT INTO nuke_pnchat VALUES (1267,'System','raboof','','<b>Welcome raboof! Users in this room:</b>  <font color=#f00f00>raboof</font> ','2003-07-14 16:27:16',0,'');
INSERT INTO nuke_pnchat VALUES (1268,'System','','','<i><b>raboof</b> just entered the chat.</i><br>','2003-07-14 16:27:47',0,'');
INSERT INTO nuke_pnchat VALUES (1269,'System','raboof','','<b>Welcome raboof! Users in this room:</b>  <font color=#f00f00>raboof</font> ','2003-07-14 16:27:47',0,'');
INSERT INTO nuke_pnchat VALUES (1270,'System','','','<i><b>raboof</b> just entered the chat.</i><br>','2003-07-14 16:28:54',0,'');
INSERT INTO nuke_pnchat VALUES (1271,'System','raboof','','<b>Welcome raboof! Users in this room:</b>  <font color=#f00f00>raboof</font> ','2003-07-14 16:28:54',0,'');
INSERT INTO nuke_pnchat VALUES (1272,'System','','','<i><b>raboof</b> just left the chat.</i><br>','2003-07-14 16:30:50',0,'');
INSERT INTO nuke_pnchat VALUES (1273,'System','','','<i><b>raboof</b> just left the chat.</i><br>','2003-07-14 16:30:50',0,'');
INSERT INTO nuke_pnchat VALUES (1274,'System','','','<i><b>raboof</b> just left the chat.</i><br>','2003-07-14 16:30:50',0,'');
INSERT INTO nuke_pnchat VALUES (1275,'System','','','<i><b>raboof</b> just left the chat.</i><br>','2003-07-14 16:30:50',0,'');
INSERT INTO nuke_pnchat VALUES (1276,'System','','','<i><b>raboof</b> just left the chat.</i><br>','2003-07-14 16:30:50',0,'');
INSERT INTO nuke_pnchat VALUES (1277,'System','','','<i><b>raboof</b> just left the chat.</i><br>','2003-07-14 16:30:50',0,'');
INSERT INTO nuke_pnchat VALUES (1278,'System','','','<i><b>raboof</b> just left the chat.</i><br>','2003-07-14 16:30:50',0,'');
INSERT INTO nuke_pnchat VALUES (1279,'System','','','<i><b>raboof</b> just left the chat.</i><br>','2003-07-14 16:30:50',0,'');
INSERT INTO nuke_pnchat VALUES (1280,'System','','','<i><b>raboof</b> just entered the chat.</i><br>','2003-07-14 16:32:04',0,'');
INSERT INTO nuke_pnchat VALUES (1281,'System','raboof','','<b>Welcome raboof! Users in this room:</b> ','2003-07-14 16:32:04',0,'');
INSERT INTO nuke_pnchat VALUES (1282,'System','','','<i><b>raboof</b> just entered the chat.</i><br>','2003-07-14 16:32:31',0,'');
INSERT INTO nuke_pnchat VALUES (1283,'System','raboof','','<b>Welcome raboof! Users in this room:</b> ','2003-07-14 16:32:31',0,'');
INSERT INTO nuke_pnchat VALUES (1284,'System','','','<i><b>raboof</b> just entered the chat.</i><br>','2003-07-14 16:32:53',0,'');
INSERT INTO nuke_pnchat VALUES (1285,'System','raboof','','<b>Welcome raboof! Users in this room:</b> ','2003-07-14 16:32:53',0,'');
INSERT INTO nuke_pnchat VALUES (1286,'raboof','','wf','','2003-07-14 16:33:00',0,'#f00f00');
INSERT INTO nuke_pnchat VALUES (1287,'System','','','<i><b>raboof</b> changed the nickname to <b>\'foobar\'</b></i><br>','2003-07-14 16:33:08',0,'');
INSERT INTO nuke_pnchat VALUES (1288,'System','','','<i><b>foobar</b> just entered the chat.</i><br>','2003-07-14 16:33:16',0,'');
INSERT INTO nuke_pnchat VALUES (1289,'System','foobar','','<b>Welcome foobar! Users in this room:</b> ','2003-07-14 16:33:16',0,'');
INSERT INTO nuke_pnchat VALUES (1290,'System','','','<i><b>foobar</b> just entered the chat.</i><br>','2003-07-14 16:33:21',0,'');
INSERT INTO nuke_pnchat VALUES (1291,'System','foobar','','<b>Welcome foobar! Users in this room:</b> ','2003-07-14 16:33:21',0,'');
INSERT INTO nuke_pnchat VALUES (1292,'foobar','','I am not here','','2003-07-14 16:33:26',0,'#f00f00');
INSERT INTO nuke_pnchat VALUES (1293,'foobar','','dsfe','','2003-07-14 16:35:12',0,'#f00f00');
INSERT INTO nuke_pnchat VALUES (1294,'System','','','<i><b>foobar</b> just entered the chat.</i><br>','2003-07-14 16:35:17',0,'');
INSERT INTO nuke_pnchat VALUES (1295,'System','foobar','','<b>Welcome foobar! Users in this room:</b> ','2003-07-14 16:35:17',0,'');
INSERT INTO nuke_pnchat VALUES (1296,'foobar','','asdfj','','2003-07-14 16:35:20',0,'#f00f00');
INSERT INTO nuke_pnchat VALUES (1297,'foobar','','iewf','','2003-07-14 16:35:21',0,'#f00f00');
INSERT INTO nuke_pnchat VALUES (1298,'System','','','<i><b>foobar</b> just entered the chat.</i><br>','2003-07-14 16:36:02',0,'');
INSERT INTO nuke_pnchat VALUES (1299,'System','foobar','','<b>Welcome foobar! Users in this room:</b>  <font color=#f00f00>foobar</font> ','2003-07-14 16:36:02',0,'');
INSERT INTO nuke_pnchat VALUES (1300,'foobar','','fwe','','2003-07-14 16:36:04',0,'#f00f00');
INSERT INTO nuke_pnchat VALUES (1301,'foobar','','I am not here','','2003-07-14 16:36:08',0,'#f00f00');
INSERT INTO nuke_pnchat VALUES (1302,'System','','','<i><b>foobar</b> just entered the chat.</i><br>','2003-07-14 16:36:21',0,'');
INSERT INTO nuke_pnchat VALUES (1303,'System','foobar','','<b>Welcome foobar! Users in this room:</b>  <font color=#f00f00>foobar</font> ','2003-07-14 16:36:21',0,'');
INSERT INTO nuke_pnchat VALUES (1304,'foobar','','I am not here','','2003-07-14 16:36:25',0,'#f00f00');
INSERT INTO nuke_pnchat VALUES (1305,'foobar','','I am not here','','2003-07-14 16:36:35',0,'#f00f00');
INSERT INTO nuke_pnchat VALUES (1306,'System','','','<i><b>foobar</b> just entered the chat.</i><br>','2003-07-14 16:36:40',0,'');
INSERT INTO nuke_pnchat VALUES (1307,'System','foobar','','<b>Welcome foobar! Users in this room:</b>  <font color=#f00f00>foobar</font> ','2003-07-14 16:36:40',0,'');
INSERT INTO nuke_pnchat VALUES (1308,'foobar','','I am not here','','2003-07-14 16:36:44',0,'#f00f00');
INSERT INTO nuke_pnchat VALUES (1309,'foobar','','asdkf','','2003-07-14 16:36:47',0,'#f00f00');
INSERT INTO nuke_pnchat VALUES (1310,'foobar','','ife','','2003-07-14 16:36:48',0,'#f00f00');
INSERT INTO nuke_pnchat VALUES (1311,'System','','','<i><b>foobar</b> just entered the chat.</i><br>','2003-07-14 16:37:38',0,'');
INSERT INTO nuke_pnchat VALUES (1312,'System','foobar','','<b>Welcome foobar! Users in this room:</b>  <font color=#f00f00>foobar</font> ','2003-07-14 16:37:38',0,'');
INSERT INTO nuke_pnchat VALUES (1313,'foobar','','adsfe','','2003-07-14 16:37:42',0,'#f00f00');
INSERT INTO nuke_pnchat VALUES (1314,'foobar','','I am here','','2003-07-14 16:37:45',0,'#f00f00');
INSERT INTO nuke_pnchat VALUES (1315,'System','','','<i><b>foobar</b> just entered the chat.</i><br>','2003-07-14 16:38:49',0,'');
INSERT INTO nuke_pnchat VALUES (1316,'System','foobar','','<b>Welcome foobar! Users in this room:</b>  <font color=#f00f00>foobar</font> ','2003-07-14 16:38:49',0,'');
INSERT INTO nuke_pnchat VALUES (1317,'foobar','','I am here','','2003-07-14 16:38:52',0,'#f00f00');
INSERT INTO nuke_pnchat VALUES (1318,'System','','','<i><b>foobar</b> changed the nickname to <b>\'blahhh\'</b></i><br>','2003-07-14 16:38:59',0,'');
INSERT INTO nuke_pnchat VALUES (1319,'blahhh','','I am not here','','2003-07-14 16:39:04',0,'#f00f00');
INSERT INTO nuke_pnchat VALUES (1320,'System','','','<i><b>blahhh</b> just entered the chat.</i><br>','2003-07-14 16:40:34',0,'');
INSERT INTO nuke_pnchat VALUES (1321,'System','blahhh','','<b>Welcome blahhh! Users in this room:</b>  <font color=#f00f00>blahhh</font> ','2003-07-14 16:40:34',0,'');
INSERT INTO nuke_pnchat VALUES (1322,'System','blahhh','','<i>Current Session ID:</i>  e5eb590b4e24d589d36e76de9fcdf958','2003-07-14 16:40:51',0,'');
INSERT INTO nuke_pnchat VALUES (1323,'blahhh','','I am not here','','2003-07-14 16:41:22',0,'#f00f00');
INSERT INTO nuke_pnchat VALUES (1324,'System','','','<i><b>blahhh</b> has changed <font color=#00ff00>color</font></i><br>','2003-07-14 16:41:31',0,'');
INSERT INTO nuke_pnchat VALUES (1325,'blahhh','','dsf','','2003-07-14 16:41:33',0,'#00ff00');
INSERT INTO nuke_pnchat VALUES (1326,'blahhh','','I am not here','','2003-07-14 16:42:03',0,'#00ff00');
INSERT INTO nuke_pnchat VALUES (1327,'System','','','<i><b>blahhh</b> has changed <font color=#ff0000>color</font></i><br>','2003-07-14 16:42:12',0,'');
INSERT INTO nuke_pnchat VALUES (1328,'System','blahhh','','Your table prefix is nuke_','2003-07-14 16:45:09',0,'');
INSERT INTO nuke_pnchat VALUES (1329,'System','','','<i><b>blahhh</b> just left the chat.</i><br>','2003-07-14 16:48:35',0,'');
INSERT INTO nuke_pnchat VALUES (1330,'System','','','<i><b>blahhh</b> just left the chat.</i><br>','2003-07-14 16:48:35',0,'');
INSERT INTO nuke_pnchat VALUES (1331,'System','','','<i><b>blahhh</b> just left the chat.</i><br>','2003-07-14 16:48:35',0,'');
INSERT INTO nuke_pnchat VALUES (1332,'System','','','<i><b></b> just entered the chat.</i><br>','2003-07-14 17:26:36',0,'');
INSERT INTO nuke_pnchat VALUES (1333,'System','','','<b>Welcome ! Users in this room:</b> ','2003-07-14 17:26:36',0,'');
INSERT INTO nuke_pnchat VALUES (1334,'System','','','Username nukeman is used by a registered user. Please register to reserve your own nickname.<br>','2003-07-14 17:26:44',0,'');
INSERT INTO nuke_pnchat VALUES (1335,'System','','','<i><b></b> just entered the chat.</i><br>','2003-07-14 17:26:51',0,'');
INSERT INTO nuke_pnchat VALUES (1336,'System','','','<b>Welcome ! Users in this room:</b> ','2003-07-14 17:26:51',0,'');
INSERT INTO nuke_pnchat VALUES (1337,'System','','','<i><b></b> just entered the chat.</i><br>','2003-07-14 17:27:16',0,'');
INSERT INTO nuke_pnchat VALUES (1338,'System','','','<b>Welcome ! Users in this room:</b> ','2003-07-14 17:27:16',0,'');
INSERT INTO nuke_pnchat VALUES (1339,'System','','','<i><b></b> just entered the chat.</i><br>','2003-07-14 17:27:20',0,'');
INSERT INTO nuke_pnchat VALUES (1340,'System','','','<b>Welcome ! Users in this room:</b> ','2003-07-14 17:27:20',0,'');
INSERT INTO nuke_pnchat VALUES (1341,'System','','','<i><b></b> just entered the chat.</i><br>','2003-07-14 17:29:44',0,'');
INSERT INTO nuke_pnchat VALUES (1342,'System','','','<b>Welcome ! Users in this room:</b> ','2003-07-14 17:29:44',0,'');
INSERT INTO nuke_pnchat VALUES (1343,'System','','','<i><b></b> just entered the chat.</i><br>','2003-07-14 17:32:09',0,'');
INSERT INTO nuke_pnchat VALUES (1344,'System','','','<b>Welcome ! Users in this room:</b> ','2003-07-14 17:32:09',0,'');
INSERT INTO nuke_pnchat VALUES (1345,'System','','','<i><b></b> just entered the chat.</i><br>','2003-07-14 17:33:10',0,'');
INSERT INTO nuke_pnchat VALUES (1346,'System','','','<b>Welcome ! Users in this room:</b> ','2003-07-14 17:33:10',0,'');
INSERT INTO nuke_pnchat VALUES (1347,'System','','','<i><b></b> just entered the chat.</i><br>','2003-07-14 17:34:49',0,'');
INSERT INTO nuke_pnchat VALUES (1348,'System','','','<b>Welcome ! Users in this room:</b> ','2003-07-14 17:34:49',0,'');
INSERT INTO nuke_pnchat VALUES (1349,'System','','','<i><b></b> just entered the chat.</i><br>','2003-07-14 17:35:18',0,'');
INSERT INTO nuke_pnchat VALUES (1350,'System','','','<b>Welcome ! Users in this room:</b> ','2003-07-14 17:35:18',0,'');
INSERT INTO nuke_pnchat VALUES (1351,'System','','','<i><b></b> just entered the chat.</i><br>','2003-07-14 17:36:04',0,'');
INSERT INTO nuke_pnchat VALUES (1352,'System','','','<b>Welcome ! Users in this room:</b> ','2003-07-14 17:36:04',0,'');
INSERT INTO nuke_pnchat VALUES (1353,'System','','','<i><b></b> changed the nickname to <b>\'boo\'</b></i><br>','2003-07-14 17:36:11',0,'');
INSERT INTO nuke_pnchat VALUES (1354,'System','','','<i><b></b> just entered the chat.</i><br>','2003-07-14 17:36:16',0,'');
INSERT INTO nuke_pnchat VALUES (1355,'System','','','<b>Welcome ! Users in this room:</b> ','2003-07-14 17:36:16',0,'');
INSERT INTO nuke_pnchat VALUES (1356,'System','','','<i><b></b> just entered the chat.</i><br>','2003-07-14 17:38:33',0,'');
INSERT INTO nuke_pnchat VALUES (1357,'System','','','<b>Welcome ! Users in this room:</b> ','2003-07-14 17:38:33',0,'');
INSERT INTO nuke_pnchat VALUES (1358,'','','Hi there','','2003-07-14 17:38:44',0,'');
INSERT INTO nuke_pnchat VALUES (1359,'System','','','<i><b></b> just entered the chat.</i><br>','2003-07-14 17:38:48',0,'');
INSERT INTO nuke_pnchat VALUES (1360,'System','','','<b>Welcome ! Users in this room:</b> ','2003-07-14 17:38:48',0,'');
INSERT INTO nuke_pnchat VALUES (1361,'System','','','<i><b>nukeman</b> just left the chat.</i><br>','2003-07-14 17:39:13',1,'');
INSERT INTO nuke_pnchat VALUES (1362,'System','','','<i><b>nukeman</b> just left the chat.</i><br>','2003-07-14 17:39:13',1,'');
INSERT INTO nuke_pnchat VALUES (1363,'System','','','<i><b>nukeman</b> just entered the chat.</i><br>','2003-07-14 17:39:42',1,'');
INSERT INTO nuke_pnchat VALUES (1364,'System','nukeman','','<b>Welcome nukeman! Users in this room:</b>  <font color=#0c0b70>Guest1</font>  <font color=#44aaff>Admin</font>  <font color=#0c0b70>Guest2</font>  <font color=#44aaff>rexlunae</font>  <font color=#44aaff>nukeman</font> ','2003-07-14 17:39:42',1,'');
INSERT INTO nuke_pnchat VALUES (1365,'','','Hello All','','2003-07-14 17:39:57',0,'');
INSERT INTO nuke_pnchat VALUES (1366,'System','','','<i><b>nukeman</b> just entered the chat.</i><br>','2003-07-14 17:40:03',1,'');
INSERT INTO nuke_pnchat VALUES (1367,'System','nukeman','','<b>Welcome nukeman! Users in this room:</b>  <font color=#0c0b70>Guest1</font>  <font color=#44aaff>Admin</font>  <font color=#0c0b70>Guest2</font>  <font color=#44aaff>rexlunae</font>  <font color=#44aaff>nukeman</font> ','2003-07-14 17:40:03',1,'');
INSERT INTO nuke_pnchat VALUES (1368,'System','','','<i><b>nukeman</b> just left the chat.</i><br>','2003-07-14 17:40:22',1,'');
INSERT INTO nuke_pnchat VALUES (1369,'System','','','<i><b>nukeman</b> just left the chat.</i><br>','2003-07-14 17:40:22',1,'');
INSERT INTO nuke_pnchat VALUES (1370,'System','','','<i><b>Admin</b> just entered the chat.</i><br>','2003-07-14 17:40:45',1,'');
INSERT INTO nuke_pnchat VALUES (1371,'System','Admin','','<b>Welcome Admin! Users in this room:</b>  <font color=#0c0b70>Guest1</font>  <font color=#44aaff>Admin</font>  <font color=#0c0b70>Guest2</font>  <font color=#44aaff>rexlunae</font> ','2003-07-14 17:40:45',1,'');
INSERT INTO nuke_pnchat VALUES (1372,'','','Foo bar','','2003-07-14 17:40:58',0,'');
INSERT INTO nuke_pnchat VALUES (1373,'System','','','<i><b>Admin</b> just left the chat.</i><br>','2003-07-14 17:41:25',1,'');
INSERT INTO nuke_pnchat VALUES (1374,'System','','','<i><b>Admin</b> just entered the chat.</i><br>','2003-07-14 17:42:01',1,'');
INSERT INTO nuke_pnchat VALUES (1375,'System','Admin','','<b>Welcome Admin! Users in this room:</b>  <font color=#0c0b70>Guest1</font>  <font color=#44aaff>Admin</font>  <font color=#0c0b70>Guest2</font>  <font color=#44aaff>rexlunae</font> ','2003-07-14 17:42:01',1,'');
INSERT INTO nuke_pnchat VALUES (1376,'System','','','<i><b></b> just jumped to room <b>\'IDEAS\'</b>.</i><br>','2003-07-14 17:42:14',0,'');
INSERT INTO nuke_pnchat VALUES (1377,'System','','','<i><b></b> just entered this room.</i><br>','2003-07-14 17:42:14',2,'');
INSERT INTO nuke_pnchat VALUES (1378,'System','','','<b>Users in this room:</b> ','2003-07-14 17:42:14',2,'');
INSERT INTO nuke_pnchat VALUES (1379,'System','','','<i><b></b> just jumped to room <b>\'IDEAS\'</b>.</i><br>','2003-07-14 17:42:20',0,'');
INSERT INTO nuke_pnchat VALUES (1380,'System','','','<i><b></b> just entered this room.</i><br>','2003-07-14 17:42:20',2,'');
INSERT INTO nuke_pnchat VALUES (1381,'System','','','<b>Users in this room:</b> ','2003-07-14 17:42:20',2,'');
INSERT INTO nuke_pnchat VALUES (1382,'','','I am here','','2003-07-14 17:42:36',0,'');
INSERT INTO nuke_pnchat VALUES (1383,'System','','','<i><b>Admin</b> just left the chat.</i><br>','2003-07-14 17:42:41',1,'');
INSERT INTO nuke_pnchat VALUES (1384,'System','','','<i><b></b> just entered the chat.</i><br>','2003-07-14 17:42:55',0,'');
INSERT INTO nuke_pnchat VALUES (1385,'System','','','<b>Welcome ! Users in this room:</b> ','2003-07-14 17:42:55',0,'');
INSERT INTO nuke_pnchat VALUES (1386,'','','asdf','','2003-07-15 09:40:22',0,'');
INSERT INTO nuke_pnchat VALUES (1387,'System','','','<i><b></b> just entered the chat.</i><br>','2003-07-15 09:40:29',0,'');
INSERT INTO nuke_pnchat VALUES (1388,'System','','','<b>Welcome ! Users in this room:</b> ','2003-07-15 09:40:29',0,'');
INSERT INTO nuke_pnchat VALUES (1389,'System','','','<i><b>Admin</b> just entered the chat.</i><br>','2003-07-15 09:43:13',1,'');
INSERT INTO nuke_pnchat VALUES (1390,'System','Admin','','<b>Welcome Admin! Users in this room:</b>  <font color=#0c0b70>Guest1</font>  <font color=#44aaff>Admin</font>  <font color=#0c0b70>Guest2</font>  <font color=#44aaff>rexlunae</font> ','2003-07-15 09:43:13',1,'');
INSERT INTO nuke_pnchat VALUES (1391,'System','','','<i><b>Admin</b> just left the chat.</i><br>','2003-07-15 09:43:53',1,'');
INSERT INTO nuke_pnchat VALUES (1392,'','','jfdsak','','2003-07-15 09:44:10',0,'');
INSERT INTO nuke_pnchat VALUES (1393,'System','','','<i><b></b> just jumped to room <b>\'\'</b>.</i><br>','2003-07-15 09:44:40',0,'');
INSERT INTO nuke_pnchat VALUES (1394,'System','','','<i><b></b> just entered this room.</i><br>','2003-07-15 09:44:40',0,'');
INSERT INTO nuke_pnchat VALUES (1395,'System','','','<b>Users in this room:</b> ','2003-07-15 09:44:40',0,'');
INSERT INTO nuke_pnchat VALUES (1396,'System','','','<i><b>Admin</b> just entered the chat.</i><br>','2003-07-15 09:44:45',1,'');
INSERT INTO nuke_pnchat VALUES (1397,'System','Admin','','<b>Welcome Admin! Users in this room:</b>  <font color=#0c0b70>Guest1</font>  <font color=#0c0b70>Guest2</font>  <font color=#44aaff>rexlunae</font> ','2003-07-15 09:44:45',1,'');
INSERT INTO nuke_pnchat VALUES (1398,'','','(b)(c)(b)(c)','','2003-07-15 09:45:41',0,'');
INSERT INTO nuke_pnchat VALUES (1399,'System','','','<i><b>Admin</b> just entered the chat.</i><br>','2003-07-15 09:45:47',1,'');
INSERT INTO nuke_pnchat VALUES (1400,'System','Admin','','<b>Welcome Admin! Users in this room:</b>  <font color=#0c0b70>Guest1</font>  <font color=#0c0b70>Guest2</font>  <font color=#44aaff>rexlunae</font> ','2003-07-15 09:45:47',1,'');
INSERT INTO nuke_pnchat VALUES (1401,'System','','','<i><b></b> just jumped to room <b>\'\'</b>.</i><br>','2003-07-15 09:45:55',0,'');
INSERT INTO nuke_pnchat VALUES (1402,'System','','','<i><b></b> just entered this room.</i><br>','2003-07-15 09:45:55',0,'');
INSERT INTO nuke_pnchat VALUES (1403,'System','','','<b>Users in this room:</b> ','2003-07-15 09:45:55',0,'');
INSERT INTO nuke_pnchat VALUES (1404,'System','','','<i><b></b> just jumped to room <b>\'\'</b>.</i><br>','2003-07-15 09:45:58',0,'');
INSERT INTO nuke_pnchat VALUES (1405,'System','','','<i><b></b> just entered this room.</i><br>','2003-07-15 09:45:58',0,'');
INSERT INTO nuke_pnchat VALUES (1406,'System','','','<b>Users in this room:</b> ','2003-07-15 09:45:58',0,'');
INSERT INTO nuke_pnchat VALUES (1407,'System','','','<i><b></b> just jumped to room <b>\'Lobby\'</b>.</i><br>','2003-07-15 09:46:03',0,'');
INSERT INTO nuke_pnchat VALUES (1408,'System','','','<i><b></b> just entered this room.</i><br>','2003-07-15 09:46:03',1,'');
INSERT INTO nuke_pnchat VALUES (1409,'System','','','<b>Users in this room:</b>  <font color=#0c0b70>Guest1</font>  <font color=#0c0b70>Guest2</font>  <font color=#44aaff>rexlunae</font> ','2003-07-15 09:46:03',1,'');
INSERT INTO nuke_pnchat VALUES (1410,'System','','','<i><b>Admin</b> just entered the chat.</i><br>','2003-07-15 09:46:10',1,'');
INSERT INTO nuke_pnchat VALUES (1411,'System','Admin','','<b>Welcome Admin! Users in this room:</b>  <font color=#0c0b70>Guest1</font>  <font color=#44aaff>Admin</font>  <font color=#0c0b70>Guest2</font>  <font color=#44aaff>rexlunae</font> ','2003-07-15 09:46:10',1,'');
INSERT INTO nuke_pnchat VALUES (1412,'System','','','<i><b>Admin</b> just left the chat.</i><br>','2003-07-15 09:46:50',1,'');
INSERT INTO nuke_pnchat VALUES (1413,'System','','','<i><b>Admin</b> just entered the chat.</i><br>','2003-07-15 09:46:53',1,'');
INSERT INTO nuke_pnchat VALUES (1414,'System','Admin','','<b>Welcome Admin! Users in this room:</b>  <font color=#0c0b70>Guest1</font>  <font color=#44aaff>Admin</font>  <font color=#0c0b70>Guest2</font>  <font color=#44aaff>rexlunae</font> ','2003-07-15 09:46:53',1,'');
INSERT INTO nuke_pnchat VALUES (1415,'System','','','<i><b>Admin</b> just left the chat.</i><br>','2003-07-15 09:47:32',1,'');
INSERT INTO nuke_pnchat VALUES (1416,'System','','','<i><b>Admin</b> just entered the chat.</i><br>','2003-07-15 09:56:45',1,'');
INSERT INTO nuke_pnchat VALUES (1417,'System','Admin','','<b>Welcome Admin! Users in this room:</b>  <font color=#0c0b70>Guest1</font>  <font color=#44aaff>Admin</font>  <font color=#0c0b70>Guest2</font>  <font color=#44aaff>rexlunae</font> ','2003-07-15 09:56:45',1,'');
INSERT INTO nuke_pnchat VALUES (1418,'','','I am foobar','','2003-07-15 09:56:55',0,'');
INSERT INTO nuke_pnchat VALUES (1419,'System','','','<i><b>Admin</b> just entered the chat.</i><br>','2003-07-15 09:57:03',1,'');
INSERT INTO nuke_pnchat VALUES (1420,'System','Admin','','<b>Welcome Admin! Users in this room:</b>  <font color=#0c0b70>Guest1</font>  <font color=#44aaff>Admin</font>  <font color=#0c0b70>Guest2</font>  <font color=#44aaff>rexlunae</font> ','2003-07-15 09:57:03',1,'');
INSERT INTO nuke_pnchat VALUES (1421,'System','','','<i><b>Admin</b> just left the chat.</i><br>','2003-07-15 09:57:25',1,'');
INSERT INTO nuke_pnchat VALUES (1422,'System','','','<i><b>Admin</b> just left the chat.</i><br>','2003-07-15 09:57:25',1,'');
INSERT INTO nuke_pnchat VALUES (1423,'System','','','<i><b>Admin</b> just entered the chat.</i><br>','2003-07-15 10:00:47',1,'');
INSERT INTO nuke_pnchat VALUES (1424,'System','Admin','','<b>Welcome Admin! Users in this room:</b>  <font color=#0c0b70>Guest1</font>  <font color=#44aaff>Admin</font>  <font color=#0c0b70>Guest2</font>  <font color=#44aaff>rexlunae</font> ','2003-07-15 10:00:47',1,'');
INSERT INTO nuke_pnchat VALUES (1425,'','','I am here','','2003-07-15 10:00:53',0,'');
INSERT INTO nuke_pnchat VALUES (1426,'','','I am here','','2003-07-15 10:01:06',0,'');
INSERT INTO nuke_pnchat VALUES (1427,'System','','','<i><b>Admin</b> just left the chat.</i><br>','2003-07-15 10:01:27',1,'');
INSERT INTO nuke_pnchat VALUES (1428,'System','','','<i><b>Admin</b> just entered the chat.</i><br>','2003-07-15 10:02:48',1,'');
INSERT INTO nuke_pnchat VALUES (1429,'System','Admin','','<b>Welcome Admin! Users in this room:</b>  <font color=#0c0b70>Guest1</font>  <font color=#44aaff>Admin</font>  <font color=#0c0b70>Guest2</font>  <font color=#44aaff>rexlunae</font> ','2003-07-15 10:02:48',1,'');
INSERT INTO nuke_pnchat VALUES (1430,'','','I am here','','2003-07-15 10:02:51',0,'');
INSERT INTO nuke_pnchat VALUES (1431,'','','I am here','','2003-07-15 10:03:01',0,'');
INSERT INTO nuke_pnchat VALUES (1432,'System','','','<i><b>Admin</b> just left the chat.</i><br>','2003-07-15 10:03:27',1,'');
INSERT INTO nuke_pnchat VALUES (1433,'System','','','<i><b>Admin</b> just entered the chat.</i><br>','2003-07-15 10:03:47',1,'');
INSERT INTO nuke_pnchat VALUES (1434,'System','Admin','','<b>Welcome Admin! Users in this room:</b>  <font color=#0c0b70>Guest1</font>  <font color=#44aaff>Admin</font>  <font color=#0c0b70>Guest2</font>  <font color=#44aaff>rexlunae</font> ','2003-07-15 10:03:47',1,'');
INSERT INTO nuke_pnchat VALUES (1435,'System','','','<i><b>Admin</b> just left the chat.</i><br>','2003-07-15 10:04:27',1,'');
INSERT INTO nuke_pnchat VALUES (1436,'System','','','<i><b>Admin</b> just entered the chat.</i><br>','2003-07-15 10:04:46',1,'');
INSERT INTO nuke_pnchat VALUES (1437,'System','Admin','','<b>Welcome Admin! Users in this room:</b>  <font color=#0c0b70>Guest1</font>  <font color=#44aaff>Admin</font>  <font color=#0c0b70>Guest2</font>  <font color=#44aaff>rexlunae</font> ','2003-07-15 10:04:46',1,'');
INSERT INTO nuke_pnchat VALUES (1438,'','','I am here','','2003-07-15 10:05:04',0,'');
INSERT INTO nuke_pnchat VALUES (1439,'System','','','<i><b>Admin</b> just entered the chat.</i><br>','2003-07-15 10:05:10',1,'');
INSERT INTO nuke_pnchat VALUES (1440,'System','Admin','','<b>Welcome Admin! Users in this room:</b>  <font color=#0c0b70>Guest1</font>  <font color=#44aaff>Admin</font>  <font color=#0c0b70>Guest2</font>  <font color=#44aaff>rexlunae</font> ','2003-07-15 10:05:10',1,'');
INSERT INTO nuke_pnchat VALUES (1441,'System','','','<i><b>Admin</b> just left the chat.</i><br>','2003-07-15 10:05:26',1,'');
INSERT INTO nuke_pnchat VALUES (1442,'System','','','<i><b>Admin</b> just left the chat.</i><br>','2003-07-15 10:05:26',1,'');
INSERT INTO nuke_pnchat VALUES (1443,'System','','','<BR><BR><FONT FACE=VERDANA,HELVETICA SIZE=1 COLOR=#000000><B>Users currently in this room:<br>----------------------------------<br></B></FONT>','2003-07-15 10:12:29',0,'');
INSERT INTO nuke_pnchat VALUES (1444,'System','','','<i><b>Admin</b> just entered the chat.</i><br>','2003-07-15 10:12:38',1,'');
INSERT INTO nuke_pnchat VALUES (1445,'System','Admin','','<b>Welcome Admin! Users in this room:</b>  <font color=#0c0b70>Guest1</font>  <font color=#0c0b70>Guest2</font>  <font color=#44aaff>rexlunae</font> ','2003-07-15 10:12:38',1,'');
INSERT INTO nuke_pnchat VALUES (1446,'System','','','<i><b>Admin</b> just entered the chat.</i><br>','2003-07-15 10:14:58',1,'');
INSERT INTO nuke_pnchat VALUES (1447,'System','Admin','','<b>Welcome Admin! Users in this room:</b>  <font color=#0c0b70>Guest1</font>  <font color=#44aaff>Admin</font>  <font color=#0c0b70>Guest2</font>  <font color=#44aaff>rexlunae</font> ','2003-07-15 10:14:58',1,'');
INSERT INTO nuke_pnchat VALUES (1448,'','','I am here','','2003-07-15 10:15:01',0,'');
INSERT INTO nuke_pnchat VALUES (1449,'System','','','<i><b>Admin</b> just left the chat.</i><br>','2003-07-15 10:15:38',1,'');
INSERT INTO nuke_pnchat VALUES (1450,'','','wefwe','','2003-07-15 10:16:14',0,'');
INSERT INTO nuke_pnchat VALUES (1451,'','','fewijfwe','','2003-07-15 10:16:31',0,'');
INSERT INTO nuke_pnchat VALUES (1452,'','','fweffwei','','2003-07-15 10:17:29',0,'');
INSERT INTO nuke_pnchat VALUES (1453,'System','','','<BR><BR><FONT FACE=VERDANA,HELVETICA SIZE=1 COLOR=#000000><B>Latest Linux kernel versions:<br>-----------------------------------<br><br>The latest stable version of the Linux kernel is:           2.4.21<br />\r\nThe latest prepatch for the stable Linux kernel tree is:    2.4.22-pre6<br />\r\nThe latest snapshot for the stable Linux kernel tree is:    2.4.21-bk10<br />\r\nThe latest beta version of the Linux kernel is:             2.6.0-test1<br />\r\nThe latest 2.2 version of the Linux kernel is:              2.2.25<br />\r\nThe latest 2.0 version of the Linux kernel is:              2.0.39<br />\r\nThe latest prepatch for the 2.0 Linux kernel tree is:       2.0.40-rc6<br />\r\nThe latest -ac patch to the stable Linux kernels is:        2.4.22-pre3-ac1<br />\r\nThe latest -ac patch to the beta Linux kernels is:          2.6.0-test1-ac1<br />\r\n</b></font>','2003-07-15 10:17:46',0,'');
INSERT INTO nuke_pnchat VALUES (1454,'','','fwewfe','','2003-07-15 10:18:21',0,'');
INSERT INTO nuke_pnchat VALUES (1455,'System','','','<i><b>Admin</b> just entered the chat.</i><br>','2003-07-15 10:20:37',1,'');
INSERT INTO nuke_pnchat VALUES (1456,'System','Admin','','<b>Welcome Admin! Users in this room:</b>  <font color=#0c0b70>Guest1</font>  <font color=#44aaff>Admin</font>  <font color=#0c0b70>Guest2</font>  <font color=#44aaff>rexlunae</font> ','2003-07-15 10:20:37',1,'');
INSERT INTO nuke_pnchat VALUES (1457,'Admin','','foo bar','','2003-07-15 10:20:42',1,'#44aaff');
INSERT INTO nuke_pnchat VALUES (1458,'Admin','','foo bar','','2003-07-15 10:20:47',1,'#44aaff');
INSERT INTO nuke_pnchat VALUES (1459,'System','','','<i><b>Admin</b> just left the chat.</i><br>','2003-07-15 10:21:17',1,'');
INSERT INTO nuke_pnchat VALUES (1460,'Admin','','foo bar','','2003-07-15 10:21:44',1,'#44aaff');
INSERT INTO nuke_pnchat VALUES (1461,'Admin','','foo bar','','2003-07-15 10:21:56',1,'#44aaff');
INSERT INTO nuke_pnchat VALUES (1462,'Admin','','Bunny funny','','2003-07-15 10:22:04',1,'#44aaff');
INSERT INTO nuke_pnchat VALUES (1463,'Admin','','','','2003-07-15 10:22:14',1,'#44aaff');
INSERT INTO nuke_pnchat VALUES (1464,'Admin','','I am here','','2003-07-15 10:22:20',1,'#44aaff');
INSERT INTO nuke_pnchat VALUES (1465,'System','','','<i><b>Admin</b> just entered the chat.</i><br>','2003-07-15 10:22:28',1,'');
INSERT INTO nuke_pnchat VALUES (1466,'System','Admin','','<b>Welcome Admin! Users in this room:</b>  <font color=#0c0b70>Guest1</font>  <font color=#0c0b70>Guest2</font>  <font color=#44aaff>rexlunae</font> ','2003-07-15 10:22:28',1,'');
INSERT INTO nuke_pnchat VALUES (1467,'System','','','<i><b>Admin</b> just entered the chat.</i><br>','2003-07-15 10:22:36',1,'');
INSERT INTO nuke_pnchat VALUES (1468,'System','Admin','','<b>Welcome Admin! Users in this room:</b>  <font color=#0c0b70>Guest1</font>  <font color=#44aaff>Admin</font>  <font color=#0c0b70>Guest2</font>  <font color=#44aaff>rexlunae</font> ','2003-07-15 10:22:36',1,'');
INSERT INTO nuke_pnchat VALUES (1469,'Admin','','foo bar','','2003-07-15 10:22:40',1,'#44aaff');
INSERT INTO nuke_pnchat VALUES (1470,'Admin','','I am here','','2003-07-15 10:22:43',1,'#44aaff');
INSERT INTO nuke_pnchat VALUES (1471,'System','','','<i><b>n00b</b> just entered the chat.</i><br>','2003-07-15 10:22:55',1,'');
INSERT INTO nuke_pnchat VALUES (1472,'System','n00b','','<b>Welcome n00b! Users in this room:</b>  <font color=#0c0b70>Guest1</font>  <font color=#44aaff>Admin</font>  <font color=#0c0b70>Guest2</font>  <font color=#44aaff>rexlunae</font>  <font color=#44aaff>n00b</font> ','2003-07-15 10:22:55',1,'');
INSERT INTO nuke_pnchat VALUES (1473,'n00b','','blah','','2003-07-15 10:22:58',1,'#44aaff');
INSERT INTO nuke_pnchat VALUES (1474,'System','','','<i><b>n00b</b> changed the nickname to <b>\'blah\'</b></i><br>','2003-07-15 10:23:02',1,'');
INSERT INTO nuke_pnchat VALUES (1475,'','','blah','','2003-07-15 10:23:03',0,'');
INSERT INTO nuke_pnchat VALUES (1476,'Admin','','Boo','','2003-07-15 10:23:04',1,'#44aaff');
INSERT INTO nuke_pnchat VALUES (1477,'System','','','<i><b>Admin</b> has changed <font color=#f00f00>color</font></i><br>','2003-07-15 10:23:11',1,'');
INSERT INTO nuke_pnchat VALUES (1478,'System','','','<i><b></b> changed the nickname to <b>\'nick\'</b></i><br>','2003-07-15 10:23:15',0,'');
INSERT INTO nuke_pnchat VALUES (1479,'System','','','<i><b>Admin</b> just left the chat.</i><br>','2003-07-15 10:23:16',1,'');
INSERT INTO nuke_pnchat VALUES (1480,'Admin','','I am here','','2003-07-15 10:23:16',1,'#f00f00');
INSERT INTO nuke_pnchat VALUES (1481,'','','','','2003-07-15 10:23:16',0,'');
INSERT INTO nuke_pnchat VALUES (1482,'','','','','2003-07-15 10:23:17',0,'');
INSERT INTO nuke_pnchat VALUES (1483,'','','','','2003-07-15 10:23:19',0,'');
INSERT INTO nuke_pnchat VALUES (1484,'','','','','2003-07-15 10:23:19',0,'');
INSERT INTO nuke_pnchat VALUES (1485,'System','','','<i><b>Admin</b> just entered the chat.</i><br>','2003-07-15 10:23:29',1,'');
INSERT INTO nuke_pnchat VALUES (1486,'System','Admin','','<b>Welcome Admin! Users in this room:</b>  <font color=#0c0b70>Guest1</font>  <font color=#0c0b70>Guest2</font>  <font color=#44aaff>rexlunae</font>  <font color=#44aaff>blah</font> ','2003-07-15 10:23:29',1,'');
INSERT INTO nuke_pnchat VALUES (1487,'','','hello','','2003-07-15 10:23:46',0,'');
INSERT INTO nuke_pnchat VALUES (1488,'System','','','<i><b></b> just entered the chat.</i><br>','2003-07-15 10:23:49',0,'');
INSERT INTO nuke_pnchat VALUES (1489,'System','','','<b>Welcome ! Users in this room:</b> ','2003-07-15 10:23:49',0,'');
INSERT INTO nuke_pnchat VALUES (1490,'System','','','<i><b></b> just entered the chat.</i><br>','2003-07-15 10:23:59',0,'');
INSERT INTO nuke_pnchat VALUES (1491,'System','','','<b>Welcome ! Users in this room:</b> ','2003-07-15 10:23:59',0,'');
INSERT INTO nuke_pnchat VALUES (1492,'System','','','<i><b>Admin</b> just jumped to room <b>\'IDEAS\'</b>.</i><br>','2003-07-15 10:25:00',1,'');
INSERT INTO nuke_pnchat VALUES (1493,'System','','','<i><b>Admin</b> just entered this room.</i><br>','2003-07-15 10:25:00',2,'');
INSERT INTO nuke_pnchat VALUES (1494,'System','Admin','','<b>Users in this room:</b> ','2003-07-15 10:25:00',2,'');
INSERT INTO nuke_pnchat VALUES (1495,'System','','','<i><b>Admin</b> just entered the chat.</i><br>','2003-07-15 10:25:05',2,'');
INSERT INTO nuke_pnchat VALUES (1496,'System','Admin','','<b>Welcome Admin! Users in this room:</b>  <font color=#f00f00>Admin</font> ','2003-07-15 10:25:05',2,'');
INSERT INTO nuke_pnchat VALUES (1497,'System','','','<i><b>Admin</b> just jumped to room <b>\'Lobby\'</b>.</i><br>','2003-07-15 10:25:16',2,'');
INSERT INTO nuke_pnchat VALUES (1498,'System','','','<i><b>Admin</b> just entered this room.</i><br>','2003-07-15 10:25:16',1,'');
INSERT INTO nuke_pnchat VALUES (1499,'System','Admin','','<b>Users in this room:</b>  <font color=#0c0b70>Guest1</font>  <font color=#f00f00>Admin</font>  <font color=#0c0b70>Guest2</font>  <font color=#44aaff>rexlunae</font>  <font color=#44aaff>blah</font> ','2003-07-15 10:25:16',1,'');
INSERT INTO nuke_pnchat VALUES (1500,'System','','','<i><b>Admin</b> just jumped to room <b>\'\'</b>.</i><br>','2003-07-15 10:25:26',1,'');
INSERT INTO nuke_pnchat VALUES (1501,'System','','','<i><b>Admin</b> just entered this room.</i><br>','2003-07-15 10:25:26',0,'');
INSERT INTO nuke_pnchat VALUES (1502,'System','Admin','','<b>Users in this room:</b>  <font color=#f00f00>Admin</font> ','2003-07-15 10:25:26',0,'');
INSERT INTO nuke_pnchat VALUES (1503,'System','','','<i><b>Admin</b> just left the chat.</i><br>','2003-07-15 10:25:45',0,'');
INSERT INTO nuke_pnchat VALUES (1504,'System','','','<i><b>Admin</b> just jumped to room <b>\'\'</b>.</i><br>','2003-07-15 10:28:31',0,'');
INSERT INTO nuke_pnchat VALUES (1505,'System','','','<i><b>Admin</b> just entered this room.</i><br>','2003-07-15 10:28:31',0,'');
INSERT INTO nuke_pnchat VALUES (1506,'System','Admin','','<b>Users in this room:</b> ','2003-07-15 10:28:31',0,'');
INSERT INTO nuke_pnchat VALUES (1507,'System','','','<i><b>Admin</b> just jumped to room <b>\'\'</b>.</i><br>','2003-07-15 10:28:34',0,'');
INSERT INTO nuke_pnchat VALUES (1508,'System','','','<i><b>Admin</b> just entered this room.</i><br>','2003-07-15 10:28:34',0,'');
INSERT INTO nuke_pnchat VALUES (1509,'System','Admin','','<b>Users in this room:</b> ','2003-07-15 10:28:34',0,'');
INSERT INTO nuke_pnchat VALUES (1510,'System','','','<i><b>Admin</b> just jumped to room <b>\'\'</b>.</i><br>','2003-07-15 10:28:38',0,'');
INSERT INTO nuke_pnchat VALUES (1511,'System','','','<i><b>Admin</b> just entered this room.</i><br>','2003-07-15 10:28:38',0,'');
INSERT INTO nuke_pnchat VALUES (1512,'System','Admin','','<b>Users in this room:</b> ','2003-07-15 10:28:38',0,'');
INSERT INTO nuke_pnchat VALUES (1513,'System','','','<i><b>Admin</b> just jumped to room <b>\'\'</b>.</i><br>','2003-07-15 10:31:09',0,'');
INSERT INTO nuke_pnchat VALUES (1514,'System','','','<i><b>Admin</b> just entered this room.</i><br>','2003-07-15 10:31:09',0,'');
INSERT INTO nuke_pnchat VALUES (1515,'System','Admin','','<b>Users in this room:</b> ','2003-07-15 10:31:09',0,'');
INSERT INTO nuke_pnchat VALUES (1516,'System','','','<i><b>Admin</b> just jumped to room <b>\'\'</b>.</i><br>','2003-07-15 10:32:42',0,'');
INSERT INTO nuke_pnchat VALUES (1517,'System','','','<i><b>Admin</b> just entered this room.</i><br>','2003-07-15 10:32:42',0,'');
INSERT INTO nuke_pnchat VALUES (1518,'System','Admin','','<b>Users in this room:</b> ','2003-07-15 10:32:42',0,'');
INSERT INTO nuke_pnchat VALUES (1519,'Admin','','I am here','','2003-07-15 10:32:42',0,'#f00f00');
INSERT INTO nuke_pnchat VALUES (1520,'System','','','<i><b>Admin</b> just entered the chat.</i><br>','2003-07-15 10:32:51',0,'');
INSERT INTO nuke_pnchat VALUES (1521,'System','Admin','','<b>Welcome Admin! Users in this room:</b> ','2003-07-15 10:32:51',0,'');
INSERT INTO nuke_pnchat VALUES (1522,'System','','','<i><b>Admin</b> just entered the chat.</i><br>','2003-07-15 10:33:21',0,'');
INSERT INTO nuke_pnchat VALUES (1523,'System','Admin','','<b>Welcome Admin! Users in this room:</b>  <font color=#f00f00>Admin</font> ','2003-07-15 10:33:21',0,'');
INSERT INTO nuke_pnchat VALUES (1524,'System','','','<i><b>Admin</b> just left the chat.</i><br>','2003-07-15 10:34:01',0,'');

--
-- Table structure for table 'nuke_pnchatfortunes'
--

CREATE TABLE nuke_pnchatfortunes (
  pn_id bigint(20) NOT NULL auto_increment,
  pn_fortune text NOT NULL,
  pn_category varchar(20) NOT NULL default '',
  PRIMARY KEY  (pn_id)
) TYPE=MyISAM;

--
-- Dumping data for table 'nuke_pnchatfortunes'
--


INSERT INTO nuke_pnchatfortunes VALUES (36,'A father doesn\'t destroy his children.\n -- Lt. Carolyn Palamas, \"Who Mourns for Adonais?\",\n		   stardate 3468.1.\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (3,'\"If a machine couldn\'t run a free operating system, we got rid of it.\"\r\n\r\n  -- Richard Stallman (Open Sources, 1999 O\'Reilly and Associates)\r\n','osfortune');
INSERT INTO nuke_pnchatfortunes VALUES (4,'\n\"The straightforward and easy path was to join the proprietary software\nworld, signing nondisclosure agreements and promising not to help my\nfellow hacker....  I could have made money this way, and perhaps had fun\nprogramming (if I closed my eyes to how I was treating other people).\nBut I knew that when my career was over, I would look back on years of\nbuilding walls to divide people, and feel I had made the world ugly.\"\n \n  -- Richard Stallman (Open Sources, 1999 O\'Reilly and Associates)\n','osfortune');
INSERT INTO nuke_pnchatfortunes VALUES (5,'\n\"But the most reliable indication of the future of Open Source is its\npast: in just a few years, we have gone from nothing to a robust body\nof software that solves many different problems and is reaching the\nmillion-user count. There\'s no reason for us to slow down now.\"\n\n  -- Bruce Perens, on the future of Open Source software.\n (Open Sources, 1999 O\'Reilly and Associates)\n','osfortune');
INSERT INTO nuke_pnchatfortunes VALUES (6,'\n\"The reason for the success of this somewhat communist-sounding strategy,\nwhile the failure of communism itself is visible around the world, is\nthat the economics of information are fundamentaly different from those\nof other products.\"\n\n  -- Bruce Perens, on Open Source software.\n (Open Sources, 1999 O\'Reilly and Associates)\n','osfortune');
INSERT INTO nuke_pnchatfortunes VALUES (7,'\n\"It is easy to sympathize with the MIS staffs around the world, I mean\nwho hasn\'t lost work due to Windows or a Microsoft application crashing?\"\n\n  -- Chris DiBona, happy he\'s been using Linux and can avoid such things,\n from the introduction. (Open Sources, 1999 O\'Reilly and Associates) \n','osfortune');
INSERT INTO nuke_pnchatfortunes VALUES (8,'\n\"So I decided that if the architecture is fundamentally sane enough,\nsay it follows some basic rules like it supported paging, then I would\nbe able to say, yes, Linux fundamentally supports that model.\"\n\n  -- Linus Torvalds on Portability (Open Sources, 1999 O\'Reilly and Associates)\n','osfortune');
INSERT INTO nuke_pnchatfortunes VALUES (9,'\n\"I\'m not saying that they were knowingly dishonest, perhaps they were\nsimply stupid. \"\n\n  -- Linus Torvalds, commenting on those who really thought Microkernels\n were wise. (Open Sources, 1999 O\'Reilly and Associates)\n','osfortune');
INSERT INTO nuke_pnchatfortunes VALUES (10,'\n\"The idea of abstracting away the one thing that must be blindingly fast,\nthe kernel, is inherently counter productive.\"\n\n  -- Linus Torvalds on Microkernels (Open Sources, 1999 O\'Reilly & Associates)\n','osfortune');
INSERT INTO nuke_pnchatfortunes VALUES (11,'\n\"So right now the only vendor that does such a stupid thing is Microsoft.\"\n\n  -- Linus Torvalds on bad file system interface design.\n (Open Sources, 1999 O\'Reilly and Associates.)\n','osfortune');
INSERT INTO nuke_pnchatfortunes VALUES (12,'\n\"Eric also holds a black belt in Tae Kwon Do and shoots pistols\nfor relaxation, His favorite gun is the classic 1911-pattern .45\nsemiautomatic\"\n\n  -- Chris DiBona on neo-renassaince Homo Heileinias Eric S. Raymond.\n (Open Sources, 1999 O\'Reilly and Associates)\n','osfortune');
INSERT INTO nuke_pnchatfortunes VALUES (13,'\n\"The world is beating a path to our door\"\n\n  -- Bruce Perens, (Open Sources, 1999 O\'Reilly and Associates)\n','osfortune');
INSERT INTO nuke_pnchatfortunes VALUES (14,'\n\"If you want an application to be portable, you don\'t necessarily\ncreate an abstraction layer like a microkernel so much as you program\nintelligently.\"\n\n  -- Linus Torvalds on Microkernels (Open Sources, 1999 O\'Reilly and Associates)\n','osfortune');
INSERT INTO nuke_pnchatfortunes VALUES (15,'\n\"Calling EMACS an editor is like calling the Earth a hunk of dirt.\"\n\n  -- Chris DiBona on Dirt (Open Sources, 1999 O\'Reilly and Associates)\n','osfortune');
INSERT INTO nuke_pnchatfortunes VALUES (16,'\n\"I am not convinced that they can write solid stable software. Proprietary\nsoftware is already hobbled by it\'s secretive cathedral nature, but\nMicrosoft seems to have a corner on incompetent programming as well.\"\n\n  -- Chris DiBona from the introduction.\n (Open Sources, 1999 O\'Reilly and Associates)\n','osfortune');
INSERT INTO nuke_pnchatfortunes VALUES (17,'\n\"The funny thing is if you actually read those papers, you find that,\nwhile the researchers were applying thier optomizational tricks on a\nmicrokernel, in fact those same tricks could be applied to traditional\nkernels to accelerate their execution.\"\n\n  -- Linus Torvalds on Microkernels (Open Sources, 1999 O\'Reilly and Associates)\n','osfortune');
INSERT INTO nuke_pnchatfortunes VALUES (18,'\n\"Computers and automation have become so ingrained and essential\nto day-to-day business that a sensible business should not rely on a\nsingle vendor to provide essential services........Thus it is always in\na customers\' interests to demand that the software they deploy be based\non non-proprietary platforms.\"\n\n  -- Brian Behlendorf on OSS (Open Sources, 1999 O\'Reilly and Associates)\n','osfortune');
INSERT INTO nuke_pnchatfortunes VALUES (19,'\n\"Nature abhors a Vacuum\"\n\n  -- Brian Behlendorf on OSS (Open Sources, 1999 O\'Reilly and Associates)\n','osfortune');
INSERT INTO nuke_pnchatfortunes VALUES (20,'\n\"While not obviously a business-friendly license there are certain\naspects of the GNU license which are attractive, believe it or not,\nfor commercial purposes.\"\n\n  -- Brian Behlendorf on OSS (Open Sources, 1999 O\'Reilly and Associates)\n','osfortune');
INSERT INTO nuke_pnchatfortunes VALUES (21,'\n\"The open-source approach is not a magic bullet for every type of software\ndevelopment project.\"\n\n  -- Brian Behlendorf on OSS (Open Sources, 1999 O\'Reilly and Associates)\n','osfortune');
INSERT INTO nuke_pnchatfortunes VALUES (22,'\n\"For something that does not exist, the Internet Engineering Task Force\nhas has quite an impact.\"\n\n  -- Scott Bradner (Open Sources, 1999 O\'Reilly and Associates)\n','osfortune');
INSERT INTO nuke_pnchatfortunes VALUES (23,'\n\"The basic publication series for the IETF is the RFC series. RPF once\nstood for \'Request for Comments,\' but since documents published as\nRFCs have generally gone through an extensive review process before\npublication, RFC is now best known understood to mean \'RFC\' \"\n \n  -- Scott Bradner (Open Sources, 1999 O\'Reilly and Associates)\n','osfortune');
INSERT INTO nuke_pnchatfortunes VALUES (24,'\n\"The IETF motto is \'rough consensus and running code\'\"\n  \n  -- Scott Bradner (Open Sources, 1999 O\'Reilly and Associates)\n','osfortune');
INSERT INTO nuke_pnchatfortunes VALUES (25,'\n\"Open Standards, Open Documents, and Open Source\"\n\n  -- Scott Bradner (Open Sources, 1999 O\'Reilly and Associates)\n','osfortune');
INSERT INTO nuke_pnchatfortunes VALUES (26,'\n\"So here\'s a picture of reality: (picture of circle with lots of sqiggles\nin it) As we all know, reality is a mess.\"\n\n  -- Larry Wall (Open Sources, 1999 O\'Reilly and Associates)\n','osfortune');
INSERT INTO nuke_pnchatfortunes VALUES (27,'\n\"However, complexity is not always the enemy.\"\n\n  -- Larry Wall (Open Sources, 1999 O\'Reilly and Associates)\n','osfortune');
INSERT INTO nuke_pnchatfortunes VALUES (28,'\n\"Suppose I want to take over the world. Simplicity says I should just\ntake over the world by myself.\"\n\n  -- Larry Wall (Open Sources, 1999 O\'Reilly and Associates)\n','osfortune');
INSERT INTO nuke_pnchatfortunes VALUES (29,'\n\"People get annoyed when you try to debug them.\"\n\n  -- Larry Wall (Open Sources, 1999 O\'Reilly and Associates)\n','osfortune');
INSERT INTO nuke_pnchatfortunes VALUES (30,'\n\"Computers may be stupid, but they\'re always obedient. Well, almost always.\"\n\n  -- Larry Wall (Open Sources, 1999 O\'Reilly and Associates)\n','osfortune');
INSERT INTO nuke_pnchatfortunes VALUES (31,'\n\"You know, how is The Force like duct tape? Answer: it has a light side,\na dark side, and it holds the universe together.\"\n\n  -- Larry Wall (Open Sources, 1999 O\'Reilly and Associates)\n','osfortune');
INSERT INTO nuke_pnchatfortunes VALUES (32,'\n\"Of course, in Perl culture, almost nothing is prohibited. My feeling\nis that the rest of the world already has plenty of perfectly good\nprohibitions, so why invent more?\"\n\n  -- Larry Wall (Open Sources, 1999 O\'Reilly and Associates)\n','osfortune');
INSERT INTO nuke_pnchatfortunes VALUES (33,'\n\"There are a billion people in China. And I want them to be able to pass\nnotes to each other written in Perl. I want them to be able to write\npoetry in Perl. That is my vision of the Future. My chosen perspective.\"\n\n  -- Larry Wall (Open Sources, 1999 O\'Reilly and Associates)\n','osfortune');
INSERT INTO nuke_pnchatfortunes VALUES (34,'\n\"In a way they were right, the basics of operating systems - and\nby extension the Linux kernel - were well understood by the early\n70s; anything after that has been to some degree an exercise in\nself-gratification.\"\n\n  -- Linus Torvalds (Open Sources, 1999 O\'Reilly and Associates)\n','osfortune');
INSERT INTO nuke_pnchatfortunes VALUES (35,'\n\"The move was on to \'Free the Lizard\'\"\n\n  -- Jim Hamerly and Tom Paquin (Open Sources, 1999 O\'Reilly and Associates)\n','osfortune');
INSERT INTO nuke_pnchatfortunes VALUES (37,'\nA little suffering is good for the soul.\n		-- Kirk, \"The Corbomite Maneuver\", stardate 1514.0\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (38,'\nA man either lives life as it happens to him, meets it head-on and\nlicks it, or he turns his back on it and starts to wither away.\n		-- Dr. Boyce, \"The Menagerie\" (\"The Cage\"), stardate unknown\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (39,'\nA princess should not be afraid -- not with a brave knight to protect\nher.\n		-- McCoy, \"Shore Leave\", stardate 3025.3\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (40,'\nA star captain\'s most solemn oath is that he will give his life, even\nhis entire crew, rather than violate the Prime Directive.\n		-- Kirk, \"The Omega Glory\", stardate unknown\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (41,'\nA Vulcan can no sooner be disloyal than he can exist without\nbreathing.\n		-- Kirk, \"The Menagerie\", stardate 3012.4\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (42,'\nA woman should have compassion.\n		-- Kirk, \"Catspaw\", stardate 3018.2\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (43,'\nActual war is a very messy business.  Very, very messy business.\n		-- Kirk, \"A Taste of Armageddon\", stardate 3193.0\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (44,'\nAfter a time, you may find that \"having\" is not so pleasing a thing,\nafter all, as \"wanting.\"  It is not logical, but it is often true.\n		-- Spock, \"Amok Time\", stardate 3372.7\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (45,'\nAll your people must learn before you can reach for the stars.\n		-- Kirk, \"The Gamesters of Triskelion\", stardate 3259.2\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (46,'\nAnother Armenia, Belgium ... the weak innocents who always seem to be\nlocated on a natural invasion route.\n		-- Kirk, \"Errand of Mercy\", stardate 3198.4\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (47,'\nAnother dream that failed.  There\'s nothing sadder.\n		-- Kirk, \"This side of Paradise\", stardate 3417.3\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (48,'\nAnother war ... must it always be so?  How many comrades have we lost\nin this way? ...  Obedience.  Duty.  Death, and more death ...\n		-- Romulan Commander, \"Balance of Terror\", stardate 1709.2\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (49,'\n... bacteriological warfare ... hard to believe we were once foolish\nenough to play around with that.\n		-- McCoy, \"The Omega Glory\", stardate unknown\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (50,'\n\"Beauty is transitory.\"\n\"Beauty survives.\"\n		-- Spock and Kirk, \"That Which Survives\", stardate unknown\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (51,'\nBehind every great man, there is a woman -- urging him on.\n		-- Harry Mudd, \"I, Mudd\", stardate 4513.3\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (52,'\nBlast medicine anyway!  We\'ve learned to tie into every organ in the\nhuman body but one.  The brain!  The brain is what life is all about.\n		-- McCoy, \"The Menagerie\", stardate 3012.4\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (53,'\nBut it\'s real.  And if it\'s real it can be affected ...  we may not be\nable to break it, but, I\'ll bet you credits to Navy Beans we can put a\ndent in it.\n		-- deSalle, \"Catspaw\", stardate 3018.2\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (54,'\n\"Can you imagine how life could be improved if we could do away with\njealousy, greed, hate ...\"\n\n\"It can also be improved by eliminating love, tenderness, sentiment --\nthe other side of the coin\"\n		-- Dr. Roger Corby and Kirk, \"What are Little Girls Made Of?\",\n		   stardate 2712.4\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (55,'\nChange is the essential process of all existence.\n		-- Spock, \"Let That Be Your Last Battlefield\", stardate 5730.2\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (56,'\nCompassion -- that\'s the one things no machine ever had.  Maybe it\'s\nthe one thing that keeps men ahead of them.\n		-- McCoy, \"The Ultimate Computer\", stardate 4731.3\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (57,'\nComputers make excellent and efficient servants, but I have no wish to\nserve under them.  Captain, a starship also runs on loyalty to one\nman.  And nothing can replace it or him.\n		-- Spock, \"The Ultimate Computer\", stardate 4729.4\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (58,'\nConquest is easy. Control is not.\n		-- Kirk, \"Mirror, Mirror\", stardate unknown\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (59,'\nDeath, when unnecessary, is a tragic thing.\n		-- Flint, \"Requiem for Methuselah\", stardate 5843.7\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (60,'\nDeath.  Destruction.  Disease.  Horror.  That\'s what war is all about.\nThat\'s what makes it a thing to be avoided.\n		-- Kirk, \"A Taste of Armageddon\", stardate 3193.0\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (61,'\nDo you know about being with somebody?  Wanting to be?  If I had the\nwhole universe, I\'d give it to you, Janice.  When I see you, I feel\nlike I\'m hungry all over.  Do you know how that feels?\n		-- Charlie Evans, \"Charlie X\", stardate 1535.8\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (62,'\nDo you know the one -- \"All I ask is a tall ship, and a star to steer\nher by ...\"  You could feel the wind at your back, about you ...  the\nsounds of the sea beneath you.  And even if you take away the wind and\nthe water, it\'s still the same.  The ship is yours ... you can feel her\n... and the stars are still there.\n		-- Kirk, \"The Ultimate Computer\", stardate 4729.4\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (63,'\n[Doctors and Bartenders], We both get the same two kinds of customers\n-- the living and the dying.\n		-- Dr. Boyce, \"The Menagerie\" (\"The Cage\"), stardate unknown\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (64,'\nEach kiss is as the first.\n		-- Miramanee, Kirk\'s wife, \"The Paradise Syndrome\",\n		   stardate 4842.6\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (65,'\nEarth -- mother of the most beautiful women in the universe.\n		-- Apollo, \"Who Mourns for Adonais?\" stardate 3468.1\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (66,'\nEither one of us, by himself, is expendable.  Both of us are not.\n		-- Kirk, \"The Devil in the Dark\", stardate 3196.1\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (67,'\nEmotions are alien to me.  I\'m a scientist.\n		-- Spock, \"This Side of Paradise\", stardate 3417.3\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (68,'\nEven historians fail to learn from history -- they repeat the same\nmistakes.\n		-- John Gill, \"Patterns of Force\", stardate 2534.7\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (69,'\nEvery living thing wants to survive.\n		-- Spock, \"The Ultimate Computer\", stardate 4731.3\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (70,'\n\"Evil does seek to maintain power by suppressing the truth.\"\n\"Or by misleading the innocent.\"\n		-- Spock and McCoy, \"And The Children Shall Lead\",\n		   stardate 5029.5.\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (71,'\nExtreme feminine beauty is always disturbing.\n		-- Spock, \"The Cloud Minders\", stardate 5818.4\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (72,'\nFascinating is a word I use for the unexpected.\n		-- Spock, \"The Squire of Gothos\", stardate 2124.5\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (73,'\nFascinating, a totally parochial attitude.\n		-- Spock, \"Metamorphosis\", stardate 3219.8\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (74,'\nFirst study the enemy.  Seek weakness.\n		-- Romulan Commander, \"Balance of Terror\", stardate 1709.2\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (75,'\nFour thousand throats may be cut in one night by a running man.\n		-- Klingon Soldier, \"Day of the Dove\", stardate unknown\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (76,'\n\"... freedom ... is a worship word...\"\n\"It is our worship word too.\"\n		-- Cloud William and Kirk, \"The Omega Glory\", stardate unknown\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (77,'\nGenius doesn\'t work on an assembly line basis.  You can\'t simply say,\n\"Today I will be brilliant.\"\n		-- Kirk, \"The Ultimate Computer\", stardate 4731.3\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (78,'\n\"Get back to your stations!\"\n\"We\'re beaming down to the planet, sir.\"\n		-- Kirk and Mr. Leslie, \"This Side of Paradise\",\n		   stardate 3417.3\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (79,'\nHe\'s dead, Jim\n		-- McCoy, \"The Devil in the Dark\", stardate 3196.1\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (80,'\nHistory tends to exaggerate.\n		-- Col. Green, \"The Savage Curtain\", stardate 5906.4\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (81,'\nHumans do claim a great deal for that particular emotion (love).\n		-- Spock, \"The Lights of Zetar\", stardate 5725.6\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (82,'\nI am pleased to see that we have differences.  May we together become\ngreater than the sum of both of us.\n		-- Surak of Vulcan, \"The Savage Curtain\", stardate 5906.4\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (83,'\nI have never understood the female capacity to avoid a direct answer to\nany question.\n		-- Spock, \"This Side of Paradise\", stardate 3417.3\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (84,'\nI object to intellect without discipline;  I object to power without\nconstructive purpose.\n		-- Spock, \"The Squire of Gothos\", stardate 2124.5\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (85,'\nI realize that command does have its fascination, even under\ncircumstances such as these, but I neither enjoy the idea of command\nnor am I frightened of it.  It simply exists, and I will do whatever\nlogically needs to be done.\n		-- Spock, \"The Galileo Seven\", stardate 2812.7\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (86,'\n\"I think they\'re going to take all this money that we spend now on war\nand death --\"\n\"And make them spend it on life.\"\n		-- Edith Keeler and Kirk, \"The City on the Edge of Forever\",\n		   stardate unknown.\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (87,'\nI thought my people would grow tired of killing.  But you were right,\nthey see it is easier than trading.  And it has its pleasures.  I feel\nit myself.  Like the hunt, but with richer rewards.\n		-- Apella, \"A Private Little War\", stardate 4211.8\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (88,'\nI\'m a soldier, not a diplomat.  I can only tell the truth.\n		-- Kirk, \"Errand of Mercy\", stardate 3198.9\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (89,'\nI\'m frequently appalled by the low regard you Earthmen have for life.\n		-- Spock, \"The Galileo Seven\", stardate 2822.3\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (90,'\nI\'ve already got a female to worry about.  Her name is the Enterprise.\n		-- Kirk, \"The Corbomite Maneuver\", stardate 1514.0\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (91,'\nIf a man had a child who\'d gone anti-social, killed perhaps, he\'d still\ntend to protect that child.\n		-- McCoy, \"The Ultimate Computer\", stardate 4731.3\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (92,'\nIf I can have honesty, it\'s easier to overlook mistakes.\n		-- Kirk, \"Space Seed\", stardate 3141.9\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (93,'\nIf some day we are defeated, well, war has its fortunes, good and bad.\n		-- Commander Kor, \"Errand of Mercy\", stardate 3201.7\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (94,'\nIf there are self-made purgatories, then we all have to live in them.\n		-- Spock, \"This Side of Paradise\", stardate 3417.7\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (95,'\nImmortality consists largely of boredom.\n		-- Zefrem Cochrane, \"Metamorphosis\", stardate 3219.8\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (96,'\nIn the strict scientific sense we all feed on death -- even\nvegetarians.\n		-- Spock, \"Wolf in the Fold\", stardate 3615.4\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (97,'\nInsufficient facts always invite danger.\n		-- Spock, \"Space Seed\", stardate 3141.9\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (98,'\nInsults are effective only where emotion is present.\n		-- Spock, \"Who Mourns for Adonais?\"  stardate 3468.1\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (99,'\nIntuition, however illogical, is recognized as a command prerogative.\n		-- Kirk, \"Obsession\", stardate 3620.7\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (100,'\nIs not that the nature of men and women -- that the pleasure is in the\nlearning of each other?\n		-- Natira, the High Priestess of Yonada, \"For the World is\n		   Hollow and I Have Touched the Sky\", stardate 5476.3.\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (101,'\nIs truth not truth for all?\n		-- Natira, \"For the World is Hollow and I have Touched\n		   the Sky\", stardate 5476.4.\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (102,'\nIt [being a Vulcan] means to adopt a philosophy, a way of life which is\nlogical and beneficial.  We cannot disregard that philosophy merely for\npersonal gain, no matter how important that gain might be.\n		-- Spock, \"Journey to Babel\", stardate 3842.4\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (103,'\nIt is a human characteristic to love little animals, especially if\nthey\'re attractive in some way.\n		-- McCoy, \"The Trouble with Tribbles\", stardate 4525.6\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (104,'\nIt is more rational to sacrifice one life than six.\n		-- Spock, \"The Galileo Seven\", stardate 2822.3\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (105,'\nIt is necessary to have purpose.\n		-- Alice #1, \"I, Mudd\", stardate 4513.3\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (106,'\nIt is undignified for a woman to play servant to a man who is not\nhers.\n		-- Spock, \"Amok Time\", stardate 3372.7\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (107,'\nIt would be illogical to assume that all conditions remain stable\n		-- Spock, \"The Enterprise\" Incident\", stardate 5027.3\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (108,'\nIt would be illogical to kill without reason\n		-- Spock, \"Journey to Babel\", stardate 3842.4\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (109,'\nIt would seem that evil retreats when forcibly confronted\n		-- Yarnek of Excalbia, \"The Savage Curtain\", stardate 5906.5\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (110,'\n\"It\'s hard to believe that something which is neither seen nor felt can\ndo so much harm.\"\n\n\"That\'s true.  But an idea can\'t be seen or felt.  And that\'s what kept\nthe Troglytes in the mines all these centuries.  A mistaken idea.\"\n		-- Vanna and Kirk, \"The Cloud Minders\", stardate 5819.0\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (111,'\nKilling is stupid; useless!\n		-- McCoy, \"A Private Little War\", stardate 4211.8\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (112,'\nKilling is wrong.\n		-- Losira, \"That Which Survives\", stardate unknown\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (113,'\nKnowledge, sir, should be free to all!\n		-- Harry Mudd, \"I, Mudd\", stardate 4513.3\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (114,'\nLandru! Guide us!\n		-- A Beta 3-oid, \"The Return of the Archons\", stardate 3157.4\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (115,'\nLeave bigotry in your quarters; there\'s no room for it on the bridge.\n		-- Kirk, \"Balance of Terror\", stardate 1709.2\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (116,'\n\"Life and death are seldom logical.\"\n\"But attaining a desired goal always is.\"\n		-- McCoy and Spock, \"The Galileo Seven\", stardate 2821.7\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (117,'\nLive long and prosper.\n		-- Spock, \"Amok Time\", stardate 3372.7\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (118,'\n\"Logic and practical information do not seem to apply here.\"\n\"You admit that?\"\n\"To deny the facts would be illogical, Doctor\"\n		-- Spock and McCoy, \"A Piece of the Action\", stardate unknown\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (119,'\nLots of people drink from the wrong bottle sometimes.\n		-- Edith Keeler, \"The City on the Edge of Forever\",\n		   stardate unknown\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (120,'\nLove sometimes expresses itself in sacrifice.\n		-- Kirk, \"Metamorphosis\", stardate 3220.3\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (121,'\nMadness has no purpose.  Or reason.  But it may have a goal.\n		-- Spock, \"The Alternative Factor\", stardate 3088.7\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (122,'\nMany Myths are based on truth\n		-- Spock, \"The Way to Eden\",  stardate 5832.3\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (123,'\nMen don\'t talk peace unless they\'re ready to back it up with war.\n		-- Col. Green, \"The Savage Curtain\", stardate 5906.4\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (124,'\nMen of peace usually are [brave].\n		-- Spock, \"The Savage Curtain\", stardate 5906.5\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (125,'\nMen will always be men -- no matter where they are.\n		-- Harry Mudd, \"Mudd\'s Women\", stardate 1329.8\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (126,'\nMilitary secrets are the most fleeting of all.\n		-- Spock, \"The Enterprise Incident\", stardate 5027.4\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (127,'\nMost legends have their basis in facts.\n		-- Kirk, \"And The Children Shall Lead\", stardate 5029.5\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (128,'\nMurder is contrary to the laws of man and God.\n		-- M-5 Computer, \"The Ultimate Computer\", stardate 4731.3\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (129,'\nNo more blah, blah, blah!\n		-- Kirk, \"Miri\", stardate 2713.6\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (130,'\nNo one can guarantee the actions of another.\n		-- Spock, \"Day of the Dove\", stardate unknown\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (131,'\nNo one may kill a man.  Not for any purpose.  It cannot be condoned.\n		-- Kirk, \"Spock\'s Brain\", stardate 5431.6\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (132,'\n\"No one talks peace unless he\'s ready to back it up with war.\"\n\"He talks of peace if it is the only way to live.\"\n		-- Colonel Green and Surak of Vulcan, \"The Savage Curtain\",\n		   stardate 5906.5.\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (133,'\nNo one wants war.\n		-- Kirk, \"Errand of Mercy\", stardate 3201.7\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (134,'\nNo problem is insoluble.\n		-- Dr. Janet Wallace, \"The Deadly Years\", stardate 3479.4\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (135,'\nNot one hundred percent efficient, of course ... but nothing ever is.\n		-- Kirk, \"Metamorphosis\", stardate 3219.8\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (136,'\nOblivion together does not frighten me, beloved.\n		-- Thalassa (in Anne Mulhall\'s body), \"Return to Tomorrow\",\n		   stardate 4770.3.\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (137,'\nOh, that sound of male ego.  You travel halfway across the galaxy and\nit\'s still the same song.\n		-- Eve McHuron, \"Mudd\'s Women\", stardate 1330.1\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (138,'\nOn my planet, to rest is to rest -- to cease using energy.  To me, it\nis quite illogical to run up and down on green grass, using energy,\ninstead of saving it.\n		-- Spock, \"Shore Leave\", stardate 3025.2\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (139,'\nOne does not thank logic.\n		-- Sarek, \"Journey to Babel\", stardate 3842.4\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (140,'\nOne of the advantages of being a captain is being able to ask for\nadvice without necessarily having to take it.\n		-- Kirk, \"Dagger of the Mind\", stardate 2715.2\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (141,'\nOnly a fool fights in a burning house.\n		-- Kank the Klingon, \"Day of the Dove\", stardate unknown\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (142,'\nOur missions are peaceful -- not for conquest.  When we do battle, it\nis only because we have no choice.\n		-- Kirk, \"The Squire of Gothos\", stardate 2124.5\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (143,'\nOur way is peace.\n		-- Septimus, the Son Worshiper, \"Bread and Circuses\",\n		   stardate 4040.7.\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (144,'\nPain is a thing of the mind.  The mind can be controlled.\n		-- Spock, \"Operation -- Annihilate!\" stardate 3287.2\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (145,'\nPeace was the way.\n		-- Kirk, \"The City on the Edge of Forever\", stardate unknown\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (146,'\nPower is danger.\n		-- The Centurion, \"Balance of Terror\", stardate 1709.2\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (147,'\nPrepare for tomorrow -- get ready.\n		-- Edith Keeler, \"The City On the Edge of Forever\",\n		   stardate unknown\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (148,'\nPunishment becomes ineffective after a certain point.  Men become\ninsensitive.\n		-- Eneg, \"Patterns of Force\", stardate 2534.7\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (149,'\nRespect is a rational process\n		-- McCoy, \"The Galileo Seven\", stardate 2822.3\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (150,'\nRomulan women are not like Vulcan females.  We are not dedicated to\npure logic and the sterility of non-emotion.\n		-- Romulan Commander, \"The Enterprise Incident\",\n		   stardate 5027.3\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (151,'\nSchshschshchsch.\n		-- The Gorn, \"Arena\", stardate 3046.2\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (152,'\nSometimes a feeling is all we humans have to go on.\n		-- Kirk, \"A Taste of Armageddon\", stardate 3193.9\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (153,'\nSometimes a man will tell his bartender things he\'ll never tell his doctor.\n		-- Dr. Phillip Boyce, \"The Menagerie\" (\"The Cage\"),\n		   stardate unknown.\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (154,'\nStar Trek Lives!\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (155,'\nSuffocating together ... would create heroic camaraderie.\n		-- Khan Noonian Singh, \"Space Seed\", stardate 3142.8\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (156,'\nSuperior ability breeds superior ambition.\n		-- Spock, \"Space Seed\", stardate 3141.9\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (157,'\n\"That unit is a woman.\"\n\"A mass of conflicting impulses.\"\n		-- Spock and Nomad, \"The Changeling\", stardate 3541.9\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (158,'\n\"The combination of a number of things to make existence worthwhile.\"\n\"Yes, the philosophy of \'none,\' meaning \'all.\'\"\n		-- Spock and Lincoln, \"The Savage Curtain\", stardate 5906.4\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (159,'\nThe face of war has never changed.  Surely it is more logical to heal\nthan to kill.\n		-- Surak of Vulcan, \"The Savage Curtain\", stardate 5906.5\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (160,'\nThe games have always strengthened us.  Death becomes a familiar\npattern.  We don\'t fear it as you do.\n		-- Proconsul Marcus Claudius, \"Bread and Circuses\",\n		   stardate 4041.2\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (161,'\n\"The glory of creation is in its infinite diversity.\"\n\"And in the way our differences combine to create meaning and beauty.\"\n		-- Dr. Miranda Jones and Spock, \"Is There in Truth No Beauty?\",\n		   stardate 5630.8\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (162,'\nThe heart is not a logical organ.\n		-- Dr. Janet Wallace, \"The Deadly Years\", stardate 3479.4\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (163,'\nThe idea of male and female are universal constants.\n		-- Kirk, \"Metamorphosis\", stardate 3219.8\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (164,'\nThe joys of love made her human and the agonies of love destroyed her.\n		-- Spock, \"Requiem for Methuselah\", stardate 5842.8\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (165,'\nThe man on tops walks a lonely street; the \"chain\" of command is often\na noose.\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (166,'\nThe more complex the mind, the greater the need for the simplicity of\nplay.\n		-- Kirk, \"Shore Leave\", stardate 3025.8\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (167,'\nThe only solution is ... a balance of power.  We arm our side with\nexactly that much more.  A balance of power -- the trickiest, most\ndifficult, dirtiest game of them all.  But the only one that preserves\nboth sides.\n		-- Kirk, \"A Private Little War\", stardate 4211.8\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (168,'\nThe people of Gideon have always believed that life is sacred.  That\nthe love of life is the greatest gift ... We are incapable of\ndestroying or interfering with the creation of that which we love so\ndeeply -- life in every form from fetus to developed being.\n		-- Hodin of Gideon, \"The Mark of Gideon\", stardate 5423.4\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (169,'\n... The prejudices people feel about each other disappear when then get\nto know each other.\n		-- Kirk, \"Elaan of Troyius\", stardate 4372.5\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (170,'\n\"The release of emotion is what keeps us health.  Emotionally healthy.\"\n\n\"That may be, Doctor.  However, I have noted that the healthy release\nof emotion is frequently unhealthy for those closest to you.\"\n		-- McCoy and Spock, \"Plato\'s Stepchildren\", stardate 5784.3\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (171,'\nThe sight of death frightens them [Earthers].\n		-- Kras the Klingon, \"Friday\'s Child\", stardate 3497.2\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (172,'\nThe sooner our happiness together begins, the longer it will last.\n		-- Miramanee, \"The Paradise Syndrome\", stardate 4842.6\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (173,'\n... The things love can drive a man to -- the ecstasies, the\nthe miseries, the broken rules, the desperate chances, the glorious\nfailures and the glorious victories.\n		-- McCoy, \"Requiem for Methuselah\", stardate 5843.7\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (174,'\nThere are always alternatives.\n		-- Spock, \"The Galileo Seven\", stardate 2822.3\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (175,'\nThere are certain things men must do to remain men.\n		-- Kirk, \"The Ultimate Computer\", stardate 4929.4\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (176,'\nThere are some things worth dying for.\n		-- Kirk, \"Errand of Mercy\", stardate 3201.7\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (177,'\nThere comes to all races an ultimate crisis which you have yet to face\n.... One day our minds became so powerful we dared think of ourselves\nas gods.\n		-- Sargon, \"Return to Tomorrow\", stardate 4768.3\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (178,'\nThere is a multi-legged creature crawling on your shoulder.\n		-- Spock, \"A Taste of Armageddon\", stardate 3193.9\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (179,'\nThere is an old custom among my people.  When a woman saves a man\'s\nlife, he is grateful.\n		-- Nona, the Kanuto which woman, \"A Private Little War\",\n		   stardate 4211.8.\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (180,'\nThere is an order of things in this universe.\n		-- Apollo, \"Who Mourns for Adonais?\" stardate 3468.1\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (181,'\nThere\'s a way out of any cage.\n		-- Captain Christopher Pike, \"The Menagerie\" (\"The Cage\"),\n		   stardate unknown.\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (182,'\nThere\'s another way to survive.  Mutual trust -- and help.\n		-- Kirk, \"Day of the Dove\", stardate unknown\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (183,'\nThere\'s no honorable way to kill, no gentle way to destroy.  There is\nnothing good in war.  Except its ending.\n		-- Abraham Lincoln, \"The Savage Curtain\", stardate 5906.5\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (184,'\nThere\'s nothing disgusting about it [the Companion].  It\'s just another\nlife form, that\'s all.  You get used to those things.\n		-- McCoy, \"Metamorphosis\", stardate 3219.8\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (185,'\n\"There\'s only one kind of woman ...\"\n\"Or man, for that matter.  You either believe in yourself or you don\'t.\"\n		-- Kirk and Harry Mudd, \"Mudd\'s Women\", stardate 1330.1\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (186,'\nThis cultural mystique surrounding the biological function -- you\nrealize humans are overly preoccupied with the subject.\n		-- Kelinda the Kelvan, \"By Any Other Name\", stardate 4658.9\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (187,'\nThose who hate and fight must stop themselves -- otherwise it is not\nstopped.\n		-- Spock, \"Day of the Dove\", stardate unknown\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (188,'\nTime is fluid ... like a river with currents, eddies, backwash.\n		-- Spock, \"The City on the Edge of Forever\", stardate 3134.0\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (189,'\nTo live is always desirable.\n		-- Eleen the Capellan, \"Friday\'s Child\", stardate 3498.9\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (190,'\nToo much of anything, even love, isn\'t necessarily a good thing.\n		-- Kirk, \"The Trouble with Tribbles\", stardate 4525.6\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (191,'\nTotally illogical, there was no chance.\n		-- Spock, \"The Galileo Seven\", stardate 2822.3\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (192,'\nUncontrolled power will turn even saints into savages.  And we can all\nbe counted on to live down to our lowest impulses.\n		-- Parmen, \"Plato\'s Stepchildren\", stardate 5784.3\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (193,'\nViolence in reality is quite different from theory.\n		-- Spock, \"The Cloud Minders\", stardate 5818.4\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (194,'\nVirtue is a relative term.\n		-- Spock, \"Friday\'s Child\", stardate 3499.1\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (195,'\nVulcans believe peace should not depend on force.\n		-- Amanda, \"Journey to Babel\", stardate 3842.3\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (196,'\nVulcans do not approve of violence.\n		-- Spock, \"Journey to Babel\", stardate 3842.4\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (197,'\nVulcans never bluff.\n		-- Spock, \"The Doomsday Machine\", stardate 4202.1\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (198,'\nVulcans worship peace above all.\n		-- McCoy, \"Return to Tomorrow\", stardate 4768.3\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (199,'\nWait!  You have not been prepared!\n		-- Mr. Atoz, \"Tomorrow is Yesterday\", stardate 3113.2\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (200,'\nWar is never imperative.\n		-- McCoy, \"Balance of Terror\", stardate 1709.2\n','startrek');
INSERT INTO nuke_pnchatfortunes VALUES (201,'\nWar isn\'t a good life, but it\'s life.\n		-- Kirk, \"A Private Little War\", stardate 4211.8\n','startrek');

--
-- Table structure for table 'nuke_pnchathelp'
--

CREATE TABLE nuke_pnchathelp (
  pn_id bigint(20) unsigned NOT NULL auto_increment,
  pn_command varchar(20) NOT NULL default '',
  pn_info varchar(100) NOT NULL default '',
  pn_exp_help text NOT NULL,
  PRIMARY KEY  (pn_id)
) TYPE=MyISAM;

--
-- Dumping data for table 'nuke_pnchathelp'
--


INSERT INTO nuke_pnchathelp VALUES (1,'/color','/color #xxxxxx (HEX)','This command lets you set a custom color.<br><br>\r\n\r\nExample:<br><br>\r\n\r\n<b>/color #3AC208</b>');
INSERT INTO nuke_pnchathelp VALUES (2,'/me','/me [action]','\'/me is sick\' would be \'username is sick\'');
INSERT INTO nuke_pnchathelp VALUES (3,'/linux','/linux','Shows you the latest <a href=http://www.kernel.org TARGET=_blank>Linux kernel</A> versions.');
INSERT INTO nuke_pnchathelp VALUES (4,'/date','/date','Shows our server\'s date and time');
INSERT INTO nuke_pnchathelp VALUES (5,'/msg','/msg [username] [message]','send a private message to a user.<br><br>\r\n\r\nExample:<br><br>\r\n\r\n<b>/msg skeeve Hi Skeeve</b>');
INSERT INTO nuke_pnchathelp VALUES (6,'/userlist','/userlist','Shows a list of all users currently in your chatroom');
INSERT INTO nuke_pnchathelp VALUES (7,'/tech','/tech','Gives you details on the basic technology I use here!');
INSERT INTO nuke_pnchathelp VALUES (8,'/roomlist','/roomlist','Shows a list of all available chatrooms');
INSERT INTO nuke_pnchathelp VALUES (9,'/room','/room [roomname]','Jump to another room.<br><br>\r\n\r\nIf the room you enter is not existing the system will create it. You will become the room admin in that case.');
INSERT INTO nuke_pnchathelp VALUES (13,'/nick','/nick [nickname]','Change your nickname.<br>\r\nFor registered users the system will remember this nickname for your next visit.<br>\r\nFor guests the system will remember the new nickname as well as the entire user profile for about one hour.');
INSERT INTO nuke_pnchathelp VALUES (11,'/help','/help','Shows a brief help in the chat window');
INSERT INTO nuke_pnchathelp VALUES (12,'/fortune','/fortune','Show a random fortune fetched from a database.<br>\r\n<br>A fortune will also be displayed if you remain unactive for a certain time.');
INSERT INTO nuke_pnchathelp VALUES (14,'Username completion','adress another user easily','You can address other users easily by typing just their first letters:<br>\r\nExample: Username is \'Skeeve\'.<br>\r\nYou type \"s: this is a test\" will result in:\r\n\"Skeeve: this is a test\".<br>\r\nIf there\'s another username \"Scott\" and you still wanna address Skeeve then type: \"sk: test\".<br> Result: \"Skeeve: test\".');
INSERT INTO nuke_pnchathelp VALUES (15,'URL detection','URL detection','If you write an URL like www.your-domain.com somewhere in your text, the system will detect the URL and make it a link.');
INSERT INTO nuke_pnchathelp VALUES (16,'Smilies','Emoticons','<font class=\"content\">These are the smilies you can use:<br>\r\n<table border=0 cellspacing=3 cellpadding=2>\r\n<td align=center><img src=\"pnimages/smilies/icon_smile.gif\" border=\"0\" alt=\":-)\"></td>\r\n<td align=center><img src=\"pnimages/smilies/icon_frown.gif\" border=\"0\" alt=\":-(\"></td>\r\n<td align=center><img src=\"pnimages/smilies/icon_biggrin.gif\" border=\"0\" alt=\":-D\"></td>\r\n<td align=center><img src=\"pnimages/smilies/icon_wink.gif\" border=\"0\" alt=\";-)\"></td>\r\n<td align=center><img src=\"pnimages/smilies/icon_eek.gif\" border=\"0\" alt=\":-o\"></td>\r\n<td align=center><img src=\"pnimages/smilies/icon_cool.gif\" border=\"0\" alt=\"8-)\"></td>\r\n<td align=center><img src=\"pnimages/smilies/icon_confused.gif\" border=\"0\" alt=\":-?\"></td>\r\n<td align=center><img src=\"pnimages/smilies/icon_razz.gif\" border=\"0\" alt=\":-P\"></td>\r\n<td align=center><img src=\"pnimages/smilies/icon_mad.gif\" border=\"0\" alt=\":-|\"></td>\r\n<td align=center><img src=\"pnimages/smilies/icon_arrow.gif\" border=\"0\" alt=\":-Z\"></td>\r\n<td align=center><img src=\"pnimages/smilies/icon_exclaim.gif\" border=\"0\" alt=\":-W\"></td>\r\n<td align=center><img src=\"pnimages/smilies/icon_evil.gif\" border=\"0\" alt=\":-Y\"></td>\r\n<td align=center><img src=\"pnimages/smilies/icon_cry.gif\" border=\"0\" alt=\":-[\"></td>\r\n<td align=center><img src=\"pnimages/smilies/icon_cheesygrin.gif\" border=\"0\" alt=\":-]\"></td>\r\n<td align=center><img src=\"pnimages/smilies/icon50.gif\" border=\"0\" alt=\"(b)\"></td>\r\n<td align=center><img src=\"pnimages/smilies/icon51.gif\" border=\"0\" alt=\"(c)\"></td>\r\n<tr>\r\n<td align=center bgcolor=#cccccc>:-)</td>\r\n<td align=center bgcolor=#cccccc>:-(</td>\r\n<td align=center bgcolor=#cccccc>:-D</td>\r\n<td align=center bgcolor=#cccccc>;-)</td>\r\n<td align=center bgcolor=#cccccc>:-o</td>\r\n<td align=center bgcolor=#cccccc>8-)</td>\r\n<td align=center bgcolor=#cccccc>:-?</td>\r\n<td align=center bgcolor=#cccccc>:-P</td>\r\n<td align=center bgcolor=#cccccc>:-|</td>\r\n<td align=center bgcolor=#cccccc>:-Z</td>\r\n<td align=center bgcolor=#cccccc>:-W</td>\r\n<td align=center bgcolor=#cccccc>:-Y</td>\r\n<td align=center bgcolor=#cccccc>:-[</td>\r\n<td align=center bgcolor=#cccccc>:-]</td>\r\n<td align=center bgcolor=#cccccc>(b)</td>\r\n<td align=center bgcolor=#cccccc>(c)</td>\r\n</table>\r\n');
INSERT INTO nuke_pnchathelp VALUES (17,'Color Picker','Choose any color you\'d like','To choose a color you simply click anywhere inside the color picker. The area to the right of the color picker will show the color you\'ve clicked on.<br><br>\r\nNow click on this area and your chat color will change accordingly.<br><br>\r\nThe <i>color picker code</i> was created by <a href=mailto:color@megaverse.de><b>hacker</b></a>! Thanks for that!');
INSERT INTO nuke_pnchathelp VALUES (18,'/load','Shows server load','/load will show you the current server load. This will only work on Linux servers because it uses the \"uptime\" command to get the information.\r\n\r\nOn the Linux server that hosts pnchat.org there is much more stuff running so don\'t take the server load you see here to be completely caused by the chat itself.');
INSERT INTO nuke_pnchathelp VALUES (19,'/bold','Switch bold on and off','/bold 1 will switch bold on<br><br>\r\n/bold 0 will switch it off.');

--
-- Table structure for table 'nuke_pnchatlayout'
--

CREATE TABLE nuke_pnchatlayout (
  pn_id bigint(20) unsigned NOT NULL default '0',
  pn_bgcolor_main varchar(7) NOT NULL default '',
  pn_bgcolor_input varchar(7) NOT NULL default '',
  pn_bgcolor_userinfo varchar(7) NOT NULL default '',
  pn_td_bgcolor_userinfo varchar(7) NOT NULL default '',
  pn_fgcolor_main varchar(7) NOT NULL default '',
  pn_fgcolor_input varchar(7) NOT NULL default '',
  pn_fgcolor_userinfo varchar(7) NOT NULL default '',
  pn_font_main varchar(20) NOT NULL default '',
  pn_font_input varchar(20) NOT NULL default '',
  pn_font_userinfo varchar(20) NOT NULL default '',
  pn_td_content_bgcolor_userinfo varchar(7) NOT NULL default '',
  pn_font_main_size tinyint(4) NOT NULL default '0',
  PRIMARY KEY  (pn_id)
) TYPE=MyISAM;

--
-- Dumping data for table 'nuke_pnchatlayout'
--


INSERT INTO nuke_pnchatlayout VALUES (0,'#c0c0c0','#b0b0b0','#d0d0d0','#f0f0f0','#000000','#000000','#000000','arial','arial','Verdana,Helvetica','#e0e0e0',2);

--
-- Table structure for table 'nuke_pnchatrooms'
--

CREATE TABLE nuke_pnchatrooms (
  pn_id bigint(20) unsigned NOT NULL auto_increment,
  pn_room char(20) NOT NULL default '',
  pn_description char(160) NOT NULL default '',
  pn_created_by char(20) NOT NULL default '',
  PRIMARY KEY  (pn_id)
) TYPE=MyISAM;

--
-- Dumping data for table 'nuke_pnchatrooms'
--


INSERT INTO nuke_pnchatrooms VALUES (1,'Lobby','Main chat room','');
INSERT INTO nuke_pnchatrooms VALUES (2,'IDEAS','Description','');

--
-- Table structure for table 'nuke_pnchatter'
--

CREATE TABLE nuke_pnchatter (
  pn_id bigint(20) unsigned NOT NULL auto_increment,
  pn_nuke_id bigint(20) NOT NULL default '0',
  pn_SID char(64) NOT NULL default '',
  pn_alias char(20) NOT NULL default '',
  pn_color char(7) NOT NULL default '',
  pn_secure_mode tinyint(4) NOT NULL default '0',
  pn_smilies tinyint(4) NOT NULL default '0',
  pn_kicked tinyint(4) NOT NULL default '0',
  pn_banned tinyint(4) NOT NULL default '0',
  pn_away tinyint(4) NOT NULL default '0',
  pn_login_timestamp datetime default NULL,
  pn_inactive_timestamp datetime default NULL,
  pn_fortune_cookies tinyint(4) NOT NULL default '0',
  pn_is_guest tinyint(4) NOT NULL default '0',
  pn_room int(11) NOT NULL default '0',
  pn_is_admin tinyint(4) NOT NULL default '0',
  pn_admin_level int(11) NOT NULL default '0',
  pn_is_chatting tinyint(4) NOT NULL default '0',
  pn_is_bold tinyint(4) NOT NULL default '0',
  PRIMARY KEY  (pn_id)
) TYPE=MyISAM;

--
-- Dumping data for table 'nuke_pnchatter'
--


INSERT INTO nuke_pnchatter VALUES (1,0,'','blahhh','#ff0000',0,0,0,0,0,'2003-07-14 16:48:35','2003-07-14 16:47:55',1,1,0,0,0,0,0);
INSERT INTO nuke_pnchatter VALUES (2,0,'8474263d0c8003f2bde239800612a228','Guest1','#0c0b70',0,0,0,0,0,'2003-07-14 15:08:53','2003-07-14 17:22:51',1,1,1,0,0,1,0);
INSERT INTO nuke_pnchatter VALUES (3,2,'8474263d0c8003f2bde239800612a228','Admin','#f00f00',0,0,0,0,0,'2003-07-15 10:34:01','2003-07-15 10:33:21',1,0,0,0,0,0,0);
INSERT INTO nuke_pnchatter VALUES (4,0,'e5eb590b4e24d589d36e76de9fcdf958','Guest2','#0c0b70',0,0,0,0,0,'2003-07-14 16:17:45','2003-07-14 16:40:34',1,1,1,0,0,1,0);
INSERT INTO nuke_pnchatter VALUES (5,5,'e5eb590b4e24d589d36e76de9fcdf958','rexlunae','#44aaff',0,0,0,0,0,'2003-07-14 16:28:54','2003-07-14 16:28:54',1,0,1,0,0,1,0);
INSERT INTO nuke_pnchatter VALUES (6,7,'8474263d0c8003f2bde239800612a228','nukeman','#44aaff',0,0,0,0,0,'2003-07-14 17:40:22','2003-07-14 17:39:42',1,0,1,0,0,0,0);
INSERT INTO nuke_pnchatter VALUES (7,6,'7ae9cc9492dea25086db050f58aa9787','blah','#44aaff',0,0,0,0,0,'2003-07-15 10:22:55','2003-07-15 10:22:55',1,0,1,0,0,1,0);

--
-- Table structure for table 'nuke_poll_check'
--

CREATE TABLE nuke_poll_check (
  pn_ip varchar(20) NOT NULL default '',
  pn_time varchar(14) NOT NULL default ''
) TYPE=MyISAM;

--
-- Dumping data for table 'nuke_poll_check'
--



--
-- Table structure for table 'nuke_poll_data'
--

CREATE TABLE nuke_poll_data (
  pn_pollid int(11) NOT NULL default '0',
  pn_optiontext char(50) NOT NULL default '',
  pn_optioncount int(11) NOT NULL default '0',
  pn_voteid int(11) NOT NULL default '0'
) TYPE=MyISAM;

--
-- Dumping data for table 'nuke_poll_data'
--



--
-- Table structure for table 'nuke_poll_desc'
--

CREATE TABLE nuke_poll_desc (
  pn_pollid int(11) NOT NULL auto_increment,
  pn_title varchar(100) NOT NULL default '',
  pn_timestamp int(11) NOT NULL default '0',
  pn_voters mediumint(9) NOT NULL default '0',
  pn_language varchar(30) NOT NULL default '',
  PRIMARY KEY  (pn_pollid)
) TYPE=MyISAM;

--
-- Dumping data for table 'nuke_poll_desc'
--



--
-- Table structure for table 'nuke_pollcomments'
--

CREATE TABLE nuke_pollcomments (
  pn_tid int(11) NOT NULL auto_increment,
  pn_pid int(11) default '0',
  pn_pollid int(11) default '0',
  pn_date datetime default NULL,
  pn_name varchar(60) NOT NULL default '',
  pn_email varchar(60) default NULL,
  pn_url varchar(254) default NULL,
  pn_host_name varchar(60) default NULL,
  pn_subject varchar(60) NOT NULL default '',
  pn_comment text NOT NULL,
  pn_score tinyint(4) NOT NULL default '0',
  pn_reason tinyint(4) NOT NULL default '0',
  PRIMARY KEY  (pn_tid)
) TYPE=MyISAM;

--
-- Dumping data for table 'nuke_pollcomments'
--



--
-- Table structure for table 'nuke_postcalendar_categories'
--

CREATE TABLE nuke_postcalendar_categories (
  pc_catid int(11) unsigned NOT NULL auto_increment,
  pc_catname varchar(100) NOT NULL default 'Undefined',
  pc_catcolor varchar(50) NOT NULL default '#FF0000',
  pc_catdesc text,
  PRIMARY KEY  (pc_catid),
  KEY basic_cat (pc_catname,pc_catcolor)
) TYPE=MyISAM;

--
-- Dumping data for table 'nuke_postcalendar_categories'
--


INSERT INTO nuke_postcalendar_categories VALUES (1,'Default','#ff0000','Default Category');

--
-- Table structure for table 'nuke_postcalendar_events'
--

CREATE TABLE nuke_postcalendar_events (
  pc_eid int(11) unsigned NOT NULL auto_increment,
  pc_catid int(11) NOT NULL default '0',
  pc_aid varchar(30) NOT NULL default '',
  pc_title varchar(150) default '',
  pc_time datetime default NULL,
  pc_hometext text,
  pc_comments int(11) default '0',
  pc_counter mediumint(8) unsigned default '0',
  pc_topic int(3) NOT NULL default '1',
  pc_informant varchar(20) NOT NULL default '',
  pc_eventDate date NOT NULL default '0000-00-00',
  pc_endDate date NOT NULL default '0000-00-00',
  pc_duration bigint(20) NOT NULL default '0',
  pc_recurrtype int(1) NOT NULL default '0',
  pc_recurrspec text,
  pc_recurrfreq int(3) NOT NULL default '0',
  pc_startTime time default NULL,
  pc_endTime time default NULL,
  pc_alldayevent int(1) NOT NULL default '0',
  pc_location text,
  pc_conttel varchar(50) default '',
  pc_contname varchar(50) default '',
  pc_contemail varchar(255) default '',
  pc_website varchar(255) default '',
  pc_fee varchar(50) default '',
  pc_eventstatus int(11) NOT NULL default '0',
  pc_sharing int(11) NOT NULL default '0',
  pc_language varchar(30) default '',
  PRIMARY KEY  (pc_eid),
  KEY basic_event (pc_catid,pc_aid,pc_eventDate,pc_endDate,pc_eventstatus,pc_sharing,pc_topic)
) TYPE=MyISAM;

--
-- Dumping data for table 'nuke_postcalendar_events'
--


INSERT INTO nuke_postcalendar_events VALUES (7,1,'2','The IDEAS-3 Project Begins','2003-07-22 16:06:18',':text:The IDEAS-3 Project begins today.',0,0,0,'Admin','2003-08-15','0000-00-00',0,0,'a:5:{s:17:\"event_repeat_freq\";s:1:\"1\";s:22:\"event_repeat_freq_type\";s:1:\"0\";s:19:\"event_repeat_on_num\";s:1:\"1\";s:19:\"event_repeat_on_day\";s:1:\"0\";s:20:\"event_repeat_on_freq\";s:1:\"1\";}',0,'01:00:00',NULL,1,'a:6:{s:14:\"event_location\";s:0:\"\";s:13:\"event_street1\";s:0:\"\";s:13:\"event_street2\";s:0:\"\";s:10:\"event_city\";s:0:\"\";s:11:\"event_state\";s:0:\"\";s:12:\"event_postal\";s:0:\"\";}','','','','','',1,3,'');
INSERT INTO nuke_postcalendar_events VALUES (8,1,'16','The IDEAS-3 Project Ends','2003-07-22 16:07:18',':text:The IDEAS-3 project ends today.',0,0,7,'Admin','2003-09-22','0000-00-00',0,0,'a:5:{s:17:\"event_repeat_freq\";s:1:\"1\";s:22:\"event_repeat_freq_type\";s:1:\"0\";s:19:\"event_repeat_on_num\";s:1:\"1\";s:19:\"event_repeat_on_day\";s:1:\"0\";s:20:\"event_repeat_on_freq\";s:1:\"1\";}',0,'01:00:00',NULL,1,'a:6:{s:14:\"event_location\";s:0:\"\";s:13:\"event_street1\";s:0:\"\";s:13:\"event_street2\";s:0:\"\";s:10:\"event_city\";s:0:\"\";s:11:\"event_state\";s:0:\"\";s:12:\"event_postal\";s:0:\"\";}','','','','','',1,3,'');
INSERT INTO nuke_postcalendar_events VALUES (9,1,'2','Meeting','2003-07-23 13:58:41',':text:the meeting.',0,0,0,'Admin','2003-07-23','0000-00-00',0,0,'a:5:{s:17:\"event_repeat_freq\";s:1:\"1\";s:22:\"event_repeat_freq_type\";s:1:\"0\";s:19:\"event_repeat_on_num\";s:1:\"1\";s:19:\"event_repeat_on_day\";s:1:\"0\";s:20:\"event_repeat_on_freq\";s:1:\"1\";}',0,'01:00:00',NULL,0,'a:6:{s:14:\"event_location\";s:0:\"\";s:13:\"event_street1\";s:0:\"\";s:13:\"event_street2\";s:0:\"\";s:10:\"event_city\";s:0:\"\";s:11:\"event_state\";s:0:\"\";s:12:\"event_postal\";s:0:\"\";}','','','','','',1,3,'');
INSERT INTO nuke_postcalendar_events VALUES (11,1,'16','Planning Meeting','2003-07-30 14:12:52',':text:Planning Meeting and Kickoff\r\n\r\nThere will be a flight planning/status meeting on 12 August at 9:00 a.m.\r\nin the RAF conference room to discuss the status of the systems and\r\nreview the flight plans, coordinate everyone\'s objectives for the first\r\nflight, and plan the first IDEAS mission for Friday (15 August) or\r\nMonday (18 August).\r\n                                                                                                       \r\nWe will also go over the IDEAS support system (web pages), and proposed\r\nactivities (e.g., weekly science meetings, etc.).  The meeting will\r\nlast two to three hours.  After the meeting we will schedule a safety\r\nbriefing, which will last another two hours or so (probably after\r\nlunch, unless we can get the first meeting done quickly).  We hope to\r\nhave most of the first IDEAS participants at this meeting, but if you\r\ncannot make it, let us know what you would like brought to the meeting\r\nand we will try and cover it for you.\r\n',0,0,6,'stither','2003-08-12','0000-00-00',10800,0,'a:5:{s:17:\"event_repeat_freq\";s:1:\"1\";s:22:\"event_repeat_freq_type\";s:1:\"0\";s:19:\"event_repeat_on_num\";s:1:\"1\";s:19:\"event_repeat_on_day\";s:1:\"0\";s:20:\"event_repeat_on_freq\";s:1:\"1\";}',0,'09:00:00',NULL,0,'a:6:{s:14:\"event_location\";s:0:\"\";s:13:\"event_street1\";s:0:\"\";s:13:\"event_street2\";s:0:\"\";s:10:\"event_city\";s:0:\"\";s:11:\"event_state\";s:0:\"\";s:12:\"event_postal\";s:0:\"\";}','','','','','',1,3,'');
INSERT INTO nuke_postcalendar_events VALUES (12,1,'16','RAF Seminar','2003-08-07 16:18:31',':text:Microphysical Cloud Parameter Measurements by Dagmar Nagel\r\n\r\nIn situ measurement probes as used since more than 25 years have been investigated according to their measurement accuracy. One important precondition for high-quality measurements is a good calibration. A second important influence factor on airborne measurements is EMI produced by the aircraft. And last but not least, In situ measurements in the air, especially from a moving platform, are always influenced by the probe shape. Results from our work to all three aspects will be presented.\r\n\r\nThe new calibration technique developed at GKSS guarantees a much better accuracy than usual procedures in the sizing of cloud particles and due to the adjustment to real aircraft speed an increased overall accuracy for the determination of parameters like concentration and liquid water content.\r\n\r\nWind tunnel tests and real measurements in clouds showed a strong influence of the probe shape on the measured size distribution and on the concentration of cloud particles. First results from measurements in natural clouds with a new styled probe will be presented and discussed.\r\n\r\nDuring more than ten years of In situ measurements with aircraft the GKSS particle measurement group was able to get a lot of experience with EMI in aircraft and how it disturbs measurements with high sensitive optical probes. Principals have been developed to avoid undesirable effects of EMI. The presentation will give a rough overview about this techniques which have been used successfully several times on many German and other research aircraft.',0,0,10,'ruth','2003-08-15','0000-00-00',3600,0,'a:5:{s:17:\"event_repeat_freq\";s:1:\"1\";s:22:\"event_repeat_freq_type\";s:1:\"0\";s:19:\"event_repeat_on_num\";s:1:\"1\";s:19:\"event_repeat_on_day\";s:1:\"0\";s:20:\"event_repeat_on_freq\";s:1:\"1\";}',0,'09:30:00',NULL,0,'a:6:{s:14:\"event_location\";s:19:\"RAF Conference Room\";s:13:\"event_street1\";s:0:\"\";s:13:\"event_street2\";s:0:\"\";s:10:\"event_city\";s:0:\"\";s:11:\"event_state\";s:0:\"\";s:12:\"event_postal\";s:0:\"\";}','','','','','',1,3,'');
INSERT INTO nuke_postcalendar_events VALUES (14,1,'17','IDEAS-3 Web Users','2003-08-12 16:13:13',':text:Discuss IDEAS-3 Web Site\r\n  Operational status\r\n  Additions/changes\r\n  Likes/Dislikes',0,0,5,'ruth','2003-08-22','0000-00-00',3600,0,'a:5:{s:17:\"event_repeat_freq\";s:1:\"1\";s:22:\"event_repeat_freq_type\";s:1:\"0\";s:19:\"event_repeat_on_num\";s:1:\"1\";s:19:\"event_repeat_on_day\";s:1:\"0\";s:20:\"event_repeat_on_freq\";s:1:\"1\";}',0,'10:00:00',NULL,0,'a:6:{s:14:\"event_location\";s:0:\"\";s:13:\"event_street1\";s:0:\"\";s:13:\"event_street2\";s:0:\"\";s:10:\"event_city\";s:0:\"\";s:11:\"event_state\";s:0:\"\";s:12:\"event_postal\";s:0:\"\";}','','','','','',1,3,'');
INSERT INTO nuke_postcalendar_events VALUES (19,1,'15','First Flight','2003-08-19 11:38:45',':text:The first IDEAS research flight is now scheduled for 15:00 today, Tuesday August 19.     Preflight planning will be at 14:00 in the RAF conference room.  We plan a flight to sample clouds at various altitudes.  ',0,0,7,'stith','2003-08-19','0000-00-00',0,0,'a:5:{s:17:\"event_repeat_freq\";s:1:\"1\";s:22:\"event_repeat_freq_type\";s:1:\"0\";s:19:\"event_repeat_on_num\";s:1:\"1\";s:19:\"event_repeat_on_day\";s:1:\"0\";s:20:\"event_repeat_on_freq\";s:1:\"1\";}',0,'01:00:00',NULL,0,'a:6:{s:14:\"event_location\";s:0:\"\";s:13:\"event_street1\";s:0:\"\";s:13:\"event_street2\";s:0:\"\";s:10:\"event_city\";s:0:\"\";s:11:\"event_state\";s:0:\"\";s:12:\"event_postal\";s:0:\"\";}','','','','','',1,1,'');
INSERT INTO nuke_postcalendar_events VALUES (17,1,'16','First Flight','2003-08-13 13:55:55',':text:The first flight in the IDEAS-3 project.',0,0,7,'stither','2003-08-19','0000-00-00',18000,0,'a:5:{s:17:\"event_repeat_freq\";s:1:\"1\";s:22:\"event_repeat_freq_type\";s:1:\"0\";s:19:\"event_repeat_on_num\";s:1:\"1\";s:19:\"event_repeat_on_day\";s:1:\"0\";s:20:\"event_repeat_on_freq\";s:1:\"1\";}',0,'13:00:00',NULL,0,'a:6:{s:14:\"event_location\";s:5:\"C-130\";s:13:\"event_street1\";s:0:\"\";s:13:\"event_street2\";s:0:\"\";s:10:\"event_city\";s:0:\"\";s:11:\"event_state\";s:0:\"\";s:12:\"event_postal\";s:0:\"\";}','','','','','',1,3,'');
INSERT INTO nuke_postcalendar_events VALUES (18,1,'19','\"Shake-and-Bake\" flight','2003-08-13 15:26:15',':text:A brief test flight will tentatively be scheduled for Monday 18 August, with the departure time to be decided later.\r\n\r\nThe purpose of the test flight is merely to test functionality of a number of probes. Scientific objectives will be pursued on later mission flights, beginning Tuesday 19 August.',0,0,7,'jbj','2003-08-18','0000-00-00',3600,0,'a:5:{s:17:\"event_repeat_freq\";s:1:\"1\";s:22:\"event_repeat_freq_type\";s:1:\"0\";s:19:\"event_repeat_on_num\";s:1:\"1\";s:19:\"event_repeat_on_day\";s:1:\"0\";s:20:\"event_repeat_on_freq\";s:1:\"1\";}',0,'01:00:00',NULL,0,'a:6:{s:14:\"event_location\";s:0:\"\";s:13:\"event_street1\";s:0:\"\";s:13:\"event_street2\";s:0:\"\";s:10:\"event_city\";s:0:\"\";s:11:\"event_state\";s:0:\"\";s:12:\"event_postal\";s:0:\"\";}','','','','','',1,3,'');
INSERT INTO nuke_postcalendar_events VALUES (20,1,'17','Science Meeting','2003-08-20 17:20:02',':text:Please be prepared to talk for 5-10 minutes about you data, and show us all your interesting results!',0,0,7,'ruth','2003-08-21','0000-00-00',3600,0,'a:5:{s:17:\"event_repeat_freq\";s:1:\"1\";s:22:\"event_repeat_freq_type\";s:1:\"0\";s:19:\"event_repeat_on_num\";s:1:\"1\";s:19:\"event_repeat_on_day\";s:1:\"0\";s:20:\"event_repeat_on_freq\";s:1:\"1\";}',0,'13:30:00',NULL,0,'a:6:{s:14:\"event_location\";s:22:\"Jeffco conference room\";s:13:\"event_street1\";s:0:\"\";s:13:\"event_street2\";s:0:\"\";s:10:\"event_city\";s:0:\"\";s:11:\"event_state\";s:0:\"\";s:12:\"event_postal\";s:0:\"\";}','','','','','',1,3,'');
INSERT INTO nuke_postcalendar_events VALUES (21,1,'17','RF02','2003-08-21 16:54:19',':text:Short Research Flight, estimated takeoff time 8:30 a.m.',0,0,7,'ruth','2003-08-22','0000-00-00',3600,0,'a:5:{s:17:\"event_repeat_freq\";s:1:\"1\";s:22:\"event_repeat_freq_type\";s:1:\"0\";s:19:\"event_repeat_on_num\";s:1:\"1\";s:19:\"event_repeat_on_day\";s:1:\"0\";s:20:\"event_repeat_on_freq\";s:1:\"1\";}',0,'08:30:00',NULL,0,'a:6:{s:14:\"event_location\";s:0:\"\";s:13:\"event_street1\";s:0:\"\";s:13:\"event_street2\";s:0:\"\";s:10:\"event_city\";s:0:\"\";s:11:\"event_state\";s:0:\"\";s:12:\"event_postal\";s:0:\"\";}','','','','','',1,3,'');
INSERT INTO nuke_postcalendar_events VALUES (22,1,'17','RF03','2003-08-21 16:56:12',':text:Research Flight , estimated takeoff time 1:00 p.m.',0,0,7,'ruth','2003-08-26','0000-00-00',10800,0,'a:5:{s:17:\"event_repeat_freq\";s:1:\"1\";s:22:\"event_repeat_freq_type\";s:1:\"0\";s:19:\"event_repeat_on_num\";s:1:\"1\";s:19:\"event_repeat_on_day\";s:1:\"0\";s:20:\"event_repeat_on_freq\";s:1:\"1\";}',0,'13:00:00',NULL,0,'a:6:{s:14:\"event_location\";s:0:\"\";s:13:\"event_street1\";s:0:\"\";s:13:\"event_street2\";s:0:\"\";s:10:\"event_city\";s:0:\"\";s:11:\"event_state\";s:0:\"\";s:12:\"event_postal\";s:0:\"\";}','','','','','',1,3,'');
INSERT INTO nuke_postcalendar_events VALUES (29,1,'17','RF04','2003-08-27 11:24:21',':text:Research Flight #4',0,0,7,'ruth','2003-08-29','0000-00-00',10800,0,'a:5:{s:17:\"event_repeat_freq\";s:1:\"1\";s:22:\"event_repeat_freq_type\";s:1:\"0\";s:19:\"event_repeat_on_num\";s:1:\"1\";s:19:\"event_repeat_on_day\";s:1:\"0\";s:20:\"event_repeat_on_freq\";s:1:\"1\";}',0,'13:00:00',NULL,0,'a:6:{s:14:\"event_location\";s:6:\"Jeffco\";s:13:\"event_street1\";s:0:\"\";s:13:\"event_street2\";s:0:\"\";s:10:\"event_city\";s:0:\"\";s:11:\"event_state\";s:0:\"\";s:12:\"event_postal\";s:0:\"\";}','','','','','',1,3,'');
INSERT INTO nuke_postcalendar_events VALUES (24,1,'17','IDEAS-3 Web Users','2003-08-25 14:05:45',':text:Discuss IDEAS-3 Web Site\r\n  Operational status\r\n  Additions/changes\r\n  Likes/Dislikes',0,0,7,'ruth','2003-08-28','0000-00-00',3600,0,'a:5:{s:17:\"event_repeat_freq\";s:1:\"1\";s:22:\"event_repeat_freq_type\";s:1:\"0\";s:19:\"event_repeat_on_num\";s:1:\"1\";s:19:\"event_repeat_on_day\";s:1:\"0\";s:20:\"event_repeat_on_freq\";s:1:\"1\";}',0,'15:00:00',NULL,0,'a:6:{s:14:\"event_location\";s:0:\"\";s:13:\"event_street1\";s:0:\"\";s:13:\"event_street2\";s:0:\"\";s:10:\"event_city\";s:0:\"\";s:11:\"event_state\";s:0:\"\";s:12:\"event_postal\";s:0:\"\";}','','','','','',1,3,'');
INSERT INTO nuke_postcalendar_events VALUES (25,1,'17','RF03 PreFlight Briefing','2003-08-25 15:00:58',':text:Flight plan\r\nEquipment status',0,0,7,'ruth','2003-08-26','0000-00-00',0,0,'a:5:{s:17:\"event_repeat_freq\";s:1:\"1\";s:22:\"event_repeat_freq_type\";s:1:\"0\";s:19:\"event_repeat_on_num\";s:1:\"1\";s:19:\"event_repeat_on_day\";s:1:\"0\";s:20:\"event_repeat_on_freq\";s:1:\"1\";}',0,'09:00:00',NULL,0,'a:6:{s:14:\"event_location\";s:22:\"Jeffco Conference Room\";s:13:\"event_street1\";s:0:\"\";s:13:\"event_street2\";s:0:\"\";s:10:\"event_city\";s:0:\"\";s:11:\"event_state\";s:0:\"\";s:12:\"event_postal\";s:0:\"\";}','','','','','',1,3,'');
INSERT INTO nuke_postcalendar_events VALUES (34,1,'17','RF06','2003-09-02 17:31:23',':text:Approximately 2 to 5 hour flight, depending on cloud type and availability',0,0,7,'ruth','2003-09-05','0000-00-00',18000,0,'a:5:{s:17:\"event_repeat_freq\";s:1:\"1\";s:22:\"event_repeat_freq_type\";s:1:\"0\";s:19:\"event_repeat_on_num\";s:1:\"1\";s:19:\"event_repeat_on_day\";s:1:\"0\";s:20:\"event_repeat_on_freq\";s:1:\"1\";}',0,'13:00:00',NULL,0,'a:6:{s:14:\"event_location\";s:6:\"Jeffco\";s:13:\"event_street1\";s:0:\"\";s:13:\"event_street2\";s:0:\"\";s:10:\"event_city\";s:0:\"\";s:11:\"event_state\";s:0:\"\";s:12:\"event_postal\";s:0:\"\";}','','','','','',1,3,'');
INSERT INTO nuke_postcalendar_events VALUES (31,1,'17','RF05','2003-08-29 09:54:58',':text:Research Flight 5\r\nI09:00 TakeOff.   Good chance to sample the  urban plume just after rush hour',0,0,7,'ruth','2003-09-04','0000-00-00',7200,0,'a:5:{s:17:\"event_repeat_freq\";s:1:\"1\";s:22:\"event_repeat_freq_type\";s:1:\"0\";s:19:\"event_repeat_on_num\";s:1:\"1\";s:19:\"event_repeat_on_day\";s:1:\"0\";s:20:\"event_repeat_on_freq\";s:1:\"1\";}',0,'09:00:00',NULL,0,'a:6:{s:14:\"event_location\";s:6:\"Jeffco\";s:13:\"event_street1\";s:0:\"\";s:13:\"event_street2\";s:0:\"\";s:10:\"event_city\";s:0:\"\";s:11:\"event_state\";s:0:\"\";s:12:\"event_postal\";s:0:\"\";}','','','','','',1,3,'');
INSERT INTO nuke_postcalendar_events VALUES (27,1,'17','Labor Day','2003-08-26 16:29:30',':text:NCAR (and National) Holiday',0,0,7,'ruth','2003-09-01','0000-00-00',0,0,'a:5:{s:17:\"event_repeat_freq\";s:1:\"1\";s:22:\"event_repeat_freq_type\";s:1:\"0\";s:19:\"event_repeat_on_num\";s:1:\"1\";s:19:\"event_repeat_on_day\";s:1:\"0\";s:20:\"event_repeat_on_freq\";s:1:\"1\";}',0,'01:00:00',NULL,1,'a:6:{s:14:\"event_location\";s:23:\"Wherever you want to be\";s:13:\"event_street1\";s:0:\"\";s:13:\"event_street2\";s:0:\"\";s:10:\"event_city\";s:0:\"\";s:11:\"event_state\";s:0:\"\";s:12:\"event_postal\";s:0:\"\";}','','','','','',1,3,'');
INSERT INTO nuke_postcalendar_events VALUES (28,1,'17','IDEAS-3 Science Meeting','2003-08-27 09:58:52',':text:Informally present and discuss instrument performance, data acquired and results obtained',0,0,6,'ruth','2003-08-28','0000-00-00',3600,0,'a:5:{s:17:\"event_repeat_freq\";s:1:\"1\";s:22:\"event_repeat_freq_type\";s:1:\"0\";s:19:\"event_repeat_on_num\";s:1:\"1\";s:19:\"event_repeat_on_day\";s:1:\"0\";s:20:\"event_repeat_on_freq\";s:1:\"1\";}',0,'14:00:00',NULL,0,'a:6:{s:14:\"event_location\";s:22:\"Jeffco Conference Room\";s:13:\"event_street1\";s:0:\"\";s:13:\"event_street2\";s:0:\"\";s:10:\"event_city\";s:0:\"\";s:11:\"event_state\";s:0:\"\";s:12:\"event_postal\";s:0:\"\";}','','','','','',1,3,'');
INSERT INTO nuke_postcalendar_events VALUES (32,1,'17','RF05 Briefing','2003-08-29 09:57:52',':text:Research Flight 5 briefing and flight-plan meeting',0,0,7,'ruth','2003-09-02','0000-00-00',1800,0,'a:5:{s:17:\"event_repeat_freq\";s:1:\"1\";s:22:\"event_repeat_freq_type\";s:1:\"0\";s:19:\"event_repeat_on_num\";s:1:\"1\";s:19:\"event_repeat_on_day\";s:1:\"0\";s:20:\"event_repeat_on_freq\";s:1:\"1\";}',0,'16:00:00',NULL,0,'a:6:{s:14:\"event_location\";s:22:\"Jeffco Conference Room\";s:13:\"event_street1\";s:0:\"\";s:13:\"event_street2\";s:0:\"\";s:10:\"event_city\";s:0:\"\";s:11:\"event_state\";s:0:\"\";s:12:\"event_postal\";s:0:\"\";}','','','','','',1,3,'');
INSERT INTO nuke_postcalendar_events VALUES (35,1,'17','Planning for RF05,RF06','2003-09-02 17:34:07',':text:Flight plans for Thursday and Friday flights',0,0,7,'ruth','2003-09-03','0000-00-00',3600,0,'a:5:{s:17:\"event_repeat_freq\";s:1:\"1\";s:22:\"event_repeat_freq_type\";s:1:\"0\";s:19:\"event_repeat_on_num\";s:1:\"1\";s:19:\"event_repeat_on_day\";s:1:\"0\";s:20:\"event_repeat_on_freq\";s:1:\"1\";}',0,'16:00:00',NULL,0,'a:6:{s:14:\"event_location\";s:22:\"Jeffco Conference Room\";s:13:\"event_street1\";s:0:\"\";s:13:\"event_street2\";s:0:\"\";s:10:\"event_city\";s:0:\"\";s:11:\"event_state\";s:0:\"\";s:12:\"event_postal\";s:0:\"\";}','','','','','',1,3,'');
INSERT INTO nuke_postcalendar_events VALUES (36,1,'17','Flight Plans for RF07','2003-09-10 10:03:06',':text:Short flight planning meeting prior to Flight RF07\r\n',0,0,7,'ruth','2003-09-11','0000-00-00',1800,0,'a:5:{s:17:\"event_repeat_freq\";s:1:\"1\";s:22:\"event_repeat_freq_type\";s:1:\"0\";s:19:\"event_repeat_on_num\";s:1:\"1\";s:19:\"event_repeat_on_day\";s:1:\"0\";s:20:\"event_repeat_on_freq\";s:1:\"1\";}',0,'11:45:00',NULL,0,'a:6:{s:14:\"event_location\";s:22:\"Jeffco Conference Room\";s:13:\"event_street1\";s:0:\"\";s:13:\"event_street2\";s:0:\"\";s:10:\"event_city\";s:0:\"\";s:11:\"event_state\";s:0:\"\";s:12:\"event_postal\";s:0:\"\";}','','','','','',1,3,'');
INSERT INTO nuke_postcalendar_events VALUES (37,1,'17','RF07','2003-09-10 10:04:46',':text:Research Flight 7 (first with new hardware configuration)',0,0,7,'ruth','2003-09-11','0000-00-00',18000,0,'a:5:{s:17:\"event_repeat_freq\";s:1:\"1\";s:22:\"event_repeat_freq_type\";s:1:\"0\";s:19:\"event_repeat_on_num\";s:1:\"1\";s:19:\"event_repeat_on_day\";s:1:\"0\";s:20:\"event_repeat_on_freq\";s:1:\"1\";}',0,'13:30:00',NULL,0,'a:6:{s:14:\"event_location\";s:6:\"Jeffco\";s:13:\"event_street1\";s:0:\"\";s:13:\"event_street2\";s:0:\"\";s:10:\"event_city\";s:0:\"\";s:11:\"event_state\";s:0:\"\";s:12:\"event_postal\";s:0:\"\";}','','','','','',1,3,'');
INSERT INTO nuke_postcalendar_events VALUES (38,1,'17','Science Review Meeting','2003-09-10 10:08:04',':text:Participants are asked to report on their instruments and the data collected\r\n',0,0,7,'ruth','2003-09-12','0000-00-00',7200,0,'a:5:{s:17:\"event_repeat_freq\";s:1:\"1\";s:22:\"event_repeat_freq_type\";s:1:\"0\";s:19:\"event_repeat_on_num\";s:1:\"1\";s:19:\"event_repeat_on_day\";s:1:\"0\";s:20:\"event_repeat_on_freq\";s:1:\"1\";}',0,'10:00:00',NULL,0,'a:6:{s:14:\"event_location\";s:22:\"Jeffco Conference Room\";s:13:\"event_street1\";s:0:\"\";s:13:\"event_street2\";s:0:\"\";s:10:\"event_city\";s:0:\"\";s:11:\"event_state\";s:0:\"\";s:12:\"event_postal\";s:0:\"\";}','','','','','',1,3,'');
INSERT INTO nuke_postcalendar_events VALUES (39,1,'17','RF08','2003-09-15 11:40:03',':text:Research Flight 8',0,0,7,'ruth','2003-09-15','0000-00-00',10800,0,'a:5:{s:17:\"event_repeat_freq\";s:1:\"1\";s:22:\"event_repeat_freq_type\";s:1:\"0\";s:19:\"event_repeat_on_num\";s:1:\"1\";s:19:\"event_repeat_on_day\";s:1:\"0\";s:20:\"event_repeat_on_freq\";s:1:\"1\";}',0,'13:30:00',NULL,0,'a:6:{s:14:\"event_location\";s:6:\"Jeffco\";s:13:\"event_street1\";s:0:\"\";s:13:\"event_street2\";s:0:\"\";s:10:\"event_city\";s:0:\"\";s:11:\"event_state\";s:0:\"\";s:12:\"event_postal\";s:0:\"\";}','','','','','',1,3,'');
INSERT INTO nuke_postcalendar_events VALUES (40,1,'17','RF09','2003-09-15 11:52:18',':text:Research Flight 9\r\n(Briefing and Flight Plan in RAF Conference Room at 11:30 a.m.)',0,0,7,'ruth','2003-09-17','0000-00-00',10800,0,'a:5:{s:17:\"event_repeat_freq\";s:1:\"1\";s:22:\"event_repeat_freq_type\";s:1:\"0\";s:19:\"event_repeat_on_num\";s:1:\"1\";s:19:\"event_repeat_on_day\";s:1:\"0\";s:20:\"event_repeat_on_freq\";s:1:\"1\";}',0,'13:30:00',NULL,0,'a:6:{s:14:\"event_location\";s:6:\"Jeffco\";s:13:\"event_street1\";s:0:\"\";s:13:\"event_street2\";s:0:\"\";s:10:\"event_city\";s:0:\"\";s:11:\"event_state\";s:0:\"\";s:12:\"event_postal\";s:0:\"\";}','','','','','',1,3,'');
INSERT INTO nuke_postcalendar_events VALUES (41,1,'17','RF10','2003-09-15 11:53:05',':text:Research Flight 10\r\n(Briefing and Flight Plan in RAF Conference Room at 8:00 a.m.)',0,0,7,'ruth','2003-09-19','0000-00-00',9000,0,'a:5:{s:17:\"event_repeat_freq\";s:1:\"1\";s:22:\"event_repeat_freq_type\";s:1:\"0\";s:19:\"event_repeat_on_num\";s:1:\"1\";s:19:\"event_repeat_on_day\";s:1:\"0\";s:20:\"event_repeat_on_freq\";s:1:\"1\";}',0,'09:00:00',NULL,0,'a:6:{s:14:\"event_location\";s:6:\"Jeffco\";s:13:\"event_street1\";s:0:\"\";s:13:\"event_street2\";s:0:\"\";s:10:\"event_city\";s:0:\"\";s:11:\"event_state\";s:0:\"\";s:12:\"event_postal\";s:0:\"\";}','','','','','',1,3,'');
INSERT INTO nuke_postcalendar_events VALUES (42,1,'17','RF11','2003-09-17 17:46:39',':text:Research Flight 11\r\n(Briefing and Flight Plan in RAF Conference Room at 12:30 p.m.)',0,0,7,'ruth','2003-09-19','0000-00-00',9000,0,'a:5:{s:17:\"event_repeat_freq\";s:1:\"1\";s:22:\"event_repeat_freq_type\";s:1:\"0\";s:19:\"event_repeat_on_num\";s:1:\"1\";s:19:\"event_repeat_on_day\";s:1:\"0\";s:20:\"event_repeat_on_freq\";s:1:\"1\";}',0,'14:00:00',NULL,0,'a:6:{s:14:\"event_location\";s:6:\"Jeffco\";s:13:\"event_street1\";s:0:\"\";s:13:\"event_street2\";s:0:\"\";s:10:\"event_city\";s:0:\"\";s:11:\"event_state\";s:0:\"\";s:12:\"event_postal\";s:0:\"\";}','','','','','',1,3,'');

--
-- Table structure for table 'nuke_postwrap_url'
--

CREATE TABLE nuke_postwrap_url (
  id int(11) NOT NULL auto_increment,
  name varchar(255) NOT NULL default '',
  alias varchar(50) NOT NULL default '',
  reg_user_only tinyint(2) default NULL,
  open_direct tinyint(2) default NULL,
  use_fixed_title tinyint(2) default NULL,
  auto_resize tinyint(2) default NULL,
  vsize int(4) default NULL,
  hsize varchar(5) default NULL,
  PRIMARY KEY  (id)
) TYPE=MyISAM;

--
-- Dumping data for table 'nuke_postwrap_url'
--



--
-- Table structure for table 'nuke_priv_msgs'
--

CREATE TABLE nuke_priv_msgs (
  pn_msg_id int(11) NOT NULL auto_increment,
  pn_msg_image varchar(100) default NULL,
  pn_subject varchar(100) default NULL,
  pn_from_userid int(11) NOT NULL default '0',
  pn_to_userid int(11) NOT NULL default '0',
  pn_msg_time varchar(20) default NULL,
  pn_msg_text text,
  pn_read_msg tinyint(4) NOT NULL default '0',
  PRIMARY KEY  (pn_msg_id),
  KEY pn_to_userid (pn_to_userid)
) TYPE=MyISAM;

--
-- Dumping data for table 'nuke_priv_msgs'
--



--
-- Table structure for table 'nuke_queue'
--

CREATE TABLE nuke_queue (
  pn_qid smallint(5) unsigned NOT NULL auto_increment,
  pn_uid mediumint(9) NOT NULL default '0',
  pn_arcd tinyint(1) NOT NULL default '0',
  pn_uname varchar(40) NOT NULL default '',
  pn_subject varchar(100) NOT NULL default '',
  pn_story text,
  pn_timestamp datetime NOT NULL default '0000-00-00 00:00:00',
  pn_topic varchar(20) NOT NULL default '',
  pn_language varchar(30) NOT NULL default '',
  pn_bodytext text,
  PRIMARY KEY  (pn_qid)
) TYPE=MyISAM;

--
-- Dumping data for table 'nuke_queue'
--



--
-- Table structure for table 'nuke_quotes'
--

CREATE TABLE nuke_quotes (
  pn_qid int(10) unsigned NOT NULL auto_increment,
  pn_quote text,
  pn_author varchar(150) NOT NULL default '',
  PRIMARY KEY  (pn_qid)
) TYPE=MyISAM;

--
-- Dumping data for table 'nuke_quotes'
--



--
-- Table structure for table 'nuke_realms'
--

CREATE TABLE nuke_realms (
  pn_rid int(11) NOT NULL auto_increment,
  pn_name varchar(255) NOT NULL default '',
  PRIMARY KEY  (pn_rid)
) TYPE=MyISAM;

--
-- Dumping data for table 'nuke_realms'
--



--
-- Table structure for table 'nuke_referer'
--

CREATE TABLE nuke_referer (
  pn_rid int(11) NOT NULL auto_increment,
  pn_url varchar(254) NOT NULL default '',
  pn_frequency int(15) default NULL,
  PRIMARY KEY  (pn_rid)
) TYPE=MyISAM;

--
-- Dumping data for table 'nuke_referer'
--


INSERT INTO nuke_referer VALUES (1,'bookmark',198662);
INSERT INTO nuke_referer VALUES (2,'http://trouble/index.php',2);
INSERT INTO nuke_referer VALUES (3,'http://trouble/user.php?stop=1',1);
INSERT INTO nuke_referer VALUES (4,'http://trouble/modules.php?op=modload&name=phpBB2&file=index',2);
INSERT INTO nuke_referer VALUES (5,'http://raf.atd.ucar.edu/~dcrogers/Wavecloud/Forecast.html',73);
INSERT INTO nuke_referer VALUES (6,'http://raf.atd.ucar.edu/IDEAS3/modules.php?op=modload&name=pnCGIIRC&file=index',238);
INSERT INTO nuke_referer VALUES (7,'http://raf.atd.ucar.edu/IDEAS3/admin.php',269);
INSERT INTO nuke_referer VALUES (8,'http://raf.atd.ucar.edu/IDEAS3/admin.php?module=NS-User&op=main',42);
INSERT INTO nuke_referer VALUES (9,'http://raf.atd.ucar.edu/IDEAS3/index.php',223);
INSERT INTO nuke_referer VALUES (10,'http://raf.atd.ucar.edu/IDEAS3/',1947);
INSERT INTO nuke_referer VALUES (11,'http://raf.atd.ucar.edu/',564);
INSERT INTO nuke_referer VALUES (12,'http://raf.atd.ucar.edu/IDEAS3/modules.php?op=modload&name=Web_Links&file=index',9);
INSERT INTO nuke_referer VALUES (13,'http://www.atd.ucar.edu/raf/Projects/IDEAS/',9);
INSERT INTO nuke_referer VALUES (14,'http://raf.atd.ucar.edu/IDEAS3/modules.php?op=modload&name=PostWrap&file=index&page=http://raf.atd.ucar.edu/cgi-bin/ion/ion-p?page=c130.ion',25);
INSERT INTO nuke_referer VALUES (15,'http://raf.atd.ucar.edu/IDEAS3/modules.php?op=modload&name=PostWrap&file=index&page=http://www.rap.ucar.edu/weather/upper/dnr.gif',11);
INSERT INTO nuke_referer VALUES (16,'http://raf.atd.ucar.edu/IDEAS3/modules.php?op=modload&name=PostWrap&file=index&page=http://www.crh.noaa.gov/den/',5);
INSERT INTO nuke_referer VALUES (17,'http://raf.atd.ucar.edu/IDEAS3/modules.php?op=modload&name=PostWrap&file=index&page=http://raf.atd.ucar.edu/cgi-bin/mail_me1.pl/jbj+From_IDEAS-3_Website',1);
INSERT INTO nuke_referer VALUES (18,'http://raf.atd.ucar.edu/Projects/IDEAS/',86);
INSERT INTO nuke_referer VALUES (19,'http://raf.atd.ucar.edu/IDEAS3/modules.php?op=modload&name=Submit_News&file=index',59);
INSERT INTO nuke_referer VALUES (20,'http://raf.atd.ucar.edu/IDEAS3/admin.php?module=NS-AddStory&op=submissions',16);
INSERT INTO nuke_referer VALUES (21,'http://raf.atd.ucar.edu/IDEAS3/modules.php?op=modload&name=News&file=article&sid=9&mode=thread&order=0&thold=0',1);
INSERT INTO nuke_referer VALUES (22,'http://raf.atd.ucar.edu/IDEAS3/admin.php?module=NS-AddStory&op=RemoveStory&sid=9',2);
INSERT INTO nuke_referer VALUES (23,'http://syrah.atd.ucar.edu/IDEAS3/index.php',2);
INSERT INTO nuke_referer VALUES (24,'http://raf.atd.ucar.edu/IDEAS3/modules.php?op=modload&name=PostWrap&file=index&page=http://raf.atd.ucar.edu/Projects/IDEAS/data_access.html',22);
INSERT INTO nuke_referer VALUES (25,'http://web.ask.com/redir?bpg=http%3a%2f%2fweb.ask.com%2fpictures%3fq%3dC%2b130%26o%3d0%26page%3d9&q=C+130&u=http%3a%2f%2fraf.atd.ucar.edu%2fProjects%2fIDEAS%2f&s=a&bu=http%3a%2f%2fraf.atd.ucar.edu%2fProjects%2fIDEAS%2f&isimageSearch=true&iskey=&thumbsrc=',1);
INSERT INTO nuke_referer VALUES (26,'http://images.google.ca/imgres?imgurl=raf.atd.ucar.edu/Projects/IDEAS/c130_right.gif&imgrefurl=http://raf.atd.ucar.edu/Projects/IDEAS/&h=517&w=865&prev=/images%3Fq%3Dc130%2Bgif%26start%3D100%26svnum%3D10%26hl%3Den%26lr%3D%26ie%3DUTF-8%26oe%3DUTF-8%26safe',1);
INSERT INTO nuke_referer VALUES (27,'http://raf.atd.ucar.edu/IDEAS3/modules.php?op=modload&name=News&file=index&catid=&topic=7',4);
INSERT INTO nuke_referer VALUES (28,'http://raf.atd.ucar.edu/IDEAS3/modules.php?op=modload&name=News&file=article&sid=7',2);
INSERT INTO nuke_referer VALUES (29,'http://raf.atd.ucar.edu/IDEAS3/modules.php?op=modload&name=Search&file=index&action=search&overview=1&active_stories=1&stories_author=stith',3);
INSERT INTO nuke_referer VALUES (30,'http://raf.atd.ucar.edu/IDEAS3/modules.php?op=modload&name=PostWrap&file=index&page=http://raf.atd.ucar.edu/Projects/IDEAS/ac_access.html',3);
INSERT INTO nuke_referer VALUES (31,'http://raf.atd.ucar.edu/IDEAS3/index.php?module=ew_filemanager&type=admin&func=manager&pathext=Aircraft/&view=C130_front_ideas3a.gif',7);
INSERT INTO nuke_referer VALUES (32,'http://raf.atd.ucar.edu/IDEAS3/modules.php?op=modload&name=phpBB_14&file=index',23);
INSERT INTO nuke_referer VALUES (33,'http://raf.atd.ucar.edu/IDEAS3/modules.php?op=modload&name=phpBB_14&file=index&action=viewforum&forum=1',4);
INSERT INTO nuke_referer VALUES (34,'http://raf.atd.ucar.edu/IDEAS3/modules.php?op=modload&name=News&file=article&sid=7&mode=thread&order=0&thold=0',1);
INSERT INTO nuke_referer VALUES (35,'http://raf.atd.ucar.edu/IDEAS3/modules.php?op=modload&name=PostWrap&file=index&page=http://raf.atd.ucar.edu/Projects/IDEAS/flights.html',12);
INSERT INTO nuke_referer VALUES (36,'http://raf.atd.ucar.edu/IDEAS3/modules.php?op=modload&name=News&file=article&sid=8',2);
INSERT INTO nuke_referer VALUES (37,'http://raf.atd.ucar.edu/IDEAS3/modules.php?op=modload&name=News&file=article&sid=8&mode=thread&order=0&thold=0',1);
INSERT INTO nuke_referer VALUES (38,'http://raf.atd.ucar.edu/IDEAS3/index.php?module=ew_filemanager&type=admin&func=manager',18);
INSERT INTO nuke_referer VALUES (39,'http://raf.atd.ucar.edu/IDEAS3/user.php',32);
INSERT INTO nuke_referer VALUES (40,'http://raf.atd.ucar.edu/IDEAS3/user.php?op=loginscreen&module=NS-User',8);
INSERT INTO nuke_referer VALUES (41,'http://raf.atd.ucar.edu/IDEAS3/modules.php?op=modload&name=PostWrap&file=index&page=http://raf.atd.ucar.edu/safety_brief.htm',3);
INSERT INTO nuke_referer VALUES (42,'http://raf.atd.ucar.edu/IDEAS3/modules.php?op=modload&name=News&file=article&sid=4&mode=thread&order=0&thold=0',1);
INSERT INTO nuke_referer VALUES (43,'http://raf.atd.ucar.edu/IDEAS3/modules.php?op=modload&name=PostWrap&file=index&page=http://raf.atd.ucar.edu/Projects/IDEAS/description.html',3);
INSERT INTO nuke_referer VALUES (44,'http://raf.atd.ucar.edu/IDEAS3/index.php?module=ew_filemanager&type=admin&func=manager&pathext=Aircraft/&view=C130_front_ideas3b.gif',4);
INSERT INTO nuke_referer VALUES (45,'http://raf.atd.ucar.edu/IDEAS3/index.php?module=ew_filemanager&type=admin&func=manager&pathext=Aircraft/&view=C130_floor_ideas3a.gif',9);
INSERT INTO nuke_referer VALUES (46,'http://raf.atd.ucar.edu/IDEAS3/index.php?module=PostCalendar&func=view&tplview=&viewtype=month&pc_username=&pc_category=&pc_topic=&print=',23);
INSERT INTO nuke_referer VALUES (47,'http://raf.atd.ucar.edu/IDEAS3/modules.php?op=modload&name=News&file=article&sid=10&mode=thread&order=0&thold=0',1);
INSERT INTO nuke_referer VALUES (48,'http://raf.atd.ucar.edu',21);
INSERT INTO nuke_referer VALUES (49,'http://raf.atd.ucar.edu/IDEAS3/modules.php?op=modload&name=News&file=article&sid=10',5);
INSERT INTO nuke_referer VALUES (50,'http://raf.atd.ucar.edu/index.html',2);
INSERT INTO nuke_referer VALUES (51,'http://www.google.com/search?hl=en&lr=&ie=UTF-8&q=science+project+weather+instrument&spell=1',1);
INSERT INTO nuke_referer VALUES (52,'http://raf.atd.ucar.edu/IDEAS3/index.php?module=PostCalendar&func=submit',21);
INSERT INTO nuke_referer VALUES (53,'http://raf.atd.ucar.edu/IDEAS3/modules.php?op=modload&name=Members_List&file=index',16);
INSERT INTO nuke_referer VALUES (54,'http://raf.atd.ucar.edu/IDEAS3/modules.php?op=modload&name=Members_List&file=index&letter=C&sortby=uname&authid=ff9168657f27fc5580ffb66d0a81a80c',2);
INSERT INTO nuke_referer VALUES (55,'http://raf.atd.ucar.edu/IDEAS3/modules.php?op=modload&name=FAQ&file=index',24);
INSERT INTO nuke_referer VALUES (56,'http://raf.atd.ucar.edu/IDEAS3/admin.php?module=NS-Groups&op=main',41);
INSERT INTO nuke_referer VALUES (57,'http://raf.atd.ucar.edu/IDEAS3/modules.php?op=modload&name=News&file=article&sid=11&mode=thread&order=0&thold=0',2);
INSERT INTO nuke_referer VALUES (58,'http://raf.atd.ucar.edu/IDEAS3/admin.php?module=NS-Groups&op=secviewgroup&gid=2',4);
INSERT INTO nuke_referer VALUES (59,'http://raf.atd.ucar.edu/IDEAS3/admin.php?module=NS-Groups&op=secviewgroup&gid=3',15);
INSERT INTO nuke_referer VALUES (60,'http://raf.atd.ucar.edu/IDEAS3/user.php?op=edituser',5);
INSERT INTO nuke_referer VALUES (61,'http://raf.atd.ucar.edu/IDEAS3/admin.php?module=NS-Groups&op=secselectuserforgroup&gid=3',18);
INSERT INTO nuke_referer VALUES (62,'http://images.google.com.au/imgres?imgurl=raf.atd.ucar.edu/Projects/IDEAS/c130_front.gif&imgrefurl=http://raf.atd.ucar.edu/Projects/IDEAS/&h=583&w=1115&prev=/images%3Fq%3Dc130%2Binterior%26svnum%3D10%26hl%3Den%26lr%3D%26ie%3DUTF-8%26oe%3DUTF-8',1);
INSERT INTO nuke_referer VALUES (63,'http://raf.atd.ucar.edu/IDEAS3/modules.php?op=modload&name=PostWrap&file=index&page=http://www.cira.colostate.edu/RAMM/Rmsdsol/main.html',26);
INSERT INTO nuke_referer VALUES (64,'http://raf.atd.ucar.edu/IDEAS3/modules.php?op=modload&name=PostWrap&file=index&page=http://www.rap.ucar.edu/weather/surface/sfc_den.gif',41);
INSERT INTO nuke_referer VALUES (65,'http://raf.atd.ucar.edu/IDEAS3/modules.php?op=modload&name=PostWrap&file=index&page=http://www.rap.ucar.edu/weather/upper/upaCNTR_500.gif',27);
INSERT INTO nuke_referer VALUES (66,'http://raf.atd.ucar.edu/IDEAS3/modules.php?op=modload&name=News&file=index',31);
INSERT INTO nuke_referer VALUES (67,'http://raf.atd.ucar.edu/IDEAS3/modules.php?op=modload&name=PostWrap&file=index&page=http://www.rap.ucar.edu/weather/upper/upaCNTR_300.gif',14);
INSERT INTO nuke_referer VALUES (68,'http://raf.atd.ucar.edu/IDEAS3/modules.php?op=modload&name=PostWrap&file=index&page=http://www.rap.ucar.edu/weather/upper/upaCNTR_700.gif',49);
INSERT INTO nuke_referer VALUES (69,'http://raf.atd.ucar.edu/IDEAS3/modules.php?op=modload&name=PostWrap&file=index&page=http://www.rap.ucar.edu/weather/model/',16);
INSERT INTO nuke_referer VALUES (70,'http://raf.atd.ucar.edu/IDEAS3/admin.php?module=NS-Groups&op=secviewgroup&gid=1',2);
INSERT INTO nuke_referer VALUES (71,'http://raf.atd.ucar.edu/IDEAS3/admin.php?module=NS-Groups&op=secviewgroups',1);
INSERT INTO nuke_referer VALUES (72,'http://raf.atd.ucar.edu/IDEAS3/modules.php?op=modload&name=News&file=article&sid=11',1);
INSERT INTO nuke_referer VALUES (73,'http://raf.atd.ucar.edu/IDEAS3/admin.php?module=NS-AddStory&op=EditStory&sid=11',2);
INSERT INTO nuke_referer VALUES (74,'http://raf.atd.ucar.edu/IDEAS3/modules.php?op=modload&name=phpBB_14&file=index&action=viewtopic&topic=5&forum=1&start=0',2);
INSERT INTO nuke_referer VALUES (75,'http://raf.atd.ucar.edu/IDEAS3/modules.php?op=modload&name=phpBB_14&file=index&action=topicadmin&mode=sticky&topic=5&forum_id=1',2);
INSERT INTO nuke_referer VALUES (76,'http://raf.atd.ucar.edu/IDEAS3/modules.php?op=modload&name=phpBB_14&file=index&action=viewtopic&topic=9&forum=3&start=0',2);
INSERT INTO nuke_referer VALUES (77,'http://raf.atd.ucar.edu/IDEAS3/modules.php?op=modload&name=phpBB_14&file=index&action=viewforum&forum=3',10);
INSERT INTO nuke_referer VALUES (78,'http://raf.atd.ucar.edu/IDEAS3/admin.php?module=NS-Groups&op=secselectuserforgroup&gid=2',2);
INSERT INTO nuke_referer VALUES (79,'http://raf.atd.ucar.edu/IDEAS3/modules.php?op=modload&name=PostWrap&file=index&page=http://nimbo.wrh.noaa.gov/satellite/1km/VIS1RIW.GIF',27);
INSERT INTO nuke_referer VALUES (80,'http://raf.atd.ucar.edu/IDEAS3/admin.php?module=NS-Settings&op=main',10);
INSERT INTO nuke_referer VALUES (81,'http://raf.atd.ucar.edu/IDEAS3/modules.php?op=modload&name=Members_List&file=index&letter=S&sortby=uname&authid=62b4706e0a3bff5cf940b719208df73d',1);
INSERT INTO nuke_referer VALUES (82,'http://raf.atd.ucar.edu/IDEAS3/modules.php?op=modload&name=Members_List&file=index&letter=R&sortby=uname&authid=62b4706e0a3bff5cf940b719208df73d',2);
INSERT INTO nuke_referer VALUES (83,'http://raf.atd.ucar.edu/IDEAS3/user.php?op=editcomm',1);
INSERT INTO nuke_referer VALUES (84,'http://raf.atd.ucar.edu/IDEAS3/modules.php?op=modload&name=News&file=article&sid=13',1);
INSERT INTO nuke_referer VALUES (85,'http://raf.atd.ucar.edu/IDEAS3/admin.php?module=NS-AddStory&op=RemoveStory&sid=13',2);
INSERT INTO nuke_referer VALUES (86,'http://raf.atd.ucar.edu/IDEAS3/modules.php?op=modload&name=PostWrap&file=index&page=http://www.rap.ucar.edu/weather/upper/riw.gif',8);
INSERT INTO nuke_referer VALUES (87,'http://raf.atd.ucar.edu/IDEAS3/modules.php?op=modload&name=FAQ&file=index&myfaq=yes&id_cat=4&categories=Project+Information&parent_id=0',3);
INSERT INTO nuke_referer VALUES (88,'http://raf.atd.ucar.edu/IDEAS3/modules.php?op=modload&name=FAQ&file=index&myfaq=yes&id_cat=5&categories=The+Chat+Program&parent_id=0',1);
INSERT INTO nuke_referer VALUES (89,'http://raf.atd.ucar.edu/IDEAS3/modules.php?op=modload&name=FAQ&file=index&myfaq=yes&id_cat=3&categories=Website+Usage&parent_id=0',4);
INSERT INTO nuke_referer VALUES (90,'http://raf.atd.ucar.edu/IDEAS3/modules.php?op=modload&name=FAQ&file=index&myfaq=yes&id_cat=6&categories=Posting+to+the+Project+Status+thread&parent_id=0',1);
INSERT INTO nuke_referer VALUES (91,'http://raf.atd.ucar.edu/IDEAS3/modules.php?op=modload&name=Members_List&file=index&letter=All&sortby=uname&authid=7cc3feb5afc0d92a6cca5e496ff4861f',1);
INSERT INTO nuke_referer VALUES (92,'http://raf.atd.ucar.edu/IDEAS3/index.php?module=PostCalendar&func=submit&tplview=',24);
INSERT INTO nuke_referer VALUES (93,'http://www.heckmangeoscience.com/av.htm',2);
INSERT INTO nuke_referer VALUES (94,'http://raf.atd.ucar.edu/IDEAS3/modules.php?op=modload&name=phpBB_14&file=index&action=viewforum&forum=5',5);
INSERT INTO nuke_referer VALUES (95,'http://raf.atd.ucar.edu/IDEAS3/modules.php?op=modload&name=phpBB_14&file=index&action=newtopic&forum=5',2);
INSERT INTO nuke_referer VALUES (96,'http://images.google.com.au/imgres?imgurl=raf.atd.ucar.edu/Projects/IDEAS/c130_left.gif&imgrefurl=http://raf.atd.ucar.edu/Projects/IDEAS/&h=518&w=745&prev=/images%3Fq%3Dc130%2Bview%26start%3D20%26svnum%3D10%26hl%3Den%26lr%3D%26ie%3DUTF-8%26oe%3DUTF-8%26s',1);
INSERT INTO nuke_referer VALUES (97,'http://raf.atd.ucar.edu/IDEAS3/admin.php?module=NS-Admin_Messages&op=main',17);
INSERT INTO nuke_referer VALUES (98,'http://raf.atd.ucar.edu/IDEAS3/admin.php?module=NS-Admin_Messages&op=editmsg&mid=11&authid=8427626ddbd2c8706855438a1f865efa',2);
INSERT INTO nuke_referer VALUES (99,'http://raf.atd.ucar.edu/IDEAS3/admin.php?module=NS-Admin_Messages&op=editmsg&mid=11&authid=80bcf3312817d0028af942db4edd654a',2);
INSERT INTO nuke_referer VALUES (100,'http://raf.atd.ucar.edu/IDEAS3/admin.php?module=NS-Admin_Messages&op=editmsg&mid=11&authid=f529d3d0587fce6fed0bb62b447fb713',2);
INSERT INTO nuke_referer VALUES (101,'http://raf.atd.ucar.edu/IDEAS3/admin.php?module=NS-Admin_Messages&op=editmsg&mid=11&authid=93105d92064a868dd51a3b9a328ca84e',2);
INSERT INTO nuke_referer VALUES (102,'http://raf.atd.ucar.edu/IDEAS3/admin.php?module=NS-Admin_Messages&op=editmsg&mid=11&authid=7c5f2b03d51b6e581bc9e0ce5bd3150f',2);
INSERT INTO nuke_referer VALUES (103,'http://raf.atd.ucar.edu/IDEAS3/admin.php?module=NS-Admin_Messages&op=editmsg&mid=11&authid=6b59b55580a975a9a10ce4bcf10732a2',2);
INSERT INTO nuke_referer VALUES (104,'http://raf.atd.ucar.edu/IDEAS3/admin.php?module=NS-Admin_Messages&op=editmsg&mid=11&authid=197187dbbbe633ac37abdf3c9b0bf281',2);
INSERT INTO nuke_referer VALUES (105,'http://raf.atd.ucar.edu/IDEAS3/modules.php?op=modload&name=Members_List&file=index&letter=All&sortby=uname&authid=ceb9e09ad140b00b992aa165a2cd7057',1);
INSERT INTO nuke_referer VALUES (106,'http://raf.atd.ucar.edu/IDEAS3/modules.php?op=modload&name=PostWrap&file=index&page=http://rams.atmos.colostate.edu/cases/',4);
INSERT INTO nuke_referer VALUES (107,'http://raf.atd.ucar.edu/IDEAS3/modules.php?op=modload&name=PostWrap&file=index&page=http://www.steamboat-ski.com/images/mtncam/current.jpg',8);
INSERT INTO nuke_referer VALUES (108,'http://raf.atd.ucar.edu/IDEAS3/modules.php?op=modload&name=PostWrap&file=index&page=http://www.wyomingcompanion.com/wcvis_2.html',1);
INSERT INTO nuke_referer VALUES (109,'http://raf.atd.ucar.edu/IDEAS3/modules.php?op=modload&name=PostWrap&file=index&page=http://orbit-net.nesdis.noaa.gov/goes/sat/images.html',2);
INSERT INTO nuke_referer VALUES (110,'http://raf.atd.ucar.edu/IDEAS3/admin.php?module=phpBB_14&op=main',8);
INSERT INTO nuke_referer VALUES (111,'http://raf.atd.ucar.edu/IDEAS3/admin.php?op=phpBB_14_ReorderForumsCat&module=phpBB_14',1);
INSERT INTO nuke_referer VALUES (112,'http://raf.atd.ucar.edu/IDEAS3/admin.php?op=phpBB_14_AddForum&module=phpBB_14',2);
INSERT INTO nuke_referer VALUES (113,'http://raf.atd.ucar.edu/IDEAS3/admin.php?op=main&module=phpBB_14',1);
INSERT INTO nuke_referer VALUES (114,'http://raf.atd.ucar.edu/IDEAS3/modules.php?op=modload&name=phpBB_14&file=index&viewcat=5',1);
INSERT INTO nuke_referer VALUES (115,'http://raf.atd.ucar.edu/IDEAS3/modules.php?op=modload&name=phpBB_14&file=index&action=prefs&authid=358219540f5c3b3491826e80f9ae2ff1',3);
INSERT INTO nuke_referer VALUES (116,'http://raf.atd.ucar.edu/IDEAS3/modules.php?op=modload&name=phpBB_14&file=index&action=newtopic&forum=3',2);
INSERT INTO nuke_referer VALUES (117,'http://raf.atd.ucar.edu/IDEAS3/admin.php?module=FAQ&op=main',8);
INSERT INTO nuke_referer VALUES (118,'http://raf.atd.ucar.edu/IDEAS3/admin.php?module=FAQ&op=FaqCatGo&id_cat=3',4);
INSERT INTO nuke_referer VALUES (119,'http://raf.atd.ucar.edu/IDEAS3/admin.php?module=FAQ&op=FaqCatGoEdit&id=7',2);
INSERT INTO nuke_referer VALUES (120,'http://raf.atd.ucar.edu/IDEAS3/admin.php?module=FAQ&op=FaqCatGo&id_cat=4',1);
INSERT INTO nuke_referer VALUES (121,'http://raf.atd.ucar.edu/IDEAS3/admin.php?module=FAQ&op=FaqCatGoEdit&id=6',2);
INSERT INTO nuke_referer VALUES (122,'http://raf.atd.ucar.edu/IDEAS3/admin.php?module=FAQ&op=FaqCatGo&id_cat=5',1);
INSERT INTO nuke_referer VALUES (123,'http://raf.atd.ucar.edu/IDEAS3/admin.php?module=FAQ&op=FaqCatGoEdit&id=11',2);
INSERT INTO nuke_referer VALUES (124,'http://raf.atd.ucar.edu/IDEAS3/admin.php?module=FAQ&op=FaqCatGo&id_cat=7',1);
INSERT INTO nuke_referer VALUES (125,'http://raf.atd.ucar.edu/IDEAS3/admin.php?module=FAQ&op=FaqCatGoEdit&id=14',2);
INSERT INTO nuke_referer VALUES (126,'http://raf.atd.ucar.edu/IDEAS3/admin.php?module=FAQ&op=FaqCatGoEdit&id=3',6);
INSERT INTO nuke_referer VALUES (127,'http://www.google.com/search?hl=en&lr=&ie=UTF-8&oe=UTF-8&q=Air+force+labor+day+safety+briefing&btnG=Google+Search',1);
INSERT INTO nuke_referer VALUES (128,'http://raf.atd.ucar.edu/IDEAS3/modules.php?op=modload&name=PostWrap&file=index&page=http://www.rap.ucar.edu/weather/satellite/latest_DEN_ir.jpg',11);
INSERT INTO nuke_referer VALUES (129,'http://raf.atd.ucar.edu/IDEAS3/modules.php?op=modload&name=News&file=article&sid=15&mode=thread&order=0&thold=0',1);
INSERT INTO nuke_referer VALUES (130,'http://raf.atd.ucar.edu/IDEAS3/modules.php?op=modload&name=News&file=article&sid=6&mode=thread&order=0&thold=0',1);
INSERT INTO nuke_referer VALUES (131,'http://raf.atd.ucar.edu/IDEAS3/modules.php?op=modload&name=Search&file=index&action=search&overview=1&active_stories=1&stories_topics[0]=7',1);
INSERT INTO nuke_referer VALUES (132,'http://raf.atd.ucar.edu/IDEAS3/modules.php?op=modload&name=News&file=article&sid=15',1);
INSERT INTO nuke_referer VALUES (133,'http://raf.atd.ucar.edu/IDEAS3/modules.php?op=modload&name=PostWrap&file=index&page=http://www.atd.ucar.edu/pipermail/ideas3/',7);
INSERT INTO nuke_referer VALUES (134,'http://raf.atd.ucar.edu/IDEAS3/modules.php?op=modload&name=PostWrap&file=index&page=http://www.thedenverchannel.com/livecams/',2);
INSERT INTO nuke_referer VALUES (135,'http://raf.atd.ucar.edu/IDEAS3/modules.php?op=modload&name=PostWrap&file=index&page=http://www.9news.com/9live/',3);
INSERT INTO nuke_referer VALUES (136,'http://raf.atd.ucar.edu/IDEAS3/modules.php?op=modload&name=PostWrap&file=index&page=http://cirrus.sprl.umich.edu/wxnet/wxcam.html',1);
INSERT INTO nuke_referer VALUES (137,'http://raf.atd.ucar.edu/IDEAS3/admin.php?module=NS-Admin_Messages&op=editmsg&mid=11&authid=3375f1883c5080417b99cab51b8f945c',2);
INSERT INTO nuke_referer VALUES (138,'http://raf.atd.ucar.edu/IDEAS3/modules.php?op=modload&name=PostWrap&file=index&page=http://www.atd.ucar.edu/mailman/listinfo/ideas3',5);
INSERT INTO nuke_referer VALUES (139,'http://raf.atd.ucar.edu/IDEAS3/modules.php?name=Search&file=index&op=modload&action=search&overview=1&active_stories=1&bool=AND&stories_cat=&stories_topics=&q=cheyenne',1);
INSERT INTO nuke_referer VALUES (140,'http://raf.atd.ucar.edu/IDEAS3/modules.php?name=Search&file=index&op=modload&action=search&overview=1&active_stories=1&bool=AND&stories_cat=&stories_topics=&q=loveland',1);
INSERT INTO nuke_referer VALUES (141,'http://raf.atd.ucar.edu/IDEAS3/modules.php?name=Search&file=index&op=modload&action=search&overview=1&active_stories=1&bool=AND&stories_cat=&stories_topics=&q=jeffco',5);
INSERT INTO nuke_referer VALUES (142,'http://raf.atd.ucar.edu/IDEAS3/modules.php?op=modload&name=PostWrap&file=index&page=http://raf.atd.ucar.edu/Projects/IDEAS/FltMatrix.html',12);
INSERT INTO nuke_referer VALUES (143,'http://raf.atd.ucar.edu/IDEAS3/modules.php?op=modload&name=PostWrap&file=index&page=http://raf.atd.ucar.edu/Projects/IDEAS/pics/Texas_am.png',2);
INSERT INTO nuke_referer VALUES (144,'http://raf.atd.ucar.edu/IDEAS3/modules.php?op=modload&name=phpBB_14&file=index&action=viewtopic&topic=10&0',1);
INSERT INTO nuke_referer VALUES (145,'http://raf.atd.ucar.edu/IDEAS3/modules.php?op=modload&name=Web_Links&file=index&req=viewlink&cid=4',1);
INSERT INTO nuke_referer VALUES (146,'http://aolsearch.aol.com/aol/search?invocationType=topsearchbox.%2Faol%2Fjsp%2Fsearch.jsp&query=http%3A%2F%2Fraf.atd.ucar.edu%2FIDEAS3%2F',1);
INSERT INTO nuke_referer VALUES (147,'http://images.google.com/imgres?imgurl=raf.atd.ucar.edu/Projects/IDEAS/c130_left.gif&imgrefurl=http://raf.atd.ucar.edu/Projects/IDEAS/&h=518&w=745&prev=/images%3Fq%3Dc130%26start%3D540%26svnum%3D10%26hl%3Den%26lr%3D%26ie%3DUTF-8%26oe%3DUTF-8%26sa%3DN',2);
INSERT INTO nuke_referer VALUES (148,'http://raf.atd.ucar.edu/IDEAS3/modules.php?op=modload&name=phpBB_14&file=index&action=viewtopic&topic=13&forum=5&start=0',1);
INSERT INTO nuke_referer VALUES (149,'http://hammondsuzuki.com/',2);
INSERT INTO nuke_referer VALUES (150,'http://raf.atd.ucar.edu/IDEAS3/modules.php?op=modload&name=News&file=article&sid=16',3);
INSERT INTO nuke_referer VALUES (151,'http://raf.atd.ucar.edu/IDEAS3/user.php?op=register&module=NS-NewUser',1);
INSERT INTO nuke_referer VALUES (152,'http://raf.atd.ucar.edu/IDEAS3/admin.php?module=Top_List&op=main',2);
INSERT INTO nuke_referer VALUES (153,'http://raf.atd.ucar.edu/IDEAS3/modules.php?op=modload&name=PostWrap&file=index&page=http://raf.atd.ucar.edu/Projects/IDEAS/pics/Shaw_students.png',3);
INSERT INTO nuke_referer VALUES (154,'http://raf.atd.ucar.edu/IDEAS3/modules.php?op=modload&name=Search&file=index',1);
INSERT INTO nuke_referer VALUES (155,'http://raf.atd.ucar.edu/IDEAS3/modules.php?op=modload&name=Search&file=index&action=search&overview=1&q=participant&bool=AND&active_downloads=1&active_faqs=1&active_weblinks=1&active_reviews=1&active_sections=1&active_stories=1&stories_topics%5B%5D=&stor',1);
INSERT INTO nuke_referer VALUES (156,'http://raf.atd.ucar.edu/IDEAS3/modules.php?op=modload&name=PostWrap&file=index&page=http://www.nrel.gov/midc/nwtc_m2/display/',2);
INSERT INTO nuke_referer VALUES (157,'http://midc:8000/report/21',1);
INSERT INTO nuke_referer VALUES (158,'http://raf.atd.ucar.edu/IDEAS3/modules.php?op=modload&name=PostWrap&file=index&page=http://weather.noaa.gov/weather/current/KBJC.html',5);
INSERT INTO nuke_referer VALUES (159,'http://raf.atd.ucar.edu/IDEAS3/admin.php?module=NS-Admin_Messages&op=editmsg&mid=11&authid=7d1c0e272e37aa4f0ec111d956cd5085',2);
INSERT INTO nuke_referer VALUES (160,'http://raf.atd.ucar.edu/IDEAS3/modules.php?op=modload&name=PostWrap&file=index&page=http://www.rap.ucar.edu/weather/upper/gjt.gif',8);
INSERT INTO nuke_referer VALUES (161,'http://raf.atd.ucar.edu/IDEAS3/admin.php?module=NS-Admin_Messages&op=editmsg&mid=11&authid=4ce642ed5369eddc8d10108cd51695ca',2);
INSERT INTO nuke_referer VALUES (162,'http://raf.atd.ucar.edu/IDEAS3/admin.php?module=NS-Admin_Messages&op=editmsg&mid=11&authid=97d8cfa15fb7e77231a5f9993ad754f5',2);
INSERT INTO nuke_referer VALUES (163,'http://raf.atd.ucar.edu/IDEAS3/modules.php?op=modload&name=phpBB_14&file=index&action=viewtopic&topic=13&0',1);
INSERT INTO nuke_referer VALUES (164,'http://images.google.nl/imgres?imgurl=raf.atd.ucar.edu/Projects/IDEAS/c130_front.gif&imgrefurl=http://raf.atd.ucar.edu/Projects/IDEAS/&h=583&w=1115&prev=/images%3Fq%3Dc130%26start%3D60%26imgsz%3Dxxlarge%26svnum%3D10%26hl%3Dnl%26lr%3D%26ie%3DUTF-8%26oe%3D',1);
INSERT INTO nuke_referer VALUES (165,'http://raf.atd.ucar.edu/IDEAS3/user.php?op=lostpassscreen&module=NS-LostPassword',2);
INSERT INTO nuke_referer VALUES (166,'http://www.google.com/search?hl=en&ie=UTF-8&oe=UTF-8&q=ideas+3+ncar',1);
INSERT INTO nuke_referer VALUES (167,'http://raf.atd.ucar.edu/IDEAS3/admin.php?module=NS-Admin_Messages&op=editmsg&mid=11&authid=298d16a0e27c4b8b88e4c63941136996',2);
INSERT INTO nuke_referer VALUES (168,'http://raf.atd.ucar.edu/IDEAS3/admin.php?module=NS-Admin_Messages&op=editmsg&mid=11&authid=694b57c7425498e83d00c43877ef73db',2);
INSERT INTO nuke_referer VALUES (169,'http://raf.atd.ucar.edu/IDEAS3/admin.php?module=NS-Admin_Messages&op=editmsg&mid=11&authid=01fc45be1bf8b9f49f52547326fdaaa9',2);
INSERT INTO nuke_referer VALUES (170,'http://www.atd.ucar.edu/rdp/services/RDCC_whitepaper.htm',5);
INSERT INTO nuke_referer VALUES (171,'http://raf.atd.ucar.edu/IDEAS3/modules.php?op=modload&name=News&file=article&sid=12',1);
INSERT INTO nuke_referer VALUES (172,'http://raf.atd.ucar.edu/IDEAS3/admin.php?module=NS-Admin_Messages&op=editmsg&mid=11&authid=5f193c6d622d5e2e47d4318838df3cad',2);
INSERT INTO nuke_referer VALUES (173,'http://raf.atd.ucar.edu/IDEAS3/admin.php?module=NS-AddStory&op=main',5);
INSERT INTO nuke_referer VALUES (174,'http://raf.atd.ucar.edu/IDEAS3/admin.php?module=NS-AddStory&op=EditStory&sid=20',16);
INSERT INTO nuke_referer VALUES (175,'http://raf.atd.ucar.edu/IDEAS3/print.php?sid=20',1);
INSERT INTO nuke_referer VALUES (176,'http://raf.atd.ucar.edu/IDEAS3/modules.php?op=modload&name=PostWrap&file=index&page=http://weather.uwyo.edu/upperair/',2);
INSERT INTO nuke_referer VALUES (177,'http://raf.atd.ucar.edu/IDEAS3/modules.php?op=modload&name=PostWrap&file=index&page=',7);
INSERT INTO nuke_referer VALUES (178,'http://raf.atd.ucar.edu/IDEAS3/modules.php?op=modload&name=PostWrap&file=index&page=http://rain.mmm.ucar.edu/mm5/',2);
INSERT INTO nuke_referer VALUES (179,'http://raf.atd.ucar.edu/IDEAS3/admin.php?module=NS-AddStory&op=RemoveStory&sid=21',2);
INSERT INTO nuke_referer VALUES (180,'http://images.google.com.my/imgres?imgurl=raf.atd.ucar.edu/Projects/IDEAS/c130_front.gif&imgrefurl=http://raf.atd.ucar.edu/Projects/IDEAS/&h=583&w=1115&prev=/images%3Fq%3Dc130%2Blayout%26svnum%3D10%26hl%3Den%26lr%3D%26ie%3DUTF-8%26oe%3DUTF-8',1);
INSERT INTO nuke_referer VALUES (181,'http://www.atd.ucar.edu/atd_data.html',11);
INSERT INTO nuke_referer VALUES (182,'http://raf.atd.ucar.edu/IDEAS3/modules.php?op=modload&name=Members_List&file=index&letter=All&sortby=uname&authid=2122bf5346c50071d97da6cc31e4b922',1);
INSERT INTO nuke_referer VALUES (183,'http://raf.atd.ucar.edu/IDEAS3/modules.php?op=modload&name=PostWrap&file=index&page=http://www.dayweather.com/wxcams.htm',1);
INSERT INTO nuke_referer VALUES (184,'http://raf.atd.ucar.edu/IDEAS3/admin.php?module=NS-AddStory&op=EditStory&sid=23',6);
INSERT INTO nuke_referer VALUES (185,'http://raf.atd.ucar.edu/IDEAS3/admin.php?module=NS-Admin_Messages&op=editmsg&mid=11&authid=0562a9c5580e3bceb3e7f6aabe5e482f',2);
INSERT INTO nuke_referer VALUES (186,'http://raf.atd.ucar.edu/IDEAS3/modules.php?op=modload&name=Members_List&file=index&letter=All&sortby=uname&authid=4b8f5868557ac4fcc105f1733b9f845d',2);
INSERT INTO nuke_referer VALUES (187,'http://raf.atd.ucar.edu/IDEAS3/modules.php?op=modload&name=PostWrap&file=index&page=http://www.ssec.wisc.edu/datacenter/terra/',1);
INSERT INTO nuke_referer VALUES (188,'http://raf.atd.ucar.edu/IDEAS3/modules.php?op=modload&name=Members_List&file=index&letter=All&sortby=uname&authid=64fe770d5f7af67e5116d664b6b86bda',1);
INSERT INTO nuke_referer VALUES (189,'http://raf.atd.ucar.edu/IDEAS3/modules.php?op=modload&name=Members_List&file=index&letter=All&sortby=uname&page=2',2);
INSERT INTO nuke_referer VALUES (190,'http://raf.atd.ucar.edu/IDEAS3/user.php?op=userinfo&uname=ruth',2);
INSERT INTO nuke_referer VALUES (191,'http://raf.atd.ucar.edu/IDEAS3/modules.php?op=modload&name=phpBB_14&file=index&action=viewforum&forum=4',1);
INSERT INTO nuke_referer VALUES (192,'http://raf.atd.ucar.edu/IDEAS3/modules.php?op=modload&name=phpBB_14&file=index&action=viewforum&forum=2',1);
INSERT INTO nuke_referer VALUES (193,'http://raf.atd.ucar.edu/IDEAS3/modules.php?op=modload&name=phpBB_14&file=index&action=viewtopic&topic=12&forum=4&start=0',1);
INSERT INTO nuke_referer VALUES (194,'http://www.google.com/search?q=3+view+plans+aircraft&hl=en&lr=&ie=UTF-8&oe=utf-8&start=10&sa=N',1);
INSERT INTO nuke_referer VALUES (195,'http://raf.atd.ucar.edu/IDEAS3/modules.php?op=modload&name=Web_Links&file=index&req=viewlink&cid=1',4);
INSERT INTO nuke_referer VALUES (196,'http://www.google.co.kr/search?q=3+PHASE+INSTRUMENT&hl=ko&ie=UTF-8&oe=UTF-8&newwindow=1',1);
INSERT INTO nuke_referer VALUES (197,'http://search.ucar.edu/seek/query.html?qp=url%3Awww.atd.ucar.edu+url%3Araf.atd.ucar.edu&charset=iso-8859-1&ws=0&fs=http%3A//www.atd.ucar.edu/dir_off/OFAP/panels/Oct02/c_airsC130.xls',1);
INSERT INTO nuke_referer VALUES (198,'http://raf.atd.ucar.edu/IDEAS3/modules.php?op=modload&name=News&file=article&sid=17',1);
INSERT INTO nuke_referer VALUES (199,'http://search.yahoo.com/search?fr=slv1&ei=UTF-8&p=C-130+Floor+plan',1);
INSERT INTO nuke_referer VALUES (200,'http://images.google.co.uk/imgres?imgurl=raf.atd.ucar.edu/Projects/IDEAS/c130_front.gif&imgrefurl=http://raf.atd.ucar.edu/Projects/IDEAS/&h=583&w=1115&prev=/images%3Fq%3Dc130%2Binterior%26svnum%3D10%26hl%3Den%26lr%3D%26ie%3DUTF-8%26oe%3DUTF-8',1);
INSERT INTO nuke_referer VALUES (201,'http://images.google.com/imgres?imgurl=raf.atd.ucar.edu/Projects/IDEAS/c130_front.gif&imgrefurl=http://raf.atd.ucar.edu/Projects/IDEAS/&h=583&w=1115&prev=/images%3Fq%3DC130%2Binterior%26svnum%3D10%26hl%3Den%26lr%3D%26ie%3DUTF-8%26oe%3DUTF-8',1);
INSERT INTO nuke_referer VALUES (202,'http://images.google.co.th/imgres?imgurl=raf.atd.ucar.edu/Projects/IDEAS/c130_left.gif&imgrefurl=http://raf.atd.ucar.edu/Projects/IDEAS/&h=518&w=745&prev=/images%3Fq%3Dc130%26start%3D540%26svnum%3D10%26hl%3Dth%26lr%3D%26ie%3DUTF-8%26oe%3DUTF-8%26sa%3DN',5);
INSERT INTO nuke_referer VALUES (203,'http://images.google.co.th/imgres?imgurl=raf.atd.ucar.edu/Projects/IDEAS/c130_front.gif&imgrefurl=http://raf.atd.ucar.edu/Projects/IDEAS/&h=583&w=1115&prev=/images%3Fq%3Dc130%26start%3D540%26svnum%3D10%26hl%3Dth%26lr%3D%26ie%3DUTF-8%26oe%3DUTF-8%26sa%3DN',3);
INSERT INTO nuke_referer VALUES (204,'http://raf.atd.ucar.edu/nindex.html',7);
INSERT INTO nuke_referer VALUES (205,'http://raf.atd.ucar.edu/Projects/IDEAS2/',1);
INSERT INTO nuke_referer VALUES (206,'http://www.google.com/search?hl=en&ie=UTF-8&oe=UTF-8&q=ideas+3+instrument+development+NCAR&btnG=Google+Search',1);
INSERT INTO nuke_referer VALUES (207,'http://raf.atd.ucar.edu/IDEAS3/modules.php?op=modload&name=Members_List&file=index&letter=All&sortby=uname&authid=6bf9161936932760cb99f099dab5b606',1);
INSERT INTO nuke_referer VALUES (208,'http://www.google.com/search?hl=en&ie=UTF-8&oe=UTF-8&q=news-4%2FDenver&btnG=Google+Search',2);
INSERT INTO nuke_referer VALUES (209,'http://www.google.com/search?q=Layer+++2003++email++contact&hl=en&lr=&ie=UTF-8&start=810&sa=N',2);
INSERT INTO nuke_referer VALUES (210,'http://www.google.com/search?q=Instrument+ideas&hl=en&lr=&ie=UTF-8&oe=UTF-8',2);
INSERT INTO nuke_referer VALUES (211,'http://raf.atd.ucar.edu/IDEAS3//',26);
INSERT INTO nuke_referer VALUES (212,'http://raf.atd.ucar.edu/IDEAS3//modules.php?op=modload&name=Members_List&file=index',1);
INSERT INTO nuke_referer VALUES (213,'http://raf.atd.ucar.edu/IDEAS3//modules.php?op=modload&name=Members_List&file=index&letter=All&sortby=uname&authid=7283f37b8a3f35fdab82156eb695fa36',1);
INSERT INTO nuke_referer VALUES (214,'http://raf.atd.ucar.edu/IDEAS3//admin.php',5);
INSERT INTO nuke_referer VALUES (215,'http://raf.atd.ucar.edu/IDEAS3//admin.php?module=NS-User&op=main',3);
INSERT INTO nuke_referer VALUES (216,'http://raf.atd.ucar.edu/IDEAS3//admin.php?module=NS-Groups&op=main',1);
INSERT INTO nuke_referer VALUES (217,'http://raf.atd.ucar.edu/IDEAS3//admin.php?module=NS-Groups&op=secviewgroup&gid=3',2);
INSERT INTO nuke_referer VALUES (218,'http://raf.atd.ucar.edu/IDEAS3//admin.php?module=NS-Groups&op=secselectuserforgroup&gid=3',2);
INSERT INTO nuke_referer VALUES (219,'http://www.google.ca/search?q=instrument+ideas&ie=UTF-8&oe=UTF-8&hl=en&meta=',2);
INSERT INTO nuke_referer VALUES (220,'http://raf.atd.ucar.edu/IDEAS3/modules.php?name=Search&file=index&op=modload&action=search&overview=1&active_stories=1&bool=AND&stories_cat=&stories_topics=&q=DATA',2);
INSERT INTO nuke_referer VALUES (221,'http://raf.atd.ucar.edu/IDEAS3/modules.php?op=modload&name=Members_List&file=index&letter=R&sortby=uname&authid=c25d7217a650de1b80a0679a7f431e06',1);
INSERT INTO nuke_referer VALUES (222,'http://raf.atd.ucar.edu/IDEAS3/modules.php',1);
INSERT INTO nuke_referer VALUES (223,'http://www.google.com/search?q=realtime+flight+status+map&ie=Shift_JIS&hl=ja&btnG=Google+%8C%9F%8D%F5&lr=',1);
INSERT INTO nuke_referer VALUES (224,'http://www.google.com/search?hl=en&ie=ISO-8859-1&q=ideas+fo+a+science+project&btnG=Google+Search',4);
INSERT INTO nuke_referer VALUES (225,'http://www.google.com/custom?hl=ar&inlang=ar&ie=windows-1256&cof=AWFID%3A0d60397048482b28%3BL%3Ahttp%3A%2F%2Fwww.fas.org%2Ffas_banner.gif%3BLH%3A50%3BLW%3A600%3BBIMG%3Ahttp%3A%2F%2Fwww.fas.org%2Fpaper2.jpg%3BAH%3Acenter%3B&domains=fas.org&q=the+latest+de',1);
INSERT INTO nuke_referer VALUES (226,'http://www.google.com/search?hl=en&lr=&ie=UTF-8&oe=UTF-8&q=ideas+jeffco',1);
INSERT INTO nuke_referer VALUES (227,'http://www.atd.ucar.edu/pipermail/ideas3/2003-September/000018.html',1);
INSERT INTO nuke_referer VALUES (228,'http://www.google.com/search?hl=en&lr=&ie=UTF-8&oe=UTF-8&q=email+flight+status+update',1);
INSERT INTO nuke_referer VALUES (229,'http://search.ucar.edu/seek/query.html?qt=IDEAS&submit=search',1);
INSERT INTO nuke_referer VALUES (230,'http://www.google.com/search?q=development+ideas&hl=en&lr=&ie=UTF-8&oe=UTF-8&start=140&sa=N',1);
INSERT INTO nuke_referer VALUES (231,'http://www.google.com/search?hl=en&lr=&ie=UTF-8&oe=UTF-8&q=ideas+3+ncar',1);
INSERT INTO nuke_referer VALUES (232,'http://raf.atd.ucar.edu/IDEAS3//index.php?module=ew_filemanager&type=admin&func=manager&pathext=Aircraft/&view=C130_front_ideas3a.gif',3);
INSERT INTO nuke_referer VALUES (233,'http://raf.atd.ucar.edu/IDEAS3//index.php?module=ew_filemanager&type=admin&func=manager&pathext=Aircraft/&view=C130_front_ideas3b.gif',7);
INSERT INTO nuke_referer VALUES (234,'http://search.ucar.edu/seek/query.html?qp=url%3Awww.atd.ucar.edu+url%3Araf.atd.ucar.edu&qt=ideas',2);
INSERT INTO nuke_referer VALUES (235,'http://raf.atd.ucar.edu/IDEAS3//modules.php?op=modload&name=PostWrap&file=index&page=http://raf.atd.ucar.edu/Projects/IDEAS/data_access.html',1);
INSERT INTO nuke_referer VALUES (236,'http://raf.atd.ucar.edu/IDEAS3//modules.php?name=Search&file=index&op=modload&action=search&overview=1&active_stories=1&bool=AND&stories_cat=&stories_topics=&q=MCR',1);
INSERT INTO nuke_referer VALUES (237,'http://www.alltheweb.com/search?cs=utf-8&cat=web&q=link.all%3Awww.nrel.gov%2Fmidc+-site%3Anrel.gov&avkw=fogg&o=10',1);
INSERT INTO nuke_referer VALUES (238,'http://www.google.com/search?hl=en&lr=&ie=ISO-8859-1&q=Jorgen+Jensen+ucar+email',1);
INSERT INTO nuke_referer VALUES (239,'http://search.msn.com/results.aspx?ps=ba%3d(0.15)0(.)0.......%26co%3d(0.15)4(0.1)3.200.2.5.10.1.3.%26pn%3d1%26rd%3d0%26&q=present+status+of+flight&ck_sc=1&ck_af=0',1);
INSERT INTO nuke_referer VALUES (240,'http://search.msn.com/results.asp?RS=CHECKED&FORM=MSNH&v=1&q=advantages+on+development+of+flight',1);
INSERT INTO nuke_referer VALUES (241,'http://www.google.com/search?hl=en&ie=UTF-8&oe=UTF-8&q=science+phase',1);
INSERT INTO nuke_referer VALUES (242,'http://www.google.com/search?hl=en&lr=&ie=ISO-8859-1&q=9news+science&btnG=Google+Search',1);

--
-- Table structure for table 'nuke_related'
--

CREATE TABLE nuke_related (
  pn_rid int(11) NOT NULL auto_increment,
  pn_tid int(11) NOT NULL default '0',
  pn_name varchar(30) NOT NULL default '',
  pn_url varchar(254) NOT NULL default '',
  PRIMARY KEY  (pn_rid)
) TYPE=MyISAM;

--
-- Dumping data for table 'nuke_related'
--


INSERT INTO nuke_related VALUES (2,5,'The IDEAS3 Website','http://syrah.atd.ucar.edu/IDEAS3');

--
-- Table structure for table 'nuke_reviews'
--

CREATE TABLE nuke_reviews (
  pn_id int(11) NOT NULL auto_increment,
  pn_date datetime NOT NULL default '0000-00-00 00:00:00',
  pn_title varchar(150) NOT NULL default '',
  pn_text text NOT NULL,
  pn_reviewer varchar(20) default NULL,
  pn_email varchar(60) default NULL,
  pn_score int(11) NOT NULL default '0',
  pn_cover varchar(100) NOT NULL default '',
  pn_url varchar(254) NOT NULL default '',
  pn_url_title varchar(150) NOT NULL default '',
  pn_hits int(11) NOT NULL default '0',
  pn_language varchar(30) NOT NULL default '',
  PRIMARY KEY  (pn_id)
) TYPE=MyISAM;

--
-- Dumping data for table 'nuke_reviews'
--



--
-- Table structure for table 'nuke_reviews_add'
--

CREATE TABLE nuke_reviews_add (
  pn_id int(11) NOT NULL auto_increment,
  pn_date datetime default NULL,
  pn_title varchar(150) NOT NULL default '',
  pn_text text NOT NULL,
  pn_reviewer varchar(20) NOT NULL default '',
  pn_email varchar(60) default NULL,
  pn_score int(11) NOT NULL default '0',
  pn_url varchar(254) NOT NULL default '',
  pn_url_title varchar(150) NOT NULL default '',
  pn_language varchar(30) NOT NULL default '',
  PRIMARY KEY  (pn_id)
) TYPE=MyISAM;

--
-- Dumping data for table 'nuke_reviews_add'
--



--
-- Table structure for table 'nuke_reviews_comments'
--

CREATE TABLE nuke_reviews_comments (
  pn_cid int(11) NOT NULL auto_increment,
  pn_rid int(11) NOT NULL default '0',
  pn_userid varchar(25) NOT NULL default '',
  pn_date datetime default NULL,
  pn_comments text,
  pn_score int(11) NOT NULL default '0',
  PRIMARY KEY  (pn_cid)
) TYPE=MyISAM;

--
-- Dumping data for table 'nuke_reviews_comments'
--



--
-- Table structure for table 'nuke_reviews_main'
--

CREATE TABLE nuke_reviews_main (
  pn_title varchar(100) default NULL,
  pn_description text
) TYPE=MyISAM;

--
-- Dumping data for table 'nuke_reviews_main'
--


INSERT INTO nuke_reviews_main VALUES ('Reviews Section Title','Reviews Section Long Description');

--
-- Table structure for table 'nuke_seccont'
--

CREATE TABLE nuke_seccont (
  pn_artid int(11) NOT NULL auto_increment,
  pn_secid int(11) NOT NULL default '0',
  pn_title text NOT NULL,
  pn_content text NOT NULL,
  pn_counter int(11) NOT NULL default '0',
  pn_language varchar(30) NOT NULL default '',
  PRIMARY KEY  (pn_artid)
) TYPE=MyISAM;

--
-- Dumping data for table 'nuke_seccont'
--



--
-- Table structure for table 'nuke_sections'
--

CREATE TABLE nuke_sections (
  pn_secid int(11) NOT NULL auto_increment,
  pn_secname varchar(40) NOT NULL default '',
  pn_image varchar(50) NOT NULL default '',
  PRIMARY KEY  (pn_secid)
) TYPE=MyISAM;

--
-- Dumping data for table 'nuke_sections'
--



--
-- Table structure for table 'nuke_session_info'
--

CREATE TABLE nuke_session_info (
  pn_sessid varchar(32) NOT NULL default '',
  pn_ipaddr varchar(20) NOT NULL default '',
  pn_firstused int(11) NOT NULL default '0',
  pn_lastused int(11) NOT NULL default '0',
  pn_uid int(11) NOT NULL default '0',
  pn_vars blob,
  PRIMARY KEY  (pn_sessid)
) TYPE=MyISAM;

--
-- Dumping data for table 'nuke_session_info'
--


INSERT INTO nuke_session_info VALUES ('e8ddec71fffbcbfe7ed131527694e398','216.88.158.142',1077499877,1077499877,0,'PNSVrand|i:880653571;PNSVlang|s:3:\"eng\";');
INSERT INTO nuke_session_info VALUES ('6861824a376d30b38f311738923c3da9','216.88.158.142',1077500157,1077500157,0,'PNSVrand|i:390577696;PNSVlang|s:3:\"eng\";');
INSERT INTO nuke_session_info VALUES ('cd5ea638ef367e0bcb3d6315e4860501','216.88.158.142',1077502790,1077502790,0,'PNSVrand|i:387261971;PNSVlang|s:3:\"eng\";');
INSERT INTO nuke_session_info VALUES ('620128381ddc48ae8220ad0e3af6f3b0','216.88.158.142',1077503240,1077503240,0,'PNSVrand|i:25299544;PNSVlang|s:3:\"eng\";');
INSERT INTO nuke_session_info VALUES ('8bcd0d60a522407d988d8dbd80a0d450','216.88.158.142',1077503394,1077503394,0,'PNSVrand|i:1320119070;PNSVlang|s:3:\"eng\";');
INSERT INTO nuke_session_info VALUES ('a5605bebe39bd3f45d4e522ed62b478c','216.88.158.142',1077505250,1077505250,0,'PNSVrand|i:2080570645;PNSVlang|s:3:\"eng\";');
INSERT INTO nuke_session_info VALUES ('ddb728924c6dd85943c5368a5cb2b8cb','66.196.72.13',1077509591,1077509591,0,'PNSVrand|i:1996263951;PNSVlang|s:3:\"eng\";');
INSERT INTO nuke_session_info VALUES ('ed12c8e9e86b2b336202364445eaebc1','216.88.158.142',1077510939,1077510939,0,'PNSVrand|i:378044679;PNSVlang|s:3:\"eng\";');
INSERT INTO nuke_session_info VALUES ('a4146a4e77fa5c5de0bd8848e7de279c','216.88.158.142',1077514435,1077514435,0,'PNSVrand|i:507140792;PNSVlang|s:3:\"eng\";');
INSERT INTO nuke_session_info VALUES ('ea0f14b5284e5114fee922f94eafc46e','216.88.158.142',1077517277,1077517277,0,'PNSVrand|i:1231268740;PNSVlang|s:3:\"eng\";');
INSERT INTO nuke_session_info VALUES ('7dcaf6a4bb8dd7bf9dc99266ebe8f1ba','66.196.72.26',1077520804,1077520804,0,'PNSVrand|i:978582663;PNSVlang|s:3:\"eng\";');
INSERT INTO nuke_session_info VALUES ('c37ab4f1106af52768812c045e4f7bc4','216.88.158.142',1077521203,1077521203,0,'PNSVrand|i:1956727138;PNSVlang|s:3:\"eng\";');
INSERT INTO nuke_session_info VALUES ('59148ee9ade9d18ae13c5b6acbafe12d','216.88.158.142',1077526703,1077526703,0,'PNSVrand|i:102441149;PNSVlang|s:3:\"eng\";');
INSERT INTO nuke_session_info VALUES ('d5ed4ae6a0518eff1feefbda3ccf7d99','216.88.158.142',1077527172,1077527172,0,'PNSVrand|i:373289812;PNSVlang|s:3:\"eng\";');
INSERT INTO nuke_session_info VALUES ('5b04cb1e3cf9504749b7525bd9f1964a','66.196.72.61',1077527884,1077527884,0,'PNSVrand|i:460481197;PNSVlang|s:3:\"eng\";');
INSERT INTO nuke_session_info VALUES ('61f3dfef667916fc00fa491569e2a896','216.88.158.142',1077531313,1077531313,0,'PNSVrand|i:274528912;PNSVlang|s:3:\"eng\";');
INSERT INTO nuke_session_info VALUES ('1d561771a157692b5bc20a905c3ce096','216.88.158.142',1077532976,1077532976,0,'PNSVrand|i:1499479476;PNSVlang|s:3:\"eng\";');
INSERT INTO nuke_session_info VALUES ('827d3e9a13751de0e4df23a5b850e02f','216.88.158.142',1077540873,1077540873,0,'PNSVrand|i:2062905171;PNSVlang|s:3:\"eng\";');
INSERT INTO nuke_session_info VALUES ('9d53c63fd801daba2e5f8d9b69751307','216.88.158.142',1077541536,1077541536,0,'PNSVrand|i:1818462653;PNSVlang|s:3:\"eng\";');
INSERT INTO nuke_session_info VALUES ('029dbcbfbaff742054cae07b3cd639ce','216.88.158.142',1077545887,1077545887,0,'PNSVrand|i:957427663;PNSVlang|s:3:\"eng\";');
INSERT INTO nuke_session_info VALUES ('544faf9f3b79798bb54bf6a26a05261a','216.88.158.142',1077556986,1077556986,0,'PNSVrand|i:152683251;PNSVlang|s:3:\"eng\";');
INSERT INTO nuke_session_info VALUES ('cd4ad4155cd021f03e779296786ab896','216.88.158.142',1077558010,1077558010,0,'PNSVrand|i:1641462444;PNSVlang|s:3:\"eng\";');
INSERT INTO nuke_session_info VALUES ('4c9b8bcefd446b914f4e9d71b56ad88c','216.88.158.142',1077558505,1077558505,0,'PNSVrand|i:1584011482;PNSVlang|s:3:\"eng\";');
INSERT INTO nuke_session_info VALUES ('c4228010be71d6f9d5854fcaac7d3dbd','216.88.158.142',1077558998,1077558998,0,'PNSVrand|i:1650491300;PNSVlang|s:3:\"eng\";');
INSERT INTO nuke_session_info VALUES ('750b8fae9e2abe873db1117589ca9984','216.88.158.142',1077562550,1077562550,0,'PNSVrand|i:1217484915;PNSVlang|s:3:\"eng\";');
INSERT INTO nuke_session_info VALUES ('9e0968f523f87d1de814d1c824556c45','216.88.158.142',1077567873,1077567873,0,'PNSVrand|i:786902148;PNSVlang|s:3:\"eng\";');
INSERT INTO nuke_session_info VALUES ('01584b6db01bc824afeb30a1118ff921','216.88.158.142',1077568508,1077568508,0,'PNSVrand|i:334357688;PNSVlang|s:3:\"eng\";');
INSERT INTO nuke_session_info VALUES ('3c6a2beba3b89357ce59f48d88adb934','216.88.158.142',1077592875,1077592875,0,'PNSVrand|i:18421670;PNSVlang|s:3:\"eng\";');
INSERT INTO nuke_session_info VALUES ('7415e29f231961a7d89ecbeb0bd47cf5','216.88.158.142',1077593765,1077593765,0,'PNSVrand|i:726028065;PNSVlang|s:3:\"eng\";');
INSERT INTO nuke_session_info VALUES ('3eb3eb02b8bef2ee50a85600860e2eab','216.88.158.142',1077597477,1077597477,0,'PNSVrand|i:1398927606;PNSVlang|s:3:\"eng\";');
INSERT INTO nuke_session_info VALUES ('3fa3072f2be70cdf356e44f1cf6b71d8','66.196.90.199',1077607333,1077607333,0,'PNSVrand|i:1064813280;PNSVlang|s:3:\"eng\";');
INSERT INTO nuke_session_info VALUES ('aa5642a25e1309ac332aeb8a7118a255','216.88.158.142',1077616401,1077616401,0,'PNSVrand|i:1494105506;PNSVlang|s:3:\"eng\";');
INSERT INTO nuke_session_info VALUES ('28cb58e530efc8603b08abbea229ae86','216.88.158.142',1077624171,1077624171,0,'PNSVrand|i:518860958;PNSVlang|s:3:\"eng\";');
INSERT INTO nuke_session_info VALUES ('34909c27fbdc32255752432f33d15555','216.88.158.142',1077634163,1077634163,0,'PNSVrand|i:1703804598;PNSVlang|s:3:\"eng\";');
INSERT INTO nuke_session_info VALUES ('0aa6adefa2e09181a5b1490d7c17fc74','216.88.158.142',1077634608,1077634608,0,'PNSVrand|i:1491223646;PNSVlang|s:3:\"eng\";');
INSERT INTO nuke_session_info VALUES ('879b106c59529391cb583c34c85d1a06','66.196.72.89',1077644572,1077644572,0,'PNSVrand|i:930842213;PNSVlang|s:3:\"eng\";');
INSERT INTO nuke_session_info VALUES ('8c220c97e40929a07be2ebb4dcfd76da','216.88.158.142',1077644600,1077644600,0,'PNSVrand|i:509825349;PNSVlang|s:3:\"eng\";');
INSERT INTO nuke_session_info VALUES ('af172cdf5d28cc30fe5bff3fb1fb68f0','216.88.158.142',1077644612,1077644612,0,'PNSVrand|i:2022229140;PNSVlang|s:3:\"eng\";');
INSERT INTO nuke_session_info VALUES ('ad2b49d5faa79deec5c0051eb66f5056','216.88.158.142',1077646840,1077646840,0,'PNSVrand|i:1735160142;PNSVlang|s:3:\"eng\";');
INSERT INTO nuke_session_info VALUES ('ab202f161a1568e41b38677775ab2f9d','216.88.158.142',1077647894,1077647894,0,'PNSVrand|i:1459303972;PNSVlang|s:3:\"eng\";');
INSERT INTO nuke_session_info VALUES ('22956f4602459bd85a591b0c72ff86a7','216.88.158.142',1077648142,1077648142,0,'PNSVrand|i:1656271213;PNSVlang|s:3:\"eng\";');
INSERT INTO nuke_session_info VALUES ('94ef24fc8d9b753304cd6e97d60edc9e','66.196.72.46',1077424106,1077424106,0,'PNSVrand|i:196216280;PNSVlang|s:3:\"eng\";');
INSERT INTO nuke_session_info VALUES ('bc77ef1ec5faca128aeaccf3ec7beaa0','66.196.72.103',1077497327,1077497327,0,'PNSVrand|i:672116131;PNSVlang|s:3:\"eng\";');
INSERT INTO nuke_session_info VALUES ('79e44cfff78e3dbc1163c7dda7509323','64.68.92.161',1077422107,1077422107,0,'PNSVrand|i:225426145;PNSVlang|s:3:\"eng\";PNSVerrormsg|s:157:\"DB Error: 1064: You have an error in your SQL syntax near \'\' at line 1SELECT nuke_ew_filemanager.path FROM nuke_ew_filemanager WHERE nuke_ew_filemanager.uid=\";');
INSERT INTO nuke_session_info VALUES ('c6955d4e22c53e7a7e67dfe66e25319c','216.88.158.142',1077494204,1077494204,0,'PNSVrand|i:352288408;PNSVlang|s:3:\"eng\";');
INSERT INTO nuke_session_info VALUES ('4c347d5a9f5ce892b50527a9878f7b6c','216.88.158.142',1077493863,1077493863,0,'PNSVrand|i:486918083;PNSVlang|s:3:\"eng\";');
INSERT INTO nuke_session_info VALUES ('38b7d523606cb8c03b04cc5e7e1f5a67','216.88.158.142',1077487606,1077487606,0,'PNSVrand|i:1474209039;PNSVlang|s:3:\"eng\";');
INSERT INTO nuke_session_info VALUES ('bf8a95097218e1b8b8b93d609d8275d4','216.88.158.142',1077469509,1077469509,0,'PNSVrand|i:1079118979;PNSVlang|s:3:\"eng\";');
INSERT INTO nuke_session_info VALUES ('823fb5517bd6e578386d0ad612fff88a','216.88.158.142',1077470319,1077470319,0,'PNSVrand|i:269044304;PNSVlang|s:3:\"eng\";');
INSERT INTO nuke_session_info VALUES ('dd44ee2cfe8e4eb16e34aca6bd12a2d4','216.88.158.142',1077471873,1077471873,0,'PNSVrand|i:38925326;PNSVlang|s:3:\"eng\";');
INSERT INTO nuke_session_info VALUES ('b73bfa07f3ba89a3a00f36558ed43ec8','128.117.224.85',1077477847,1077564311,0,'PNSVrand|i:1556344425;PNSVlang|s:3:\"eng\";');
INSERT INTO nuke_session_info VALUES ('a0ea8bddd00dbb6d82394a5d88bdae2b','216.88.158.142',1077483100,1077483100,0,'PNSVrand|i:609180106;PNSVlang|s:3:\"eng\";');
INSERT INTO nuke_session_info VALUES ('56cbb957955ad2c318e7a793e4e9fa89','216.88.158.142',1077452917,1077452917,0,'PNSVrand|i:1329122889;PNSVlang|s:3:\"eng\";');
INSERT INTO nuke_session_info VALUES ('dd121cb947eec31431d2c5e03d52358e','216.88.158.142',1077452494,1077452494,0,'PNSVrand|i:1294312330;PNSVlang|s:3:\"eng\";');
INSERT INTO nuke_session_info VALUES ('7bd506a6bf663f6230188ebf24da385b','216.88.158.142',1077445269,1077445269,0,'PNSVrand|i:2121319378;PNSVlang|s:3:\"eng\";');
INSERT INTO nuke_session_info VALUES ('4ace626708ce0125f06ff84549033ce3','216.88.158.142',1077447260,1077447260,0,'PNSVrand|i:1533627591;PNSVlang|s:3:\"eng\";');
INSERT INTO nuke_session_info VALUES ('0fafd8bde25b4849d217a4eb19cc015a','64.68.92.207',1077426306,1077426306,0,'PNSVrand|i:385104220;PNSVlang|s:3:\"eng\";PNSVerrormsg|s:157:\"DB Error: 1064: You have an error in your SQL syntax near \'\' at line 1SELECT nuke_ew_filemanager.path FROM nuke_ew_filemanager WHERE nuke_ew_filemanager.uid=\";');
INSERT INTO nuke_session_info VALUES ('4c0632cbf90ce2ea68fa49f749529f6b','216.88.158.142',1077427996,1077427996,0,'PNSVrand|i:1667154034;PNSVlang|s:3:\"eng\";');
INSERT INTO nuke_session_info VALUES ('00d969df140a8b5b6578aa6dbfe2c540','64.68.92.194',1077430154,1077430154,0,'PNSVrand|i:1227319983;PNSVlang|s:3:\"eng\";PNSVerrormsg|s:157:\"DB Error: 1064: You have an error in your SQL syntax near \'\' at line 1SELECT nuke_ew_filemanager.path FROM nuke_ew_filemanager WHERE nuke_ew_filemanager.uid=\";');
INSERT INTO nuke_session_info VALUES ('c839bd691e57b79db70a0e234a2ef996','216.88.158.142',1077430878,1077430878,0,'PNSVrand|i:1129137257;PNSVlang|s:3:\"eng\";');
INSERT INTO nuke_session_info VALUES ('f1b347a83b4230d2104920e04c7eb6ed','64.68.92.194',1077432602,1077432602,0,'PNSVrand|i:224829198;PNSVlang|s:3:\"eng\";PNSVerrormsg|s:157:\"DB Error: 1064: You have an error in your SQL syntax near \'\' at line 1SELECT nuke_ew_filemanager.path FROM nuke_ew_filemanager WHERE nuke_ew_filemanager.uid=\";');
INSERT INTO nuke_session_info VALUES ('371a08e540340bf486255e4df8d70417','216.88.158.142',1077441992,1077441992,0,'PNSVrand|i:1265480229;PNSVlang|s:3:\"eng\";');
INSERT INTO nuke_session_info VALUES ('1635be6e761f10f8b47ee595b4376280','216.88.158.142',1077442478,1077442478,0,'PNSVrand|i:290968021;PNSVlang|s:3:\"eng\";');
INSERT INTO nuke_session_info VALUES ('c781df1550c09e5a733142f52bca0e37','216.88.158.142',1077445128,1077445128,0,'PNSVrand|i:1981450391;PNSVlang|s:3:\"eng\";');
INSERT INTO nuke_session_info VALUES ('0240a5f7c76ab0a0a6a67722b8d61942','216.88.158.142',1077425232,1077425232,0,'PNSVrand|i:749978810;PNSVlang|s:3:\"eng\";');

--
-- Table structure for table 'nuke_stats_date'
--

CREATE TABLE nuke_stats_date (
  pn_date varchar(80) NOT NULL default '',
  pn_hits int(11) unsigned NOT NULL default '0'
) TYPE=MyISAM;

--
-- Dumping data for table 'nuke_stats_date'
--


INSERT INTO nuke_stats_date VALUES ('08072003',22);
INSERT INTO nuke_stats_date VALUES ('09072003',48);
INSERT INTO nuke_stats_date VALUES ('10072003',58);
INSERT INTO nuke_stats_date VALUES ('11072003',55);
INSERT INTO nuke_stats_date VALUES ('12072003',1);
INSERT INTO nuke_stats_date VALUES ('13072003',1);
INSERT INTO nuke_stats_date VALUES ('14072003',134);
INSERT INTO nuke_stats_date VALUES ('15072003',67);
INSERT INTO nuke_stats_date VALUES ('16072003',384);
INSERT INTO nuke_stats_date VALUES ('17072003',2);
INSERT INTO nuke_stats_date VALUES ('18072003',1);
INSERT INTO nuke_stats_date VALUES ('19072003',5);
INSERT INTO nuke_stats_date VALUES ('20072003',1);
INSERT INTO nuke_stats_date VALUES ('21072003',1);
INSERT INTO nuke_stats_date VALUES ('22072003',38);
INSERT INTO nuke_stats_date VALUES ('23072003',18);
INSERT INTO nuke_stats_date VALUES ('24072003',46);
INSERT INTO nuke_stats_date VALUES ('25072003',40);
INSERT INTO nuke_stats_date VALUES ('26072003',1);
INSERT INTO nuke_stats_date VALUES ('27072003',1);
INSERT INTO nuke_stats_date VALUES ('28072003',21);
INSERT INTO nuke_stats_date VALUES ('29072003',51);
INSERT INTO nuke_stats_date VALUES ('30072003',34);
INSERT INTO nuke_stats_date VALUES ('31072003',97);
INSERT INTO nuke_stats_date VALUES ('01082003',27);
INSERT INTO nuke_stats_date VALUES ('04082003',4);
INSERT INTO nuke_stats_date VALUES ('05082003',60);
INSERT INTO nuke_stats_date VALUES ('06082003',23);
INSERT INTO nuke_stats_date VALUES ('07082003',25);
INSERT INTO nuke_stats_date VALUES ('08082003',106);
INSERT INTO nuke_stats_date VALUES ('11082003',23);
INSERT INTO nuke_stats_date VALUES ('12082003',20);
INSERT INTO nuke_stats_date VALUES ('13082003',33);
INSERT INTO nuke_stats_date VALUES ('14082003',42);
INSERT INTO nuke_stats_date VALUES ('15082003',41);
INSERT INTO nuke_stats_date VALUES ('18082003',42);
INSERT INTO nuke_stats_date VALUES ('19082003',9839);
INSERT INTO nuke_stats_date VALUES ('20082003',18117);
INSERT INTO nuke_stats_date VALUES ('21082003',20112);
INSERT INTO nuke_stats_date VALUES ('22082003',24069);
INSERT INTO nuke_stats_date VALUES ('23082003',39736);
INSERT INTO nuke_stats_date VALUES ('24082003',36643);
INSERT INTO nuke_stats_date VALUES ('25082003',10988);
INSERT INTO nuke_stats_date VALUES ('26082003',304);
INSERT INTO nuke_stats_date VALUES ('27082003',133);
INSERT INTO nuke_stats_date VALUES ('28082003',101);
INSERT INTO nuke_stats_date VALUES ('29082003',216);
INSERT INTO nuke_stats_date VALUES ('30082003',328);
INSERT INTO nuke_stats_date VALUES ('31082003',503);
INSERT INTO nuke_stats_date VALUES ('01092003',458);
INSERT INTO nuke_stats_date VALUES ('02092003',557);
INSERT INTO nuke_stats_date VALUES ('03092003',577);
INSERT INTO nuke_stats_date VALUES ('04092003',711);
INSERT INTO nuke_stats_date VALUES ('05092003',805);
INSERT INTO nuke_stats_date VALUES ('06092003',769);
INSERT INTO nuke_stats_date VALUES ('07092003',773);
INSERT INTO nuke_stats_date VALUES ('08092003',896);
INSERT INTO nuke_stats_date VALUES ('09092003',952);
INSERT INTO nuke_stats_date VALUES ('10092003',1045);
INSERT INTO nuke_stats_date VALUES ('11092003',1114);
INSERT INTO nuke_stats_date VALUES ('12092003',1092);
INSERT INTO nuke_stats_date VALUES ('13092003',1141);
INSERT INTO nuke_stats_date VALUES ('14092003',1243);
INSERT INTO nuke_stats_date VALUES ('15092003',1338);
INSERT INTO nuke_stats_date VALUES ('16092003',1344);
INSERT INTO nuke_stats_date VALUES ('17092003',1496);
INSERT INTO nuke_stats_date VALUES ('18092003',1478);
INSERT INTO nuke_stats_date VALUES ('19092003',1571);
INSERT INTO nuke_stats_date VALUES ('20092003',1571);
INSERT INTO nuke_stats_date VALUES ('21092003',1624);
INSERT INTO nuke_stats_date VALUES ('22092003',1693);
INSERT INTO nuke_stats_date VALUES ('23092003',1783);
INSERT INTO nuke_stats_date VALUES ('24092003',1793);
INSERT INTO nuke_stats_date VALUES ('25092003',1845);
INSERT INTO nuke_stats_date VALUES ('26092003',1904);
INSERT INTO nuke_stats_date VALUES ('27092003',1921);
INSERT INTO nuke_stats_date VALUES ('28092003',2012);
INSERT INTO nuke_stats_date VALUES ('02102003',19);
INSERT INTO nuke_stats_date VALUES ('03102003',42);
INSERT INTO nuke_stats_date VALUES ('04102003',42);
INSERT INTO nuke_stats_date VALUES ('05102003',31);
INSERT INTO nuke_stats_date VALUES ('06102003',53);
INSERT INTO nuke_stats_date VALUES ('07102003',60);
INSERT INTO nuke_stats_date VALUES ('08102003',80);
INSERT INTO nuke_stats_date VALUES ('09102003',96);
INSERT INTO nuke_stats_date VALUES ('10102003',71);
INSERT INTO nuke_stats_date VALUES ('11102003',29);
INSERT INTO nuke_stats_date VALUES ('12102003',20);
INSERT INTO nuke_stats_date VALUES ('13102003',57);
INSERT INTO nuke_stats_date VALUES ('14102003',26);
INSERT INTO nuke_stats_date VALUES ('15102003',62);
INSERT INTO nuke_stats_date VALUES ('16102003',23);
INSERT INTO nuke_stats_date VALUES ('17102003',25);
INSERT INTO nuke_stats_date VALUES ('18102003',5);
INSERT INTO nuke_stats_date VALUES ('19102003',32);
INSERT INTO nuke_stats_date VALUES ('20102003',40);
INSERT INTO nuke_stats_date VALUES ('21102003',34);
INSERT INTO nuke_stats_date VALUES ('22102003',7);
INSERT INTO nuke_stats_date VALUES ('23102003',52);
INSERT INTO nuke_stats_date VALUES ('24102003',56);
INSERT INTO nuke_stats_date VALUES ('25102003',29);
INSERT INTO nuke_stats_date VALUES ('26102003',29);
INSERT INTO nuke_stats_date VALUES ('27102003',46);
INSERT INTO nuke_stats_date VALUES ('28102003',52);
INSERT INTO nuke_stats_date VALUES ('29102003',35);
INSERT INTO nuke_stats_date VALUES ('30102003',42);
INSERT INTO nuke_stats_date VALUES ('31102003',48);
INSERT INTO nuke_stats_date VALUES ('01112003',29);
INSERT INTO nuke_stats_date VALUES ('02112003',28);
INSERT INTO nuke_stats_date VALUES ('03112003',34);
INSERT INTO nuke_stats_date VALUES ('04112003',13);
INSERT INTO nuke_stats_date VALUES ('05112003',50);
INSERT INTO nuke_stats_date VALUES ('06112003',13);
INSERT INTO nuke_stats_date VALUES ('07112003',35);
INSERT INTO nuke_stats_date VALUES ('08112003',18);
INSERT INTO nuke_stats_date VALUES ('09112003',14);
INSERT INTO nuke_stats_date VALUES ('10112003',32);
INSERT INTO nuke_stats_date VALUES ('11112003',34);
INSERT INTO nuke_stats_date VALUES ('12112003',15);
INSERT INTO nuke_stats_date VALUES ('13112003',49);
INSERT INTO nuke_stats_date VALUES ('14112003',15);
INSERT INTO nuke_stats_date VALUES ('15112003',23);
INSERT INTO nuke_stats_date VALUES ('16112003',8);
INSERT INTO nuke_stats_date VALUES ('17112003',8);
INSERT INTO nuke_stats_date VALUES ('18112003',19);
INSERT INTO nuke_stats_date VALUES ('19112003',30);
INSERT INTO nuke_stats_date VALUES ('20112003',27);
INSERT INTO nuke_stats_date VALUES ('21112003',20);
INSERT INTO nuke_stats_date VALUES ('22112003',8);
INSERT INTO nuke_stats_date VALUES ('23112003',11);
INSERT INTO nuke_stats_date VALUES ('24112003',29);
INSERT INTO nuke_stats_date VALUES ('25112003',14);
INSERT INTO nuke_stats_date VALUES ('26112003',22);
INSERT INTO nuke_stats_date VALUES ('27112003',33);
INSERT INTO nuke_stats_date VALUES ('28112003',7);
INSERT INTO nuke_stats_date VALUES ('29112003',56);
INSERT INTO nuke_stats_date VALUES ('30112003',18);
INSERT INTO nuke_stats_date VALUES ('01122003',10);
INSERT INTO nuke_stats_date VALUES ('02122003',14);
INSERT INTO nuke_stats_date VALUES ('03122003',16);
INSERT INTO nuke_stats_date VALUES ('04122003',26);
INSERT INTO nuke_stats_date VALUES ('05122003',20);
INSERT INTO nuke_stats_date VALUES ('06122003',7);
INSERT INTO nuke_stats_date VALUES ('07122003',3);
INSERT INTO nuke_stats_date VALUES ('08122003',48);
INSERT INTO nuke_stats_date VALUES ('09122003',7);
INSERT INTO nuke_stats_date VALUES ('10122003',7);
INSERT INTO nuke_stats_date VALUES ('11122003',4);
INSERT INTO nuke_stats_date VALUES ('12122003',3);
INSERT INTO nuke_stats_date VALUES ('13122003',10);
INSERT INTO nuke_stats_date VALUES ('15122003',15);
INSERT INTO nuke_stats_date VALUES ('16122003',14);
INSERT INTO nuke_stats_date VALUES ('17122003',1);
INSERT INTO nuke_stats_date VALUES ('01012004',7);
INSERT INTO nuke_stats_date VALUES ('02012004',14);
INSERT INTO nuke_stats_date VALUES ('03012004',17);
INSERT INTO nuke_stats_date VALUES ('04012004',14);
INSERT INTO nuke_stats_date VALUES ('05012004',28);
INSERT INTO nuke_stats_date VALUES ('06012004',28);
INSERT INTO nuke_stats_date VALUES ('07012004',31);
INSERT INTO nuke_stats_date VALUES ('08012004',215);
INSERT INTO nuke_stats_date VALUES ('09012004',30);
INSERT INTO nuke_stats_date VALUES ('10012004',18);
INSERT INTO nuke_stats_date VALUES ('11012004',22);
INSERT INTO nuke_stats_date VALUES ('12012004',21);
INSERT INTO nuke_stats_date VALUES ('13012004',27);
INSERT INTO nuke_stats_date VALUES ('14012004',17);
INSERT INTO nuke_stats_date VALUES ('15012004',56);
INSERT INTO nuke_stats_date VALUES ('16012004',31);
INSERT INTO nuke_stats_date VALUES ('21012004',13);
INSERT INTO nuke_stats_date VALUES ('22012004',7);
INSERT INTO nuke_stats_date VALUES ('23012004',9);
INSERT INTO nuke_stats_date VALUES ('24012004',2);
INSERT INTO nuke_stats_date VALUES ('25012004',5);
INSERT INTO nuke_stats_date VALUES ('26012004',7);
INSERT INTO nuke_stats_date VALUES ('27012004',7);
INSERT INTO nuke_stats_date VALUES ('28012004',18);
INSERT INTO nuke_stats_date VALUES ('29012004',27);
INSERT INTO nuke_stats_date VALUES ('30012004',4);
INSERT INTO nuke_stats_date VALUES ('31012004',2);
INSERT INTO nuke_stats_date VALUES ('01022004',8);
INSERT INTO nuke_stats_date VALUES ('02022004',13);
INSERT INTO nuke_stats_date VALUES ('03022004',10);
INSERT INTO nuke_stats_date VALUES ('04022004',15);
INSERT INTO nuke_stats_date VALUES ('05022004',38);
INSERT INTO nuke_stats_date VALUES ('06022004',14);
INSERT INTO nuke_stats_date VALUES ('07022004',8);
INSERT INTO nuke_stats_date VALUES ('08022004',11);
INSERT INTO nuke_stats_date VALUES ('09022004',12);
INSERT INTO nuke_stats_date VALUES ('10022004',6);
INSERT INTO nuke_stats_date VALUES ('11022004',14);
INSERT INTO nuke_stats_date VALUES ('12022004',22);
INSERT INTO nuke_stats_date VALUES ('13022004',36);
INSERT INTO nuke_stats_date VALUES ('14022004',35);
INSERT INTO nuke_stats_date VALUES ('15022004',34);
INSERT INTO nuke_stats_date VALUES ('16022004',29);
INSERT INTO nuke_stats_date VALUES ('17022004',32);
INSERT INTO nuke_stats_date VALUES ('18022004',32);
INSERT INTO nuke_stats_date VALUES ('19022004',25);
INSERT INTO nuke_stats_date VALUES ('20022004',35);
INSERT INTO nuke_stats_date VALUES ('21022004',50);
INSERT INTO nuke_stats_date VALUES ('22022004',28);
INSERT INTO nuke_stats_date VALUES ('23022004',23);
INSERT INTO nuke_stats_date VALUES ('24022004',11);

--
-- Table structure for table 'nuke_stats_hour'
--

CREATE TABLE nuke_stats_hour (
  pn_hour tinyint(2) unsigned NOT NULL default '0',
  pn_hits int(11) unsigned NOT NULL default '0'
) TYPE=MyISAM;

--
-- Dumping data for table 'nuke_stats_hour'
--


INSERT INTO nuke_stats_hour VALUES (0,9532);
INSERT INTO nuke_stats_hour VALUES (1,8258);
INSERT INTO nuke_stats_hour VALUES (2,8736);
INSERT INTO nuke_stats_hour VALUES (3,6310);
INSERT INTO nuke_stats_hour VALUES (4,4979);
INSERT INTO nuke_stats_hour VALUES (5,9605);
INSERT INTO nuke_stats_hour VALUES (6,25377);
INSERT INTO nuke_stats_hour VALUES (7,21296);
INSERT INTO nuke_stats_hour VALUES (8,8114);
INSERT INTO nuke_stats_hour VALUES (9,3635);
INSERT INTO nuke_stats_hour VALUES (10,3737);
INSERT INTO nuke_stats_hour VALUES (11,4188);
INSERT INTO nuke_stats_hour VALUES (12,4020);
INSERT INTO nuke_stats_hour VALUES (13,4246);
INSERT INTO nuke_stats_hour VALUES (14,4671);
INSERT INTO nuke_stats_hour VALUES (15,4945);
INSERT INTO nuke_stats_hour VALUES (16,4832);
INSERT INTO nuke_stats_hour VALUES (17,4201);
INSERT INTO nuke_stats_hour VALUES (18,7016);
INSERT INTO nuke_stats_hour VALUES (19,9486);
INSERT INTO nuke_stats_hour VALUES (20,11220);
INSERT INTO nuke_stats_hour VALUES (21,11784);
INSERT INTO nuke_stats_hour VALUES (22,9819);
INSERT INTO nuke_stats_hour VALUES (23,11539);

--
-- Table structure for table 'nuke_stats_month'
--

CREATE TABLE nuke_stats_month (
  pn_month tinyint(2) unsigned NOT NULL default '0',
  pn_hits int(11) unsigned NOT NULL default '0'
) TYPE=MyISAM;

--
-- Dumping data for table 'nuke_stats_month'
--


INSERT INTO nuke_stats_month VALUES (1,677);
INSERT INTO nuke_stats_month VALUES (2,541);
INSERT INTO nuke_stats_month VALUES (3,0);
INSERT INTO nuke_stats_month VALUES (4,0);
INSERT INTO nuke_stats_month VALUES (5,0);
INSERT INTO nuke_stats_month VALUES (6,0);
INSERT INTO nuke_stats_month VALUES (7,1127);
INSERT INTO nuke_stats_month VALUES (8,161535);
INSERT INTO nuke_stats_month VALUES (9,35506);
INSERT INTO nuke_stats_month VALUES (10,1243);
INSERT INTO nuke_stats_month VALUES (11,712);
INSERT INTO nuke_stats_month VALUES (12,205);

--
-- Table structure for table 'nuke_stats_week'
--

CREATE TABLE nuke_stats_week (
  pn_weekday tinyint(1) unsigned NOT NULL default '0',
  pn_hits int(11) unsigned NOT NULL default '0'
) TYPE=MyISAM;

--
-- Dumping data for table 'nuke_stats_week'
--


INSERT INTO nuke_stats_week VALUES (0,43117);
INSERT INTO nuke_stats_week VALUES (1,16103);
INSERT INTO nuke_stats_week VALUES (2,15445);
INSERT INTO nuke_stats_week VALUES (3,24166);
INSERT INTO nuke_stats_week VALUES (4,26412);
INSERT INTO nuke_stats_week VALUES (5,30442);
INSERT INTO nuke_stats_week VALUES (6,45861);

--
-- Table structure for table 'nuke_stories'
--

CREATE TABLE nuke_stories (
  pn_sid int(11) NOT NULL auto_increment,
  pn_catid int(11) NOT NULL default '0',
  pn_aid varchar(30) NOT NULL default '',
  pn_title varchar(255) default NULL,
  pn_time datetime default NULL,
  pn_hometext text,
  pn_bodytext text NOT NULL,
  pn_comments int(11) default '0',
  pn_counter mediumint(8) unsigned default NULL,
  pn_topic tinyint(4) NOT NULL default '1',
  pn_informant varchar(20) NOT NULL default '',
  pn_notes text NOT NULL,
  pn_ihome tinyint(1) NOT NULL default '0',
  pn_themeoverride varchar(30) NOT NULL default '',
  pn_language varchar(30) NOT NULL default '',
  pn_withcomm tinyint(1) NOT NULL default '0',
  pn_format_type tinyint(1) unsigned NOT NULL default '0',
  PRIMARY KEY  (pn_sid)
) TYPE=MyISAM;

--
-- Dumping data for table 'nuke_stories'
--


INSERT INTO nuke_stories VALUES (7,0,'15','Air Force Plans','2003-08-15 15:16:22','The air force group is planning a two hour flight early on  Tuesday 26 August.    The plan would be to be on site fat the AFA runway between 6:30 and 7:15 AM (!) .   This would require an early morning launch, but would give high pollution levels due to the morning inversion.    We will discuss at the meeting next Tuesday morning at 9:00 on August 19. <br />\r\n<br />\r\n','',0,106,6,'stith','',0,'','eng',0,0);
INSERT INTO nuke_stories VALUES (6,0,'17','Current Status','2003-08-11 14:45:19','First aircraft flight to be on 18 August 2003.','',0,107,7,'ruth','',0,'','',0,0);
INSERT INTO nuke_stories VALUES (4,1,'16','The Website has moved','2003-07-28 13:11:21','The Web site for the IDEAS3 project has been moved.','The Web site for the IDEAS3 project has been moved to <a href=\"http://syrah.atd.ucar.edu/IDEAS3\">http://syrah.atd.ucar.edu/IDEAS3</a> .  Future development activity will occur there.',0,93,5,'stither','',1,'','',0,5);
INSERT INTO nuke_stories VALUES (8,0,'16','The Web Site is Now Public','2003-08-20 10:40:03','The IDEAS3 Web Site is now available from outside the UCAR network from the URL <a href=\"http://raf.atd.ucar.edu/IDEAS3\">http://raf.atd.ucar.edu/IDEAS3</a>.  ','',0,107,5,'stither','',0,'','eng',0,0);
INSERT INTO nuke_stories VALUES (10,0,'15','Flight Summary for RF01','2003-08-21 16:19:49','RF01 was a successful cloud test of the FSSPs and other instruments.    A climbout was conducted to 20 k feet, stopping at 8000 and 13000 feet for about 5 minutes.    Then reverse track manuvers were conducted.   Next a series of flight legs through cu congestus were conducted between 18000 and 14000 (top and base of the cloud).  The final part of the flight did high angle of attack passes through the clouds and sideslips through the clouds to test for differences between the two FSSPs. <br />\r\n<br />\r\nJeff Stith','',0,115,6,'stith','',0,'','eng',0,0);
INSERT INTO nuke_stories VALUES (11,0,'17','Research Flight 3','2003-08-25 14:40:27','RF03 will take place Tuesday 26 August 2003.<br />\r\n  9:00 a.m briefing in Jeffco Conference Room<br />\r\n  1:00 p.m. take-off<br />\r\n','',0,106,7,'ruth','',0,'','eng',0,0);
INSERT INTO nuke_stories VALUES (12,0,'15','Status for 26 August','2003-08-26 11:31:27','A 13:00 2 to 3 hour flight is planned for today.   We will debrief in the break room following the flight.   The next flight is planned for 06:00 on Thursday, but may be canceled, so check back before showing up.    If the Thursday (Air Force Academy) flight is on, we will have a brief meeting at 4:00 tomorrow (Wednesday) to review the flight plan and participants.    <br />\r\n<br />\r\nA science meeting to discuss the results to-date will be held on Friday at 2:00 in the conference room.  We will also do flight planning for next week.    <br />\r\n<br />\r\nWe will observe the Labor Day weekend.  <br />\r\n<br />\r\nRon will hold a web development meeting on Thursday (see Calendar).  <br />\r\n<br />\r\nJeff Stith','',0,104,7,'stith','',0,'','eng',0,0);
INSERT INTO nuke_stories VALUES (14,0,'15','Status update','2003-08-27 10:56:35','The Air Force cannot get clearance for a flight tomorrow, so the flight tomorrow is canceled.   They will try and reschedule for next Thursday, September 4. <br />\r\nI propose we fly Friday with a 13:00 takeoff, and move the science meeting earlier from Friday to Thursday (tomorrow) at 2:00.   We can discuss the result from the last flight and plan the flight schedule and payload for next week.   Ron\'s Thursday web page development meeting will remain as scheduled.<br />\r\n<br />\r\nWe will observe the Labor day holiday.<br />\r\nJeff ','',0,104,7,'stith','',0,'','eng',0,0);
INSERT INTO nuke_stories VALUES (15,0,'18',' RF04','2003-08-28 17:03:53','Research Flight 4 take-off scheduled for 13:00 on Friday 29 August.  Flight planning with pilots at 09:00.<br />\r\nFlights for next week are tentatively planned for Wednesday 3 September at 11:00 (with a briefing at 16:00 on Tuesday 2 September) and for Thursday  4 September at 06:00 (Air Force Academy). ','',0,115,7,'dcrogers','',0,'','eng',0,0);
INSERT INTO nuke_stories VALUES (16,0,'15','Summary of RF04','2003-09-02 17:17:16','Summary of RF04<br />\r\n<br />\r\n29 August, 2003<br />\r\n<br />\r\n<br />\r\nThe flight began with a climb to 16 k feet, on the way to Cheyenne.   We did a reverse track maneuver at 16, a climb to 22 k feet and another reverse track.   We had considerable delays due to ATC, but accomplished the above the first hour of the flight.   We then went northeast to a storm outside of the busy traffic area and were able to sample it from 22 k feet (about -18 �C) to 10 k feet (near cloud base at about +5 �C)).    This was a strong thunderstorm, with nearby lightning, heavy rain, graupel, and turbulence.   It should provide a wide variety of particle types in both warm and cold convective cloud environments.    <br />\r\n<br />\r\nOn the way home we pass through some lower clouds that were near the top of the BL, and also sampled below them in the BL for aerosol  <br />\r\n<br />\r\nA good day.   Most instruments worked well.    <br />\r\n','',0,100,7,'stith','',0,'','eng',0,0);
INSERT INTO nuke_stories VALUES (17,0,'17','Status as of 16:45 Tuesday, September 2, 2003','2003-09-02 17:21:21','We have two unknowns at present.  The Air Force group (as of 15:30) was still uncertain of their status for a flight on Thursday.  Second, the instrumentation for an 11:00 flight tomorrow may not be fully ready.  Consequently, we will cancel the flight tomorrow to assure that instruments will be ready for a flight on Thursday.  We will get a go/no go from the Air Force group tomorrow.  We will plan on a Thursday morning flight in any event, with a 06:45 take off time if the Air Force is ready.  If the Air Force is not ready, we will fly with a takeoff time of 09:00.  Unless there happen to be clouds available (the forecast does have a chance of widespread clouds), the Thursday morning flight will be relatively brief.<br />\r\n                                                                                <br />\r\nWe will plan for a second flight this week at 13:00 on Friday, approximately 2 to 5 hours, depending on cloud type and availability.<br />\r\n                                                                                <br />\r\nWe will meet again at 16:00 tomorrow to do flight planning for the Thursday and<br />\r\nFriday flights.   The results will be posted to the email and to the web.<br />\r\n                                                                                <br />\r\nJeff Stith','',0,104,7,'ruth','',0,'','eng',0,0);
INSERT INTO nuke_stories VALUES (18,0,'15','Update','2003-09-03 10:34:57','Folks,<br />\r\n<br />\r\nThe Air Force has canceled their flight tomorrow.    We will plan on a morning flight anyway, as it will give us a good chance to sample the  urban plume just after rush hour.     So we will plan on a 9:00 take off.   We will still do a 16:00 flight planning meeting today for those able to attend.   For those not able to attend, let me know of your wishes.<br />\r\nWe are still planning a Friday afternoon flight and will discuss it briefly at the 16:00 meeting today.<br />\r\n<br />\r\nJeff Stith<br />\r\n','',0,154,7,'stith','',0,'','eng',0,0);
INSERT INTO nuke_stories VALUES (19,0,'18','status update - Thursday morning flight outlook','2003-09-03 16:57:50','A flight of about two hours is planned for Thursday Sep 4.  Likely flight plan includes boundary layer transects through urban plume downwind of Denver, climb to about 22,000ft and then cloud penetrations if clouds are present.<br />\r\n<br />\r\n07:15am aircraft pull out of hangar<br />\r\n07:30 power available on aircraft<br />\r\n08:00 brief flight planning meeting<br />\r\n08:30 all personnel on board<br />\r\n09:00 take-off<br />\r\n<br />\r\nNext flight Friday afternoon.<br />\r\n<br />\r\n  ..Dave Rogers..','',0,151,7,'dcrogers','',0,'','eng',0,0);
INSERT INTO nuke_stories VALUES (20,0,'17','Upcoming Events','2003-09-10 12:49:55','Thursday 11 September 2003<br />\r\n&nbsp;&nbsp;11:45 a.m.&nbsp;&nbsp;Jeffco Conference Room:  Brief flight-planning meeting<br />\r\n&nbsp;&nbsp; &nbsp;&nbsp;1:30 p.m.&nbsp;&nbsp;scheduled take-off for Research Flight 7 (RF07)<br />\r\n                                                                                <br />\r\n&nbsp;&nbsp;Friday 12 September 2003<br />\r\n&nbsp;&nbsp;10:00 a.m.&nbsp;&nbsp;Jeffco Conference Room:  Science Review Meeting<br />\r\n&nbsp;&nbsp;- 12&nbsp;noon&nbsp;&nbsp;&nbsp;&nbsp;Bring your stuff to share<br />\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;(Web site discussion, too, if time permits)','',0,123,7,'ruth','',0,'','',0,0);
INSERT INTO nuke_stories VALUES (22,0,'18','plans Sep 15-19','2003-09-15 11:36:38','<P>At the science meeting today, we decided to propose flights for 13:30 (take-off) o�n Monday, Wednesday, and Friday of next week.    Those interested will meet at 11:30 o�n Monday to do flight planning.    Each flight is planned for three hours, although we may modify this as instrumentation needs become clearer.</P><P>Have a good weekend.</P><P>Jeff Stith<BR></P>','',0,102,7,'dcrogers','',0,'','eng',0,1);
INSERT INTO nuke_stories VALUES (23,0,'17','RF10 and RF11','2003-09-17 17:59:27','Research Flight 10 takeoff 19 September 2003 @ 0900<br />\r\n(Briefing and Flight Plan in RAF Conference Room at 0800)<br><br />\r\nResearch Flight 11 takeoff 19 September 2003 @ 1400<br />\r\n(Briefing and Flight Plan in RAF Conference Room at  1230)','',0,99,7,'ruth','',0,'','eng',0,0);

--
-- Table structure for table 'nuke_stories_cat'
--

CREATE TABLE nuke_stories_cat (
  pn_catid int(11) NOT NULL auto_increment,
  pn_title varchar(40) NOT NULL default '',
  pn_counter int(11) NOT NULL default '0',
  pn_themeoverride varchar(30) NOT NULL default '',
  PRIMARY KEY  (pn_catid)
) TYPE=MyISAM;

--
-- Dumping data for table 'nuke_stories_cat'
--


INSERT INTO nuke_stories_cat VALUES (1,'Status',98,'IDEASNuke');

--
-- Table structure for table 'nuke_topics'
--

CREATE TABLE nuke_topics (
  pn_topicid tinyint(4) NOT NULL auto_increment,
  pn_topicname varchar(255) default NULL,
  pn_topicimage varchar(255) default NULL,
  pn_topictext varchar(255) default NULL,
  pn_counter int(11) NOT NULL default '0',
  PRIMARY KEY  (pn_topicid)
) TYPE=MyISAM;

--
-- Dumping data for table 'nuke_topics'
--


INSERT INTO nuke_topics VALUES (6,'Project News','blank.png','Information about the IDEAS3 Project',65);
INSERT INTO nuke_topics VALUES (5,'This Website','blank.png','The IDEAS3 Website',82);
INSERT INTO nuke_topics VALUES (7,'missionstatus','blank.png','Current Mission Status',94);
INSERT INTO nuke_topics VALUES (10,'RAF Seminar','blank.png','RAF Seminar',0);

--
-- Table structure for table 'nuke_user_data'
--

CREATE TABLE nuke_user_data (
  pn_uda_id int(11) NOT NULL auto_increment,
  pn_uda_propid int(11) NOT NULL default '0',
  pn_uda_uid int(11) NOT NULL default '0',
  pn_uda_value mediumblob NOT NULL,
  PRIMARY KEY  (pn_uda_id)
) TYPE=MyISAM;

--
-- Dumping data for table 'nuke_user_data'
--



--
-- Table structure for table 'nuke_user_perms'
--

CREATE TABLE nuke_user_perms (
  pn_pid int(11) NOT NULL auto_increment,
  pn_uid int(11) NOT NULL default '0',
  pn_sequence int(6) NOT NULL default '0',
  pn_realm int(4) NOT NULL default '0',
  pn_component varchar(255) NOT NULL default '',
  pn_instance varchar(255) NOT NULL default '',
  pn_level int(4) NOT NULL default '0',
  pn_bond int(2) NOT NULL default '0',
  PRIMARY KEY  (pn_pid)
) TYPE=MyISAM;

--
-- Dumping data for table 'nuke_user_perms'
--



--
-- Table structure for table 'nuke_user_property'
--

CREATE TABLE nuke_user_property (
  pn_prop_id int(11) NOT NULL auto_increment,
  pn_prop_label varchar(255) NOT NULL default '',
  pn_prop_dtype int(11) NOT NULL default '0',
  pn_prop_length int(11) NOT NULL default '255',
  pn_prop_weight int(11) NOT NULL default '0',
  pn_prop_validation varchar(255) default NULL,
  PRIMARY KEY  (pn_prop_id),
  UNIQUE KEY pn_prop_label (pn_prop_label)
) TYPE=MyISAM;

--
-- Dumping data for table 'nuke_user_property'
--


INSERT INTO nuke_user_property VALUES (1,'_UREALNAME',0,255,1,NULL);
INSERT INTO nuke_user_property VALUES (2,'_UREALEMAIL',-1,255,2,NULL);
INSERT INTO nuke_user_property VALUES (3,'_UFAKEMAIL',0,255,3,NULL);
INSERT INTO nuke_user_property VALUES (4,'_YOURHOMEPAGE',0,255,4,NULL);
INSERT INTO nuke_user_property VALUES (5,'_TIMEZONEOFFSET',0,255,5,NULL);
INSERT INTO nuke_user_property VALUES (6,'_YOURAVATAR',0,255,6,NULL);
INSERT INTO nuke_user_property VALUES (7,'_YICQ',0,255,7,NULL);
INSERT INTO nuke_user_property VALUES (8,'_YAIM',0,255,8,NULL);
INSERT INTO nuke_user_property VALUES (9,'_YYIM',0,255,9,NULL);
INSERT INTO nuke_user_property VALUES (10,'_YMSNM',0,255,10,NULL);
INSERT INTO nuke_user_property VALUES (11,'_YLOCATION',0,255,11,NULL);
INSERT INTO nuke_user_property VALUES (12,'_YOCCUPATION',0,255,12,NULL);
INSERT INTO nuke_user_property VALUES (13,'_YINTERESTS',0,255,13,NULL);
INSERT INTO nuke_user_property VALUES (14,'_SIGNATURE',0,255,14,NULL);
INSERT INTO nuke_user_property VALUES (15,'_EXTRAINFO',0,255,15,NULL);
INSERT INTO nuke_user_property VALUES (16,'_PASSWORD',-1,255,16,NULL);

--
-- Table structure for table 'nuke_userblocks'
--

CREATE TABLE nuke_userblocks (
  pn_uid int(11) NOT NULL default '0',
  pn_bid int(11) NOT NULL default '0',
  pn_active tinyint(3) NOT NULL default '1',
  pn_last_update timestamp(14) NOT NULL
) TYPE=MyISAM;

--
-- Dumping data for table 'nuke_userblocks'
--


INSERT INTO nuke_userblocks VALUES (2,16,1,20030708152626);
INSERT INTO nuke_userblocks VALUES (2,1,1,20030715162951);
INSERT INTO nuke_userblocks VALUES (2,3,1,20030708150222);
INSERT INTO nuke_userblocks VALUES (2,8,1,20030708150222);
INSERT INTO nuke_userblocks VALUES (2,15,1,20030708150222);
INSERT INTO nuke_userblocks VALUES (2,11,1,20030708150222);
INSERT INTO nuke_userblocks VALUES (2,2,1,20030708164604);
INSERT INTO nuke_userblocks VALUES (2,18,1,20030709111850);
INSERT INTO nuke_userblocks VALUES (2,19,1,20030709112003);
INSERT INTO nuke_userblocks VALUES (2,20,1,20030709112058);
INSERT INTO nuke_userblocks VALUES (2,21,1,20030709113449);
INSERT INTO nuke_userblocks VALUES (2,22,1,20030709123224);
INSERT INTO nuke_userblocks VALUES (2,23,1,20030709124627);
INSERT INTO nuke_userblocks VALUES (3,22,1,20030709125315);
INSERT INTO nuke_userblocks VALUES (3,1,1,20030709125315);
INSERT INTO nuke_userblocks VALUES (3,15,1,20030709125315);
INSERT INTO nuke_userblocks VALUES (3,23,1,20030709125315);
INSERT INTO nuke_userblocks VALUES (3,21,1,20030709125315);
INSERT INTO nuke_userblocks VALUES (3,20,1,20030709125315);
INSERT INTO nuke_userblocks VALUES (3,19,1,20030709125315);
INSERT INTO nuke_userblocks VALUES (3,18,1,20030709125315);
INSERT INTO nuke_userblocks VALUES (3,3,1,20030709125315);
INSERT INTO nuke_userblocks VALUES (3,8,1,20030709125315);
INSERT INTO nuke_userblocks VALUES (2,24,1,20030709150221);
INSERT INTO nuke_userblocks VALUES (2,26,1,20030709150316);
INSERT INTO nuke_userblocks VALUES (2,27,1,20030709150405);
INSERT INTO nuke_userblocks VALUES (2,28,1,20030709150502);
INSERT INTO nuke_userblocks VALUES (5,1,1,20030710123419);
INSERT INTO nuke_userblocks VALUES (5,15,1,20030710123419);
INSERT INTO nuke_userblocks VALUES (5,23,1,20030710123419);
INSERT INTO nuke_userblocks VALUES (5,21,1,20030710123419);
INSERT INTO nuke_userblocks VALUES (5,3,1,20030710123419);
INSERT INTO nuke_userblocks VALUES (5,8,1,20030710123419);
INSERT INTO nuke_userblocks VALUES (2,4,1,20030722164956);
INSERT INTO nuke_userblocks VALUES (2,0,1,20030710152731);
INSERT INTO nuke_userblocks VALUES (6,1,1,20030711161929);
INSERT INTO nuke_userblocks VALUES (6,15,1,20030714123522);
INSERT INTO nuke_userblocks VALUES (6,23,1,20030714123522);
INSERT INTO nuke_userblocks VALUES (6,3,1,20030714123522);
INSERT INTO nuke_userblocks VALUES (7,1,1,20030714172247);
INSERT INTO nuke_userblocks VALUES (7,15,1,20030714172247);
INSERT INTO nuke_userblocks VALUES (7,23,1,20030714172247);
INSERT INTO nuke_userblocks VALUES (7,3,1,20030714172247);
INSERT INTO nuke_userblocks VALUES (8,1,1,20030715164719);
INSERT INTO nuke_userblocks VALUES (8,15,1,20030715164720);
INSERT INTO nuke_userblocks VALUES (8,23,1,20030715164720);
INSERT INTO nuke_userblocks VALUES (8,4,1,20030715164720);
INSERT INTO nuke_userblocks VALUES (8,3,1,20030715164720);
INSERT INTO nuke_userblocks VALUES (8,12,1,20030715164720);
INSERT INTO nuke_userblocks VALUES (8,0,1,20030715164754);
INSERT INTO nuke_userblocks VALUES (5,4,1,20030715164856);
INSERT INTO nuke_userblocks VALUES (5,12,1,20030715164856);
INSERT INTO nuke_userblocks VALUES (2,12,1,20030715170000);
INSERT INTO nuke_userblocks VALUES (2,30,1,20030716111020);
INSERT INTO nuke_userblocks VALUES (2,31,1,20030716111100);
INSERT INTO nuke_userblocks VALUES (5,30,1,20030716123155);
INSERT INTO nuke_userblocks VALUES (10,1,1,20030716142052);
INSERT INTO nuke_userblocks VALUES (10,30,1,20030716142053);
INSERT INTO nuke_userblocks VALUES (10,4,1,20030716142053);
INSERT INTO nuke_userblocks VALUES (10,23,1,20030716142424);
INSERT INTO nuke_userblocks VALUES (10,3,1,20030716142424);
INSERT INTO nuke_userblocks VALUES (8,30,1,20030716160301);
INSERT INTO nuke_userblocks VALUES (2,32,1,20030724143012);
INSERT INTO nuke_userblocks VALUES (2,35,1,20030724170527);
INSERT INTO nuke_userblocks VALUES (11,35,0,20030909110706);
INSERT INTO nuke_userblocks VALUES (11,1,1,20030724154337);
INSERT INTO nuke_userblocks VALUES (11,4,1,20030724154337);
INSERT INTO nuke_userblocks VALUES (11,30,1,20030724154337);
INSERT INTO nuke_userblocks VALUES (22,1,1,20031014092607);
INSERT INTO nuke_userblocks VALUES (22,35,1,20031014092601);
INSERT INTO nuke_userblocks VALUES (22,23,1,20030725102141);
INSERT INTO nuke_userblocks VALUES (22,3,1,20030725102141);
INSERT INTO nuke_userblocks VALUES (22,4,1,20030725102141);
INSERT INTO nuke_userblocks VALUES (22,30,1,20030725102141);
INSERT INTO nuke_userblocks VALUES (16,1,1,20030801153827);
INSERT INTO nuke_userblocks VALUES (16,35,0,20030819112224);
INSERT INTO nuke_userblocks VALUES (16,23,1,20030725105013);
INSERT INTO nuke_userblocks VALUES (16,3,1,20030725105013);
INSERT INTO nuke_userblocks VALUES (16,4,1,20030725105013);
INSERT INTO nuke_userblocks VALUES (16,30,1,20030725105013);
INSERT INTO nuke_userblocks VALUES (16,37,0,20030819112220);
INSERT INTO nuke_userblocks VALUES (17,1,1,20030917162944);
INSERT INTO nuke_userblocks VALUES (17,37,0,20040121170142);
INSERT INTO nuke_userblocks VALUES (17,35,0,20031008104100);
INSERT INTO nuke_userblocks VALUES (17,23,1,20030725163246);
INSERT INTO nuke_userblocks VALUES (17,3,1,20030828173417);
INSERT INTO nuke_userblocks VALUES (17,4,1,20031013144036);
INSERT INTO nuke_userblocks VALUES (17,30,0,20030905135016);
INSERT INTO nuke_userblocks VALUES (2,37,1,20030728123817);
INSERT INTO nuke_userblocks VALUES (16,0,1,20030728130708);
INSERT INTO nuke_userblocks VALUES (16,12,1,20030728131223);
INSERT INTO nuke_userblocks VALUES (17,12,1,20030728171343);
INSERT INTO nuke_userblocks VALUES (21,1,1,20030729111347);
INSERT INTO nuke_userblocks VALUES (21,37,0,20030812105223);
INSERT INTO nuke_userblocks VALUES (21,35,1,20030812105234);
INSERT INTO nuke_userblocks VALUES (21,0,1,20030729111347);
INSERT INTO nuke_userblocks VALUES (21,23,1,20030729111404);
INSERT INTO nuke_userblocks VALUES (21,3,0,20030829093842);
INSERT INTO nuke_userblocks VALUES (21,4,1,20030729111404);
INSERT INTO nuke_userblocks VALUES (21,30,1,20030729111404);
INSERT INTO nuke_userblocks VALUES (17,39,0,20031215110401);
INSERT INTO nuke_userblocks VALUES (16,39,0,20030813144859);
INSERT INTO nuke_userblocks VALUES (17,0,1,20030729165349);
INSERT INTO nuke_userblocks VALUES (20,1,1,20030730131913);
INSERT INTO nuke_userblocks VALUES (20,37,1,20030730131913);
INSERT INTO nuke_userblocks VALUES (20,35,1,20030730131913);
INSERT INTO nuke_userblocks VALUES (20,39,1,20030730131913);
INSERT INTO nuke_userblocks VALUES (20,23,1,20030730131914);
INSERT INTO nuke_userblocks VALUES (20,3,1,20030730131914);
INSERT INTO nuke_userblocks VALUES (20,4,1,20030730131914);
INSERT INTO nuke_userblocks VALUES (20,30,1,20030730131914);
INSERT INTO nuke_userblocks VALUES (22,37,1,20031014092558);
INSERT INTO nuke_userblocks VALUES (22,39,0,20030808113622);
INSERT INTO nuke_userblocks VALUES (18,1,1,20030731130123);
INSERT INTO nuke_userblocks VALUES (18,37,1,20031020141334);
INSERT INTO nuke_userblocks VALUES (18,35,1,20031020141332);
INSERT INTO nuke_userblocks VALUES (18,39,0,20030903165419);
INSERT INTO nuke_userblocks VALUES (18,23,1,20030731130124);
INSERT INTO nuke_userblocks VALUES (18,3,1,20030828170543);
INSERT INTO nuke_userblocks VALUES (18,4,1,20030731130124);
INSERT INTO nuke_userblocks VALUES (18,30,1,20030731130124);
INSERT INTO nuke_userblocks VALUES (17,15,1,20030731151847);
INSERT INTO nuke_userblocks VALUES (16,15,1,20030801094420);
INSERT INTO nuke_userblocks VALUES (18,15,1,20030801124707);
INSERT INTO nuke_userblocks VALUES (16,2,1,20030805104523);
INSERT INTO nuke_userblocks VALUES (23,1,1,20030805150213);
INSERT INTO nuke_userblocks VALUES (23,37,1,20030805150213);
INSERT INTO nuke_userblocks VALUES (23,35,1,20030805150213);
INSERT INTO nuke_userblocks VALUES (23,39,1,20030805150213);
INSERT INTO nuke_userblocks VALUES (23,15,1,20030805150341);
INSERT INTO nuke_userblocks VALUES (23,23,1,20030805150341);
INSERT INTO nuke_userblocks VALUES (23,3,1,20030805150341);
INSERT INTO nuke_userblocks VALUES (23,4,1,20030805150341);
INSERT INTO nuke_userblocks VALUES (23,30,1,20030805150341);
INSERT INTO nuke_userblocks VALUES (21,39,1,20030806110915);
INSERT INTO nuke_userblocks VALUES (21,15,1,20030806110915);
INSERT INTO nuke_userblocks VALUES (17,2,1,20030911115901);
INSERT INTO nuke_userblocks VALUES (17,33,1,20030807160547);
INSERT INTO nuke_userblocks VALUES (17,9,1,20030807153836);
INSERT INTO nuke_userblocks VALUES (16,33,1,20030807160511);
INSERT INTO nuke_userblocks VALUES (16,9,0,20030807162952);
INSERT INTO nuke_userblocks VALUES (22,15,1,20030808113609);
INSERT INTO nuke_userblocks VALUES (10,37,1,20030808132604);
INSERT INTO nuke_userblocks VALUES (10,35,1,20030808132604);
INSERT INTO nuke_userblocks VALUES (10,39,1,20030808132604);
INSERT INTO nuke_userblocks VALUES (10,15,1,20030808132604);
INSERT INTO nuke_userblocks VALUES (19,1,1,20030813152216);
INSERT INTO nuke_userblocks VALUES (19,37,0,20030821123421);
INSERT INTO nuke_userblocks VALUES (19,35,1,20030827170503);
INSERT INTO nuke_userblocks VALUES (19,39,0,20030821123446);
INSERT INTO nuke_userblocks VALUES (19,15,1,20030813152627);
INSERT INTO nuke_userblocks VALUES (19,23,1,20030813152627);
INSERT INTO nuke_userblocks VALUES (19,3,1,20030813152627);
INSERT INTO nuke_userblocks VALUES (19,4,1,20030813152627);
INSERT INTO nuke_userblocks VALUES (19,30,1,20030813152627);
INSERT INTO nuke_userblocks VALUES (15,1,1,20030815142624);
INSERT INTO nuke_userblocks VALUES (15,37,1,20030815142624);
INSERT INTO nuke_userblocks VALUES (15,35,1,20030815142624);
INSERT INTO nuke_userblocks VALUES (15,39,1,20030815142624);
INSERT INTO nuke_userblocks VALUES (15,15,1,20030815142944);
INSERT INTO nuke_userblocks VALUES (15,23,1,20030815142944);
INSERT INTO nuke_userblocks VALUES (15,3,1,20030826112234);
INSERT INTO nuke_userblocks VALUES (15,4,1,20030827103000);
INSERT INTO nuke_userblocks VALUES (15,30,1,20030815142944);
INSERT INTO nuke_userblocks VALUES (19,0,1,20030815150408);
INSERT INTO nuke_userblocks VALUES (18,0,1,20030818091635);
INSERT INTO nuke_userblocks VALUES (11,37,1,20030819112150);
INSERT INTO nuke_userblocks VALUES (11,39,1,20030819112150);
INSERT INTO nuke_userblocks VALUES (11,15,1,20030819112150);
INSERT INTO nuke_userblocks VALUES (11,23,1,20030819112151);
INSERT INTO nuke_userblocks VALUES (11,3,0,20030820230916);
INSERT INTO nuke_userblocks VALUES (11,0,1,20030819112246);
INSERT INTO nuke_userblocks VALUES (18,12,1,20030820104250);
INSERT INTO nuke_userblocks VALUES (11,12,1,20030820230035);
INSERT INTO nuke_userblocks VALUES (38,1,1,20030825165816);
INSERT INTO nuke_userblocks VALUES (38,37,1,20030825165816);
INSERT INTO nuke_userblocks VALUES (38,35,1,20030829151502);
INSERT INTO nuke_userblocks VALUES (38,39,0,20030826151031);
INSERT INTO nuke_userblocks VALUES (38,15,1,20030825165816);
INSERT INTO nuke_userblocks VALUES (38,23,1,20030825165817);
INSERT INTO nuke_userblocks VALUES (38,3,1,20030825165817);
INSERT INTO nuke_userblocks VALUES (38,12,1,20030825165817);
INSERT INTO nuke_userblocks VALUES (38,4,1,20030825165817);
INSERT INTO nuke_userblocks VALUES (38,30,1,20030825165817);
INSERT INTO nuke_userblocks VALUES (43,1,1,20030826103840);
INSERT INTO nuke_userblocks VALUES (43,37,1,20030826103840);
INSERT INTO nuke_userblocks VALUES (43,35,1,20030826103840);
INSERT INTO nuke_userblocks VALUES (43,39,1,20030826103840);
INSERT INTO nuke_userblocks VALUES (43,15,1,20030826103945);
INSERT INTO nuke_userblocks VALUES (43,23,1,20030826103945);
INSERT INTO nuke_userblocks VALUES (43,3,1,20030826103945);
INSERT INTO nuke_userblocks VALUES (43,4,1,20030826103945);
INSERT INTO nuke_userblocks VALUES (43,30,1,20030826103945);
INSERT INTO nuke_userblocks VALUES (27,1,1,20030826130020);
INSERT INTO nuke_userblocks VALUES (27,37,0,20030910082952);
INSERT INTO nuke_userblocks VALUES (27,35,0,20030910082955);
INSERT INTO nuke_userblocks VALUES (27,39,0,20030826130112);
INSERT INTO nuke_userblocks VALUES (27,15,1,20030826130020);
INSERT INTO nuke_userblocks VALUES (27,23,1,20030826130020);
INSERT INTO nuke_userblocks VALUES (27,3,0,20030910083058);
INSERT INTO nuke_userblocks VALUES (27,4,0,20030910083118);
INSERT INTO nuke_userblocks VALUES (27,30,0,20030910083046);
INSERT INTO nuke_userblocks VALUES (40,1,1,20030826130309);
INSERT INTO nuke_userblocks VALUES (40,37,1,20030826130309);
INSERT INTO nuke_userblocks VALUES (40,35,1,20030826130309);
INSERT INTO nuke_userblocks VALUES (40,39,1,20030826130309);
INSERT INTO nuke_userblocks VALUES (40,15,1,20030826130309);
INSERT INTO nuke_userblocks VALUES (40,23,1,20030826130309);
INSERT INTO nuke_userblocks VALUES (40,3,1,20030826130309);
INSERT INTO nuke_userblocks VALUES (40,4,1,20030826130309);
INSERT INTO nuke_userblocks VALUES (40,30,1,20030826130309);
INSERT INTO nuke_userblocks VALUES (45,1,1,20030826151954);
INSERT INTO nuke_userblocks VALUES (45,37,1,20030826151954);
INSERT INTO nuke_userblocks VALUES (45,35,1,20030826151954);
INSERT INTO nuke_userblocks VALUES (45,39,1,20030826151954);
INSERT INTO nuke_userblocks VALUES (45,15,1,20030826151954);
INSERT INTO nuke_userblocks VALUES (45,23,1,20030826151954);
INSERT INTO nuke_userblocks VALUES (45,3,1,20030826151954);
INSERT INTO nuke_userblocks VALUES (45,4,1,20030826151954);
INSERT INTO nuke_userblocks VALUES (45,30,1,20030826151954);
INSERT INTO nuke_userblocks VALUES (15,2,1,20030902154708);
INSERT INTO nuke_userblocks VALUES (29,1,1,20030827105413);
INSERT INTO nuke_userblocks VALUES (29,37,1,20030827105413);
INSERT INTO nuke_userblocks VALUES (29,35,1,20030827105413);
INSERT INTO nuke_userblocks VALUES (29,39,1,20030827105413);
INSERT INTO nuke_userblocks VALUES (29,15,1,20030827105413);
INSERT INTO nuke_userblocks VALUES (29,23,1,20030827105414);
INSERT INTO nuke_userblocks VALUES (29,3,1,20030827105414);
INSERT INTO nuke_userblocks VALUES (29,4,1,20030827105414);
INSERT INTO nuke_userblocks VALUES (29,30,1,20030827105414);
INSERT INTO nuke_userblocks VALUES (32,1,1,20030827143311);
INSERT INTO nuke_userblocks VALUES (32,37,1,20030827143311);
INSERT INTO nuke_userblocks VALUES (32,35,1,20030827143311);
INSERT INTO nuke_userblocks VALUES (32,39,1,20030827143311);
INSERT INTO nuke_userblocks VALUES (32,15,1,20030827143311);
INSERT INTO nuke_userblocks VALUES (32,23,1,20030827143312);
INSERT INTO nuke_userblocks VALUES (32,3,1,20030827143312);
INSERT INTO nuke_userblocks VALUES (32,12,1,20030827143312);
INSERT INTO nuke_userblocks VALUES (32,4,1,20030827143312);
INSERT INTO nuke_userblocks VALUES (32,30,1,20030827143312);
INSERT INTO nuke_userblocks VALUES (19,12,1,20030827170453);
INSERT INTO nuke_userblocks VALUES (18,2,1,20030828170323);
INSERT INTO nuke_userblocks VALUES (28,1,1,20030829130442);
INSERT INTO nuke_userblocks VALUES (28,37,1,20030829130442);
INSERT INTO nuke_userblocks VALUES (28,35,1,20030829130442);
INSERT INTO nuke_userblocks VALUES (28,39,1,20030829130442);
INSERT INTO nuke_userblocks VALUES (28,15,1,20030829130442);
INSERT INTO nuke_userblocks VALUES (28,23,1,20030829130442);
INSERT INTO nuke_userblocks VALUES (28,3,1,20030829130442);
INSERT INTO nuke_userblocks VALUES (28,4,1,20030829130442);
INSERT INTO nuke_userblocks VALUES (28,30,1,20030829130442);
INSERT INTO nuke_userblocks VALUES (37,1,1,20030829143512);
INSERT INTO nuke_userblocks VALUES (37,37,0,20030829143647);
INSERT INTO nuke_userblocks VALUES (37,35,0,20030829143651);
INSERT INTO nuke_userblocks VALUES (37,39,0,20030829143654);
INSERT INTO nuke_userblocks VALUES (37,15,1,20030829143512);
INSERT INTO nuke_userblocks VALUES (37,23,1,20030829143513);
INSERT INTO nuke_userblocks VALUES (37,3,1,20030829143513);
INSERT INTO nuke_userblocks VALUES (37,4,1,20030829143513);
INSERT INTO nuke_userblocks VALUES (37,30,1,20030829143513);
INSERT INTO nuke_userblocks VALUES (41,1,1,20030901140238);
INSERT INTO nuke_userblocks VALUES (41,37,1,20030901140238);
INSERT INTO nuke_userblocks VALUES (41,35,1,20030901140238);
INSERT INTO nuke_userblocks VALUES (41,39,1,20030901140238);
INSERT INTO nuke_userblocks VALUES (41,15,1,20030901140238);
INSERT INTO nuke_userblocks VALUES (41,23,1,20030901140238);
INSERT INTO nuke_userblocks VALUES (41,3,1,20030917095742);
INSERT INTO nuke_userblocks VALUES (41,4,1,20030901140239);
INSERT INTO nuke_userblocks VALUES (41,30,1,20030901140239);
INSERT INTO nuke_userblocks VALUES (17,14,1,20031010124432);
INSERT INTO nuke_userblocks VALUES (18,14,1,20030903155719);
INSERT INTO nuke_userblocks VALUES (21,14,1,20030904085728);
INSERT INTO nuke_userblocks VALUES (38,14,1,20030904121406);
INSERT INTO nuke_userblocks VALUES (11,14,1,20030904141500);
INSERT INTO nuke_userblocks VALUES (22,14,1,20030904160212);
INSERT INTO nuke_userblocks VALUES (29,14,1,20030905102619);
INSERT INTO nuke_userblocks VALUES (28,14,1,20030905123331);
INSERT INTO nuke_userblocks VALUES (47,1,1,20030905143601);
INSERT INTO nuke_userblocks VALUES (47,37,1,20030905143601);
INSERT INTO nuke_userblocks VALUES (47,35,1,20030905143601);
INSERT INTO nuke_userblocks VALUES (47,39,1,20030905143601);
INSERT INTO nuke_userblocks VALUES (47,15,1,20030905143601);
INSERT INTO nuke_userblocks VALUES (47,23,1,20030905143601);
INSERT INTO nuke_userblocks VALUES (47,3,1,20030905143601);
INSERT INTO nuke_userblocks VALUES (47,14,1,20030905143601);
INSERT INTO nuke_userblocks VALUES (47,4,1,20030905143601);
INSERT INTO nuke_userblocks VALUES (47,30,1,20030905143601);
INSERT INTO nuke_userblocks VALUES (42,1,1,20030908094014);
INSERT INTO nuke_userblocks VALUES (42,37,1,20030908094014);
INSERT INTO nuke_userblocks VALUES (42,35,1,20030908094014);
INSERT INTO nuke_userblocks VALUES (42,39,1,20030908094014);
INSERT INTO nuke_userblocks VALUES (42,15,1,20030908094014);
INSERT INTO nuke_userblocks VALUES (42,23,1,20030908094015);
INSERT INTO nuke_userblocks VALUES (42,3,1,20030910102136);
INSERT INTO nuke_userblocks VALUES (42,14,1,20030908094015);
INSERT INTO nuke_userblocks VALUES (42,4,1,20030908094015);
INSERT INTO nuke_userblocks VALUES (42,30,1,20030908094015);
INSERT INTO nuke_userblocks VALUES (27,14,0,20030910083055);
INSERT INTO nuke_userblocks VALUES (42,0,1,20030910102156);
INSERT INTO nuke_userblocks VALUES (33,1,1,20030910111413);
INSERT INTO nuke_userblocks VALUES (33,37,1,20030910111413);
INSERT INTO nuke_userblocks VALUES (33,35,1,20030910111413);
INSERT INTO nuke_userblocks VALUES (33,39,1,20030910111413);
INSERT INTO nuke_userblocks VALUES (33,15,1,20030910111413);
INSERT INTO nuke_userblocks VALUES (33,23,1,20030910111414);
INSERT INTO nuke_userblocks VALUES (33,3,1,20030910111414);
INSERT INTO nuke_userblocks VALUES (33,14,1,20030910111414);
INSERT INTO nuke_userblocks VALUES (33,4,1,20030910111414);
INSERT INTO nuke_userblocks VALUES (33,30,1,20030910111414);
INSERT INTO nuke_userblocks VALUES (12,1,1,20030911143142);
INSERT INTO nuke_userblocks VALUES (12,37,1,20030911143142);
INSERT INTO nuke_userblocks VALUES (12,35,1,20030911143142);
INSERT INTO nuke_userblocks VALUES (12,39,1,20030911143142);
INSERT INTO nuke_userblocks VALUES (12,15,1,20030911143142);
INSERT INTO nuke_userblocks VALUES (12,23,1,20030911143143);
INSERT INTO nuke_userblocks VALUES (12,3,1,20030911143143);
INSERT INTO nuke_userblocks VALUES (12,14,1,20030911143143);
INSERT INTO nuke_userblocks VALUES (12,4,1,20030911143143);
INSERT INTO nuke_userblocks VALUES (12,30,1,20030911143143);
INSERT INTO nuke_userblocks VALUES (43,14,1,20030915130347);
INSERT INTO nuke_userblocks VALUES (19,14,1,20030915140308);
INSERT INTO nuke_userblocks VALUES (40,14,1,20030915144904);
INSERT INTO nuke_userblocks VALUES (41,14,1,20030917095733);
INSERT INTO nuke_userblocks VALUES (37,14,1,20030917154340);
INSERT INTO nuke_userblocks VALUES (15,14,1,20030919091915);
INSERT INTO nuke_userblocks VALUES (20,15,1,20030919153001);
INSERT INTO nuke_userblocks VALUES (20,14,1,20030919153002);
INSERT INTO nuke_userblocks VALUES (16,14,1,20030924002529);
INSERT INTO nuke_userblocks VALUES (30,1,1,20031116093552);
INSERT INTO nuke_userblocks VALUES (30,37,1,20031208115719);
INSERT INTO nuke_userblocks VALUES (30,35,1,20031116093552);
INSERT INTO nuke_userblocks VALUES (30,39,1,20031116093552);
INSERT INTO nuke_userblocks VALUES (30,15,1,20031116093552);
INSERT INTO nuke_userblocks VALUES (30,23,1,20031116093553);
INSERT INTO nuke_userblocks VALUES (30,3,1,20031116093553);
INSERT INTO nuke_userblocks VALUES (30,14,1,20031116093553);
INSERT INTO nuke_userblocks VALUES (30,4,1,20031116093553);
INSERT INTO nuke_userblocks VALUES (30,30,1,20031116093553);

--
-- Table structure for table 'nuke_users'
--

CREATE TABLE nuke_users (
  pn_uid int(11) NOT NULL auto_increment,
  pn_name varchar(60) NOT NULL default '',
  pn_uname varchar(25) NOT NULL default '',
  pn_email varchar(60) NOT NULL default '',
  pn_femail varchar(60) NOT NULL default '',
  pn_url varchar(254) NOT NULL default '',
  pn_user_avatar varchar(30) default NULL,
  pn_user_regdate varchar(20) NOT NULL default '',
  pn_user_icq varchar(15) default NULL,
  pn_user_occ varchar(100) default NULL,
  pn_user_from varchar(100) default NULL,
  pn_user_intrest varchar(150) default NULL,
  pn_user_sig varchar(255) default NULL,
  pn_user_viewemail tinyint(2) default NULL,
  pn_user_theme tinyint(3) default NULL,
  pn_user_aim varchar(18) default NULL,
  pn_user_yim varchar(25) default NULL,
  pn_user_msnm varchar(25) default NULL,
  pn_pass varchar(40) NOT NULL default '',
  pn_storynum tinyint(4) NOT NULL default '10',
  pn_umode varchar(10) NOT NULL default '',
  pn_uorder tinyint(1) NOT NULL default '0',
  pn_thold tinyint(1) NOT NULL default '0',
  pn_noscore tinyint(1) NOT NULL default '0',
  pn_bio tinytext NOT NULL,
  pn_ublockon tinyint(1) NOT NULL default '0',
  pn_ublock text NOT NULL,
  pn_theme varchar(255) NOT NULL default '',
  pn_commentmax int(11) NOT NULL default '4096',
  pn_counter int(11) NOT NULL default '0',
  pn_timezone_offset float(3,1) NOT NULL default '0.0',
  PRIMARY KEY  (pn_uid)
) TYPE=MyISAM;

--
-- Dumping data for table 'nuke_users'
--


INSERT INTO nuke_users VALUES (1,'','Anonymous','','','','blank.gif','1057698091','','','','','',0,0,'','','','',10,'',0,0,0,'',0,'','',4096,0,12.0);
INSERT INTO nuke_users VALUES (2,'Admin','Admin','none@none.com','','http://www.postnuke.com','001.gif','1057698091','','','','','',0,0,'','','','5fd42e4473fb245ed4eb6401c8d87ea3',10,'',0,0,0,'',0,'','PostNuke',4096,2,12.0);
INSERT INTO nuke_users VALUES (13,'','vinson','vinson@ucar.edu','','','blank.gif','1059149387','','','','','',0,NULL,'','','','4cb9c8a8048fd02294477fcb1a41191a',10,'',0,0,0,'',0,'','',4096,0,5.0);
INSERT INTO nuke_users VALUES (10,'','rexlunae','fwe@boo.as','','','001.gif','1058386848','',NULL,'','','',0,0,'','','','5fd42e4473fb245ed4eb6401c8d87ea3',10,'',0,0,0,'',0,'','IDEASNuke',4096,0,0.0);
INSERT INTO nuke_users VALUES (11,'Mike Daniels','daniels','daniels@ucar.edu','daniels@ucar.edu','http://','005.gif','1059083011','','Manager, ATD/RDP','','','',0,0,'','','','9ba611b4c86cd77815032be9a407657d',10,'',0,0,0,'',0,'','PostNuke',4096,0,5.0);
INSERT INTO nuke_users VALUES (12,'','cjw','cjw@ucar.edu','','','blank.gif','1059149320','','','','','',0,NULL,'','','','4cb9c8a8048fd02294477fcb1a41191a',10,'',0,0,0,'',0,'','',4096,0,5.0);
INSERT INTO nuke_users VALUES (46,'','genzling','genzling@ucar.edu','','','blank.gif','1062623601','','','','','',0,NULL,'','','','4cb9c8a8048fd02294477fcb1a41191a',10,'',0,0,0,'',0,'','',4096,0,5.0);
INSERT INTO nuke_users VALUES (14,'','snorman','snorman@ucar.edu','','','blank.gif','1059149441','','','','','',0,NULL,'','','','4cb9c8a8048fd02294477fcb1a41191a',10,'',0,0,0,'',0,'','',4096,0,5.0);
INSERT INTO nuke_users VALUES (15,'','stith','stith@ucar.edu','','http://','blank.gif','1059149471','','','','','',0,NULL,'','','','86b230f9b4007cb904316fb11db41025',10,'',0,0,0,'',0,'','',4096,6,5.0);
INSERT INTO nuke_users VALUES (16,'','stither','stither@ucar.edu','','','013.gif','1059149495','','','','','',0,NULL,'','','','5fd42e4473fb245ed4eb6401c8d87ea3',10,'',0,0,0,'',0,'','IDEASNuke',4096,2,5.0);
INSERT INTO nuke_users VALUES (17,'Ron Ruth','ruth','ruth@ucar.edu','','http://','006.gif','1059149531','','','','','',0,NULL,'','','','2132b49796d283b6238a4f7c8ea929a8',10,'',0,0,0,'',0,'','IDEASNuke',4096,7,5.0);
INSERT INTO nuke_users VALUES (18,'Dave Rogers','dcrogers','dcrogers@ucar.edu','','http://raf.atd.ucar.edu/dcrogers/','blank.gif','1059149575','','','','','',0,NULL,'','','','4d44cc209067d72c9ed298578b447434',10,'',0,0,0,'',0,'','',4096,3,5.0);
INSERT INTO nuke_users VALUES (19,'','jbj','jbj@ucar.edu','','http://http://','blank.gif','1059149617','','','','','',0,NULL,'','','','fec4d306e72015afd1e75930878c56fe',10,'',0,0,0,'',0,'','',4096,0,5.0);
INSERT INTO nuke_users VALUES (20,'','campos','campos@ucar.edu','','','blank.gif','1059149669','','','','','',0,NULL,'','','','4cb9c8a8048fd02294477fcb1a41191a',10,'',0,0,0,'',0,'','',4096,0,5.0);
INSERT INTO nuke_users VALUES (21,'','beaton','beaton@ucar.edu','','','blank.gif','1059149718','','','','','',0,NULL,'','','','4cb9c8a8048fd02294477fcb1a41191a',10,'',0,0,0,'',0,'','',4096,0,5.0);
INSERT INTO nuke_users VALUES (22,'','anstett','anstett@ucar.edu','','http://http://','blank.gif','1059149782','','','','','',0,NULL,'','','','8f46042af43613d0bfe7b773ce67b7cc',10,'',0,0,0,'',0,'','',4096,0,5.0);
INSERT INTO nuke_users VALUES (23,'','lloyd','me@here.com','','','blank.gif','1060117315','','','','','',0,NULL,'','','','912ec803b2ce49e4a541068d495ab570',10,'',0,0,0,'',0,'','',4096,0,5.0);
INSERT INTO nuke_users VALUES (25,'','bheckman','aviation@heckman.geoscience.com','','','blank.gif','1060805638','','','','','',0,NULL,'','','','2cf962bbd4e64f8d4927981aa04d4ee2',10,'',0,0,0,'',0,'','',4096,0,5.0);
INSERT INTO nuke_users VALUES (26,'','tkoehle','thomas.koehler@usata.at.mil','','','blank.gif','1060805685','','','','','',0,NULL,'','','','4cb9c8a8048fd02294477fcb1a41191a',10,'',0,0,0,'',0,'','',4096,0,5.0);
INSERT INTO nuke_users VALUES (27,'Raymond Shaw','rashaw','rashaw@mtu.edu','','http://','blank.gif','1060805715','','','','','',0,NULL,'','','','f2f71023044234d76a83a4b8f8b389fe',10,'',0,0,0,'',0,'','',4096,0,5.0);
INSERT INTO nuke_users VALUES (28,'','ewsaw','ewsaw@mtu.edu','','','blank.gif','1060805742','','','','','',0,NULL,'','','','4cb9c8a8048fd02294477fcb1a41191a',10,'',0,0,0,'',0,'','',4096,0,5.0);
INSERT INTO nuke_users VALUES (29,'','jpfugal','jpfugal@mtu.edu','','','blank.gif','1060805896','','','','','',0,NULL,'','','','4cb9c8a8048fd02294477fcb1a41191a',10,'',0,0,0,'',0,'','',4096,0,5.0);
INSERT INTO nuke_users VALUES (30,'','ndagmar','dagmar.nagee@gkss.de','','','blank.gif','1060805936','','','','','',0,NULL,'','','','4cb9c8a8048fd02294477fcb1a41191a',10,'',0,0,0,'',0,'','',4096,0,5.0);
INSERT INTO nuke_users VALUES (31,'','kkoehle','koehler@chem.atmos.colostate.edu','','','blank.gif','1060805992','','','','','',0,NULL,'','','','2452404bdfc4874becf567e59cdfecc5',10,'',0,0,0,'',0,'','',4096,0,5.0);
INSERT INTO nuke_users VALUES (32,'','sbrooks','sbroks@lamar.costate.edu','','','blank.gif','1060808032','','','','','',0,NULL,'','','','4cb9c8a8048fd02294477fcb1a41191a',10,'',0,0,0,'',0,'','',4096,0,5.0);
INSERT INTO nuke_users VALUES (33,'','pdemott','pdemott@lamar.colostate.edu','','','blank.gif','1060808128','','','','','',0,NULL,'','','','4cb9c8a8048fd02294477fcb1a41191a',10,'',0,0,0,'',0,'','',4096,0,5.0);
INSERT INTO nuke_users VALUES (34,'','lavallo','avallone@colorado.edu','','','blank.gif','1060808193','','','','','',0,NULL,'','','','694d284d40bd3e6e32ab0ec556c19863',10,'',0,0,0,'',0,'','',4096,0,5.0);
INSERT INTO nuke_users VALUES (35,'','lkalnaj','kalnajs@colorado.edu','','','blank.gif','1060808254','','','','','',0,NULL,'','','','11ef5e99898509146c0b06050b3a2dc8',10,'',0,0,0,'',0,'','',4096,0,5.0);
INSERT INTO nuke_users VALUES (36,'','mkueste','michele.kuester@colorado.edu','','','blank.gif','1060808306','','','','','',0,NULL,'','','','0e972009780418109630497fb8b915e8',10,'',0,0,0,'',0,'','',4096,0,5.0);
INSERT INTO nuke_users VALUES (37,'','schanot','schanot@ucar.edu','','','blank.gif','1061594963','','','','','',0,NULL,'','','','4cb9c8a8048fd02294477fcb1a41191a',10,'',0,0,0,'',0,'','',4096,0,5.0);
INSERT INTO nuke_users VALUES (38,'','tschudi','tschudi@atd.ucar.edu','','http://','blank.gif','1061851499','','','','','',0,NULL,'','','','94ce78bdc7359f56bcc37731f254253b',10,'',0,0,0,'',0,'','',4096,0,5.0);
INSERT INTO nuke_users VALUES (39,'','hallett','hallett@dri.edu','','','blank.gif','1061914453','','','','','',0,NULL,'','','','4cb9c8a8048fd02294477fcb1a41191a',10,'',0,0,0,'',0,'','',4096,0,5.0);
INSERT INTO nuke_users VALUES (40,'','dcollins','dcollins@tamu.edu','','','blank.gif','1061914514','','','','','',0,NULL,'','','','4cb9c8a8048fd02294477fcb1a41191a',10,'',0,0,0,'',0,'','',4096,0,5.0);
INSERT INTO nuke_users VALUES (41,'','robertog','unk@tamu.edu','','','blank.gif','1061914557','','','','','',0,NULL,'','','','4cb9c8a8048fd02294477fcb1a41191a',10,'',0,0,0,'',0,'','',4096,0,5.0);
INSERT INTO nuke_users VALUES (42,'German Vidaurre','gvidaurr','gvidaurr@dri.edu','','http://','blank.gif','1061914598','','Ph. D. Student','Reno, NV','Atmospheric Physics','',0,NULL,'','vidaurreg@yahoo.com','gvidaurr@hotmail.com','b5ebe02cb8aa584f9d0bda5823661255',10,'',0,0,0,'',0,'','',4096,0,5.0);
INSERT INTO nuke_users VALUES (43,'','twohy','twohy@coas.oregonstate.edu','','http://','blank.gif','1061915545','','','','','',0,NULL,'','','','648e3d5996cf4d6aa7e65287c59eaef1',10,'',0,0,0,'',0,'','',4096,0,5.0);
INSERT INTO nuke_users VALUES (44,'','rickp','rickp@dri.edu','','','blank.gif','1061923658','','','','','',0,NULL,'','','','4cb9c8a8048fd02294477fcb1a41191a',10,'',0,0,0,'',0,'','',4096,0,5.0);
INSERT INTO nuke_users VALUES (45,'','morien','morien@dri.edu','','http://','blank.gif','1061932199','','','','','',0,NULL,'','','','dc1942cb3073f88027ed102739e6ea99',10,'',0,0,0,'',0,'','',4096,0,5.0);
INSERT INTO nuke_users VALUES (47,'','alex','alex@dummy.org','','','blank.gif','1062794052','','','','','',0,NULL,'','','','4cb9c8a8048fd02294477fcb1a41191a',10,'',0,0,0,'',0,'','',4096,0,5.0);
INSERT INTO nuke_users VALUES (48,'','slasher','slasher@purdue.edu','','','blank.gif','1067635418','','','','','',0,NULL,'','','','40a965d05136639974c40faf6cfdf21d',10,'',0,0,0,'',0,'','',4096,0,5.0);

--
-- Table structure for table 'phpbb_auth_access'
--

CREATE TABLE phpbb_auth_access (
  group_id mediumint(8) NOT NULL default '0',
  forum_id smallint(5) unsigned NOT NULL default '0',
  auth_view tinyint(1) NOT NULL default '0',
  auth_read tinyint(1) NOT NULL default '0',
  auth_post tinyint(1) NOT NULL default '0',
  auth_reply tinyint(1) NOT NULL default '0',
  auth_edit tinyint(1) NOT NULL default '0',
  auth_delete tinyint(1) NOT NULL default '0',
  auth_sticky tinyint(1) NOT NULL default '0',
  auth_announce tinyint(1) NOT NULL default '0',
  auth_vote tinyint(1) NOT NULL default '0',
  auth_pollcreate tinyint(1) NOT NULL default '0',
  auth_attachments tinyint(1) NOT NULL default '0',
  auth_mod tinyint(1) NOT NULL default '0',
  KEY group_id (group_id),
  KEY forum_id (forum_id)
) TYPE=MyISAM;

--
-- Dumping data for table 'phpbb_auth_access'
--



--
-- Table structure for table 'phpbb_banlist'
--

CREATE TABLE phpbb_banlist (
  ban_id mediumint(8) unsigned NOT NULL auto_increment,
  ban_userid mediumint(8) NOT NULL default '0',
  ban_ip varchar(8) NOT NULL default '',
  ban_email varchar(255) default NULL,
  PRIMARY KEY  (ban_id),
  KEY ban_ip_user_id (ban_ip,ban_userid)
) TYPE=MyISAM;

--
-- Dumping data for table 'phpbb_banlist'
--



--
-- Table structure for table 'phpbb_categories'
--

CREATE TABLE phpbb_categories (
  cat_id mediumint(8) unsigned NOT NULL auto_increment,
  cat_title varchar(100) default NULL,
  cat_order mediumint(8) unsigned NOT NULL default '0',
  PRIMARY KEY  (cat_id),
  KEY cat_order (cat_order)
) TYPE=MyISAM;

--
-- Dumping data for table 'phpbb_categories'
--


INSERT INTO phpbb_categories VALUES (4,'The IDEAS3 Project',10);

--
-- Table structure for table 'phpbb_config'
--

CREATE TABLE phpbb_config (
  config_name varchar(255) NOT NULL default '',
  config_value varchar(255) NOT NULL default '',
  PRIMARY KEY  (config_name)
) TYPE=MyISAM;

--
-- Dumping data for table 'phpbb_config'
--


INSERT INTO phpbb_config VALUES ('config_id','1');
INSERT INTO phpbb_config VALUES ('board_disable','0');
INSERT INTO phpbb_config VALUES ('sitename','trouble');
INSERT INTO phpbb_config VALUES ('site_desc','The IDEAS3 Forum');
INSERT INTO phpbb_config VALUES ('cookie_name','phpbb2mysql');
INSERT INTO phpbb_config VALUES ('cookie_path','/');
INSERT INTO phpbb_config VALUES ('cookie_domain','');
INSERT INTO phpbb_config VALUES ('cookie_secure','0');
INSERT INTO phpbb_config VALUES ('session_length','3600');
INSERT INTO phpbb_config VALUES ('allow_html','0');
INSERT INTO phpbb_config VALUES ('allow_html_tags','b,i,u,pre');
INSERT INTO phpbb_config VALUES ('allow_bbcode','1');
INSERT INTO phpbb_config VALUES ('allow_smilies','1');
INSERT INTO phpbb_config VALUES ('allow_sig','1');
INSERT INTO phpbb_config VALUES ('allow_namechange','0');
INSERT INTO phpbb_config VALUES ('allow_theme_create','0');
INSERT INTO phpbb_config VALUES ('allow_avatar_local','0');
INSERT INTO phpbb_config VALUES ('allow_avatar_remote','0');
INSERT INTO phpbb_config VALUES ('allow_avatar_upload','0');
INSERT INTO phpbb_config VALUES ('enable_confirm','0');
INSERT INTO phpbb_config VALUES ('override_user_style','0');
INSERT INTO phpbb_config VALUES ('posts_per_page','15');
INSERT INTO phpbb_config VALUES ('topics_per_page','50');
INSERT INTO phpbb_config VALUES ('hot_threshold','25');
INSERT INTO phpbb_config VALUES ('max_poll_options','10');
INSERT INTO phpbb_config VALUES ('max_sig_chars','255');
INSERT INTO phpbb_config VALUES ('max_inbox_privmsgs','50');
INSERT INTO phpbb_config VALUES ('max_sentbox_privmsgs','25');
INSERT INTO phpbb_config VALUES ('max_savebox_privmsgs','50');
INSERT INTO phpbb_config VALUES ('board_email_sig','Thanks, The Management');
INSERT INTO phpbb_config VALUES ('board_email','stither@atd.ucar.edu');
INSERT INTO phpbb_config VALUES ('smtp_delivery','0');
INSERT INTO phpbb_config VALUES ('smtp_host','');
INSERT INTO phpbb_config VALUES ('smtp_username','');
INSERT INTO phpbb_config VALUES ('smtp_password','');
INSERT INTO phpbb_config VALUES ('sendmail_fix','0');
INSERT INTO phpbb_config VALUES ('require_activation','0');
INSERT INTO phpbb_config VALUES ('flood_interval','15');
INSERT INTO phpbb_config VALUES ('board_email_form','0');
INSERT INTO phpbb_config VALUES ('avatar_filesize','6144');
INSERT INTO phpbb_config VALUES ('avatar_max_width','80');
INSERT INTO phpbb_config VALUES ('avatar_max_height','80');
INSERT INTO phpbb_config VALUES ('avatar_path','/modules/phpBB2/images/avatars');
INSERT INTO phpbb_config VALUES ('avatar_gallery_path','/modules/phpBB2/images/avatars/gallery');
INSERT INTO phpbb_config VALUES ('smilies_path','/modules/phpBB2/images/smiles');
INSERT INTO phpbb_config VALUES ('default_style','2');
INSERT INTO phpbb_config VALUES ('default_dateformat','D M d, Y g:i a');
INSERT INTO phpbb_config VALUES ('board_timezone','0');
INSERT INTO phpbb_config VALUES ('prune_enable','1');
INSERT INTO phpbb_config VALUES ('privmsg_disable','0');
INSERT INTO phpbb_config VALUES ('gzip_compress','0');
INSERT INTO phpbb_config VALUES ('coppa_fax','');
INSERT INTO phpbb_config VALUES ('coppa_mail','');
INSERT INTO phpbb_config VALUES ('record_online_users','3');
INSERT INTO phpbb_config VALUES ('record_online_date','1057865025');
INSERT INTO phpbb_config VALUES ('server_name','trouble');
INSERT INTO phpbb_config VALUES ('server_port','80');
INSERT INTO phpbb_config VALUES ('script_path','/modules/phpBB2');
INSERT INTO phpbb_config VALUES ('version','.0.5');
INSERT INTO phpbb_config VALUES ('board_startdate','1057788949');
INSERT INTO phpbb_config VALUES ('default_lang','english');

--
-- Table structure for table 'phpbb_confirm'
--

CREATE TABLE phpbb_confirm (
  confirm_id char(32) NOT NULL default '',
  session_id char(32) NOT NULL default '',
  code char(6) NOT NULL default '',
  PRIMARY KEY  (session_id,confirm_id)
) TYPE=MyISAM;

--
-- Dumping data for table 'phpbb_confirm'
--



--
-- Table structure for table 'phpbb_disallow'
--

CREATE TABLE phpbb_disallow (
  disallow_id mediumint(8) unsigned NOT NULL auto_increment,
  disallow_username varchar(25) NOT NULL default '',
  PRIMARY KEY  (disallow_id)
) TYPE=MyISAM;

--
-- Dumping data for table 'phpbb_disallow'
--



--
-- Table structure for table 'phpbb_forum_prune'
--

CREATE TABLE phpbb_forum_prune (
  prune_id mediumint(8) unsigned NOT NULL auto_increment,
  forum_id smallint(5) unsigned NOT NULL default '0',
  prune_days smallint(5) unsigned NOT NULL default '0',
  prune_freq smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (prune_id),
  KEY forum_id (forum_id)
) TYPE=MyISAM;

--
-- Dumping data for table 'phpbb_forum_prune'
--



--
-- Table structure for table 'phpbb_forums'
--

CREATE TABLE phpbb_forums (
  forum_id smallint(5) unsigned NOT NULL default '0',
  cat_id mediumint(8) unsigned NOT NULL default '0',
  forum_name varchar(150) default NULL,
  forum_desc text,
  forum_status tinyint(4) NOT NULL default '0',
  forum_order mediumint(8) unsigned NOT NULL default '1',
  forum_posts mediumint(8) unsigned NOT NULL default '0',
  forum_topics mediumint(8) unsigned NOT NULL default '0',
  forum_last_post_id mediumint(8) unsigned NOT NULL default '0',
  prune_next int(11) default NULL,
  prune_enable tinyint(1) NOT NULL default '0',
  auth_view tinyint(2) NOT NULL default '0',
  auth_read tinyint(2) NOT NULL default '0',
  auth_post tinyint(2) NOT NULL default '0',
  auth_reply tinyint(2) NOT NULL default '0',
  auth_edit tinyint(2) NOT NULL default '0',
  auth_delete tinyint(2) NOT NULL default '0',
  auth_sticky tinyint(2) NOT NULL default '0',
  auth_announce tinyint(2) NOT NULL default '0',
  auth_vote tinyint(2) NOT NULL default '0',
  auth_pollcreate tinyint(2) NOT NULL default '0',
  auth_attachments tinyint(2) NOT NULL default '0',
  PRIMARY KEY  (forum_id),
  KEY forums_order (forum_order),
  KEY cat_id (cat_id),
  KEY forum_last_post_id (forum_last_post_id)
) TYPE=MyISAM;

--
-- Dumping data for table 'phpbb_forums'
--


INSERT INTO phpbb_forums VALUES (1,4,'IDEAS3','The IDEAS3 Project General Discussion',0,10,1,1,2,NULL,0,0,0,0,0,1,1,1,3,1,1,0);

--
-- Table structure for table 'phpbb_groups'
--

CREATE TABLE phpbb_groups (
  group_id mediumint(8) NOT NULL auto_increment,
  group_type tinyint(4) NOT NULL default '1',
  group_name varchar(40) NOT NULL default '',
  group_description varchar(255) NOT NULL default '',
  group_moderator mediumint(8) NOT NULL default '0',
  group_single_user tinyint(1) NOT NULL default '1',
  PRIMARY KEY  (group_id),
  KEY group_single_user (group_single_user)
) TYPE=MyISAM;

--
-- Dumping data for table 'phpbb_groups'
--


INSERT INTO phpbb_groups VALUES (1,1,'Anonymous','Personal User',0,1);
INSERT INTO phpbb_groups VALUES (2,1,'Admin','Personal User',0,1);
INSERT INTO phpbb_groups VALUES (3,1,'','Personal User',0,1);
INSERT INTO phpbb_groups VALUES (4,1,'','Personal User',0,1);
INSERT INTO phpbb_groups VALUES (5,1,'','Personal User',0,1);

--
-- Table structure for table 'phpbb_posts'
--

CREATE TABLE phpbb_posts (
  post_id mediumint(8) unsigned NOT NULL auto_increment,
  topic_id mediumint(8) unsigned NOT NULL default '0',
  forum_id smallint(5) unsigned NOT NULL default '0',
  poster_id mediumint(8) NOT NULL default '0',
  post_time int(11) NOT NULL default '0',
  poster_ip varchar(8) NOT NULL default '',
  post_username varchar(25) default NULL,
  enable_bbcode tinyint(1) NOT NULL default '1',
  enable_html tinyint(1) NOT NULL default '0',
  enable_smilies tinyint(1) NOT NULL default '1',
  enable_sig tinyint(1) NOT NULL default '1',
  post_edit_time int(11) default NULL,
  post_edit_count smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (post_id),
  KEY forum_id (forum_id),
  KEY topic_id (topic_id),
  KEY poster_id (poster_id),
  KEY post_time (post_time)
) TYPE=MyISAM;

--
-- Dumping data for table 'phpbb_posts'
--


INSERT INTO phpbb_posts VALUES (2,2,1,2,1057793331,'7f000001','',1,0,1,0,NULL,0);

--
-- Table structure for table 'phpbb_posts_text'
--

CREATE TABLE phpbb_posts_text (
  post_id mediumint(8) unsigned NOT NULL default '0',
  bbcode_uid varchar(10) NOT NULL default '',
  post_subject varchar(60) default NULL,
  post_text text,
  PRIMARY KEY  (post_id)
) TYPE=MyISAM;

--
-- Dumping data for table 'phpbb_posts_text'
--


INSERT INTO phpbb_posts_text VALUES (2,'c233bb34fe','What does the IDEAS project do?','I was wondering what the IDEAS project would do.');

--
-- Table structure for table 'phpbb_privmsgs'
--

CREATE TABLE phpbb_privmsgs (
  privmsgs_id mediumint(8) unsigned NOT NULL auto_increment,
  privmsgs_type tinyint(4) NOT NULL default '0',
  privmsgs_subject varchar(255) NOT NULL default '0',
  privmsgs_from_userid mediumint(8) NOT NULL default '0',
  privmsgs_to_userid mediumint(8) NOT NULL default '0',
  privmsgs_date int(11) NOT NULL default '0',
  privmsgs_ip varchar(8) NOT NULL default '',
  privmsgs_enable_bbcode tinyint(1) NOT NULL default '1',
  privmsgs_enable_html tinyint(1) NOT NULL default '0',
  privmsgs_enable_smilies tinyint(1) NOT NULL default '1',
  privmsgs_attach_sig tinyint(1) NOT NULL default '1',
  PRIMARY KEY  (privmsgs_id),
  KEY privmsgs_from_userid (privmsgs_from_userid),
  KEY privmsgs_to_userid (privmsgs_to_userid)
) TYPE=MyISAM;

--
-- Dumping data for table 'phpbb_privmsgs'
--



--
-- Table structure for table 'phpbb_privmsgs_text'
--

CREATE TABLE phpbb_privmsgs_text (
  privmsgs_text_id mediumint(8) unsigned NOT NULL default '0',
  privmsgs_bbcode_uid varchar(10) NOT NULL default '0',
  privmsgs_text text,
  PRIMARY KEY  (privmsgs_text_id)
) TYPE=MyISAM;

--
-- Dumping data for table 'phpbb_privmsgs_text'
--



--
-- Table structure for table 'phpbb_ranks'
--

CREATE TABLE phpbb_ranks (
  rank_id smallint(5) unsigned NOT NULL auto_increment,
  rank_title varchar(50) NOT NULL default '',
  rank_min mediumint(8) NOT NULL default '0',
  rank_special tinyint(1) default '0',
  rank_image varchar(255) default NULL,
  PRIMARY KEY  (rank_id)
) TYPE=MyISAM;

--
-- Dumping data for table 'phpbb_ranks'
--


INSERT INTO phpbb_ranks VALUES (1,'Site Admin',-1,1,NULL);

--
-- Table structure for table 'phpbb_search_results'
--

CREATE TABLE phpbb_search_results (
  search_id int(11) unsigned NOT NULL default '0',
  session_id varchar(32) NOT NULL default '',
  search_array text NOT NULL,
  PRIMARY KEY  (search_id),
  KEY session_id (session_id)
) TYPE=MyISAM;

--
-- Dumping data for table 'phpbb_search_results'
--


INSERT INTO phpbb_search_results VALUES (1460326622,'62c8d1d475f883251244f25a5b234d88','a:7:{s:14:\"search_results\";s:1:\"2\";s:17:\"total_match_count\";i:1;s:12:\"split_search\";N;s:7:\"sort_by\";i:0;s:8:\"sort_dir\";s:4:\"DESC\";s:12:\"show_results\";s:5:\"posts\";s:12:\"return_chars\";i:200;}');

--
-- Table structure for table 'phpbb_search_wordlist'
--

CREATE TABLE phpbb_search_wordlist (
  word_text varchar(50) binary NOT NULL default '',
  word_id mediumint(8) unsigned NOT NULL auto_increment,
  word_common tinyint(1) unsigned NOT NULL default '0',
  PRIMARY KEY  (word_text),
  KEY word_id (word_id)
) TYPE=MyISAM;

--
-- Dumping data for table 'phpbb_search_wordlist'
--


INSERT INTO phpbb_search_wordlist VALUES ('example',1,0);
INSERT INTO phpbb_search_wordlist VALUES ('post',2,0);
INSERT INTO phpbb_search_wordlist VALUES ('phpbb',3,0);
INSERT INTO phpbb_search_wordlist VALUES ('installation',4,0);
INSERT INTO phpbb_search_wordlist VALUES ('delete',5,0);
INSERT INTO phpbb_search_wordlist VALUES ('topic',6,0);
INSERT INTO phpbb_search_wordlist VALUES ('forum',7,0);
INSERT INTO phpbb_search_wordlist VALUES ('since',8,0);
INSERT INTO phpbb_search_wordlist VALUES ('everything',9,0);
INSERT INTO phpbb_search_wordlist VALUES ('seems',10,0);
INSERT INTO phpbb_search_wordlist VALUES ('working',11,0);
INSERT INTO phpbb_search_wordlist VALUES ('welcome',12,0);
INSERT INTO phpbb_search_wordlist VALUES ('does',13,0);
INSERT INTO phpbb_search_wordlist VALUES ('ideas',14,0);
INSERT INTO phpbb_search_wordlist VALUES ('project',15,0);
INSERT INTO phpbb_search_wordlist VALUES ('the',16,0);
INSERT INTO phpbb_search_wordlist VALUES ('was',17,0);
INSERT INTO phpbb_search_wordlist VALUES ('what',18,0);
INSERT INTO phpbb_search_wordlist VALUES ('wondering',19,0);
INSERT INTO phpbb_search_wordlist VALUES ('would',20,0);

--
-- Table structure for table 'phpbb_search_wordmatch'
--

CREATE TABLE phpbb_search_wordmatch (
  post_id mediumint(8) unsigned NOT NULL default '0',
  word_id mediumint(8) unsigned NOT NULL default '0',
  title_match tinyint(1) NOT NULL default '0',
  KEY post_id (post_id),
  KEY word_id (word_id)
) TYPE=MyISAM;

--
-- Dumping data for table 'phpbb_search_wordmatch'
--


INSERT INTO phpbb_search_wordmatch VALUES (2,18,1);
INSERT INTO phpbb_search_wordmatch VALUES (2,16,1);
INSERT INTO phpbb_search_wordmatch VALUES (2,15,1);
INSERT INTO phpbb_search_wordmatch VALUES (2,14,1);
INSERT INTO phpbb_search_wordmatch VALUES (2,13,1);
INSERT INTO phpbb_search_wordmatch VALUES (2,20,0);
INSERT INTO phpbb_search_wordmatch VALUES (2,19,0);
INSERT INTO phpbb_search_wordmatch VALUES (2,18,0);
INSERT INTO phpbb_search_wordmatch VALUES (2,17,0);
INSERT INTO phpbb_search_wordmatch VALUES (2,16,0);
INSERT INTO phpbb_search_wordmatch VALUES (2,15,0);
INSERT INTO phpbb_search_wordmatch VALUES (2,14,0);

--
-- Table structure for table 'phpbb_sessions'
--

CREATE TABLE phpbb_sessions (
  session_id char(32) NOT NULL default '',
  session_user_id mediumint(8) NOT NULL default '0',
  session_start int(11) NOT NULL default '0',
  session_time int(11) NOT NULL default '0',
  session_ip char(8) NOT NULL default '0',
  session_page int(11) NOT NULL default '0',
  session_logged_in tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (session_id),
  KEY session_user_id (session_user_id),
  KEY session_id_ip_user_id (session_id,session_ip,session_user_id)
) TYPE=MyISAM;

--
-- Dumping data for table 'phpbb_sessions'
--


INSERT INTO phpbb_sessions VALUES ('4e53e2ca3ea9ac5259fe458e48b08c4b',8,1058309287,1058373348,'80755017',0,1);

--
-- Table structure for table 'phpbb_smilies'
--

CREATE TABLE phpbb_smilies (
  smilies_id smallint(5) unsigned NOT NULL auto_increment,
  code varchar(50) default NULL,
  smile_url varchar(100) default NULL,
  emoticon varchar(75) default NULL,
  PRIMARY KEY  (smilies_id)
) TYPE=MyISAM;

--
-- Dumping data for table 'phpbb_smilies'
--


INSERT INTO phpbb_smilies VALUES (1,':D','icon_biggrin.gif','Very Happy');
INSERT INTO phpbb_smilies VALUES (2,':-D','icon_biggrin.gif','Very Happy');
INSERT INTO phpbb_smilies VALUES (3,':grin:','icon_biggrin.gif','Very Happy');
INSERT INTO phpbb_smilies VALUES (4,':)','icon_smile.gif','Smile');
INSERT INTO phpbb_smilies VALUES (5,':-)','icon_smile.gif','Smile');
INSERT INTO phpbb_smilies VALUES (6,':smile:','icon_smile.gif','Smile');
INSERT INTO phpbb_smilies VALUES (7,':(','icon_sad.gif','Sad');
INSERT INTO phpbb_smilies VALUES (8,':-(','icon_sad.gif','Sad');
INSERT INTO phpbb_smilies VALUES (9,':sad:','icon_sad.gif','Sad');
INSERT INTO phpbb_smilies VALUES (10,':o','icon_surprised.gif','Surprised');
INSERT INTO phpbb_smilies VALUES (11,':-o','icon_surprised.gif','Surprised');
INSERT INTO phpbb_smilies VALUES (12,':eek:','icon_surprised.gif','Surprised');
INSERT INTO phpbb_smilies VALUES (13,':shock:','icon_eek.gif','Shocked');
INSERT INTO phpbb_smilies VALUES (14,':?','icon_confused.gif','Confused');
INSERT INTO phpbb_smilies VALUES (15,':-?','icon_confused.gif','Confused');
INSERT INTO phpbb_smilies VALUES (16,':???:','icon_confused.gif','Confused');
INSERT INTO phpbb_smilies VALUES (17,'8)','icon_cool.gif','Cool');
INSERT INTO phpbb_smilies VALUES (18,'8-)','icon_cool.gif','Cool');
INSERT INTO phpbb_smilies VALUES (19,':cool:','icon_cool.gif','Cool');
INSERT INTO phpbb_smilies VALUES (20,':lol:','icon_lol.gif','Laughing');
INSERT INTO phpbb_smilies VALUES (21,':x','icon_mad.gif','Mad');
INSERT INTO phpbb_smilies VALUES (22,':-x','icon_mad.gif','Mad');
INSERT INTO phpbb_smilies VALUES (23,':mad:','icon_mad.gif','Mad');
INSERT INTO phpbb_smilies VALUES (24,':P','icon_razz.gif','Razz');
INSERT INTO phpbb_smilies VALUES (25,':-P','icon_razz.gif','Razz');
INSERT INTO phpbb_smilies VALUES (26,':razz:','icon_razz.gif','Razz');
INSERT INTO phpbb_smilies VALUES (27,':oops:','icon_redface.gif','Embarassed');
INSERT INTO phpbb_smilies VALUES (28,':cry:','icon_cry.gif','Crying or Very sad');
INSERT INTO phpbb_smilies VALUES (29,':evil:','icon_evil.gif','Evil or Very Mad');
INSERT INTO phpbb_smilies VALUES (30,':twisted:','icon_twisted.gif','Twisted Evil');
INSERT INTO phpbb_smilies VALUES (31,':roll:','icon_rolleyes.gif','Rolling Eyes');
INSERT INTO phpbb_smilies VALUES (32,':wink:','icon_wink.gif','Wink');
INSERT INTO phpbb_smilies VALUES (33,';)','icon_wink.gif','Wink');
INSERT INTO phpbb_smilies VALUES (34,';-)','icon_wink.gif','Wink');
INSERT INTO phpbb_smilies VALUES (35,':!:','icon_exclaim.gif','Exclamation');
INSERT INTO phpbb_smilies VALUES (36,':?:','icon_question.gif','Question');
INSERT INTO phpbb_smilies VALUES (37,':idea:','icon_idea.gif','Idea');
INSERT INTO phpbb_smilies VALUES (38,':arrow:','icon_arrow.gif','Arrow');
INSERT INTO phpbb_smilies VALUES (39,':|','icon_neutral.gif','Neutral');
INSERT INTO phpbb_smilies VALUES (40,':-|','icon_neutral.gif','Neutral');
INSERT INTO phpbb_smilies VALUES (41,':neutral:','icon_neutral.gif','Neutral');
INSERT INTO phpbb_smilies VALUES (42,':mrgreen:','icon_mrgreen.gif','Mr. Green');

--
-- Table structure for table 'phpbb_themes'
--

CREATE TABLE phpbb_themes (
  themes_id mediumint(8) unsigned NOT NULL auto_increment,
  template_name varchar(30) NOT NULL default '',
  style_name varchar(30) NOT NULL default '',
  head_stylesheet varchar(100) default NULL,
  body_background varchar(100) default NULL,
  body_bgcolor varchar(6) default NULL,
  body_text varchar(6) default NULL,
  body_link varchar(6) default NULL,
  body_vlink varchar(6) default NULL,
  body_alink varchar(6) default NULL,
  body_hlink varchar(6) default NULL,
  tr_color1 varchar(6) default NULL,
  tr_color2 varchar(6) default NULL,
  tr_color3 varchar(6) default NULL,
  tr_class1 varchar(25) default NULL,
  tr_class2 varchar(25) default NULL,
  tr_class3 varchar(25) default NULL,
  th_color1 varchar(6) default NULL,
  th_color2 varchar(6) default NULL,
  th_color3 varchar(6) default NULL,
  th_class1 varchar(25) default NULL,
  th_class2 varchar(25) default NULL,
  th_class3 varchar(25) default NULL,
  td_color1 varchar(6) default NULL,
  td_color2 varchar(6) default NULL,
  td_color3 varchar(6) default NULL,
  td_class1 varchar(25) default NULL,
  td_class2 varchar(25) default NULL,
  td_class3 varchar(25) default NULL,
  fontface1 varchar(50) default NULL,
  fontface2 varchar(50) default NULL,
  fontface3 varchar(50) default NULL,
  fontsize1 tinyint(4) default NULL,
  fontsize2 tinyint(4) default NULL,
  fontsize3 tinyint(4) default NULL,
  fontcolor1 varchar(6) default NULL,
  fontcolor2 varchar(6) default NULL,
  fontcolor3 varchar(6) default NULL,
  span_class1 varchar(25) default NULL,
  span_class2 varchar(25) default NULL,
  span_class3 varchar(25) default NULL,
  img_size_poll smallint(5) unsigned default NULL,
  img_size_privmsg smallint(5) unsigned default NULL,
  PRIMARY KEY  (themes_id)
) TYPE=MyISAM;

--
-- Dumping data for table 'phpbb_themes'
--


INSERT INTO phpbb_themes VALUES (3,'subSilver','subSilver','subSilver.css','','E5E5E5','000000','006699','5493B4','','DD6900','EFEFEF','DEE3E7','D1D7DC','','','','98AAB1','006699','FFFFFF','cellpic1.gif','cellpic3.gif','cellpic2.jpg','FAFAFA','FFFFFF','','row1','row2','','Verdana, Arial, Helvetica, sans-serif','Trebuchet MS','Courier, \'Courier New\', sans-serif',10,11,12,'444444','006600','FFA34F','','','',0,0);
INSERT INTO phpbb_themes VALUES (2,'fs2','fs2 Gold','fs2_gold.css','','fafafa','000000','979900','979900','979900','c1c287','f5f5ed','f3f3e9','e8e8df','','','','98AAB1','006699','FFFFFF','','','','FAFAFA','ffffff','','row1','row2','','Verdana, Arial, Helvetica, sans-serif','Trebuchet MS','Courier, \'Courier New\', sans-serif',10,11,12,'000000','006600','FFA34F','','','',0,0);
INSERT INTO phpbb_themes VALUES (4,'fs2','fs2','fs2.css','','E5E5E5','000000','006699','5493B4','','DD6900','EFEFEF','DEE3E7','D1D7DC','','','','98AAB1','006699','FFFFFF','cellpic1.gif','cellpic3.gif','cellpic2.jpg','FAFAFA','FFFFFF','','row1','row2','','Verdana, Arial, Helvetica, sans-serif','Trebuchet MS','Courier, \'Courier New\', sans-serif',10,11,12,'444444','006600','FFA34F','','','',0,0);
INSERT INTO phpbb_themes VALUES (5,'fs2','fs2 Silver','fs2_silver.css','','','','','','','','','','','','','','','','','','','','','','','row1','row2','','','','',10,11,12,'000000','006600','FFA34F','','','',0,0);

--
-- Table structure for table 'phpbb_themes_name'
--

CREATE TABLE phpbb_themes_name (
  themes_id smallint(5) unsigned NOT NULL default '0',
  tr_color1_name char(50) default NULL,
  tr_color2_name char(50) default NULL,
  tr_color3_name char(50) default NULL,
  tr_class1_name char(50) default NULL,
  tr_class2_name char(50) default NULL,
  tr_class3_name char(50) default NULL,
  th_color1_name char(50) default NULL,
  th_color2_name char(50) default NULL,
  th_color3_name char(50) default NULL,
  th_class1_name char(50) default NULL,
  th_class2_name char(50) default NULL,
  th_class3_name char(50) default NULL,
  td_color1_name char(50) default NULL,
  td_color2_name char(50) default NULL,
  td_color3_name char(50) default NULL,
  td_class1_name char(50) default NULL,
  td_class2_name char(50) default NULL,
  td_class3_name char(50) default NULL,
  fontface1_name char(50) default NULL,
  fontface2_name char(50) default NULL,
  fontface3_name char(50) default NULL,
  fontsize1_name char(50) default NULL,
  fontsize2_name char(50) default NULL,
  fontsize3_name char(50) default NULL,
  fontcolor1_name char(50) default NULL,
  fontcolor2_name char(50) default NULL,
  fontcolor3_name char(50) default NULL,
  span_class1_name char(50) default NULL,
  span_class2_name char(50) default NULL,
  span_class3_name char(50) default NULL,
  PRIMARY KEY  (themes_id)
) TYPE=MyISAM;

--
-- Dumping data for table 'phpbb_themes_name'
--


INSERT INTO phpbb_themes_name VALUES (2,'','','','','','','','','','','','','','','','','','','','','','','','','','','','','','');
INSERT INTO phpbb_themes_name VALUES (4,'','','','','','','','','','','','','','','','','','','','','','','','','','','','','','');

--
-- Table structure for table 'phpbb_topics'
--

CREATE TABLE phpbb_topics (
  topic_id mediumint(8) unsigned NOT NULL auto_increment,
  forum_id smallint(8) unsigned NOT NULL default '0',
  topic_title char(60) NOT NULL default '',
  topic_poster mediumint(8) NOT NULL default '0',
  topic_time int(11) NOT NULL default '0',
  topic_views mediumint(8) unsigned NOT NULL default '0',
  topic_replies mediumint(8) unsigned NOT NULL default '0',
  topic_status tinyint(3) NOT NULL default '0',
  topic_vote tinyint(1) NOT NULL default '0',
  topic_type tinyint(3) NOT NULL default '0',
  topic_first_post_id mediumint(8) unsigned NOT NULL default '0',
  topic_last_post_id mediumint(8) unsigned NOT NULL default '0',
  topic_moved_id mediumint(8) unsigned NOT NULL default '0',
  PRIMARY KEY  (topic_id),
  KEY forum_id (forum_id),
  KEY topic_moved_id (topic_moved_id),
  KEY topic_status (topic_status),
  KEY topic_type (topic_type)
) TYPE=MyISAM;

--
-- Dumping data for table 'phpbb_topics'
--


INSERT INTO phpbb_topics VALUES (2,1,'What does the IDEAS project do?',2,1057793331,4,0,0,0,0,2,2,0);

--
-- Table structure for table 'phpbb_topics_watch'
--

CREATE TABLE phpbb_topics_watch (
  topic_id mediumint(8) unsigned NOT NULL default '0',
  user_id mediumint(8) NOT NULL default '0',
  notify_status tinyint(1) NOT NULL default '0',
  KEY topic_id (topic_id),
  KEY user_id (user_id),
  KEY notify_status (notify_status)
) TYPE=MyISAM;

--
-- Dumping data for table 'phpbb_topics_watch'
--



--
-- Table structure for table 'phpbb_user_group'
--

CREATE TABLE phpbb_user_group (
  group_id mediumint(8) NOT NULL default '0',
  user_id mediumint(8) NOT NULL default '0',
  user_pending tinyint(1) default NULL,
  KEY group_id (group_id),
  KEY user_id (user_id)
) TYPE=MyISAM;

--
-- Dumping data for table 'phpbb_user_group'
--


INSERT INTO phpbb_user_group VALUES (1,-1,0);
INSERT INTO phpbb_user_group VALUES (2,2,0);
INSERT INTO phpbb_user_group VALUES (1,-1,0);
INSERT INTO phpbb_user_group VALUES (2,2,0);
INSERT INTO phpbb_user_group VALUES (3,5,0);
INSERT INTO phpbb_user_group VALUES (4,6,0);
INSERT INTO phpbb_user_group VALUES (5,8,0);

--
-- Table structure for table 'phpbb_users'
--

CREATE TABLE phpbb_users (
  user_id mediumint(8) NOT NULL default '0',
  user_active tinyint(1) default '1',
  username varchar(25) NOT NULL default '',
  user_password varchar(32) NOT NULL default '',
  user_session_time int(11) NOT NULL default '0',
  user_session_page smallint(5) NOT NULL default '0',
  user_lastvisit int(11) NOT NULL default '0',
  user_regdate int(11) NOT NULL default '0',
  user_level tinyint(4) default '0',
  user_posts mediumint(8) unsigned NOT NULL default '0',
  user_timezone decimal(5,2) NOT NULL default '0.00',
  user_style tinyint(4) default NULL,
  user_lang varchar(255) default NULL,
  user_dateformat varchar(14) NOT NULL default 'd M Y H:i',
  user_new_privmsg smallint(5) unsigned NOT NULL default '0',
  user_unread_privmsg smallint(5) unsigned NOT NULL default '0',
  user_last_privmsg int(11) NOT NULL default '0',
  user_emailtime int(11) default NULL,
  user_viewemail tinyint(1) default NULL,
  user_attachsig tinyint(1) default NULL,
  user_allowhtml tinyint(1) default '1',
  user_allowbbcode tinyint(1) default '1',
  user_allowsmile tinyint(1) default '1',
  user_allowavatar tinyint(1) NOT NULL default '1',
  user_allow_pm tinyint(1) NOT NULL default '1',
  user_allow_viewonline tinyint(1) NOT NULL default '1',
  user_notify tinyint(1) NOT NULL default '1',
  user_notify_pm tinyint(1) NOT NULL default '0',
  user_popup_pm tinyint(1) NOT NULL default '0',
  user_rank int(11) default '0',
  user_avatar varchar(100) default NULL,
  user_avatar_type tinyint(4) NOT NULL default '0',
  user_email varchar(255) default NULL,
  user_icq varchar(15) default NULL,
  user_website varchar(100) default NULL,
  user_from varchar(100) default NULL,
  user_sig text,
  user_sig_bbcode_uid varchar(10) default NULL,
  user_aim varchar(255) default NULL,
  user_yim varchar(255) default NULL,
  user_msnm varchar(255) default NULL,
  user_occ varchar(100) default NULL,
  user_interests varchar(255) default NULL,
  user_actkey varchar(32) default NULL,
  user_newpasswd varchar(32) default NULL,
  PRIMARY KEY  (user_id),
  KEY user_session_time (user_session_time)
) TYPE=MyISAM;

--
-- Dumping data for table 'phpbb_users'
--


INSERT INTO phpbb_users VALUES (-1,0,'Anonymous','',0,0,0,1057788949,0,0,0.00,NULL,'','',0,0,0,NULL,0,0,0,1,1,1,0,1,0,1,0,NULL,'',0,'','','','','',NULL,'','','','','','','');
INSERT INTO phpbb_users VALUES (2,1,'Admin','5fd42e4473fb245ed4eb6401c8d87ea3',1058309287,0,1057868141,1057788949,1,2,0.00,2,'english','d M Y h:i a',0,0,1057789104,NULL,0,0,0,1,1,1,1,1,0,1,1,1,'',0,'stither@atd.ucar.edu','','','','','','','','','','','','');
INSERT INTO phpbb_users VALUES (5,1,'rexlunae','',1057865473,0,1057862067,1057862067,0,0,0.00,1,'english','d M Y h:i a',0,0,0,NULL,0,1,0,1,1,1,1,1,0,1,1,0,'',0,'stither@atd.ucar.edu','','','','','','','','','','','',NULL);
INSERT INTO phpbb_users VALUES (6,1,'n00b','',1057962096,0,1057962096,1057962096,0,0,0.00,1,'english','d M Y h:i a',0,0,0,NULL,0,1,0,1,1,1,1,1,0,1,1,0,'',0,'me@here.com','','','','','','','','','','','',NULL);
INSERT INTO phpbb_users VALUES (8,1,'ScienceGuy','',1058373348,0,1058309287,1058309287,0,0,0.00,1,'english','d M Y h:i a',0,0,0,NULL,0,1,0,1,1,1,1,1,0,1,1,0,'',0,'sadf','','','','','','','','','','','',NULL);

--
-- Table structure for table 'phpbb_vote_desc'
--

CREATE TABLE phpbb_vote_desc (
  vote_id mediumint(8) unsigned NOT NULL auto_increment,
  topic_id mediumint(8) unsigned NOT NULL default '0',
  vote_text text NOT NULL,
  vote_start int(11) NOT NULL default '0',
  vote_length int(11) NOT NULL default '0',
  PRIMARY KEY  (vote_id),
  KEY topic_id (topic_id)
) TYPE=MyISAM;

--
-- Dumping data for table 'phpbb_vote_desc'
--



--
-- Table structure for table 'phpbb_vote_results'
--

CREATE TABLE phpbb_vote_results (
  vote_id mediumint(8) unsigned NOT NULL default '0',
  vote_option_id tinyint(4) unsigned NOT NULL default '0',
  vote_option_text varchar(255) NOT NULL default '',
  vote_result int(11) NOT NULL default '0',
  KEY vote_option_id (vote_option_id),
  KEY vote_id (vote_id)
) TYPE=MyISAM;

--
-- Dumping data for table 'phpbb_vote_results'
--



--
-- Table structure for table 'phpbb_vote_voters'
--

CREATE TABLE phpbb_vote_voters (
  vote_id mediumint(8) unsigned NOT NULL default '0',
  vote_user_id mediumint(8) NOT NULL default '0',
  vote_user_ip char(8) NOT NULL default '',
  KEY vote_id (vote_id),
  KEY vote_user_id (vote_user_id),
  KEY vote_user_ip (vote_user_ip)
) TYPE=MyISAM;

--
-- Dumping data for table 'phpbb_vote_voters'
--



--
-- Table structure for table 'phpbb_words'
--

CREATE TABLE phpbb_words (
  word_id mediumint(8) unsigned NOT NULL auto_increment,
  word char(100) NOT NULL default '',
  replacement char(100) NOT NULL default '',
  PRIMARY KEY  (word_id)
) TYPE=MyISAM;

--
-- Dumping data for table 'phpbb_words'
--



--
-- Table structure for table 'postnuke_pnchatrooms'
--

CREATE TABLE postnuke_pnchatrooms (
  postnuke_pnchatrooms text,
  pn_room text
) TYPE=MyISAM;

--
-- Dumping data for table 'postnuke_pnchatrooms'
--



