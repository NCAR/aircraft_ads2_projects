<?php
// File: $Id: phpnuke53.php,v 1.3 2002/11/01 12:37:00 magicx Exp $ $Name:  $
mysql_query("DROP TABLE ".$prefix."_modules");

/* Update stories for the comments selection */
mysql_query("ALTER TABLE ".$prefix."_stories ADD withcomm int(1) DEFAULT '0' NOT NULL AFTER alanguage");
mysql_query("ALTER TABLE ".$prefix."_stories ADD pn_format_type int(1) UNSIGNED DEFAULT '0' NOT NULL AFTER withcomm");
mysql_query("ALTER TABLE ".$prefix."_autonews ADD withcomm int(1) DEFAULT '0' NOT NULL AFTER alanguage");

mysql_query("ALTER TABLE ".$prefix."_queue ADD arcd INT (1) DEFAULT '0' NOT NULL AFTER uid");
mysql_query("ALTER TABLE ".$prefix."_users ADD timezone_offset float(3,1) DEFAULT '0.0' NOT NULL");

?>