<?php // File: $Id: phpBB_14.php,v 1.18 2002/11/27 07:53:07 larsneo Exp $ $Name:  $
/************************************************************************
 * phpBB_14 - The Post-Nuke Module                                      *
 * ==============================                                       *
 *                                                                      *
 * Copyright (c) 2001, 2002 by the PN_phpBB14  Module Development Team  *
 * http://postnuke.pwp.ru/                                              *
 ************************************************************************
 * Modified version of: *
 ************************************************************************
 * phpBB version 1.4                                                    *
 * begin                : Wed July 19 2000                              *
 * copyright            : (C) 2001 The phpBB Group                      *
 * email                : support@phpbb.com                             *
 ************************************************************************
 * License *
 ************************************************************************
 * This program is free software; you can redistribute it and/or modify *
 * it under the terms of the GNU General Public License as published by *
 * the Free Software Foundation; either version 2 of the License, or    *
 * (at your option) any later version.                                  *
 *                                                                      *
 * This program is distributed in the hope that it will be useful,      *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of       *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        *
 * GNU General Public License for more details.                         *
 *                                                                      *
 * You should have received a copy of the GNU General Public License    *
 * along with this program; if not, write to the Free Software          *
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 *
 * USA                                                                  *
 ************************************************************************/ 

// german translation: larsneo - http://pncommunity.de

define('_RESULTS',"Ergebnisse");
define('_PHPBB_SEARCHINCLUDE_AUTHOR',"Verfasser");
define('_PHPBB_SEARCHINCLUDE_BYDATE',"nach Datum");
define('_PHPBB_SEARCHINCLUDE_BYTITLE',"nach Titel");
define('_PHPBB_SEARCHINCLUDE_BYFORUM',"nach Forum");
define('_PHPBB_SEARCHINCLUDE_DATE',"Datum");
define('_PHPBB_SEARCHINCLUDE_FORUM',"Kategorie und Forum");
define('_PHPBB_SEARCHINCLUDE_NEWWIN',"in neuem Fenster �ffnen");
define('_PHPBB_SEARCHINCLUDE_NOENTRIES',"keine Forenbeitr�ge gefunden");
define('_PHPBB_SEARCHINCLUDE_ORDER',"Reihenfolge");
define('_PHPBB_SEARCHINCLUDE_REPLIES',"Antworten");
define('_PHPBB_SEARCHINCLUDE_RESULTS',"phpBB Forum");
define('_PHPBB_SEARCHINCLUDE_TITLE',"phpBB Foren");
define('_PHPBB_SEARCHINCLUDE_VIEWS',"Views");

?>