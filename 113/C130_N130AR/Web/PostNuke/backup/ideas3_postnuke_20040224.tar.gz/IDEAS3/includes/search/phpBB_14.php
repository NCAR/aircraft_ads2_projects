<?php // $Id: phpBB_14.php,v 1.19 2003/01/07 10:11:14 larsneo Exp $ $Name:  $
/************************************************************************
 * phpBB_14 - The Post-Nuke Module                                      *
 * ==============================                                       *
 *                                                                      *
 * Copyright (c) 2001, 2002 by the PN_phpBB14  Module Development Team  *
 * http://www.pncommunity.de/                                           *
 ************************************************************************
 * Modified version of: *
 ************************************************************************
 * phpBB version 1.4                                                    *
 * begin                : Wed July 19 2000                              *
 * copyright            : (C) 2001 The phpBB Group                      *
 * email                : support@phpbb.com                             *
 ************************************************************************
 * License *
 ************************************************************************
 * This program is free software; you can redistribute it and/or modify *
 * it under the terms of the GNU General Public License as published by *
 * the Free Software Foundation; either version 2 of the License, or    *
 * (at your option) any later version.                                  *
 *                                                                      *
 * This program is distributed in the hope that it will be useful,      *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of       *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        *
 * GNU General Public License for more details.                         *
 *                                                                      *
 * You should have received a copy of the GNU General Public License    *
 * along with this program; if not, write to the Free Software          *
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 *
 * USA                                                                  *
 ************************************************************************/

$search_modules[] = array(
    'title' => 'phpBB_14',
    'func_search' => 'search_phpBB_14',
    'func_opt' => 'search_phpBB_14_opt'
);

// Load the language files
$currentlang = pnVarPrepForOS(pnUserGetLang());
if (!@include_once "includes/language/blocks/$currentlang/phpBB_14.php") {
        $defaultlang = pnVarPrepForOS(pnConfigGetVar('language'));
        if (empty($defaultlang)) {
            $defaultlang = 'eng';
        }
        @include "includes/language/blocks/$defaultlang/phpBB_14.php";
    }


function search_phpBB_14_opt($vars) {
    
	pnModDBInfoLoad('phpBB_14');
	list($dbconn) = pnDBGetConn();
	$pntable = pnDBGetTables();
	$output = "";
        
    $output .= "<table border=\"0\" width=\"100%\"><tr bgcolor=\"$GLOBALS[bgcolor2]\"><td><input type=\"checkbox\" name=\"active_phpBB_14\" id=\"active_phpBB_14\" value=\"1\" checked>&nbsp;"._PHPBB_SEARCHINCLUDE_TITLE."</td></tr></table>";
    $output .= "<table border=\"0\" cellpadding=\"2\" cellspacing=\"0\">";

		// Forums
		$output .= "<tr>"
        ."<td nowrap align=\"right\" valign=\"top\">"._PHPBB_SEARCHINCLUDE_FORUM.":</td>"
        ."<td><select name=\"phpBB_14_forum[]\" id=\"phpBB_14_forum[]\" size=\"1\">"
        ."<option value=\"\" selected>"._SRCHALLTOPICS."</option>"
    ;
		//hide private forums later with auth-check
        $sql = "SELECT 
			f.forum_id, f.forum_name, c.cat_title
			FROM 
			".$pntable['phpbb14_forums']." AS f,
			".$pntable['phpbb14_categories']." AS c			
			WHERE f.cat_id = c.cat_id
			ORDER BY c.cat_order, f.forum_order";
			
		
		$result = $dbconn->Execute($sql);
	    if($dbconn->ErrorNo() != 0) {
	      die("Error accesing to the database " . $dbconn->ErrorNo() . ": " . $dbconn->ErrorMsg() . "<br>");
	    }
	
	    while (!$result->EOF) {
			list($forum_id, $forum_name, $cat_title) = $result->fields;
			//auth-check for display in box
			$forum_name = pnVarPrepForDisplay($forum_name);
			$cat_title = pnVarPrepForDisplay($cat_title);
			if  (pnSecAuthAction(0, 'phpBB_14::Forum', "$forum_name::", ACCESS_READ) && pnSecAuthAction(0, 'phpBB_14::Category', "$cat_title::", ACCESS_READ)) 	{
				$output .= "<option value=\"$forum_id\">$cat_title :: $forum_name</option>\n";
			}
			$result->MoveNext();
		}
    $output .= "</select></td></tr>";

		// author
		$output .= "<tr>"
        ."<td nowrap align=\"right\" valign=\"top\">"._PHPBB_SEARCHINCLUDE_AUTHOR.":</td>"
        ."<td colspan=\"3\"><input type=\"text\" name=\"phpBB_14_author\" id=\"phpBB_14_author\" size=\"20\" maxlength=\"255\"></td>"
        ."</tr>";

		// order
		$output .= "<tr>"
        ."<td nowrap align=\"right\" valign=\"top\">"._PHPBB_SEARCHINCLUDE_ORDER.":</td>"
        ."<td><select name=\"phpBB_14_order[]\" id=\"phpBB_14_order[]\" size=\"1\">"
		."<option value=\"1\" selected>"._PHPBB_SEARCHINCLUDE_BYDATE."</option>"
		."<option value=\"2\">"._PHPBB_SEARCHINCLUDE_BYTITLE."</option>"
		."<option value=\"3\">"._PHPBB_SEARCHINCLUDE_BYFORUM."</option>"
		."</select></td>"
        ."</tr>";

        $output .= "</table>";
        return $output; 
}


function search_phpBB_14($vars) 
{
    if(!isset($vars['active_phpBB_14'])) {
        return;
    }

	pnModDBInfoLoad('phpBB_14');
	list($dbconn) = pnDBGetConn();
	$pntable = pnDBGetTables();

    $w = search_split_query($vars['q']);
    $flag = false;
        
    $query = "SELECT"
    // DISTINCT
		."	f.forum_id,
			f.cat_id,
			p.forum_id,
			pt.post_text,
			pt.post_id,
			t.forum_id,
			t.topic_id,
			t.topic_title,
			t.topic_replies,
			t.topic_views,
			c.cat_title,
			f.forum_name,
			p.poster_id,
			p.post_time 
			FROM 
			".$pntable['phpbb14_posts']." AS p, 
			".$pntable['phpbb14_forums']." AS f,
			".$pntable['phpbb14_posts_text']." AS pt, 
			".$pntable['phpbb14_topics']." AS t,
			".$pntable['phpbb14_categories']." AS c
			WHERE ";
			
	// words
    foreach($w as $word) 
		{
        if($flag) 
			{
            switch($vars['bool']) 
				{
                case 'AND' :
                    $query .= ' AND ';
                    break;
                case 'OR' :
                default :
                    $query .= ' OR ';
                    break;
            	}
        	}

		// get post_text and match up forums/topics/posts
		//$query .= '(';
		$query .= "(pt.post_text LIKE '$word' OR t.topic_title LIKE '$word') \n";
		$query .= "AND p.post_id=pt.post_id \n";
		$query .= "AND p.topic_id=t.topic_id \n";
		$query .= "AND p.forum_id=f.forum_id\n";
		$query .= "AND c.cat_id=f.cat_id\n";
		//$query .= ')';
		$flag = true;
		
		//check forums (multiple selection is possible!)
	    if($vars['phpBB_14_forum'][0]) 
		{
        $query .= " AND (";
        $flag = false;
        foreach($vars['phpBB_14_forum'] as $w) 
			{
            if($flag) 
				{
                $query .= " OR ";
         	   }
            $query .= "f.forum_id=$w";
            $flag = true;
			}
        $query .= ") ";
	   	}
	
		// authors with adodb
		if($vars['phpBB_14_author']) {
			$search_username = addslashes($vars['phpBB_14_author']);
			$result= $dbconn->SelectLimit("SELECT pn_uid FROM $pntable[users] WHERE pn_uname = '$search_username'", 1);
			$row = $result->GetRowAssoc(false);
			$author = $row['pn_uid'];
			if ($author > 0){
				$query .= " AND p.poster_id=$author \n";
				}
				else {
				$query .= " AND p.poster_id=0 \n";
				}
		}

	}

	// Not sure this is needed and is not cross DB compat
    //$query .= " GROUP BY pt.post_id ";
    
	$order = $vars['phpBB_14_order']['0'];

	if ($order == 1){
		$query .= " ORDER BY pt.post_id DESC";
	}
	if ($order == 2){
		$query .= " ORDER BY t.topic_title";
	}
	if ($order == 3){
		$query .= " ORDER BY f.forum_name";
	}
	
	$result = $dbconn->Execute($query);
    $total_rows = $result->PO_RecordCount();
    if($vars['overview']) {
        $result->Close();
        // fifers - only run if necessary!
        $result = $dbconn->SelectLimit($query,3);
    }


    if(!$result->EOF) {

        print ""._PHPBB_SEARCHINCLUDE_RESULTS.": ";
        if($total_rows > 2 && $vars['overview']) {
        // Rebuild the search string from previous information
            print " <a href=\"modules.php?op=modload&amp;name=Search&amp;file=index&amp;action=search&amp;active_phpBB_14=1";
            if ($vars['stories_cat']) {
               foreach($vars['phpBB_14_forum'] as $v) {
               print "&amp;phpBB_14_forum%5B%5D=$v";
               }
            }
            print "&amp;bool=$vars[bool]&amp;q=$vars[q]&amp;phpBB_14_author=$vars[phpBB_14_author]&amp;phpBB_14_order=$order\">"._SEEALL." ($total_rows "._RESULTS."...)</a>";
        }
        print "<ul>";

        while(!$result->EOF) {
		$row = $result->GetRowAssoc(false);
	
		// timezone
		$posted_unixtime= strtotime ($row['post_time']);
		$posted_ml = ml_ftime(_DATETIMEBRIEF, GetUserTime($posted_unixtime));
	
		$row['topic_title'] = stripslashes($row['topic_title']);

		//without signature
		$row['post_text'] = eregi_replace("\[addsig]$", "", $row['post_text']);

		//strip_tags is needed here 'cause maybe we cut within a html-tag...
		$row['post_text'] = strip_tags($row['post_text']);

		//cut off right after 128 chars
		if(strlen($row['post_text']) > 128) {
            $row['post_text'] = substr($row['post_text'],0,125) . '...';
        }

		$posttext = $row['post_text'];

		// username
		$user_id = $row['poster_id'];
		$uresult= $dbconn->SelectLimit("SELECT pn_uname FROM $pntable[users] WHERE pn_uid = $user_id", 1);
		$urow = $uresult->GetRowAssoc(false);
		$user_name = $urow['pn_uname'];
		
		//auth check for forum an category before displaying search result
		$forum_name = stripslashes($row['forum_name']);
		$cat_title = stripslashes($row['cat_title']);
		if (pnSecAuthAction(0, 'phpBB_14::Forum', "$forum_name::", ACCESS_READ) && pnSecAuthAction(0, 'phpBB_14::Category', "$cat_title::", ACCESS_READ)) 	{
			echo "<li><a href=\"modules.php?op=modload&amp;name=phpBB_14&amp;file=index&amp;action=viewtopic&topic=$row[topic_id]&amp;$row[post_id]\">"
			.$row['topic_title']."</a>&nbsp;&nbsp;&nbsp;<a href=\"modules.php?op=modload&amp;name=phpBB_14&amp;file=index&amp;action=viewtopic&topic="
			.$row['topic_id']."&amp;"   
			.$row['post_id']."\" target=_new>("._PHPBB_SEARCHINCLUDE_NEWWIN.")</a><br>"
			."<a class=\"header\" href=\"modules.php?op=modload&amp;name=phpBB_14&amp;file=index&amp;action=viewforum&amp;forum="
			.$row['forum_id']."\" target=_new>"
			.$row['cat_title']." :: "
			.$row['forum_name']."</a><br>"
			._PHPBB_SEARCHINCLUDE_AUTHOR.": $user_name&nbsp;|&nbsp;"._PHPBB_SEARCHINCLUDE_DATE.": ".$posted_ml."&nbsp;|&nbsp;"._PHPBB_SEARCHINCLUDE_REPLIES.": ".$row['topic_replies']." | "._PHPBB_SEARCHINCLUDE_VIEWS.": ".$row['topic_views']."<br>";
		echo "$posttext<p></li>\n";
		}
        $result->MoveNext();
        }

        print "</ul>\n";
		} else {
        print ''._PHPBB_SEARCHINCLUDE_NOENTRIES.'';
    }
    print "<br>";
}
?>
