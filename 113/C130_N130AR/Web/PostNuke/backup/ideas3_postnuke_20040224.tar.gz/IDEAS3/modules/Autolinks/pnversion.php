<?php
// $Id: pnversion.php,v 1.1.1.1 2002/09/15 22:26:15 root Exp $
$modversion['name'] = 'Autolinks';
$modversion['version'] = '1.0';
$modversion['description'] = 'Automatically link key words';
$modversion['credits'] = 'pndocs/credits.txt';
$modversion['help'] = 'pndocs/help.txt';
$modversion['changelog'] = 'pndocs/changelog.txt';
$modversion['license'] = 'pndocs/license.txt';
$modversion['coding'] = 'pndocs/coding.txt';
$modversion['official'] = 1;
$modversion['author'] = 'Jim McDonald';
$modversion['contact'] = 'Jim@mcdee.net';
$modversion['admin'] = 1;
$modversion['securityschema'] = array();
?>