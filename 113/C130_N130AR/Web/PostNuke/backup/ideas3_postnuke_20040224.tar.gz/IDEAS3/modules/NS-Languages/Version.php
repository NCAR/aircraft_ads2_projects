<?php
// $Id: Version.php,v 1.1.1.1 2002/09/15 22:26:15 root Exp $ $Name:  $
$modversion['name'] = 'Languages Admin';
$modversion['version'] = '1.2';
$modversion['description'] = 'List languages by their ISO Key and name.';
$modversion['credits'] = '';
$modversion['help'] = '';
$modversion['changelog'] = '';
$modversion['license'] = '';
$modversion['official'] = 1;
$modversion['author'] = 'Patrick Kellum';
$modversion['contact'] = 'http://www.ctarl-ctarl.com';
$modversion['admin'] = 1;
$modversion['securityschema'] = array('Languages::' => '::');
?>