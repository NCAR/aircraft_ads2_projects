<?php
$modversion['name'] = 'Your Account';
$modversion['version'] = '0.8';
$modversion['description'] = 'User options';
$modversion['official'] = 1;
$modversion['author'] = 'David Sede�o Fernandez';
$modversion['contact'] = 'frimost@softhome.net';
$modversion['admin'] = 1;
?>