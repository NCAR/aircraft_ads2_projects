<?php
// $Id: Version.php,v 1.1.1.1 2002/09/15 22:26:15 root Exp $ $Name:  $
$modversion['name'] = 'Story Submission Module';
$modversion['version'] = '1.0';
$modversion['description'] = 'Post new articles on your site.';
$modversion['credits'] = '';
$modversion['help'] = '';
$modversion['changelog'] = '';
$modversion['license'] = '';
$modversion['official'] = 1;
$modversion['author'] = 'Francisco Burzi';
$modversion['contact'] = 'http://www.phpnuke.org';
$modversion['admin'] = 1;
// Uses 'Stories' security schema
?>