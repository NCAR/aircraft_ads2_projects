<?php
#   include 'modules/NS-User/user/database.php';
   include 'modules/NS-User/user/menu.php';
   include 'modules/NS-User/user/access.php';
#   include 'modules/NS-User/user/language.php';

function redirect_index($message, $url="index.php")
{
    $ThemeSel = pnConfigGetVar('Default_Theme');
    echo "<html><head><META HTTP-EQUIV=Refresh CONTENT=\"2; URL=$url\">\n";
    if (defined("_CHARSET") && _CHARSET != "") {
       echo "<META HTTP-EQUIV=\"Content-Type\" CONTENT=\"text/html; charset="._CHARSET."\">\n";
    }
    echo "<LINK REL=\"StyleSheet\" HREF=\"themes/$ThemeSel/style/styleNN.css\" TYPE=\"text/css\">\n";
    echo "<style type=\"text/css\">";
    echo "@import url(\"themes/$ThemeSel/style/style.css\"); ";
    echo "</style>\n";
    echo "</head><body bgcolor=#2F363F text=#DADEE3>\n";
    echo "<table align=center border=0 cellpadding=2 cellspacing=0><tr><td><font class=\"pn-title\">$message</font></td></tr></table></body></html>";

    if (function_exists('session_write_close')) {
        session_write_close();
    } else {
        // Hack for old versions of PHP with bad session save
        /* Credit to M.W.Herbert from Forum Post*/
        $sessvars = '';
        foreach ($GLOBALS as $k => $v) {
            if ((preg_match('/^PNSV/', $k)) && (isset($v))) {
            $sessvars .= "$k|" . serialize($v);
            }
        }
        pnSessionWrite(session_id(), $sessvars);
    }


}

function redirect_user()
{
    $ThemeSel = pnConfigGetVar('Default_Theme');
    echo "<html><head><META HTTP-EQUIV=Refresh CONTENT=\"2; URL=user.php\">\n";
    if (defined("_CHARSET") && _CHARSET != "") {
       echo "<META HTTP-EQUIV=\"Content-Type\" CONTENT=\"text/html; charset="._CHARSET."\">\n";
    }
    echo " <LINK REL=\"StyleSheet\" HREF=\"themes/$ThemeSel/style/style.css\" TYPE=\"text/css\">\n";
    echo "</head><body bgcolor=#2F363F text=#DADEE3>\n";
    echo "<table align=center border=0 cellpadding=2 "
         .'cellspacing=0><tr><td><font class=\"pn-title\">'._INFOCHANGED.'</font></td></tr></table></body></html>';
    if (function_exists('session_write_close')) {
        session_write_close();
    } else {
        // Hack for old versions of PHP with bad session save
        $sessvars = '';
        foreach ($GLOBALS as $k => $v) {
            if ((preg_match('/^PNSV/', $k)) &&
                (isset($v))) {
                $sessvars .= "$k|" . serialize($v);
            }
        }
        pnSessionWrite(session_id(), $sessvars);
    }
}

function docookie($setuid, $setuname, $setpass, $setstorynum, $setumode, $setuorder, $setthold, $setnoscore, $setublockon, $settheme, $setcommentmax)
{
    $info = base64_encode("$setuid:$setuname:$setpass:$setstorynum:$setumode:$setuorder:$setthold:$setnoscore:$setublockon:$settheme:$setcommentmax");
    setcookie("user","$info",time() + 15552000);
}

// for compatibility : use user_menu_add_option($url,$title,$image)
function usermenu($url,$title,$image)
{
    if (!ereg('/',$image)) $image = pnConfigGetVar('userimg')."/".$image;
        user_menu_add_option($url,$title,$image);
}

   function GraphicUser($help='')
   {
      //modified by Chris van de Steeg.. I guess this should display the menu
      //it didn't do that.
      //if ($help!='') user_menu_help($help,_ONLINEMANUAL);
      user_menu($help);
      //user_menu_detail(false);
      user_menu_draw();
   }

   function user_menu($help_file='')
   {
      $pntable = pnDBGetTables();

      user_menu_title('user.php',_THISISYOURPAGE);
      user_menu_graphic(pnConfigGetVar('usergraphic'));
      if ($help_file!='') user_menu_help($help_file,_ONLINEMANUAL);
      //include 'modules/NS-Modules/data.php';
      //foreach ($module_item as $k=>$item)
      //   user_menu_add_option('user.php?module='.$item['module'].'&op=main',$item['text'],$item['image']);
//    modules, old way
      $moddir = opendir('modules/');
      while ($modulename=readdir($moddir))
      {
         if (@is_dir($dir='modules/'.pnVarPrepForOS($modulename).'/user/links/'))
         {
            $linksdir = opendir("modules/".pnVarPrepForOS($modulename)."/user/links/");
            while ($func = readdir($linksdir))
            {
               if (eregi('^links.',$func))
               {
                  //modified by Chris van de Steeg to have $ModName available in the links file
                  //$menulist[$func] = "modules/$modulename/user/links";
                  $menulist[$func]["dir"] = 'modules/' . pnVarPrepForOS($modulename) . '/user/links';
                  $menulist[$func]["modname"] = $modulename;
                  //end mofication by Chris van de Steeg
               }
            }
            closedir($linksdir);
         }
      }
      closedir($moddir);
//    display
      ksort($menulist);
      foreach ($menulist as $k=>$v)
      {
         //modified by Chris van de Steeg to have $ModName available in the links file
         // $currMod = $GLOBALS["ModName"]; //moved a bit down by Andy Varganov
         $GLOBALS["ModName"] = $v["modname"];
         $currMod = $GLOBALS["ModName"];
         include $v['dir'] . '/' . pnVarPrepForOS($k);
         $GLOBALS["ModName"] = $currMod;
         //end mofication by Chris van de Steeg
      }
      user_menu_add_option('user.php?module=NS-User&op=logout', _LOGOUTEXIT, 'modules/NS-Your_Account/images/exit.gif');
   }

   function user_title($title)
   {
    OpenTable();
    echo "<center><font class=\"pn-title\"><b>".pnVarPrepForDisplay($title)."</b></font></center>";
    CloseTable();
   }

   function user_submit($module,$op,$text)
   {
      echo  '<input type="hidden" NAME="module" value="'.$module.'">'."\n"
           .'<input type="hidden" NAME="op" value="'.$op.'">'."\n"
           .'<input type="submit" VALUE="'.$text.'">'."\n";
   }



// HACKED BY CHESTNUT !!!

function getfieldDynamicDisplay($dynafield, $dynavalue) {

    if (!isset($dynavalue)) {
        $dynavalue = "";
    }
	if (pnSecAuthAction(0, '::', '::', ACCESS_ADMIN)) {
		$cansee = 1;
	} else {
		$cansee = 0;
	}
    if ($dynafield['NAME'] == "_TIMEZONEOFFSET") {
           global $tzinfo;
        foreach ($tzinfo as $tzindex => $tzdata) {
            if ($dynavalue == $tzindex) {
                $varaffiche .= "\n".$tzdata;
            }
        }
    } else {
   		switch($dynafield['TYPE']) {
    	    case "TEXT":
    	        if ($dynafield['ADMINONLY'] == 1 && $cansee != 1) {
					$varaffiche = "";
				} else {
					$varaffiche .= $dynavalue."\n";
				}            
    	        break;
    	    case "TEXTAREA":
    	        if ($dynafield['ADMINONLY'] == 1 && $cansee != 1) {
					$varaffiche = "";
				} else {
					$varaffiche .= $dynavalue."\n";
				}
    	        break;
    	    case "CHECKBOX":
    	        if ($dynafield['ADMINONLY'] == 1 && $cansee != 1) {
					$varaffiche = "";
				} else {
					if ($dynavalue == 1) {
		                $varaffiche .= "Yes\n";
		            } else {
		                $varaffiche .= "No\n";
		            }
				}            
    	        break;
    	    case "RADIO":
				if ($dynafield['ADMINONLY'] == 1 && $cansee != 1) {
					$varaffiche = "";
				} else {
					$listfill = explode('@@',$dynafield['LISTFILL']);
    	        	$count = count($listfill);
		            $compteur = 0;
		            $varaffiche = "";
		            while(list($key,$val) = each($listfill)) {
		                if ($dynavalue == $compteur) {
		                    $varaffiche = $val."\n";
		                    $compteur++;
		                }
		                $compteur++;
		            }
				}
    	        break;
    	    case "SELECT":
				if ($dynafield['ADMINONLY'] == 1 && $cansee != 1) {
					$varaffiche = "";
				} else {
					$listfill = explode('@@',$dynafield['LISTFILL']);
    	        	$compteur = 0;
    	        	$varaffiche = "";
    	        	while(list($key,$val) = each($listfill)) {
    	        	    if ($dynafield['LISTOPTION'] == 1) {
    	        	        $getdyna = $dynavalue;
    	        	        $check = $key;
    	        	        if (!empty($getdyna) && is_array($getdyna)) {
    	        	            $count = count($getdyna);
    	        	            $cherche = array_search($check, $getdyna);
    	        	            if ($cherche!==null&&$cherche!==false) {
    	        	                if ($compteur+1 >= $count) {
    	        	                    $varaffiche .= $val."\n";
    	        	                } else {
    	        	                    $varaffiche .= $val."\n<br>&nbsp;";
    	        	                }
    	        	                $compteur++;
    	        	            }
    	        	        }
    	        	    } else {
    	        	        if ($dynavalue == $compteur) {
    	        	            $varaffiche .= $val."\n";
    	        	        }
    	        	        $compteur++;
    	        	    }
    	        	}
    	        }
    	        break;
    	    default:
    	        if ($dynafield['ADMINONLY'] == 1 && $cansee != 1) {
					$varaffiche = "";
				} else {
					$varaffiche .= $dynavalue."\n";
				}
    	        break;
    	}
    }

    return $varaffiche;
}

##########################################################
// Added by Chestnut ! - 20030214 13h41 (pncUserHack v1.6)
// Fetching the HTML to display the dynamic field.
//

function getuserfieldHTMLDef($dynafield, $dynavalue) {

    if (!isset($dynavalue)) {
        $dynavalue = "";
    }

    switch($dynafield['TYPE']) {
        case "TEXT":
            $varaffiche = "<table><tr><td>\n";
            $varaffiche .= "<input type=text name=\"dynafield[".$dynafield['NAME']."]\" value=\"".$dynavalue."\" size=\"40\">\n";
            $varaffiche .= "</td><td>\n";
            if ($dynafield['ADMINONLY'] == 1) $varaffiche .= " <b>"._FORYOUREYESONLY."</b>";
            if ($dynafield['NOTE']."" != "") $varaffiche .= ""._UANOTE."".nl2br($dynafield['NOTE']);
            $varaffiche .= "</td></tr></table>";
            $varaffiche .= "\n";
            break;
        case "TEXTAREA":
            $varaffiche = "<table><tr><td>\n";
            $varaffiche .= "<textarea cols=50 rows=10 name=\"dynafield[".$dynafield['NAME']."]\">".$dynavalue."</textarea>\n";
            $varaffiche .= "</td><td>\n";
            if ($dynafield['ADMINONLY'] == 1) $varaffiche .= " <b>"._FORYOUREYESONLY."</b>";
            if ($dynafield['NOTE']."" != "") $varaffiche .= ""._UANOTE."".nl2br($dynafield['NOTE']);
            $varaffiche .= "</td></tr></table>";
            $varaffiche .= "\n";
            break;
        case "CHECKBOX":
            $varaffiche = "<table><tr><td>\n";
            $varaffiche .= "<input type=\"CHECKBOX\" name=\"dynafield[".$dynafield['NAME']."]\">&nbsp;".$dynavalue."&nbsp;";
            $varaffiche .= "</td><td>\n";
            if ($dynafield['ADMINONLY'] == 1) $varaffiche .= " <b>"._FORYOUREYESONLY."</b>";
            if ($dynafield['NOTE']."" != "") $varaffiche .= ""._UANOTE."".nl2br($dynafield['NOTE']);
            $varaffiche .= "</td></tr></table>";
            $varaffiche .= "\n";
            break;
        case "RADIO":
            $listfill = explode('@@',$dynafield['LISTFILL']);
            $count = count($listfill);
            $compteur = 1;
            $varaffiche = "";
            $varaffiche .= "<table><tr><td valign=\"middle\">\n";
            while(list($key,$val) = each($listfill)) {
                if ($dynavalue == $compteur) {
                    $checked = " checked";
                } else {
                    $checked = "";
                }
                if ($val != "") {
                    $varaffiche .= "<input type=\"radio\" name=\"dynafield[".$dynafield['NAME']."]\" value=\"".$compteur."\"$checked> ".$val."<br>\n";
                    $compteur++;
                }
            }
            if ($dynafield['REQUIRED'] == 1 || $dynafield['ADMINONLY'] == 1 || $dynafield['NOTE']."" != "") $varaffiche .= "</td><td>\n";
            if ($dynafield['ADMINONLY'] == 1) $varaffiche .= " <b>"._FORYOUREYESONLY."</b>";
            if ($dynafield['NOTE']."" != "") $varaffiche .= ""._UANOTE."".nl2br($dynafield['NOTE']);
            $varaffiche .= "</td></tr></table>";
            $varaffiche .= "\n";
            break;
        case "SELECT":
            $listfill = explode('@@',$dynafield['LISTFILL']);
            $count = count($listfill);
            $compteur = 1;
            if ($dynafield['LISTOPTION']==1) {
                $multiple = " multiple";
                $size = "size=\"5\"";
            } else {
                $multiple = "";
                $size = "size=\"1\"";
            }

            $varaffiche = "<table><tr><td>\n";
            if ($multiple."" != "") {
                $varaffiche .= "<SELECT NAME=\"dynafield[".$dynafield['NAME']."][]\"".$multiple." ".$size.">\n";
            } else {
                $varaffiche .= "<SELECT NAME=\"dynafield[".$dynafield['NAME']."]\" ".$size.">\n";
            }
            
            if ($multiple."" == "") $varaffiche .= "<option value=\"\"".$selected."></option>\n";
            
            $getdyna = $dynavalue;
            $parselist = $listfill;
            while(list($key,$val) = each($listfill)) {
                if ($dynafield['LISTOPTION'] == 1) {
                    if ($val."" != "") {
                        $getdyna = $dynavalue;
                        $check = $key;
                        if (!empty($getdyna) && is_array($getdyna)) {
                            $cherche = array_search($check, $getdyna);
                            if ($cherche!==null&&$cherche!==false) {
                                $selected = " selected";
                                $varaffiche .= "<option value=\"".$compteur."\"".$selected.">".$val."</option>\n";
                            } else {
                                $selected = "";
                                $varaffiche .= "<option value=\"".$compteur."\"".$selected.">".$val."</option>\n";
                            }
                        } else {
                            $selected = "";
                            $varaffiche .= "<option value=\"".$compteur."\"".$selected.">".$val."</option>\n";
                        }
                        $compteur++;
                    }
                } else {
					if ($val."" != "") {
					    if ($dynavalue == $compteur) {
                        	$selected = " selected";
	                    } else {
	                        $selected = "";
	                    }
	                    $varaffiche .= "<option value=\"".$compteur."\"".$selected.">".$val."</option>\n";
	                    $compteur++;
					}
                }
            }
            $varaffiche .= "</select>";
            $varaffiche .= "</td><td>\n";
            if ($dynafield['ADMINONLY'] == 1) $varaffiche .= " <b>"._FORYOUREYESONLY."</b>";
            if ($dynafield['NOTE']."" != "") $varaffiche .= ""._UANOTE."".nl2br($dynafield['NOTE']);
            $varaffiche .= "</td></tr></table>";
            $varaffiche .= "\n";
            break;
        default:
            $varaffiche = "<table><tr><td>\n";
            $varaffiche .= "<input type=text name=\"dynafield[".$dynafield['NAME']."]\" value=\"".$dynavalue."\" size=\"40\">\n";
            $varaffiche .= "</td><td>\n";
            if ($dynafield['ADMINONLY'] == 1) $varaffiche .= " <b>"._FORYOUREYESONLY."</b>";
            if ($dynafield['NOTE']."" != "") $varaffiche .= ""._UANOTE."".nl2br($dynafield['NOTE']);
            $varaffiche .= "</td></tr></table>";
            $varaffiche .= "\n";
            break;
    }

    return $varaffiche;
}

function getuserfieldrequired()
{
    
    list($dbconn) = pnDBGetConn();
    $pntable = pnDBGetTables();
    $propcolumn = &$pntable['user_property_column'];
    $propresult = $dbconn->Execute("SELECT		$propcolumn[prop_label],
												$propcolumn[prop_validation]
                                    FROM        $pntable[user_property]
                                    WHERE		$propcolumn[prop_dtype]!='-1'
									AND			$propcolumn[prop_weight]!='0'
                                    ORDER BY	$propcolumn[prop_weight]");
    if (!$propresult->EOF) {
        $fieldrequired = array();
        while(list($prop_label, $prop_validation) = $propresult->fields) {
			$propresult->MoveNext();
            $prop_validation = unserialize($prop_validation);
            if ($prop_validation['REQUIRED'] == 1) {
	            $prop_label_text = "";
                $eval_cmd = "\$prop_label_text = $prop_label;";
                @eval($eval_cmd);    
                if (empty($prop_label_text)) {
	                $prop_label_text = $prop_label;
                }
                $fieldrequired[$prop_label]['FIELD'] = $prop_label;
                $fieldrequired[$prop_label]['LIBEL'] = $prop_label_text;
                $fieldrequired[$prop_label]['VALIDATION'] = $prop_validation;
            }
        }
    }

    return $fieldrequired;

}

function getuserfieldlist()
{
    
    list($dbconn) = pnDBGetConn();
    $pntable = pnDBGetTables();
    $propcolumn = &$pntable['user_property_column'];
    $propresult = $dbconn->Execute("SELECT		$propcolumn[prop_label],
												$propcolumn[prop_validation]
                                    FROM        $pntable[user_property]
                                    WHERE		$propcolumn[prop_dtype]!='-1'
									AND			$propcolumn[prop_weight]!='0'
                                    ORDER BY	$propcolumn[prop_weight]");
    if (!$propresult->EOF) {
        $fieldrequired = array();
        while(list($prop_label, $prop_validation) = $propresult->fields) {
            $propresult->MoveNext();
            $prop_validation = unserialize($prop_validation);
            $prop_label_text = "";
            $eval_cmd = "\$prop_label_text = $prop_label;";
            @eval($eval_cmd);    
            if (empty($prop_label_text)) {
	            $prop_label_text = $prop_label;
            }
            $fieldrequired[$prop_label]['FIELD'] = $prop_label;
            $fieldrequired[$prop_label]['LIBEL'] = $prop_label_text;
            $fieldrequired[$prop_label]['VALIDATION'] = $prop_validation;
        }
    }

    return $fieldrequired;

}

function getfieldConfirmUser($dynafield, $dynavalue) {

    if (!isset($dynavalue)) {
        $dynavalue = "";
    }

    if ($dynafield['FIELD'] == "_TIMEZONEOFFSET") {
		global $tzinfo;
        foreach ($tzinfo as $tzindex => $tzdata) {
            if ($dynavalue == $tzindex) {
                $varaffiche .= "\n".$tzdata;
            }
        }
    } elseif ($dynafield['FIELD'] == "_YOURAVATAR") {
        $varaffiche = "<img src=images/avatar/".$dynavalue.">\n";
    } else {
        switch($dynafield['TYPE']) {
            case "TEXT":
                $varaffiche .= $dynavalue."\n";
                break;
            case "TEXTAREA":
                $varaffiche .= $dynavalue."\n";
                break;
            case "CHECKBOX":
                if ($dynavalue == 1) {
                    $varaffiche .= "Yes\n";
                } else {
                    $varaffiche .= "No\n";
                }
                break;
            case "RADIO":
                $listfill = explode('@@',$dynafield['LISTFILL']);
                $count = count($listfill);
                $compteur = 0;
                $varaffiche = "";
                while(list($key,$val) = each($listfill)) {
                    if ($dynavalue == $compteur) {
                        $varaffiche .= $val."\n";
                    }
                    $compteur++;
                }
                break;
            case "SELECT":
                $listfill = explode('@@',$dynafield['LISTFILL']);
                $count = count($dynavalue);
                $compteur = 0;
                $varaffiche = "";
                while(list($key,$val) = each($listfill)) {
                	if ($dynafield['LISTOPTION'] == 1) {
	                    if ($val."" != "") {
	                        $getdyna = $dynavalue;
	                        $check = $key;
	                        if (!empty($getdyna) && is_array($getdyna)) {
	                            $cherche = array_search($check, $getdyna);
	                            if ($cherche!==null&&$cherche!==false) {
                            		if ($compteur+1 >= $count) {
                            		    $varaffiche .= $val."\n";
                            		} else {
                            		    $varaffiche .= $val."\n<br>&nbsp;";
                            		}
                            		$compteur++;
	                            }
	                        } else {
	                            $varaffiche .= $val."\n";
	                        }
	                        $compteur++;
	                    }
	                } else {
						if ($val."" != "") {
		                    if ($dynavalue == $compteur) {
								$varaffiche .= $val."\n";
							}
						}
						$compteur++;
					}
                }
                break;
            default:
                $varaffiche .= $dynavalue."\n";
                break;
        }
    }

    return $varaffiche;
}

function getnewuserfield()
{
    
    list($dbconn) = pnDBGetConn();
    $pntable = pnDBGetTables();
    $propcolumn = &$pntable['user_property_column'];
    $propresult = $dbconn->Execute("SELECT		$propcolumn[prop_label],
												$propcolumn[prop_validation]
                                    FROM        $pntable[user_property]
									AND			$propcolumn[prop_weight]!='0'
                                    ORDER BY    $propcolumn[prop_weight]");
    if (!$propresult->EOF) {
        $newuserfield = array();
        while(list($prop_label, $prop_validation) = $propresult->fields) {
            $propresult->MoveNext();
            $prop_validation = unserialize($prop_validation);
            if ($prop_validation['REQUIRED'] == 1) {
            	$prop_label_text = "";
	            $eval_cmd = "\$prop_label_text = $prop_label;";
                @eval($eval_cmd);    
                if (empty($prop_label_text)) {
	                $prop_label_text = $prop_label;
                }
	            $newuserfield[$prop_label]['FIELD'] = $prop_label;
                $newuserfield[$prop_label]['LIBEL'] = $prop_label_text;
                $newuserfield[$prop_label]['VALIDATION'] = $prop_validation;
            }
        }
    }

    return $newuserfield;

}

function pncGetFieldValidationByLabel($prop_label)
{

    list($dbconn) = pnDBGetConn();
    $pntable = pnDBGetTables();
    
    $validcolumn = &$pntable['user_property_column'];
    $sql = "SELECT	$validcolumn[prop_validation]
            FROM	$pntable[user_property]
            WHERE	$validcolumn[prop_label]='".pnVarPrepForStore($prop_label)."'";
    $validresult = $dbconn->Execute($sql);
    list($validdef) = $validresult->fields;
    
    return unserialize($validdef);
}

function pncNewUserSetVar($name, $value, $uid)
{
    global $psnconfirm;
    list($dbconn) = pnDBGetConn();
    $pntable = pnDBGetTables();

    if (empty($name)) {
        $fncreturn = false;
    }

    if (    $name != "_UREALNAME"
        &&    $name != "_UFAKEMAIL"
        &&    $name != "_YOURHOMEPAGE"
        &&    $name != "_TIMEZONEOFFSET"
        &&    $name != "_YOURAVATAR"
        &&    $name != "_YICQ"
        &&    $name != "_YAIM"
        &&    $name != "_YYIM"
        &&    $name != "_YMSNM"
        &&    $name != "_YLOCATION"
        &&    $name != "_YOCCUPATION"
        &&    $name != "_YINTERESTS"
        &&    $name != "_SIGNATURE"
        &&    $name != "_EXTRAINFO") {
    
        $isdynamic = 1;

    } else {

        $isdynamic = 0;
        $fieldname['_UREALNAME'] = "name";
        $fieldname['_UFAKEMAIL'] = "uname";
        $fieldname['_YOURHOMEPAGE'] = "url";
        $fieldname['_TIMEZONEOFFSET'] = "timezone_offset";
        $fieldname['_YOURAVATAR'] = "user_avatar";
        $fieldname['_YICQ'] = "user_icq";
        $fieldname['_YAIM'] = "user_aim";
        $fieldname['_YYIM'] = "user_yim";
        $fieldname['_YMSNM'] = "user_msnm";
        $fieldname['_YLOCATION'] = "user_from";
        $fieldname['_YOCCUPATION'] = "user_occ";
        $fieldname['_YINTERESTS'] = "user_intrest";
        $fieldname['_SIGNATURE'] = "user_sig";
        $fieldname['_EXTRAINFO'] = "bio";

    }

    if ($isdynamic == 1) {
        
        $propertiestable = $pntable['user_property'];
        $datatable = $pntable['user_data'];
        $propcolumns = &$pntable['user_property_column'];
        $datacolumns = &$pntable['user_data_column'];

    // Confirm that this is a known value
        $query = "SELECT    $propcolumns[prop_id],
                            $propcolumns[prop_dtype]
                  FROM        $propertiestable
                  WHERE     $propcolumns[prop_label] = '" . pnVarPrepForStore($name) ."'";
        $result = $dbconn->Execute($query);

        if ($result->EOF) {
            $psnconfirm ='Confirm that this is a known value';
            $fncreturn = false;
        }

        list ($id, $type) = $result->fields;
        // check for existence of the variable in user data
        $query = "SELECT    $datacolumns[uda_id]
                  FROM        $datatable
                  WHERE        $datacolumns[uda_propid] = '" . pnVarPrepForStore($id) ."'
                  AND        $datacolumns[uda_uid] = '" . pnVarPrepForStore($uid) ."'";
        $result = $dbconn->Execute($query);

        // jgm - this won't work in databases that care about typing
        // but this should get fixed when we move to the dynamic user
        // variables setup
        // TODO: do some checking with $type to maybe do conditional sql

        if ($result->EOF) {
        // record does not exist
            $query = "INSERT INTO $datatable
                    ($datacolumns[uda_propid],
                    $datacolumns[uda_uid],
                    $datacolumns[uda_value])
                    VALUES ('".pnVarPrepForStore($id)."',
                            '".pnVarPrepForStore($uid)."',
                            '".pnVarPrepForStore($value)."')";
            $dbconn->Execute($query);

            if($dbconn->ErrorNo() != 0) {
                $psnconfirm ='record does not exist, inscription capout';
                $fncreturn = false;
            }

        } else {
            // existing record
            if (is_array($value)) {
                while(list($m, $p) = each($value)) {
                    $v[] = $p;
                }
                if (is_array($v)) $v = serialize($v);
                $value = $v;
            }
            
            $query = "UPDATE $datatable
                      SET $datacolumns[uda_value] = '" . pnVarPrepForStore($value) . "'
                      WHERE $datacolumns[uda_propid] = '" . pnVarPrepForStore($id) ."'
                      AND $datacolumns[uda_uid] = '" . pnVarPrepForStore($uid) ."'";
            $dbconn->Execute($query);

            if($dbconn->ErrorNo() != 0) {
                $psnconfirm ='existait d�j�';
                $fncreturn = false;
                echo "Shit !";
                exit;
            }
        }
    
    } else {
        // Non dynamic
        $usertable = $pntable['users'];
        $usercolumn = $pntable['users_column'];
        
        $query = "	UPDATE	$usertable
                    SET		".$usercolumn[$fieldname[$name]]." = '" . pnVarPrepForStore($value) . "'
                    WHERE	$usercolumn[uid] = '" . pnVarPrepForStore($uid) ."'";
        $dbconn->Execute($query);
        
        if ($dbconn->ErrorNo() != 0) {
            $fncreturn = false;
        }
    }
    
    return $fncreturn;
}


// Courtesy of George Kilroy from http://swissnukes.com


/**
 * clean user input
 * <br>
 * Gets a global variable, cleaning it up to try to ensure that
 * hack attacks don't work
 * @param var name of variable to get
 * @param ...
 * @returns string/array
 * @return prepared variable if only one variable passed
 * in, otherwise an array of prepared variables
 */

function pncVarCleanFromInput()
{
    $resarray = array();
    foreach (func_get_args() as $var) {
        // Get var
        global $$var;
        if (empty($var)) {
            return;
        }

        $ourvar = pncVarCleanVarFromInput($$var);
        array_push($resarray, $ourvar);
    }

    // Return vars
    if (func_num_args() == 1) {
        return $resarray[0];
    } else {
        return $resarray;
    }
}

/**
 * clean user input
 * <br>
 * Gets a global variable, cleaning it up to try to ensure that
 * hack attacks don't work
 * @param var name of variable to get
 * @param ...
 * @returns string/array
 * @return prepared variable if only one variable passed
 * in, otherwise an array of prepared variables
 */

/*Thanks to Kilroy that got me out of impass with those array buggers.*/
function pncVarCleanVarFromInput($ourvar)
{
 if(is_array($ourvar))
 {
     $res = array();
     foreach($ourvar as $index=>$newElem)
         $res[$index] = pncVarCleanVarFromInput($newElem);
     return $res;
 }

    $search = array('|</?\s*SCRIPT.*?>|si',
                    '|</?\s*FRAME.*?>|si',
                    '|</?\s*OBJECT.*?>|si',
                    '|</?\s*META.*?>|si',
                    '|</?\s*APPLET.*?>|si',
                    '|</?\s*LINK.*?>|si',
                    '|</?\s*IFRAME.*?>|si',
                    '|STYLE\s*=\s*"[^"]*"|si');
    $replace = array('');

    // Clean var
    if (get_magic_quotes_gpc()) {
        pnStripslashes($ourvar);
    }
    if (!pnSecAuthAction(0, '::', '::', ACCESS_ADMIN)) {
        $ourvar = preg_replace($search, $replace, $ourvar);
    }
     // Add to result array
    return $ourvar;
}
?>