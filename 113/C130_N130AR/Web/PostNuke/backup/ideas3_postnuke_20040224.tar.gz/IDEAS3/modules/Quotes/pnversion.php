<?php
// $Id: pnversion.php,v 1.1.1.1 2002/09/15 22:26:15 root Exp $ $Name:  $
$modversion['name'] = 'Random Quote';
$modversion['version'] = '1.3';
$modversion['description'] = 'Random quotes administration.';
$modversion['credits'] = '';
$modversion['help'] = '';
$modversion['changelog'] = '';
$modversion['license'] = '';
$modversion['official'] = 1;
$modversion['author'] = 'Erik Sloof';
$modversion['contact'] = 'http://www.sloof.com';
$modversion['admin'] = 1;
$modversion['securityschema'] = array('Quotes::' => 'Author name::Quote ID');
?>