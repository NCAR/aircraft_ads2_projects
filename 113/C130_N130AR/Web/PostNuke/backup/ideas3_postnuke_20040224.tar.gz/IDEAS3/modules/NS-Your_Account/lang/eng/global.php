<?php
// Generated: $d$ by $id$
// ----------------------------------------------------------------------
// POST-NUKE Content Management System
// Copyright (C) 2001 by the Post-Nuke Development Team.
// http://www.postnuke.com/
// ----------------------------------------------------------------------
// Based on:
// PHP-NUKE Web Portal System - http://phpnuke.org/
// Thatware - http://thatware.org/
// ----------------------------------------------------------------------
// LICENSE
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License (GPL)
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// To read the license please visit http://www.gnu.org/copyleft/gpl.html
// ----------------------------------------------------------------------
// Original Author of file: Everyone
// Purpose of file: Translation files
// Translation team: Read credits in /docs/CREDITS.txt
// ----------------------------------------------------------------------
define('_255CHARMAX','(255 characters max. Type your signature with HTML coding)');
define('_ACTIVATEPERSONAL','Activate personal menu');
define('_CANKNOWABOUT','(255 characters max. Type what you\'d like others to know about you)');
define('_CHANGEHOME','Change homepage');
define('_CHANGEYOURINFO','Change your info');
define('_CHARLONG','characters long');
define('_CHECKTHISOPTION','(Check this option and the following text will appear on the homepage)');
define('_EMAILNOTPUBLIC','(This e-mail will not be public but is required.  It will be used to send your password if you lose it)');
define('_EMAILPUBLIC','(This e-mail will be public. Type what you\'d like. Spam proof)');
define('_HOMECONFIG','Homepage configuration');
define('_MAX127','(max. 127):');
define('_NEWSINHOME','Number of stories on the homepage');
define('_PASSDIFFERENT','The passwords are different. They need to be identical.');
define('_PERSONALINFO','Personal information');
define('_SELECTTHEME','Select a theme');
define('_SELECTTHETHEME','Select theme');
define('_THEMESELECTION','Theme selection');
define('_THEMETEXT1','This option will change the look for the whole site.');
define('_THEMETEXT2','The changes will be valid only to you.');
define('_THEMETEXT3','Each user can view the site with a different theme.');
define('_TYPENEWPASSWORD','(type a new password twice to change it)');
define('_YOUCANUSEHTML','(You can use HTML code for links as an example)');
define('_YOURPASSMUSTBE','Sorry, your password must be at least');

//Added by Chestnut !
define('_UAISADMIN1','Your are an Administrator.');
define('_UAISADMIN2','Ask another administrator to change the group you are in.');
define('_UAASKAGAIN1','You already made a request ! There is no need to ask again.');
define('_UAASKAGAIN2','We will treat your demand as soon as possible.');

define('_UASECURE1','For security reasons, the account deletion is not automatic.');
define('_UASECURE2','Please verify these information and type your password to confirm.');
define('_UASECURE3','You will soon receive an email when your request will be fulfilled.');
define('_UAAPPROVED','Approved');

define('_UAYES','OK !');
define('_UANO','NO !');
define('_UAEMPTY','Empty !');
define('_UAPASSDIFF','Password is different !');
define('_UANGOODPASS','Password don\'t match !');
define('_UAREQSAVING','Saving your request !');
define('_UAYOURID','Your ID : ');
define('_UAIDNOTREG','This ID is not registered !');
define('_UAYOURUNAME','Your UserName : ');
define('_UAUNAMENOTREG','This UserName is not yours or not registered !');
define('_UAYOUREMAIL','Your Email : ');
define('_UAYOURPASS','Your Password : ');
define('_UAMAILNOTREG','This Email is not your or not registered !');
define('_UAPASSVERIF','Password Verification : ');
define('_UAMUSTPASS','You must type your password !');
define('_UAREQSAVEOK','Request saved :');
define('_UAREQWRITE','Saving in Request List !');

define('_UAREQEND','<center><font class=\"pn-title\">The End !</font><br><br>Your request has been sended. We will look into it as soon as possible.<br><br>');
define('_UAREQEND1','You will receive an email to confirm your account deletion and it will be the last one.<br><br>');
define('_UAREQEND1B','In hope to see you with us again in the future.<br><br>');
define('_UAREQEND2','<font class=\"pn-title\">Good Bye !</font><br><br><a href=user.php?module=NS-User&op=logout>Exit</a></center>');

define('_UAUSRMAILOBJ','Account Delete Request on');
define('_UAUSRMAILSBJ','ask to delete his/her account on');
define('_UAINFOWRONG','Something is wrong with the information given. Please go back and try again.');
//FIX Hardcode text
define('_UAREQSUCCESSFUL','Request saved succesfully : ');
// pncUserHack v1.5
define('_UAREQFEMPTY','Fields required empty !!!');
//pncUserHack v1.6
define('_UAREQREASON','Reason (Optional) :');
define('_UAFIELDREQUIRED','*');
define('_EMPTYREQUIRED','Field required empty !!!');
define('_EMAILNEEDED','Valid Email needed !!!');
define('_LOGGEDINAS','Logged in as : ');
?>