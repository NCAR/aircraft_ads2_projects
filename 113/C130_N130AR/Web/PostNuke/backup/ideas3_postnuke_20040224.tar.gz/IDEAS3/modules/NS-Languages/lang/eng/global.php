<?php
// Generated: $d$ by $id$
// ----------------------------------------------------------------------
// POST-NUKE Content Management System
// Copyright (C) 2001 by the Post-Nuke Development Team.
// http://www.postnuke.com/
// ----------------------------------------------------------------------
// Based on:
// PHP-NUKE Web Portal System - http://phpnuke.org/
// Thatware - http://thatware.org/
// ----------------------------------------------------------------------
// LICENSE
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License (GPL)
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// To read the license please visit http://www.gnu.org/copyleft/gpl.html
// ----------------------------------------------------------------------
// Original Author of file: Everyone
// Purpose of file: Translation files
// Translation team: Read credits in /docs/CREDITS.txt
// ----------------------------------------------------------------------
define('_ACTMULTILINGUAL','Activate ML');
define('_ACTUSEFLAGS','Activate User Flags');
define('_ADDMISSING','All missing translations could be seen at file missing.php on your language directory,');
define('_ADMINTRANSLATION','Files list');
define('_CLICKLINK','please click at link');
define('_CONSTANTSLOADING','All constants have been loaded,');
define('_DIEOPEN','Unable to open');
define('_GENERATELANG','create');
define('_GENERATELANG1','create file');
define('_GENERATELANG2','All files needed for your language system');
define('_GENERATELANG3','have been created on your directory <b>language_');
define('_GENERATELANG4','You just need to copy all files from this directory on your <b>root</b> directory.');
define('_LANGCONF','Languages Configuration');
define('_LANGUAGE_ALL_CONSTANT_HARDCODE','All constants were hardcoded');
define('_LANG_ADD_MISSING','Add missing');
define('_LANG_CURENT','Current language');
define('_LANG_DEFAULT_TRANSLATION','Default');
define('_LANG_FILE','Language file');
define('_LANG_FILE_TARGET','Target file');
define('_LANG_GENERATE','Generate');
define('_LANG_HARDCODE','Hardcode');
define('_LANG_LANGUAGES_NUMBER','Number of Translation Defines');
define('_LANG_LOAD_CONSTANT','Constant loading');
define('_LANG_LOAD_TRANSLATION','Load translation');
define('_LANG_MISSING_NUMBER','Missing number');
define('_LANG_NUM_CONSTANT','Constant number');
define('_LANG_NUM_TRANSLATION','Translation number');
define('_LANG_OBJECTIVE','Standard');
define('_LANG_RELOAD_CONSTANT','Reload Constant');
define('_LANG_SELECT','Choose language');
define('_NEXT_OP_TODO','Next step');
define('_TARGET','To produce');
define('_TRANSLATIONSLOADING','All translations have been loaded for');
?>