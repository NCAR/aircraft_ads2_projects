<?php
// File: $Id: moderate.php,v 1.6 2002/05/17
// ----------------------------------------------------------------------
// POST-NUKE Content Management System
// Copyright (C) 2001 by the PostNuke Development Team.
// http://www.postnuke.com/
// ----------------------------------------------------------------------
// Based on:
// PHP-NUKE Web Portal System - http://phpnuke.org/
// Thatware - http://thatware.org/
// ----------------------------------------------------------------------
// LICENSE
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License (GPL)
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// To read the license please visit http://www.gnu.org/copyleft/gpl.html
// ----------------------------------------------------------------------
// Original Author of file: Chestnut !
// Purpose of file:
// ----------------------------------------------------------------------

########################
function user_admin_addRequest($show)
{
    if (!pnSecAuthAction(0, "Users::", "::", ACCESS_ADD)) {
    	include 'header.php';
        echo _UAUSRNODEL;
        include 'footer.php';
        exit;
    }
        
    global $bgcolor1, $bgcolor2, $bgcolor3;
    include 'header.php';
    list($dbconn) = pnDBGetConn();
    $pntable = pnDBGetTables();
    //include('modules/NS-User/uapntables.php');
    $authid = pnSecGenAuthKey();

    GraphicAdmin();
    OpenTable();
    echo '<center><font class="pn-title"><b>'._UAADMADDSEND.'</b></font></center>';
    CloseTable();
	
    if ($show != '') {
    	OpenTable();
		$column = &$pntable['users_modrequest_column'];
        $result = $dbconn->Execute("SELECT	$column[uactr],                 $column[uid],			$column[name],
											$column[uname],					$column[pass],			$column[email],
											$column[femail],        		$column[url],			$column[user_icq],
											$column[user_aim],              $column[user_yim],     	$column[user_msnm],
                                            $column[user_from],         	$column[user_occ],      $column[user_intrest],
											$column[user_viewemail],        $column[user_avatar],  	$column[user_sig],
											$column[bio],                   $column[uda_vars],      $column[timezone_offset]
                                     FROM 	$pntable[users_modrequest]
                                     WHERE	$column[uname]='".pnVarPrepForStore($show)."'");

        list($ctr,			$uid,           $name,          $uname,					$pass,
			 $email,        $femail,       	$url,           $user_icq,              $user_aim,              $user_yim,
			 $user_msnm,	$user_from,    	$user_occ,		$user_intrest,	        $user_viewemail,        $user_avatar,
             $user_sig,	 	$bio,	 		$dynamicdata,	$timezone) = $result->fields;
                
		$dynamicdata = unserialize($dynamicdata);
    	echo "<center><font class=\"pn-normal\"><b>"._UAADDDETAILS."</b></font></center><br>";

    	echo "<form name=\"modadvRegister\" action=\"admin.php\" method=\"post\">";
	    echo "<table cellspacing=1 cellpadding=2 bgcolor=\"#000000\" width=\"100%\" align=\"center\">\n"
			."<tr bgcolor=\"".$GLOBALS['bgcolor2']."\">"
	        ."<td height=30 align=\"center\"><b>"._UAFIELDS."</b></td>"
	        ."<td align=\"center\" width=50%><b>"._UAUINPUT."</b></td>"
	    	."<td align=\"center\" width=100><b>"._UAADMININPUT."</b></td>";

		$uname = stripslashes($uname);

	    echo "<tr bgcolor=\"".$GLOBALS['bgcolor1']."\">";
		echo "<td align=\"left\"><font size=1><b>"._USERNAME."</b></font></td>"
	        ."<td align=\"center\"><b>".pnVarPrepForDisplay($uname)."</b></td>"
	        ."<td align=\"left\"><input type=\"text\" name=\"uname\"  value=\"".pnVarPrepForDisplay($uname)."\" size=\"26\" maxlength=\"30\"></td>";
	    echo "</tr>";
		echo "<tr bgcolor=\"".$GLOBALS['bgcolor1']."\">";
		echo "<td align=\"left\"><font size=1><b>"._UREALEMAIL."</b></font></td>"
	        ."<td align=\"center\"><b>".pnVarPrepForDisplay($email)."</b></td>"
	        ."<td align=\"left\"><input type=\"text\" name=\"email\"  value=\"".pnVarPrepForDisplay($email)."\" size=\"26\" maxlength=\"30\"></td>";
	    echo "</tr>";

		if (pnConfigGetVar('pncuaadvreg') == "1") {
			$requiredfields = getuserfieldlist();
		} else {
			$requiredfields = getnewuserfield();
		}
		// Aliasing
	    $modfield['_UREALEMAIL'] = $email;
	    $modfield['_UFAKEMAIL'] = $femail;
	    $modfield['_UREALNAME'] = $name;
	    $modfield['_TIMEZONEOFFSET'] = $timezone;
	    $modfield['_YOURAVATAR'] = $user_avatar;
	    $modfield['_YICQ'] = $user_icq;
	    $modfield['_YAIM'] = $user_aim;
	    $modfield['_YYIM'] = $user_yim;
	    $modfield['_YMSNM'] = $user_msnm;
	    $modfield['_YLOCATION'] = $user_from;
	    $modfield['_YOCCUPATION'] = $user_occ;
	    $modfield['_YINTERESTS'] = $user_intrest;
	    $modfield['_SIGNATURE'] = $user_sig;
	    $modfield['_EXTRAINFO'] = $bio;
	    $modfield['_YOURHOMEPAGE'] = $url;
		$modfield['_PASSWORD'] = $pass;
		$modfield['_USERVIEWEMAL'] = $user_viewemail;
		$modfield['_UDAVARS'] = $dynamicdata;

		echo "<tr bgcolor=\"".$GLOBALS['bgcolor1']."\"><td colspan=3 bgcolor=\"".$GLOBALS['bgcolor2']."\"></td></tr>\n";
		while(list($key, $val) = each($requiredfields)) {
			
			//Simplifying
			$namefield = $val['FIELD'];
			$isrequired = $val['VALIDATION']['REQUIRED'];
			$fieldvalid = $val['VALIDATION'];
			$fieldlibel = $val['LIBEL'];
			
			if (($namefield != '_PASSWORD' && $modfield[$namefield]."" != "") || ($namefield != '_PASSWORD' && $dynamicdata[$namefield]."" != "")) {
			
				echo "<tr bgcolor=\"".$GLOBALS['bgcolor1']."\"><td height=\"25\"><font class=\"pn-normal\">\n".pnVarPrepForDisplay($fieldlibel);
			
				echo "</font></td>\n";
				//echo "<td>\n";
				switch ($namefield) {
					case "_TIMEZONEOFFSET":
						global $tzinfo;
						$pnctzinfo = $tzinfo;
						echo "<td align=\"center\">\n";
	                    foreach ($pnctzinfo as $tzindex => $tzdata) {
	                        if ($timezone == $tzindex) echo $tzdata."\n";
	                    }
						echo "</td>\n";
						echo "<td>\n";                	
	                    echo "<table>\n"
							."<tr>\n"
							."<td>\n"
							."<select name=\"dynafield[".$namefield."]\" class=\"pn-normal\">\n";
	                	foreach ($tzinfo as $tzindex => $tzdata) {
							if ($timezone == $tzindex) {
								$selected = ' selected';
							} else {
								$selected = '';
							}
		                	echo "<option value=\"$tzindex\"$selected>".$tzdata."</option>\n";
	                	}
						echo "</select>\n"
							."</td>\n"
							."</tr>\n"
							."</table>\n";
						break;
					case "_YOURAVATAR":
						echo "<td align=\"center\">\n"
							."<img src=\"images/avatar/".pnVarPrepForDisplay($user_avatar)."\" border=\"0\">\n"
							."</td>\n"
							."<td>\n"
							."<table>\n"
							."<tr>\n"
							."<td>\n"
							."<select name=\"dynafield[".$namefield."]\" class=\"pn-normal\">\n";
							
	                    $handle = opendir('./images/avatar');
	                    while ($file = readdir($handle)) {
		                    $filelist[] = $file;
	                    }
	                    asort($filelist);
	                    while (list ($key, $file) = each ($filelist)) {
		                    ereg(".gif|.jpg",$file);
	                        if ($file != "." && $file != "..") {
								if ($file == $user_avatar) {
									$selected = ' selected';
								} else {
									$selected = '';
								}
		                        echo "<option value=\"$file\"$selected>$file</option>\n";
	                        }
	                    }
	                    echo "			    </select>&nbsp;&nbsp;";
	                    echo "<script language=\"JavaScript\">
						<!--
						function OpenAvatarWindow(theURL,winName,features) { //v2.0
							window.open(theURL,winName,features);
						}
						//-->
						</script>[ <a onClick=\"OpenAvatarWindow('avatar.php','Avatars','scrollbars=yes,width=450,height=400')\">avatar list</a> ]\n"
							."            </td>\n"
							."        </tr>\n"
							."    </table>"
							."</td>\n";
						break;
					default:
						echo "<td align=\"center\">\n";
						if (!isset($modfield[$namefield])) {
							$checkdyna = $dynamicdata;
							while (list($dynakey, $dynaval) = each($checkdyna)) {
								if ($dynakey == $namefield) {
									if ($fieldvalid['LISTOPTION'] == "1") $dynaval = unserialize($dynaval);
									$modvalue = $dynaval;
									echo getfieldConfirmUser($fieldvalid, $modvalue);
								}
							}
						} else {
							if (is_array($modfield[$namefield])) {
								$modvalue = unserialize($modfield[$namefield]);
							} else {
								$modvalue = $modfield[$namefield];
							}
	
							echo getfieldConfirmUser($fieldvalid, $modvalue);
						}
						echo "</td>\n"
							."<td>\n";
					
						$fieldvalid['NAME'] = $namefield;
						echo getuserfieldHTMLDef($fieldvalid, $modvalue);
						echo "</td>\n";
						break;
				}
			}
			//echo " <font class=\"pn-sub\">"._REQUIRED."</font>\n";
			echo "</tr>\n";
		}

########################################################################
		echo "<input type=\"hidden\" name=\"pass\" value=\"".pnVarPrepForDisplay($pass)."\">\n"
			."<input type=\"hidden\" name=\"user_viewemail\" value=\"".pnVarPrepForDisplay($user_viewemail)."\">\n"
			."<input type=\"hidden\" name=\"authid\" value=\"" . pnSecGenAuthKey() . "\">\n"
        	."<input type=\"hidden\" name=\"module\" value=\"NS-User\">\n"
            ."<input type=\"hidden\" name=\"op\" value=\"ModUAddUser\">\n"
            ."<br><center>\n";
		echo "<tr><td colspan=3 bgcolor=\" bgcolor=\"".$GLOBALS['bgcolor2']."\" height=1></td></tr>\n";
		
		echo "<tr bgcolor=\"#FFFFFF\"><td valign=center rowspan=2><b>"._UAFUNCTIONS."</b></td><td bgcolor=\"#F0F0F0\" colspan=2 align=center><br>\n";
   	
		$column = &$pntable['groups_column'];
	    $result = $dbconn->Execute("SELECT 		$column[name]
	    	                        FROM 		$pntable[groups]
	                                ORDER BY 	$column[name]");
	    $oldgroup = pnConfigGetVar('defaultgroup');
	    echo _UAGROUP."<br><select name=\"gname\">\n";
	
	    while(list($gname) = $result->fields) {
	    	$result->MoveNext();
	        if ($gname==$oldgroup) {
	    	    echo "<option value=\"".pnVarPrepForDisplay($gname)."\" selected>".pnVarPrepForDisplay($gname)."</option>\n";
	        } else {
	            echo "<option value=\"".pnVarPrepForDisplay($gname)."\">".pnVarPrepForDisplay($gname)."</option>\n";
	        }
	    }

		echo "</tr><tr><td colspan=2 bgcolor=\"#F0F0F0\" align=center><br><input type=\"submit\" value=\""._REGNEWUSER."\">\n"
            ."</form><br>\n"
			."<a href=admin.php?module=".$GLOBALS["module"]."&amp;op=delModConfRequest&amp;chng_uid=".pnVarPrepForDisplay($uname).">"._UAMODREJECT."</a></td></tr></table></center>\n";

        echo "</center>";
    	CloseTable();
    }
               
   	OpenTable();
    echo "<center><font class=\"pn-normal\"><b>"._UAACCLST."</b></font></center><br>\n\n"
		."<table cellspacing=1 bgcolor=\"#000000\" width=100% align=\"center\">"
		."<tr bgcolor=\"".$GLOBALS['bgcolor2']."\">\n"
        ."<td align=\"center\"><font size=2><b>"._UAUNAME."</b></font></td>\n"
        ."<td align=\"center\"><font size=2><b>"._UANAME."</b></font></td>\n"
        ."<td align=\"center\"><font size=2><b>"._UAEMAIL."</b></font></td>\n"
        ."<td align=\"center\"><font size=2><b>"._UAFUNCTIONS."</b></font></td>\n"
		."</tr>\n";

    $column = &$pntable['users_modrequest_column'];
    $result = $dbconn->Execute("SELECT 		$column[uactr], $column[uid], $column[name], $column[uname], $column[email]
                              	FROM 		$pntable[users_modrequest]
                              	WHERE 		$column[uadd]='1'
	                            ORDER BY 	$column[uname]");
    while(list($uactr, $uid, $name, $uname, $email) = $result->fields) {
		$uname = stripslashes($uname);
        $result->MoveNext();
        echo "<tr bgcolor=\"".$GLOBALS['bgcolor1']."\">\n"
			."<td align=\"center\" width=\"20%\">".pnVarPrepForDisplay($uname)."</td>\n"
            ."<td align=\"center\" width=\"25%\" height=30>".pnVarPrepForDisplay($name)."&nbsp;</td>\n"
            ."<td align=\"center\" width=\"35%\"><a href=\"mailto:".pnVarPrepForDisplay($email)."\">".pnVarPrepForDisplay($email)."</a></td>\n"
            ."<td align=\"center\" width=\"20%\">[ <a href=\"admin.php?module=".$GLOBALS["module"]."&amp;op=ListUAddRequest&amp;show=".pnVarPrepForDisplay($uname)."\">"._UAADDDETAILS."</a> ]</td>\n"
			."</tr>\n"
            ."</td></tr>\n";
    }

    echo '</table>';
    CloseTable();

    OpenTable();
    echo "<center>"._GOBACK."</center>\n";
    CloseTable();
		
    include 'footer.php';
}

function user_admin_modadduser()
{
    if (!pnSecConfirmAuthKey()) {
        include 'header.php';
        echo _BADAUTHKEY;
        include 'footer.php';
        exit;
    }
	
    list($dbconn) = pnDBGetConn();
    $pntable = pnDBGetTables();

	list($uname, $email, $pass, $user_viewemail, $gname) = 
		pnVarCleanFromInput('uname', 'email', 'pass', 'user_viewemail', 'gname');
		
	$dynafield = pncVarCleanFromInput('dynafield');
	
    $system = pnConfigGetVar('system');
    $adminmail = pnConfigGetVar('adminmail');
    $sitename = pnConfigGetVar('sitename');
    $Default_Theme = pnConfigGetVar('Default_Theme');
    $commentlimit = pnConfigGetVar('commentlimit');
    $storynum = pnConfigGetVar('storyhome');
    /*Added by Chestnut !*/
    $senduserpass = pnConfigGetVar('senduserpass');

    if (isset($dynafield['_TIMEZONEOFFSET'])) {
		$timezoneoffset = $dynafield['_TIMEZONEOFFSET'][0];
	} else {
		$timezoneoffset = pnConfigGetVar('timezone_offset');
	}
	
    if (isset($dynafield['_YOURAVATAR'])) {
		$avatar = $dynafield['_YOURAVATAR'];
	} else {
		$avatar = "blank.gif";
	}

	// Aliasing
    $storefield['_UREALEMAIL']['NAME'] = 'email';
    $storefield['_UFAKEMAIL']['NAME'] = 'femail';
    $storefield['_UREALNAME']['NAME'] = 'name';
    $storefield['_TIMEZONEOFFSET']['NAME'] = 'timezone_offset';
    //$userinfo['email']['NAME'] = 'uname';
    $storefield['_YOURAVATAR']['NAME'] = 'user_avatar';
    $storefield['_YICQ']['NAME'] = 'user_icq';
    $storefield['_YAIM']['NAME'] = 'user_aim';
    $storefield['_YYIM']['NAME'] = 'user_yim';
    $storefield['_YMSNM']['NAME'] = 'user_msnm';
    $storefield['_YLOCATION']['NAME'] = 'user_from';
    $storefield['_YOCCUPATION']['NAME'] = 'user_occ';
    $storefield['_YINTERESTS']['NAME'] = 'user_intrest';
    $storefield['_SIGNATURE']['NAME'] = 'user_sig';
    $storefield['_EXTRAINFO']['NAME'] = 'bio';
    $storefield['_YOURHOMEPAGE']['NAME'] = 'url';
	$storefield['_PASSWORD']['NAME'] = 'pass';
	$storefield['_USERVIEWEMAL']['NAME'] = 'user_viewemail';
	$storefield['_USERTHEME']['NAME'] = 'user_theme';
	$storefield['_THEME']['NAME'] = 'theme';
	
	$storecontent = $dynafield;
	while(list($fieldname, $fieldvalue) = each($storecontent)) {
		if (!isset($storefield[$fieldname]['NAME'])) {
			$newdynafield[$fieldname]['VALUE'] = $fieldvalue;
			$newdynafield[$fieldname]['NAME'] = $fieldname;
		} else {
			$storefield[$fieldname]['VALUE'] = $fieldvalue;
		}
	}

	$storefield['_UREALEMAIL']['VALUE'] = $email;
	if ($user_viewemail) {
		$storefield['_UFAKEMAIL']['VALUE'] = $email;
		$storefield['_USERVIEWEMAIL']['VALUE'] = 1;
	} else {
		$storefield['_USERVIEWEMAIL']['VALUE'] = 0;
	}
	$storefield['_USERTHEME']['VALUE'] = 0;
	$storefield['_THEME']['VALUE'] = $Default_Theme;
	
	$agreetoterms = 1;
    $stop = moduserCheck($uname, $email, $dynafield);
    $user_regdate = time();
	
	if ($stop."" != "") $stop .= "<br><br>"._GOBACK."\n";	

    include 'header.php';

    if (empty($stop)) {

		$makepass = $pass;
		//$cryptpass = md5($pass);
		$cryptpass = $makepass;
       
        $uid = $dbconn->GenId($pntable['users']);

		$column = &$pntable['users_column'];
		$result = $dbconn->Execute("INSERT INTO	$pntable[users]
    		        			  ($column[uname],
		    					 ".$column[$storefield['_UREALEMAIL']['NAME']].",
								 ".$column[$storefield['_UFAKEMAIL']['NAME']].",
								 ".$column[$storefield['_UREALNAME']['NAME']].",
								 ".$column[$storefield['_USERVIEWEMAL']['NAME']].",
								 $column[user_avatar],
								 ".$column[$storefield['_YICQ']['NAME']].",
								 ".$column[$storefield['_YAIM']['NAME']].",
								 ".$column[$storefield['_YYIM']['NAME']].",
								 ".$column[$storefield['_YMSNM']['NAME']].",
								 $column[timezone_offset],
								 ".$column[$storefield['_YLOCATION']['NAME']].",
								 ".$column[$storefield['_YINTERESTS']['NAME']].",
								 ".$column[$storefield['_SIGNATURE']['NAME']].",
								 ".$column[$storefield['_EXTRAINFO']['NAME']].",
								 ".$column[$storefield['_YOURHOMEPAGE']['NAME']].",
								 $column[user_regdate],
								 $column[storynum],
								 $column[commentmax],
								 $column[user_theme],
								 $column[theme],
								 $column[pass])
						VALUES (
								 '".pnVarPrepForStore($uname)."',
								 '".pnVarPrepForStore($storefield['_UREALEMAIL']['VALUE'])."',
								 '".pnVarPrepForStore($storefield['_UFAKEMAIL']['VALUE'])."',
								 '".pnVarPrepForStore($storefield['_UREALNAME']['VALUE'])."',
								 '".pnVarPrepForStore($storefield['_USERVIEWEMAL']['VALUE'])."',
								 '".pnVarPrepForStore($avatar)."',
								 '".pnVarPrepForStore($storefield['_YICQ']['VALUE'])."',
								 '".pnVarPrepForStore($storefield['_YAIM']['VALUE'])."',
								 '".pnVarPrepForStore($storefield['_YYIM']['VALUE'])."',
								 '".pnVarPrepForStore($storefield['_YMSNM']['VALUE'])."',
								 '".pnVarPrepForStore($timezoneoffset)."',
								 '".pnVarPrepForStore($storefield['_YLOCATION']['VALUE'])."',
								 '".pnVarPrepForStore($storefield['_YINTERESTS']['VALUE'])."',
								 '".pnVarPrepForStore($storefield['_SIGNATURE']['VALUE'])."',
								 '".pnVarPrepForStore($storefield['_EXTRAINFO']['VALUE'])."',
								 '".pnVarPrepForStore($storefield['_YOURHOMEPAGE']['VALUE'])."',
								 '".pnVarPrepForStore($user_regdate)."',
								 '".pnVarPrepForStore($storynum)."',
								 '".pnVarPrepForStore($commentlimit)."',
								 '".pnVarPrepForStore($storefield['_USERTHEME']['VALUE'])."',
								 '".pnVarPrepForStore($storefield['_THEME']['VALUE'])."',
								 '".pnVarPrepForStore($cryptpass)."')");
	
        if($dbconn->ErrorNo()<>0) {
            echo $dbconn->ErrorNo(). ": ".$dbconn->ErrorMsg(). "<br>";
        	error_log ($dbconn->ErrorNo(). ": ".$dbconn->ErrorMsg(). "<br>");
        } else {
        	// get the generated id
        	$uid = $dbconn->PO_Insert_ID($pntable['users'],$column['uid']);
				
			//Add dynamic values
			
			$dynarequired = $newdynafield;
			if (is_array($dynarequired) && !empty($dynarequired)) {
				while(list($key, $val) = each($dynarequired)) {
					$inputfield = $key;
					$inputvalue = $val['VALUE'];
					if (is_array($inputvalue)) {
						$inputvalue = serialize($inputvalue);
					}
					pncNewUserSetVar($inputfield, $inputvalue, $uid);
				}
			}
				
        	// Add user to group
        	$column = &$pntable['groups_column'];
        	$result = $dbconn->Execute("SELECT $column[gid]
        								FROM $pntable[groups]
        	                            WHERE $column[name]='". pnVarPrepForStore($gname) . "'");
        	if($dbconn->ErrorNo()<>0) {
       	        echo $dbconn->ErrorNo(). "Error getting Group ID : ".$dbconn->ErrorMsg(). "<br>";
       	        //error_log ($dbconn->ErrorNo(). "Get default group: ".$dbconn->ErrorMsg(). "<br>");
       	    } else {
       	        if (!$result->EOF) {
       	            list($gid) = $result->fields;
       	            $result->Close();
       	            $column = &$pntable['group_membership_column'];
       	            $result = $dbconn->Execute("INSERT INTO $pntable[group_membership] ($column[gid], $column[uid])
       	                                      VALUES (".pnVarPrepForStore($gid).", ".pnVarPrepForStore($uid).")");
       	            if($dbconn->ErrorNo()<>0) {
       	                echo $dbconn->ErrorNo(). "Create default group membership: ".$dbconn->ErrorMsg(). "<br>";
       	                //error_log ($dbconn->ErrorNo(). "Create default group membership: ".$dbconn->ErrorMsg(). "<br>");
       	            }
       	        }
				$column = &$pntable[users_modrequest_column];
			    $dbconn->Execute("DELETE FROM   $pntable[users_modrequest]
			                      WHERE         $column[uname]='".pnVarPrepForStore($uname)."'
								  AND 			$column[uadd]='1'");
			    if($dbconn->ErrorNo()<>0) {
			    	echo $dbconn->ErrorMsg();
			    	//error_log("DB Error: " . $dbconn->ErrorMsg());
			    }
				$from = pnConfigGetVar('adminmail');
				$sitename = pnConfigGetVar('sitename');
				if (pnConfigGetVar('pnc_mail_usrregok')=="1") {
					$message = ""._MODREGUSROK." $sitename\n\n";
					$message .= ""._USERNAME." : $uname\n\n"._UACYA."";
					$subject = ""._MODREGUSROKSBJ." $sitename";
					pnMail($email, $subject, $message, "From: $from\nX-Mailer: PHP/" . phpversion());
				}
			}
            echo "<div align=center><font class=\"pn-title\">"
                ."<a href=\"admin.php?module=NS-User&op=modifyUser&chng_uid=$uid\">".pnVarPrepForDisplay($var['add_uname'])." ("
                ._USERID." $uid)</A> "._ADDED."</div></font><br>";
            echo "<a href=\"admin.php?module=NS-User&op=main\">"._ADDUSER."</a>\n";
			
			echo "<br><br>\n";
			
			$modlist = pncModShowList();
			echo pnVarPrepHTMLDisplay($modlist);
        }
	} else {
	    echo $stop;
	}
	include 'footer.php';
}

function moduserCheck($uname, $email, $dynafield)
{
   
    list($dbconn) = pnDBGetConn();
    $pntable = pnDBGetTables();

    $res = pnVarValidate($email, 'email');
    if($res == false) {
        $stop = "<center><font class=\"pn-title\">"._ERRORINVEMAIL."</center></font><br>";
    }
    
    // Here we test the uname. Any value is possible but space.
    // On special character sets you might configure the server.
    // (was bug #455288)
    if ((!$uname) || !(ereg("^[[:print:]]+",$uname) && !ereg("[[:space:]]",$uname))) {
    /*if ((!$uname) || ($uname=="") || (ereg("[^a-zA-Z0-9_-]",$uname))) {*/
        $stop = "<center><font class=\"pn-title\">"._ERRORINVNICK."</center></font><br>";
    }
    if (strlen($uname) > 25) {
        $stop = "<center><font class=\"pn-title\">"._NICK2LONG."</center></font>";
    }
    if (preg_match('/((root)|(adm)|(linux)|(webmaster)|(admin)|(god)|(administrator)|(administrador)|(nobody)|(anonymous)|(anonimo)|
(an��imo)|(operator))/iAD',$uname)) {
        $stop = "<center><font class=\"pn-title\">"._NAMERESERVED."</center></font>";
    }
	/*Added by Chestnut ! 17/02/2003 - Took from [class007]*/
	$vtest = pnConfigGetVar('reservedstring');
	if (!empty($vtest) && is_array($vtest)) {
        $count = count($vtest);
        $pregcondition = "/((";
        for ($i = 0;$i < $count;$i++) {
            if ($i != $count-1) {
                $pregcondition .= $vtest[$i] . ")|(";
            } else {
                $pregcondition .= $vtest[$i] . "))/iAD";
            } 
        } 
        if (preg_match($pregcondition, $uname)) {
            $stop = "<center><font class=\"pn-title\">" . _NAMERESERVED . "</center></font>";
        } 
	}
    if (strrpos($uname,' ') > 0) {
        $stop = "<center><font class=\"pn-title\">"._NICKNOSPACES."</center></font>";
    }
    $column = &$pntable['users_column'];
    $existinguser = $dbconn->Execute("SELECT $column[uname] FROM $pntable[users] WHERE $column[uname]='".pnVarPrepForStore($uname)."'");
    if (!$existinguser->EOF) {
        $stop = "<center><font class=\"pn-title\">"._NICKTAKEN."</center></font><br>";
    }
    $existinguser->Close();
    $existinguser = $dbconn->Execute("SELECT $column[email] FROM $pntable[users] WHERE $column[email]='".pnVarPrepForStore($email)."'");
    if (!$existinguser->EOF) {
        $stop = "<center><font class=\"pn-title\">"._EMAILREGISTERED."</center></font><br>";
    }

	if (!empty($var['dynafield']) && is_array($var['dynafield'])) {
		$fieldrequired = getfieldrequired();
		if (is_array($fieldrequired) && !empty($fieldrequired)) {
			while(list($key, $val) = each($fieldrequired)) {
				$field = $val['FIELD'];
				$newvar = $var['dynafield'];
				while(list($nkey, $nvar) = each($newvar)) {
					if ($field == $key && $nvar."" == "") {
						$stop = "<center><font class=\"pn-title\">MISSING FIELDS ".$field." - To add to lang file</font></center><br>\n";
					}
				}
			}
		}
	}
    return($stop);
}

function deleteModRequest($chng_uid)
{
	list($dbconn) = pnDBGetConn();
	$pntable = pnDBGetTables();
	$authid = pnSecGenAuthKey();

	include("header.php");
    GraphicAdmin();
    OpenTable();
    echo "<center><font class=\"pn-title\"><b>"._USERADMIN."</b></font></center>";
    CloseTable();

    OpenTable();
    echo "<center><font class=\"pn-title\"><b>"._DELETEUSER."</b></font><br><br>";

    $column = &$pntable['users_modrequest_column'];
	$result = $dbconn->Execute("SELECT	$column[uname]
								FROM	$pntable[users_modrequest]
								WHERE	$column[uname] = '".pnVarPrepForStore($chng_uid)."'
								AND		$column[uadd]='1'");

	if(!$result->EOF) {
	    list($uname) = $result->fields;
    } else {
	    echo _USERNOEXIST.' '.pnVarPrepForDisplay($chng_uid);
	    CloseTable();
		include 'footer.php';
		exit;
	}
    if (!pnSecAuthAction(0, 'Users::', "$uname::$chng_uid", ACCESS_DELETE)) {
        echo _MODIFYUSERSDELNOAUTH;
        CloseTable();
        include 'footer.php';
        exit;
    }
    echo ""._SURE2DELETE." $uname ?<br><br>"
		."[ <a href=\"admin.php?module=NS-User&amp;op=delModRequestConfOK&amp;del_uid=$uname&amp;authid=$authid\">"._YES
        ."</a> | <a href=\"admin.php?module=NS-User&amp;op=ListUAddRequest\">"._NO."</a> ]</center>";
    CloseTable();
    include("footer.php");
}

function deleteModConfRequestOK($del_uid)
{

    if (!pnSecConfirmAuthKey()) {
        include 'header.php';
        echo _BADAUTHKEY;
        include 'footer.php';
        exit;
    }

    if (!pnSecAuthAction(0, "Users::", "::", ACCESS_ADD)) {
        include 'header.php';
        echo _UAUSRNODEL;
        include 'footer.php';
        exit;
    }

    list($dbconn) = pnDBGetConn();
    $pntable = pnDBGetTables();
    $column = &$pntable['users_modrequest_column'];
	$result = $dbconn->Execute("SELECT 	$column[email]
								FROM 	$pntable[users_modrequest]
								WHERE	$column[uname]='".pnVarPrepForStore($del_uid)."'
								AND		$column[uadd]='1'");
	list($email) = $result->fields;
	
    $dbconn->Execute("DELETE FROM $pntable[users_modrequest]
                      WHERE $column[uname]='".pnVarPrepForStore($del_uid)."'
                      AND $column[uadd]='1'");
    if($dbconn->ErrorNo()<>0) {
       echo $dbconn->ErrorMsg();
       error_log("DB Error: " . $dbconn->ErrorMsg());
    } else {
		if (pnConfigGetVar('pnc_mail_usrregsorry')=="1") {
			$from = pnConfigGetVar('adminmail');
    		$sitename = pnConfigGetVar('sitename');
		    $message = ""._UAMAILSORRY1." ".$sitename."\n\n"._UAMAILSORRY2."$uname "._UAMAILSORRY3."\n\n"._UACYA;
		    $subject = _UAMAILSORRYSBJ." ".$sitename;
		    pnMail($email, $subject, $message, "From: $from\nX-Mailer: PHP/" . phpversion());
		}
	}        
    pnRedirect("admin.php");
}

function user_admin_delRequest()
{
    if (!pnSecAuthAction(0, "Users::", "::", ACCESS_DELETE)) {
       include 'header.php';
       echo _UAUSRNODEL;
       include 'footer.php';
       exit;
    }

    global $bgcolor1, $bgcolor2;
    include 'header.php';
    list($dbconn) = pnDBGetConn();
    $pntable = pnDBGetTables();
    $authid = pnSecGenAuthKey();

    GraphicAdmin();
    OpenTable();
    echo "<center><font class=\"pn-title\"><b>"._UAADMDELSEND."</b></font></center>";
    CloseTable();

    OpenTable();
    echo "<center><font class=\"pn-normal\"><b>"._UAACCLST."</b></font></center><br>"
        ."<table cellspacing=1 bgcolor=\"#000000\" border=0 width=100% align=center><tr bgcolor=\"".$GLOBALS['bgcolor2']."\">"
        ."<td align=\"center\" height=\"30\">"._UANOID."</td>"
        ."<td align=\"center\">"._UAUNAME."</td>"
        ."<td align=\"center\">"._UAREQREASON."</td>"
        ."<td align=\"center\">"._UAEMAIL."</td>"
        ."<td align=\"center\">"._FUNCTIONS."</td></tr>";

    $column = &$pntable['users_modrequest_column'];
    $result = $dbconn->Execute("SELECT $column[uid], $column[reason], $column[uname], $column[email]
								FROM $pntable[users_modrequest]
								WHERE $column[udel]='1'
                                ORDER BY $column[uname]");
    while(list($uid, $reason, $uname, $email) = $result->fields) {

        $result->MoveNext();
            echo "<tr bgcolor=\"".$GLOBALS['bgcolor1']."\"><td align=\"center\" width=\"5%\">".pnVarPrepHTMLDisplay($uid)."</td>"
            	."<td align=\"center\" width=\"15%\">".pnVarPrepForDisplay($uname)."</td>"
	            ."<td align=\"center\" width=\"20%\">".pnVarPrepForDisplay($reason)."&nbsp;</td>"
	            ."<td align=\"center\" width=\"20%\"><a href=\"mailto:".pnVarPrepForDisplay($email)."\">".pnVarPrepForDisplay($email)."</a></td>"
	            ."<td align=\"center\">"
				."[ <b><a href=\"admin.php?module=".$GLOBALS["module"]."&amp;op=delUserRequest&amp;chng_uid=".pnVarPrepForDisplay($uid)."&amp;ok=0&amp;authid=".pnVarPrepForDisplay($authid)."\">"._DELETE."</a></b> ]"
				." --- "
				."[ <a href=\"admin.php?module=".$GLOBALS["module"]."&amp;op=IgnoreDelRequest&amp;chng_uid=".pnVarPrepForDisplay($uid)."&amp;ok=0&amp;authid=".pnVarPrepForDisplay($authid)."\">"._IGNOREDELREQ."</a> ]"
				."</td></tr>"
	            ."</td></tr>";
    }

    echo "</table>";
    CloseTable();

    OpenTable();
    echo "<center>" . _GOBACK . "</center>";
    CloseTable();

    include 'footer.php';
}

function user_admin_ignoredelrequest()
{
	list($dbconn) = pnDBGetConn();
	$pntable = pnDBGetTables();
    if (!pnSecConfirmAuthKey()) {
        include 'header.php';
        echo _BADAUTHKEY;
        include 'footer.php';
        exit;
    }
	
	$chng_uid = pnVarCleanFromInput('chng_uid');
	
	$modtable = $pntable['users_modrequest'];
	$modcolumn = &$pntable['users_modrequest_column'];
	
	$sql = "DELETE FROM $modtable
			WHERE	$modcolumn[uid]='".pnVarPrepForStore($chng_uid)."'
			AND		$modcolumn[udel]='1'";
	
	$dbconn->Execute($sql);
    if($dbconn->ErrorNo()<>0) {
		include 'header.php';
        echo $dbconn->ErrorMsg();
        include 'footer.php';
    } else {
		pnredirect('admin.php');
	}
}
	
function user_admin_deleteUserRequest()
{
	list($dbconn) = pnDBGetConn();
	$chng_uid = pnVarCleanFromInput('chng_uid');
	$pntable = pnDBGetTables();
	$authid = pnSecGenAuthKey();

	include("header.php");
    GraphicAdmin();
    OpenTable();
    echo "<center><font class=\"pn-title\"><b>"._USERADMIN."</b></font></center>";
    CloseTable();

    OpenTable();
    echo "<center><font class=\"pn-title\"><b>"._DELETEUSER."</b></font><br><br>";

    $column = &$pntable['users_column'];
    // Someone got uname and uid the wrong way around in the form.
    // This needs to be sorted one day to avoid further confusion
	$result = $dbconn->Execute("SELECT	$column[uname], $column[uid]
								FROM	$pntable[users]
								WHERE	$column[uid] = \"".pnVarPrepForStore($chng_uid)."\"
								OR		$column[uname] = \"".pnVarPrepForStore($chng_uid)."\"");

	if(!$result->EOF) {
	    list($uname, $uid) = $result->fields;
    } else {
	    echo _USERNOEXIST;
	    CloseTable();
		include 'footer.php';
		exit;
	}
    if (!pnSecAuthAction(0, 'Users::', "$uname::$chng_uid", ACCESS_DELETE)) {
        echo _MODIFYUSERSDELNOAUTH;
        CloseTable();
        include 'footer.php';
        exit;
    }
    echo ""._SURE2DELETE." $uname ?<br><br>"
		."[ <a href=\"admin.php?module=NS-User&amp;op=delUserConfRequest&amp;del_uid=$uid&amp;authid=$authid\">"._YES
        ."</a> | <a href=\"admin.php?module=NS-User&amp;op=mod_users\">"._NO."</a> ]</center>";
    CloseTable();
    include("footer.php");
}

function deleteUserConfirmRequest()
{

    if (!pnSecConfirmAuthKey()) {
        include 'header.php';
        echo _BADAUTHKEY;
        include 'footer.php';
        exit;
    }

	$del_uid = pnVarCleanFromInput('del_uid');

    if (!pnSecAuthAction(0, "Users::", "::", ACCESS_DELETE)) {
        include 'header.php';
        echo _UAUSRNODEL;
        include 'footer.php';
        exit;
    }

    list($dbconn) = pnDBGetConn();
    $pntable = pnDBGetTables();
    $column = &$pntable['users_column'];

    $result = $dbconn->Execute("SELECT	$column[uname], $column[email]
    							FROM	$pntable[users]
    							WHERE	$column[uid] = \"$del_uid\"");

    if(!$result->EOF) {
        list($uname, $email) = $result->fields;
    } else {
        include 'header.php';
        echo _USERNOEXIST;
        include 'footer.php';
        exit;
    }
    if (!pnSecAuthAction(0, 'Users::', "$uname::$del_uid", ACCESS_DELETE)) {
    	include 'header.php';
        echo _MODIFYUSERSDELNOAUTH;
        include 'footer.php';
        exit;
    }
    $column = &$pntable['user_perms_column'];
    $dbconn->Execute("DELETE FROM $pntable[user_perms]
                      WHERE $column[uid]='".pnVarPrepForStore($del_uid)."'");
    if($dbconn->ErrorNo()<>0) {
        echo $dbconn->ErrorMsg();
        error_log("DB Error: " . $dbconn->ErrorMsg());
    }
    $column = &$pntable['users_modrequest_column'];
    $dbconn->Execute("DELETE FROM $pntable[users_modrequest]
                      WHERE $column[uid]='".pnVarPrepForStore($del_uid)."'
                      AND $column[udel]='1'");
    if($dbconn->ErrorNo()<>0) {
       echo $dbconn->ErrorMsg();
       error_log("DB Error: " . $dbconn->ErrorMsg());
    }
    $column = &$pntable['group_membership_column'];
    $dbconn->Execute("DELETE FROM $pntable[group_membership]
                      WHERE $column[uid]='".pnVarPrepForStore($del_uid)."'");
    if($dbconn->ErrorNo()<>0) {
        echo $dbconn->ErrorMsg();
        error_log("DB Error: " . $dbconn->ErrorMsg());
    }
    $column = &$pntable['users_column'];
    $dbconn->Execute("DELETE FROM $pntable[users]
                      WHERE $column[uid]='".pnVarPrepForStore($del_uid)."'");
    if($dbconn->ErrorNo()<>0) {
        echo $dbconn->ErrorMsg();
        error_log("DB Error: " . $dbconn->ErrorMsg());
    }
    
	if (pnConfigGetVar('pnc_mail_modusrwning') == "1") {
		$from = pnConfigGetVar('adminmail');
    	$sitename = pnConfigGetVar('sitename');
	    $message = ""._UACONFIRMATION."\n\n"._UADELEMAIL1."$uname "._UADELEMAIL2."\n\n"._UADELEMAIL3."\n\n"._UADELEMAIL4."\n\n"._UAENDEMAIL1."\n"._UAENDEMAIL2."$sitename";
	    $subject = "Confirmation ! $sitename";
	    pnMail($email, $subject, $message, "From: $from\nX-Mailer: PHP/" . phpversion());
	}
        
    pnRedirect("admin.php");
}

function pncModShowList()
{

    //Delete User Request
    list($dbconn) = pnDBGetConn();
    $pntable = pnDBGetTables();
	$uatable = $pntable['users_modrequest'];
	$uacolumn = &$pntable[users_modrequest_column];
	
	$showme = "";
	
    if (pnSecAuthAction(0, 'Users::', '::', ACCESS_DELETE)) {
        $result = $dbconn->Execute("SELECT count(*) FROM ".$uatable['users_modrequest']." WHERE $uacolumn[udel]='1'");
		list($delreq) = $result->fields;
        if ($delreq != 0) {
            //OpenTable();
            $showme .= "<center><font class=\"pn-title\"><b>"._UADELWAIT."</b></font><br><br>\n";
            $showme .= "<center><a href=\"admin.php?module=".$GLOBALS['module']."&op=ListDelRequest\">"._UADELWAITLST." ( ".pnVarPrepForDisplay($delreq)." )</a></center><br><br>\n";
            //CloseTable();
        }
    }
	// Moderate List
    if (pnSecAuthAction(0, 'Users::', '::', ACCESS_ADD)) {
        $result = $dbconn->Execute("SELECT count(*) FROM ".$uatable['users_modrequest']." WHERE $uacolumn[uadd]='1'");
        list($addreq) = $result->fields;
        if ($addreq != 0) {
            //OpenTable();
            $showme .= "<center><font class=\"pn-title\"><b>"._UAADDWAIT."</b></font><br><br>\n";
            $showme .= "<center><a href=\"admin.php?module=".$GLOBALS['module']."&op=ListUAddRequest\">"._UAADDWAITLST." ( ".pnVarPrepForDisplay($addreq)." )</a></center><br><br>\n";
            //CloseTable();
        }
    }
	
	return $showme;

}
?>