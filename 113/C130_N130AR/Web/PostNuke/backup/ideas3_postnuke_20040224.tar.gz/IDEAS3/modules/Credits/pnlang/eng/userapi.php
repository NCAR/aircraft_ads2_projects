<?php
define('_MODULESAPIINVALIDSTATETRANSITION','Invalid module state transition');
define('_MODULESAPINOAUTH','Not authorised to carry out that operation');
define('_MODULESAPIUPDATEFAILED','Update attempt failed');
define('_MODULESAPIUPGRADED','Module has been upgraded, now inactive');
define('_MODCHANGESTATEFAILED','Module state change failed');
define('_MODINITFAILED','Module initialisation failed');
define('_MODNOSUCHMOD','No such module');
?>
