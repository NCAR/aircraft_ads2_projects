<?php /* $Id: user.php,v 1.1.1.1 2003/06/18 19:21:49 fd Exp $ */
// ----------------------------------------------------------------------
// POST-NUKE Content Management System
// Copyright (C) 2001 by the Post-Nuke Development Team.
// http://www.postnuke.com/
// ----------------------------------------------------------------------
// Based on:
// PHP-NUKE Web Portal System - http://phpnuke.org/
// Thatware - http://thatware.org/
// ----------------------------------------------------------------------
// LICENSE
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License (GPL)
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// To read the license please visit http://www.gnu.org/copyleft/gpl.html
// ----------------------------------------------------------------------
// Original Author of this file:
// Purpose of this file:  new user routines
// ----------------------------------------------------------------------
//Added calls to pnVarCleanFromInput since it's more secure than using $var[]. - Skooter

$ModName = 'NS-NewUser';
modules_get_language();

function newuser_user_underage()
{
    include 'header.php';

    OpenTable();
        echo "<font class=\"pn-title\">"._SORRY."</font>";
        echo "<br><br>\n"
            ."<font class=\"pn-normal\">"._MUSTBE."<br>"
            ."<br>"._CLICK."<a href=\"index.php\">"._HERE."</a> "._RETURN."</font><br>\n";
   CloseTable();
   include 'footer.php';
}

function newuser_user_check_age($var)
{
    $sitename = pnConfigGetVar('sitename');

    include 'header.php';
	/*Added by Chestnut !*/
	if (pnConfigGetVar('blkusrreg')=="0") {
		echo "<center><font class=\"pn-title\">"._UAREGNOACTIVE."<br>";
		echo ""._UAREGBEBACK."</font></center>";
		include 'footer.php';
		Exit();
	}

    OpenTable();
    echo "<center>"
        ."<font class=\"pn-title\">"._WELCOMETO." ".pnVarPrepForDisplay($sitename)." "._REGISTRATION."</font>"
        ."<br><br>\n"
        ."<font class=\"pn-normal\">"._MUSTBE."</font><br>\n"

        ."<a href=\"user.php?op=register&amp;module=NS-NewUser\">"
        .""._OVER13.""
        ."</a><br><br>"

        ."<font class=\"pn-normal\">"._CONSENT."</font><br><br>\n"

        ."<a href=\"user.php?op=underage&amp;module=NS-NewUser\">"
        .""._UNDER13.""
        ."</a><br>\n"

        ."</font></center>\n";

    CloseTable();
    include 'footer.php';
}


function newuser_user_register()
{
    //$system = pnConfigGetVar('system');
    $fullprofile = pnConfigGetVar('pncuaadvreg');

        include 'header.php';
		/*Added by Chestnut !*/
		if (pnConfigGetVar('blkusrreg')=="0") {
			echo "<center><font class=\"pn-title\">"._UAREGNOACTIVE."<br>";
			echo ""._UAREGBEBACK."</font></center>";
			include 'footer.php';
			Exit();
		}
        OpenTable();
        echo "<form name=\"Register\" action=\"user.php\" method=\"post\">\n"
            ."<font class=\"pn-title\">"._REGNEWUSER."</font><br><br>\n"
            ."<table width=\"100%\" cellpadding=\"0\" cellspacing=\"0\" border=\"0\">\n"
            ."<tr><td width=\"25%\" height=\"25\"><font class=\"pn-normal\">"._NICKNAME.": </font></td><td><table><tr><td><input type=\"text\" name=\"uname\" size=\"26\" maxlength=\"25\"></td></tr></table></td></tr>\n";
        
		$allowuserpass = pnConfigGetVar('allowuserpass');
        
		if ($allowuserpass=="1") {
            echo "<tr><td colspan=\"2\"> ------ </td></tr>\n";
            echo "<tr><td><font class=\"pn-normal\">"._UAUPASS." *</font></td><td><table><tr><td><input type=\"password\" name=\"upass\" size=\"26\" maxlength=\"26\"></td></tr></table></td></tr>\n";        /*Valeur langue � d�terminer*/
            echo "<tr><td><font class=\"pn-normal\">"._UAUPASSCONFIRM." *</font></td><td><table><tr><td><input type=\"password\" name=\"upassverif\" size=\"26\" maxlength=\"25\"></td></tr></table></td></tr>\n";    /*Valeur langue � d�terminer*/
            echo "<tr><td colspan=\"2\"> ------ </td></tr>\n";
        }
        echo "<tr><td height=\"25\"><font class=\"pn-normal\">"._EMAIL.":  ( <b>"._FIELD_REQUIRED."</b> )</font></td><td><table><tr><td><input type=\"text\" name=\"email\" size=\"26\" maxlength=\"60\"></td></tr></table></td></tr>\n"
            ."<tr><td height=\"25\"><font class=\"pn-normal\">"._OPTION.":</font> </td><td><table><tr><td><INPUT TYPE=\"CHECKBOX\" NAME=\"user_viewemail\" VALUE=\"1\"><font class=\"pn-normal\"> "._ALLOWEMAILVIEW."</font></td></tr></table></td></tr>\n";

        // Hacked by Chestnut !
        
        if ($fullprofile == "1") {
            $requiredfields = getuserfieldlist();
        } else {
            $requiredfields = getuserfieldrequired();
        }
        
        echo "<tr><td colspan=2> ------ </td></tr>\n";
        while(list($key, $val) = each($requiredfields)) {
            
			//Simplifying
			
			$namefield = $val['FIELD'];
			$isrequired = $val['VALIDATION']['REQUIRED'];
			$fieldvalid = $val['VALIDATION'];
			$fieldlibel = $val['LIBEL'];
			
			
			
			
			echo "<tr><td height=\"25\"><font class=\"pn-normal\">\n".pnVarPrepForDisplay($fieldlibel);
            
			if ($isrequired == 1) {
                echo " ( <b>"._FIELD_REQUIRED."</b> )";
            }
            
            echo "</font></td>\n";
            echo "<td>\n";
            switch ($namefield) {
                case "_TIMEZONEOFFSET":
                    global $tzinfo;
                    echo "<table><tr><td><select name=\"dynafield[".$namefield."]\" class=\"pn-normal\">";
                    foreach ($tzinfo as $tzindex => $tzdata) {
                        echo "\n<option value=\"$tzindex\">";
                        echo $tzdata;
                        echo "</option>";
                    }
                    echo "</select>\n</td>\n</tr>\n</table>\n";
                    break;
                case "_YOURAVATAR":
                    echo "<table><tr><td><select name=\"user_avatar\" onChange=\"showimage()\" class=\"pn-normal\">\n";
                    $handle = opendir('./images/avatar');
                    while ($file = readdir($handle)) {
                        $filelist[] = $file;
                    }
                    asort($filelist);
                    while (list ($key, $file) = each ($filelist)) {
                        ereg(".gif|.jpg",$file);
                        if ($file != "." && $file != "..") {
                            echo "<option value=\"$file\">$file</option>";
                        }
                    }
                    echo "</select>&nbsp;&nbsp;<img src=\"images/avatar/blank.gif\" name=\"avatar\" width=\"32\" height=\"32\" alt=\"\" align=\"top\">&nbsp;&nbsp;";
                    echo "<script language=\"JavaScript\">
                    <!--
                    function OpenAvatarWindow(theURL,winName,features) { //v2.0
                        window.open(theURL,winName,features);
                    }
                    //-->
                    </script>[ <a onClick=\"OpenAvatarWindow('avatar.php','Avatars','scrollbars=yes,width=450,height=400')\">"._UAAVATARLIST."</a> ]</td></tr></table>";
                    break;
                default:
                    $fieldvalid['NAME'] = $namefield;
                    echo getuserfieldHTMLDef($fieldvalid, $dynavalue='');
                    break;
            }
            //echo " <font class=\"pn-sub\">"._REQUIRED."</font>\n";
            echo "</td></tr>\n";
        }

        echo "<tr><td colspan=\"2\"> ------ </td></tr>\n";
        //Check for legal module
        if (pnModAvailable("legal")) {
            echo "<tr><td colspan=\"2\"><INPUT TYPE=\"CHECKBOX\" NAME=\"agreetoterms\" VALUE=\"1\"><font class=\"pn-normal\">"._REGISTRATIONAGREEMENT." <a href=\"modules.php?op=modload&amp;name=legal&amp;file=index\">"._TERMSOFUSE."</a> "._ANDCONNECTOR." <a href=\"modules.php?op=modload&amp;name=legal&amp;file=privacy\">"._PRIVACYPOLICY."</a>.</td></tr>\n";
        }
        echo "<tr><td colspan=\"2\" height=\"15\">&nbsp;</td><tr><tr><td colspan=\"2\">\n"
            ."<input type=\"hidden\" name=\"module\" value=\"NS-NewUser\">\n"
            ."<input type=\"hidden\" name=\"op\" value=\"confirmnewuser\">\n"
            ."<input type=\"submit\" value=\""._NEWUSER."\">\n"
            ."</td></tr></table>\n"
            ."</form>\n"
            ."<br>\n"
			."<font class=\"pn-normal\"><b>"._UAREMARKTEXT."</b></font><br><br>\n";
        if($system == 0) {
	        echo "<font class=\"pn-normal\">" . _PASSWILLSEND . "</font><br><br>\n";
        }

        echo "<font class=\"pn-normal\">"._COOKIEWARNING."</font><br>\n"
            ."<font class=\"pn-normal\">"._ASREGUSER."</font><br>\n"
            ."<font class=\"pn-normal\"><ul>\n"
            ."<li>"._ASREG1."\n"
            ."<li>"._ASREG2."\n"
            ."<li>"._ASREG3."\n"
            ."<li>"._ASREG4."\n"
            ."<li>"._ASREG5."\n"
            ."<li>"._ASREG6."\n"
            ."<li>"._ASREG7."\n"
            ."</ul></font>\n"
            ."<font class=\"pn-title\">"._REGISTERNOW."</font><br>\n"
            ."<font class=\"pn-normal\">"._WEDONTGIVE."</font>\n";
        CloseTable();

        include 'footer.php';

}

function userCheck($uname, $email, $agreetoterms, $dynafield)
{
    list($dbconn) = pnDBGetConn();
    $pntable = pnDBGetTables();
    
    $stop = '';
    $res = pnVarValidate($email, 'email');
    if($res == false) {
        $stop .= "<center><font class=\"pn-title\">"._ERRORINVEMAIL."</center></font><br>";
    }

    //Check for legal module
    if (pnModAvailable("legal")) {
        // If legal var agreetoterms checkbox not checked, value is 0 and results in error
        if ($agreetoterms == 0) {
           $stop .= "<center><font class=\"pn-title\">"._ERRORMUSTAGREE."</center></font><br>";
        }
    }

    // By this test (without on printable characters) it should be possible to have
    // eg. Chinese characters on the username. (hinrich, 2002-07-03, reported by class 007
    //
    if ((!$uname) || !(/* preg_match("/^[[:print:]]+/",$uname) && */ !preg_match("/[[:space:]]/",$uname))) {

    // Here we test the uname. Any value is possible but space.
    // On special character sets you might configure the server.
    // (was bug #455288)
    // if ((!$uname) || !(ereg("^[[:print:]]+",$uname) && !ereg("[[:space:]]",$uname))) {
    /*if ((!$uname) || ($uname=="") || (ereg("[^a-zA-Z0-9_-]",$uname))) {*/

        $stop .= "<center><font class=\"pn-title\">"._ERRORINVNICK."</center></font><br>";
    }
    if (strlen($uname) > 25) {
        $stop .= "<center><font class=\"pn-title\">"._NICK2LONG."</center></font>";
    }
    if (preg_match('/((root)|(adm)|(linux)|(webmaster)|(admin)|(god)|(administrator)|(administrador)|(nobody)|(anonymous)|(anonimo)|(an��imo)|(operator))/iAD',$uname)) {
        $stop .= "<center><font class=\"pn-title\">"._NAMERESERVED."</center></font>";
    }
    $vtest = pnConfigGetVar('reservedstring');
    if ($vtest) foreach($vtest as $element) {
        if (preg_match("/$element/i", $uname)) {
            $stop .= "<center><font class=\"pn-title\">"._NAMERESERVED." "._UAORCENS."</center></font>";
            break;
        }
    }
    if (strrpos($uname,' ') > 0) {
        $stop .= "<center><font class=\"pn-title\">"._NICKNOSPACES."</center></font>";
    }
    $column = &$pntable['users_column'];
    $existinguser = $dbconn->Execute("SELECT $column[uname] FROM $pntable[users] WHERE $column[uname]='".pnVarPrepForStore($uname)."'");
    if (!$existinguser->EOF) {
        $stop .= "<center><font class=\"pn-title\">"._NICKTAKEN."</center></font><br>";
    }
    $existinguser->Close();
    $existinguser = $dbconn->Execute("SELECT $column[email] FROM $pntable[users] WHERE $column[email]='".pnVarPrepForStore($email)."'");
    if (!$existinguser->EOF) {
        $stop .= "<center><font class=\"pn-title\">"._EMAILREGISTERED."</center></font><br>";
    }
    $existinguser->Close();
    
    $fieldrequired = getuserfieldrequired();
    $fieldtocheck = $dynafield;
    while(list($checkkey, $checkval) = each($fieldrequired)) {
        if(!isset($fieldtocheck[$checkval['FIELD']]) || $fieldtocheck[$checkval['FIELD']]."" == "") {
            $stop .= "<center><font class=\"pn-title\">".$checkval['LIBEL']." "._DYNAEMPTY."</center></font><br>\n";
        }
    }
    $column = &$pntable['users_modrequest_column'];
       $existinguser = $dbconn->Execute("    SELECT    $column[uname]
                                        FROM    $pntable[users_modrequest]
                                        WHERE   $column[uname]='".pnVarPrepForStore($uname)."'
                                        OR      $column[email]='".pnVarPrepForStore($email)."'
                                        AND     $column[uadd]=1");
    if ($existinguser) {
        $stop .= "<center><font class=\"pn-title\">$existinguser:  "._UAALLREADYASK."</center></font><br>";
    }
    if ($allowuserpass=="0") {
        if (strlen($upass) < pnConfigGetVar('minpass')) {
            $stop .= "<center><font class=\"pn-title\">"._UAPASSTOOSHORT." ".pnConfigGetVar('minpass')." "._UAPASSTOOSHORT2."</center></font>";
        }
        if ($upass!=$upassverif) {
            $stop .= "<center><font class=\"pn-title\">"._UAPASSDIFF."</center></font>";        /*Valeur langue � d�terminer*/
        }
    }
    return($stop);
}

function newuser_user_confirmNewUser($var)
{

	list(	$uname,
			$user_viewemail,
			$email,
			$user_avatar,
			$agreetoterms) = pnVarCleanFromInput(	'uname',
													'user_viewemail',
													'email',
													'user_avatar',
													'agreetoterms');
    
	$dynafield = pncVarCleanFromInput('dynafield');
    
    $allowuserpass = pnConfigGetVar('allowuserpass');
    if ($allowuserpass=="1") {
        list($upass, $upassverif) = pnVarCleanFromInput('upass', 'upassverif');
    }
    
    include 'header.php';

    $uname = filter_text($uname);
    
    if(isset($user_viewemail) && $user_viewemail == 1) {
        $user_viewemail = "1";
        $femail = $email;
    } else {
        $user_viewemail = "0";
        $femail = "";
    }
    if(empty($agreetoterms)) {
        $agreetoterms = '0';
    }

    OpenTable();
    echo "<font class=\"pn-normal\">"._USERNAME.": ".pnVarPrepForDisplay($uname)."<br>"
        .""._EMAIL.": ".pnVarPrepForDisplay($email)."<br></font><br>\n";

	if ($user_avatar) {
		$dynafield['_YOURAVATAR'] = $user_avatar;
	}

	$showdyna = $dynafield;
    
	if (pnConfigGetVar('pncuaadvreg') == "1") {
        $getfields = getuserfieldlist();
    } else {
        $getfields = getnewuserfield();
    }
	
	if (is_array($showdyna) && !empty($showdyna)) {
    	while(list($key, $val) = each($showdyna)) {
    
    	    if ($val."" != "") {
    	        $confirmfield = $getfields;
				$confirmfield[$key]['VALIDATION']['FIELD'] = $confirmfield[$key]['FIELD'];
    	       	$fieldvalidation = $confirmfield[$key]['VALIDATION'];
				echo $confirmfield[$key]['LIBEL']." = ".getfieldConfirmUser($fieldvalidation, $val)."<br>\n";
    	    }
    	}
	}
    
    echo "<br>\n";
    echo ""._GOBACK."\n";
    echo "<form action=\"user.php\" method=\"post\">\n"
        ."<input type=\"hidden\" name=\"uname\" value=\"$uname\">\n"
        ."<input type=\"hidden\" name=\"email\" value=\"$email\">\n"
        ."<input type=\"hidden\" name=\"agreetoterms\" value=\"$agreetoterms\">\n"
        ."<input type=\"hidden\" name=\"user_viewemail\" value=\"$user_viewemail\">\n\n";

	if (is_array($dynafield) && !empty($dynafield)) {
    	while(list($key, $val) = each($dynafield)) {
    	    if (is_array($val)) {
    	        foreach($val as $subval) {
    	            if ($subval."" != "") {
    	                echo "<input type=\"hidden\" name=\"dynafield[".pnVarPrepForDisplay($key)."][".pnVarPrepForDisplay($subval)."]\" value=\"".pnVarPrepForDisplay($subval)."\">\n";
    	            }
    	        }
    	    } else {
    	        if ($val."" != "") {
    	            echo "<input type=\"hidden\" name=\"dynafield[".pnVarPrepForDisplay($key)."]\" value=\"".pnVarPrepForDisplay($val)."\">\n";
    	        }
    	    }
    	}
	}
	echo "<input type=\"hidden\" name=\"dynafield[_YOURAVATAR]\" value=\"".pnVarPrepForDisplay($user_avatar)."\">\n";

    echo "<input type=\"hidden\" name=\"op\" value=\"finishnewuser\">\n"
        ."<input type=\"hidden\" name=\"module\" value=\"NS-NewUser\">\n";

    if ($allowuserpass=="1") {
        echo "<input type=\"hidden\" name=\"upass\" value=\"".$upass."\">\n";
        echo "<input type=\"hidden\" name=\"upassverif\" value=\"".$upassverif."\">\n";
    }

    echo "<input type=\"submit\" value=\""._FINISH."\"></form>\n";

    CloseTable();

    include 'footer.php';
}

function newuser_user_finishnewuser($var)
{
    list($dbconn) = pnDBGetConn();
    $pntable = pnDBGetTables();

    list($uname,$user_viewemail,$email,$agreetoterms) = 
        pnVarCleanFromInput('uname','user_viewemail','email','agreetoterms');
        
    $dynafield = pncVarCleanFromInput('dynafield');
    
    $allowuserpass = pnConfigGetVar('allowuserpass');
    if ($allowuserpass=="1") {
        list($upass, $upassverif) = pnVarCleanFromInput('upass', 'upassverif');
    }
    
    $system = pnConfigGetVar('system');
    $adminmail = pnConfigGetVar('adminmail');
    $sitename = pnConfigGetVar('sitename');
    $Default_Theme = pnConfigGetVar('Default_Theme');
    $commentlimit = pnConfigGetVar('commentlimit');
    $storynum = pnConfigGetVar('storyhome');
    /*Added by Chestnut !*/
    $senduserpass = pnConfigGetVar('senduserpass');
    $moderatereg = pnConfigGetVar('pncusrmodreg');

    if (isset($dynafield['_TIMEZONEOFFSET'])) {
        $timezoneoffset = $dynafield['_TIMEZONEOFFSET'];
    } else {
        $timezoneoffset = pnConfigGetVar('timezone_offset');
    }
    
    if (isset($dynafield['_YOURAVATAR'])) {
        $avatar = $dynafield['_YOURAVATAR'];
    } else {
        $avatar = "blank.gif";
    }

    // Aliasing
    $storefield['_UREALEMAIL']['NAME'] = 'email';
    $storefield['_UFAKEMAIL']['NAME'] = 'femail';
    $storefield['_UREALNAME']['NAME'] = 'name';
    $storefield['_TIMEZONEOFFSET']['NAME'] = 'timezone_offset';
    $storefield['_YOURAVATAR']['NAME'] = 'user_avatar';
    $storefield['_YICQ']['NAME'] = 'user_icq';
    $storefield['_YAIM']['NAME'] = 'user_aim';
    $storefield['_YYIM']['NAME'] = 'user_yim';
    $storefield['_YMSNM']['NAME'] = 'user_msnm';
    $storefield['_YLOCATION']['NAME'] = 'user_from';
    $storefield['_YOCCUPATION']['NAME'] = 'user_occ';
    $storefield['_YINTERESTS']['NAME'] = 'user_intrest';
    $storefield['_SIGNATURE']['NAME'] = 'user_sig';
    $storefield['_EXTRAINFO']['NAME'] = 'bio';
    $storefield['_YOURHOMEPAGE']['NAME'] = 'url';
    $storefield['_PASSWORD']['NAME'] = 'pass';
    $storefield['_USERVIEWEMAL']['NAME'] = 'user_viewemail';
    $storefield['_USERTHEME']['NAME'] = 'user_theme';
    $storefield['_THEME']['NAME'] = 'theme';
    
    $storecontent = $dynafield;
	if (is_array($storecontent) && !empty($storecontent)) {
	    while(list($fieldname, $fieldvalue) = each($storecontent)) {
	        if (!isset($storefield[$fieldname]['NAME'])) {
	            $newdynafield[$fieldname]['VALUE'] = $fieldvalue;
	            $newdynafield[$fieldname]['NAME'] = $fieldname;
	        } else {
	            $storefield[$fieldname]['VALUE'] = $fieldvalue;
	        }
	    }
	}

    if ($email) $storefield['_UREALEMAIL']['VALUE'] = $email;
    if ($user_viewemail) {
        $storefield['_UFAKEMAIL']['VALUE'] = $email;
        $storefield['_USERVIEWEMAIL']['VALUE'] = 1;
    } else {
        $storefield['_USERVIEWEMAIL']['VALUE'] = 0;
    }
    $storefield['_USERTHEME']['VALUE'] = 0;
    $storefield['_THEME']['VALUE'] = $Default_Theme;
    
    
    include 'header.php';
    $stop = userCheck($uname, $email, $agreetoterms, $dynafield);
    $user_regdate = time();
    
    if ($allowuserpass=="1") {
        if ($upass."" == "" || $upass != $upassverif) {
            $stop .= "<center><font class=\"pn-title\">"._ERRORINPASSWORD."</center></font><br>";
        }
    }

    if ($stop."" != "") $stop .= "<br><br>"._GOBACK."\n";    
    
    if (empty($stop)) {

        if ($allowuserpass=="1") {
            $makepass = $upass;
        } else {
            $makepass = makepass();
        }
        //if ($moderatereg == "1") {
        //    $cryptpass = $makepass;
        //} else {
            $cryptpass = md5($makepass);
        //}

        echo $stop;
        $uid = $dbconn->GenId($pntable['users']);

        if (pnConfigGetVar('pncusrmodreg') == "1") {
            $usertable = $pntable['users_modrequest'];
            $column = &$pntable['users_modrequest_column'];
            $dynarequired = $newdynafield;
			if (is_array($dynarequired) && !empty($dynarequired)) {
            	while(list($key, $val) = each($dynarequired)) {
	                $inputfield = $key;
	                $inputvalue = $val['VALUE'];
	                if (is_array($inputvalue)) {
	                    $inputvalue = serialize($inputvalue);
	                }
	                $dynamod[$inputfield] = $inputvalue;
	            }
			}

            $result = $dbconn->Execute("INSERT INTO $usertable
                                      ($column[uname],
                                       ".$column[$storefield['_UREALEMAIL']['NAME']].",
                                       ".$column[$storefield['_UFAKEMAIL']['NAME']].",
                                       ".$column[$storefield['_UREALNAME']['NAME']].",
                                       ".$column[$storefield['_USERVIEWEMAL']['NAME']].",
                                       $column[user_avatar],
                                       ".$column[$storefield['_YICQ']['NAME']].",
                                       ".$column[$storefield['_YAIM']['NAME']].",
                                       ".$column[$storefield['_YYIM']['NAME']].",
                                       ".$column[$storefield['_YMSNM']['NAME']].",
                                       $column[timezone_offset],
                                       ".$column[$storefield['_YLOCATION']['NAME']].",
                                       ".$column[$storefield['_YINTERESTS']['NAME']].",
                                       ".$column[$storefield['_SIGNATURE']['NAME']].",
                                       ".$column[$storefield['_EXTRAINFO']['NAME']].",
                                       ".$column[$storefield['_YOURHOMEPAGE']['NAME']].",
                                       $column[user_regdate],
                                       $column[storynum],
                                       $column[commentmax],
                                       $column[user_theme],
                                       $column[theme],
                                       $column[pass],
                                       $column[uda_vars],
                                       $column[uadd])
                                 VALUES (
                                       '".pnVarPrepForStore($uname)."',
                                       '".pnVarPrepForStore($storefield['_UREALEMAIL']['VALUE'])."',
                                       '".pnVarPrepForStore($storefield['_UFAKEMAIL']['VALUE'])."',
                                       '".pnVarPrepForStore($storefield['_UREALNAME']['VALUE'])."',
                                       '".pnVarPrepForStore($storefield['_USERVIEWEMAL']['VALUE'])."',
                                       '".pnVarPrepForStore($avatar)."',
                                       '".pnVarPrepForStore($storefield['_YICQ']['VALUE'])."',
                                       '".pnVarPrepForStore($storefield['_YAIM']['VALUE'])."',
                                       '".pnVarPrepForStore($storefield['_YYIM']['VALUE'])."',
                                       '".pnVarPrepForStore($storefield['_YMSNM']['VALUE'])."',
                                       '".pnVarPrepForStore($timezoneoffset)."',
                                       '".pnVarPrepForStore($storefield['_YLOCATION']['VALUE'])."',
                                       '".pnVarPrepForStore($storefield['_YINTERESTS']['VALUE'])."',
                                       '".pnVarPrepForStore($storefield['_SIGNATURE']['VALUE'])."',
                                       '".pnVarPrepForStore($storefield['_EXTRAINFO']['VALUE'])."',
                                       '".pnVarPrepForStore($storefield['_YOURHOMEPAGE']['VALUE'])."',
                                       '".pnVarPrepForStore($user_regdate)."',
                                       '".pnVarPrepForStore($storynum)."',
                                       '".pnVarPrepForStore($commentlimit)."',
                                       '".pnVarPrepForStore($storefield['_USERTHEME']['VALUE'])."',
                                       '".pnVarPrepForStore($storefield['_THEME']['VALUE'])."',
                                       '".pnVarPrepForStore($cryptpass)."',
                                       '".pnVarPrepForStore(serialize($dynamod))."',
                                       1)");
            if($dbconn->ErrorNo()<>0) {
                echo $dbconn->ErrorNo(). ": ".$dbconn->ErrorMsg(). "<br>";
                error_log ($dbconn->ErrorNo(). ": ".$dbconn->ErrorMsg(). "<br>");
            } else {
                $newuseremail = $storefield['_UREALEMAIL']['VALUE'];
                if (pnConfigGetVar('pnc_mail_modusrwning')=="1") {
                    $message = ""._UAMAILMODREG1." ".$sitename." "._UAMAILMODREG2."\n\n"._YOUUSEDEMAIL." ($newuseremail) "._TOREGISTER." ".$sitename.". "._FOLLOWINGMEM."\n\n"._UNICKNAME." $uname\n"._UPASSWORD." : $makepass\n"._UACYA."";
                    $subject = ""._UAMAILMODREGSBJ1." $uname";
                    $from = "$adminmail";
                    pnMail($newuseremail, $subject, $message, "From: $from\nX-Mailer: PHP/" . phpversion());
                }
                if (pnConfigGetVar('pnc_mail_adminwning')=="1") {
                    $message = ""._UAMAILADMINMODREG1." ".$sitename."\n\n"._UAMAILADMINMODREG2." $uname\n"._UAMAILADMINMODREG3." $newuseremail\n\n"._UACYA."";
                    $subject = ""._UAMAILADMINMODSBJ." $uname";
                    $from="$adminmail";
                    pnMail($adminmail, $subject, $message, "From: $from\nX-Mailer: PHP/" . phpversion());
                }
                OpenTable();
                echo '<center><font class=pn-title>'._UAMODREQSAVED.'</font></center>';
                CloseTable();
            }
        } else {
            $column = &$pntable['users_column'];

            $result = $dbconn->Execute("INSERT INTO    $pntable[users]
                        			  ($column[uname],
									   ".$column[$storefield['_UREALEMAIL']['NAME']].",
                                       ".$column[$storefield['_UFAKEMAIL']['NAME']].",
                                       ".$column[$storefield['_UREALNAME']['NAME']].",
                                       ".$column[$storefield['_USERVIEWEMAL']['NAME']].",
                                       $column[user_avatar],
                                       ".$column[$storefield['_YICQ']['NAME']].",
                                       ".$column[$storefield['_YAIM']['NAME']].",
                                       ".$column[$storefield['_YYIM']['NAME']].",
                                       ".$column[$storefield['_YMSNM']['NAME']].",
                                       $column[timezone_offset],
                                       ".$column[$storefield['_YLOCATION']['NAME']].",
                                       ".$column[$storefield['_YINTERESTS']['NAME']].",
                                       ".$column[$storefield['_SIGNATURE']['NAME']].",
                                       ".$column[$storefield['_EXTRAINFO']['NAME']].",
                                       ".$column[$storefield['_YOURHOMEPAGE']['NAME']].",
                                       $column[user_regdate],
                                       $column[storynum],
                                       $column[commentmax],
                                       $column[user_theme],
                                       $column[theme],
                                       $column[pass])
                               VALUES (
                                       '".pnVarPrepForStore($uname)."',
                                       '".pnVarPrepForStore($storefield['_UREALEMAIL']['VALUE'])."',
                                       '".pnVarPrepForStore($storefield['_UFAKEMAIL']['VALUE'])."',
                                       '".pnVarPrepForStore($storefield['_UREALNAME']['VALUE'])."',
                                       '".pnVarPrepForStore($storefield['_USERVIEWEMAL']['VALUE'])."',
                                       '".pnVarPrepForStore($avatar)."',
                                       '".pnVarPrepForStore($storefield['_YICQ']['VALUE'])."',
                                       '".pnVarPrepForStore($storefield['_YAIM']['VALUE'])."',
                                       '".pnVarPrepForStore($storefield['_YYIM']['VALUE'])."',
                                       '".pnVarPrepForStore($storefield['_YMSNM']['VALUE'])."',
                                       '".pnVarPrepForStore($timezoneoffset)."',
                                       '".pnVarPrepForStore($storefield['_YLOCATION']['VALUE'])."',
                                       '".pnVarPrepForStore($storefield['_YINTERESTS']['VALUE'])."',
                                       '".pnVarPrepForStore($storefield['_SIGNATURE']['VALUE'])."',
                                       '".pnVarPrepForStore($storefield['_EXTRAINFO']['VALUE'])."',
                                       '".pnVarPrepForStore($storefield['_YOURHOMEPAGE']['VALUE'])."',
                                       '".pnVarPrepForStore($user_regdate)."',
                                       '".pnVarPrepForStore($storynum)."',
                                       '".pnVarPrepForStore($commentlimit)."',
                                       '".pnVarPrepForStore($storefield['_USERTHEME']['VALUE'])."',
                                       '".pnVarPrepForStore($storefield['_THEME']['VALUE'])."',
                                       '".pnVarPrepForStore($cryptpass)."')");
    
            if($dbconn->ErrorNo()<>0) {
                echo $dbconn->ErrorNo(). ": ".$dbconn->ErrorMsg(). "<br>";
                error_log ($dbconn->ErrorNo(). ": ".$dbconn->ErrorMsg(). "<br>");
            } else {
                // get the generated id
                $uid = $dbconn->PO_Insert_ID($pntable['users'],$column['uid']);
                
                //Add dynamic values
                $dynarequired = $newdynafield;
				
				if (is_array($dynarequired) && !empty($dynarequired)) {
                	while(list($key, $val) = each($dynarequired)) {
	                    $inputfield = $key;
	                    $inputvalue = $val['VALUE'];
	                    if (is_array($inputvalue)) {
	                        $inputvalue = serialize($inputvalue);
	                    }
	                    pncNewUserSetVar($inputfield, $inputvalue, $uid);
	                }
				}
                
                // Add user to group
                $column = &$pntable['groups_column'];
                $result = $dbconn->Execute("SELECT $column[gid]
                                          FROM $pntable[groups]
                                          WHERE $column[name]='". pnConfigGetVar('defaultgroup') . "'");
                if($dbconn->ErrorNo()<>0) {
                    echo $dbconn->ErrorNo(). "Get default group: ".$dbconn->ErrorMsg(). "<br>";
                    error_log ($dbconn->ErrorNo(). "Get default group: ".$dbconn->ErrorMsg(). "<br>");
                } else {
                    if (!$result->EOF) {
                        list($gid) = $result->fields;
                        $result->Close();
                        $column = &$pntable['group_membership_column'];
                        $result = $dbconn->Execute("INSERT INTO $pntable[group_membership]
						                          (				$column[gid],
												   				$column[uid])
                                                    VALUES
												  (				".pnVarPrepForStore($gid).",
												  				".pnVarPrepForStore($uid).")");
                        if($dbconn->ErrorNo()<>0) {
                            echo $dbconn->ErrorNo(). "Create default group membership: ".$dbconn->ErrorMsg(). "<br>";
                            error_log ($dbconn->ErrorNo(). "Create default group membership: ".$dbconn->ErrorMsg(). "<br>");
                        }
                    }
                    $message = ""._WELCOMETO." $sitename!\n\n"._YOUUSEDEMAIL." ($email) "._TOREGISTER." $sitename. "._FOLLOWINGMEM."\n\n"._UNICKNAME." $uname\n"._UPASSWORD." $makepass";
                    $subject=""._USERPASS4." $uname";
                    $from="$adminmail";
                    if ($system == 1 || pnConfigGetVar('senduserpass') == "0") {
                        echo "<table align=\"center\"><tr><td><font class=\"pn-normal\">"._YOURPASSIS." <b>$makepass</b></font><br>";
                        echo "<a class=\"pn-normal\" href=\"user.php?module=NS-User&op=login&uname=$uname&pass=$makepass&url=user.php\">"._LOGIN."</a><font class=\"pn-normal\"> "._2CHANGEINFO."</font></td></tr></table>";
                    } else {
                        pnMail($email, $subject, $message, "From: $from\nX-Mailer: PHP/" . phpversion());
                        OpenTable();
                        echo "<font class=\"pn-normal\">"._YOUAREREGISTERED."</font>\n";
						if ($allowuserpass=="1") {
							echo "<br><br>\n"
								."<a class=\"pn-normal\" href=\"user.php?module=NS-User&op=login&uname=$uname&pass=$makepass&url=user.php\">"._LOGIN."</a>\n";
						}
                        CloseTable();
                    }
	                if (pnConfigGetVar('pnc_mail_adminwning')=="1") {
	                    $message = ""._UAMAILADMINNUSRREG1." ".$sitename."\n\n"._UAMAILADMINNUSRREG2." $uname\n"._UAMAILADMINNUSRREG3." $email\n\n"._UACYA."";
	                    $subject = ""._UAMAILADMINNUSRREG0." $sitename";
	                    $from="$adminmail";
	                    pnMail($adminmail, $subject, $message, "From: $from\nX-Mailer: PHP/" . phpversion());
	                }
                }
            }
        }
    } else {
        echo "$stop";
    }
    include 'footer.php';
}
?>