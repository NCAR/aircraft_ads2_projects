<?php // $Id: Version.php,v 1.1.1.1 2002/09/15 22:26:15 root Exp $ $Name:  $
$modversion['name'] = 'Messages';
$modversion['version'] = '1.0';
$modversion['description'] = 'Private messaging system for your site';
$modversion['official'] = 1;
$modversion['author'] = 'Richard Tirtadji AKA King Richard';
$modversion['contact'] = 'rtirtadji@hotmail.com';
$modversion['admin'] = 0;
?>