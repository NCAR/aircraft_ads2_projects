<?php
// Generated: $d$ by $id$
// ----------------------------------------------------------------------
// POST-NUKE Content Management System
// Copyright (C) 2001 by the Post-Nuke Development Team.
// http://www.postnuke.com/
// ----------------------------------------------------------------------
// Based on:
// PHP-NUKE Web Portal System - http://phpnuke.org/
// Thatware - http://thatware.org/
// ----------------------------------------------------------------------
// LICENSE
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License (GPL)
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// To read the license please visit http://www.gnu.org/copyleft/gpl.html
// ----------------------------------------------------------------------
// Original Author of file: Everyone
// Purpose of file: Translation files
// Translation team: Read credits in /docs/CREDITS.txt
// ----------------------------------------------------------------------
define('_AT','at');
define('_AWEBUSERFROM','A user from');
define('_CODEFOR','Confirmation code for');
define('_CODEREQUESTED','has just requested a confirmation code to change the password.');
define('_CONFIRMATIONCODE','Confirmation code');
define('_HASREQUESTED','has just requested that a password be sent.');
define('_HASTHISEMAIL','has this e-mail associated with it.');
define('_IFYOUDIDNOTASK','If you didn\'t asked for this, don\'t worry. You are seeing this message, not \'them\'. If this was an error just login with your new password.');
define('_IFYOUDIDNOTASK2','If you didn\'t ask for this, don\'t worry. Just delete this e-mail.');
define('_MAILED','mailed.');
define('_NOPROBLEM','No problem. Just type your username and click the send button. We will send an automatic e-mail to you with your \'Confirmation Code\', then you need to re-type your username and type your \'Confirmation Code\' and we will send you a new password.');
define('_PASSWORD4','Password for');
define('_PASSWORDLOST','Lost your password?');
define('_SENDPASSWORD','Send password');
define('_SORRYNOUSERINFO','Sorry, no corresponding user info was found');
define('_USERACCOUNT','The user account');
define('_USERPASSWORD4','User password for');
define('_WITHTHISCODE','With this code you can now create a new password at');
define('_YOUCANCHANGE','You can change it after you login at');
define('_YOURCODEIS','Your confirmation code is:');
define('_YOURNEWPASSWORD','Your new password is:');
?>