<?php // $Id: Version.php,v 1.1.1.1 2002/09/15 22:26:15 root Exp $ $Name:  $
$modversion['name']           = 'NS-Admin';
$modversion['version']        = '0.1';
$modversion['description']    = 'Core admin of Post-nuke project';
$modversion['credits']        = 'doc/credits.txt';
$modversion['help']           = 'doc/install.txt';
$modversion['changelog']      = 'doc/changelog.txt';
$modversion['license']        = 'doc/license.txt';
$modversion['official']       = true;
$modversion['author']         = 'Pascal Riva - The PostNuke Project';
$modversion['contact']        = 'pascal@e-riva.org';
$modversion['admin']          = '1';
$modversion['securityschema'] = array('Admin::' => '::');

?>
