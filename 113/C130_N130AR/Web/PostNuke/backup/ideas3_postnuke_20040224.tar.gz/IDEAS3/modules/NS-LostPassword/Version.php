<?php
$modversion['name'] = 'Lost Password';
$modversion['version'] = '0,5';
$modversion['description'] = 'Retrive lost password of a user.';
$modversion['credits'] = '';
$modversion['help'] = '';
$modversion['changelog'] = '';
$modversion['license'] = '';
$modversion['official'] = 1;
$modversion['author'] = 'David Sede�o Fernandez';
$modversion['contact'] = 'frimost@softhome.net';
$modversion['admin'] = 1;
?>