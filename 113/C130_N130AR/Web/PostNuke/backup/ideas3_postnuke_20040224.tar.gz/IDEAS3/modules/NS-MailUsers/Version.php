<?php
// $Id: Version.php,v 1.1.1.1 2002/09/15 22:26:15 root Exp $ $Name:  $
$modversion['name'] = 'Mail Users Admin';
$modversion['version'] = '1.3';
$modversion['description'] = 'Mail all/individual users on your site.';
$modversion['credits'] = '';
$modversion['help'] = '';
$modversion['changelog'] = '';
$modversion['license'] = '';
$modversion['official'] = 1;
$modversion['author'] = 'Christopher Thorjussen';
$modversion['contact'] = 'http://www.nukemodules.com';
$modversion['admin'] = 1;
$modversion['securityschema'] = array('MailUsers::' => 'User name::User ID');
?>