<?php
// $Id: pnversion.php,v 1.1.1.1 2002/09/15 22:26:15 root Exp $
$modversion['name'] = 'Ratings';
$modversion['version'] = '1.1';
$modversion['description'] = 'Rate PostNuke items';
$modversion['credits'] = 'pndocs/credits.txt';
$modversion['help'] = 'pndocs/help.txt';
$modversion['changelog'] = 'pndocs/changelog.txt';
$modversion['license'] = 'pndocs/license.txt';
$modversion['coding'] = 'pndocs/coding.txt';
$modversion['official'] = 1;
$modversion['author'] = 'Jim McDonald';
$modversion['contact'] = 'http://www.mcdee.net/';
$modversion['admin'] = 1;
$modversion['securityschema'] = array('Ratings::' => 'Module name:Rating type:Item ID');
?>