<?php
// Generated: $d$ by $id$
// ----------------------------------------------------------------------
// POST-NUKE Content Management System
// Copyright (C) 2001 by the Post-Nuke Development Team.
// http://www.postnuke.com/
// ----------------------------------------------------------------------
// Based on:
// PHP-NUKE Web Portal System - http://phpnuke.org/
// Thatware - http://thatware.org/
// ----------------------------------------------------------------------
// LICENSE
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License (GPL)
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// To read the license please visit http://www.gnu.org/copyleft/gpl.html
// ----------------------------------------------------------------------
// Original Author of file: Everyone
// Purpose of file: Translation files
// Translation team: Read credits in /docs/CREDITS.txt
// ----------------------------------------------------------------------
define('_ERRMODNOSUCHMODID','Error: No such module ID');
define('_FILESMISSING','Files missing');
define('_GENERATEMODS','Generate list of modules');
define('_HEADMODACTIONS','Actions');
define('_HEADMODDESC','Description');
define('_HEADMODDIR','Directory');
define('_HEADMODDISPNAME','Display name');
define('_HEADMODNAME','Module name');
define('_HEADMODSTATE','State');
define('_INITIALISE','Initialise');
define('_LIST','List');
define('_MODACTIVATED','Module activated');
define('_MODDEACTIVATED','Module deactivated');
define('_MODREGENERATED','Modules list regenerated from filesystem');
define('_MODREMOVED','Module removed');
define('_MODULES','Modules');
define('_MODULESACTIVATE','Activate');
define('_MODULESEDITNOAUTH','Not authorised to edit modules');
define('_MODULESFORTHIS','for this module');
define('_MODULESNEWDESCRIPTION','Enter new description');
define('_MODULESNEWNAME','Enter new name');
define('_MODULESNOAUTH','Not authorised to access Modules module');
define('_MODULESNOMODID','No module id supplied');
define('_MODULESNOMODS','No modules available');
define('_REGENERATE','Regenerate');
define('_REMOVE','Remove');
define('_UNINIT','Uninitialised');
define('_UPGRADE','Upgrade');
define('_UPGRADED','New version installed');
?>