<?php // $Id: changeexist.php,v 1.1.1.1 2003/06/18 19:21:50 fd Exp $
// ----------------------------------------------------------------------
// POST-NUKE Content Management System
// Copyright (C) 2001 by the Post-Nuke Development Team.
// http://www.postnuke.com/
// ----------------------------------------------------------------------
// Based on:
// PHP-NUKE Web Portal System - http://phpnuke.org/
// Thatware - http://thatware.org/
// ----------------------------------------------------------------------
// LICENSE
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License (GPL)
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// To read the license please visit http://www.gnu.org/copyleft/gpl.html
// ----------------------------------------------------------------------
// Original Author of this file: Chestnut !
// Purpose of this file: Allow Users to request deletion of their account
// ----------------------------------------------------------------------

list($dbconn) = pnDBGetConn();

modules_get_language();


function user_selfdeleteuser()
{

    list($dbconn) = pnDBGetConn();
    $pntable = pnDBGetTables();
	$uname = pnUserGetVar('uname');


	$gusers = &$pntable['users_column'];
	$gmember = &$pntable['group_membership_column'];
	$groups = &$pntable['groups_column'];
	$grpadm = "Admins";

	$sql = "SELECT		$gusers[uname]
			FROM		$pntable[users]
			LEFT JOIN	$pntable[group_membership]
			ON			$gusers[uid]=$gmember[uid]
			LEFT JOIN	$pntable[groups]
			ON			$gmember[gid]=$groups[gid]
			WHERE (		$gusers[uname]='".$uname."'
			AND			$groups[name]='".$grpadm."')";
	
	$groupexe = $dbconn->Execute($sql);

	list($groupeverif) = $groupexe->fields;
	if ($groupeverif) {
		include 'header.php';
		OpenTable();
		echo "$uname : "._UAISADMIN1."<br>";
		echo _UAISADMIN2;
		CloseTable();
		include 'footer.php';
		exit();
	}		
	
	$column = &$pntable['users_modrequest_column'];
    $sql = "SELECT	$column[uname]
			FROM	$pntable[users_modrequest]
			WHERE	$column[uname]='".pnVarPrepForStore($uname)."'
			AND		$column[udel]='1'";

    $result = $dbconn->Execute($sql);
	list($unameverif) = $result->fields;
	if ($unameverif) {
		include 'header.php';
		OpenTable();
		echo ""._UAASKAGAIN1."<br>"._UAASKAGAIN2."";
		//$stop = "oups";
		CloseTable();
		include 'footer.php';
		exit();
	}

	$column = &$pntable['users_column'];
    $sql = "SELECT	$column[uid],
					$column[email],
					$column[pass]
			FROM	$pntable[users]
			WHERE	$column[uname]='".pnVarPrepForStore($uname)."'";
    $result = $dbconn->Execute($sql);
	list($uid, $email, $upass) = $result->fields;

	include 'header.php';
	OpenTable();
	echo "".$unameverif." "._UASECURE1."<br>";
	echo ""._UASECURE2."<br>";
	echo _UASECURE3;
	CloseTable();
	OpenTable();
	echo "<table border=\"0\" width=\"40%\">";
	echo "<form method=\"post\" action=\"user.php\">";	
	echo "<tr><td>"._UAYOURUNAME."</td><td><input type=\"text\" name=\"uname\" size=\"35\" value=\"".pnVarPrepForDisplay($uname)."\"><br></td></tr>";
	echo "<tr><td>"._UAYOUREMAIL."</td><td><input type=\"text\" name=\"email\" size=\"35\" value=\"".pnVarPrepForDisplay($email)."\"><br></td></tr>";
	echo "<tr><td>"._UAYOURPASS."</td><td><input type=\"password\" name=\"passverif\" size=\"35\" value=\"\"><br></td></tr>";
	echo "<tr><td>"._UAREQREASON."</td><td><textarea name=\"reason\" cols=30 rows=5></textarea><br></td></tr>";
	echo "</table><br>";
	echo "<input type=\"hidden\" name =\"pass\" value=\"$upass\">";
	echo "<input type=\"hidden\" name=\"uid\" value=\"$uid\">";
	echo "<input type=\"hidden\" name=\"op\" value=\"SelfDeleteUser_Confirm\">";
	echo "<input type=\"submit\" value=\""._UAAPPROVED."\" class=\"pn-normal\" style=\"text-align:center\">";
	echo "</form>";
	CloseTable();
	include 'footer.php';
}

function user_selfdeleteuser_Confirm()
{

    list($dbconn) = pnDBGetConn();
    $pntable = pnDBGetTables();
    list($uid,
         $uname,
		 $passverif,
         $upass,
         $uname,
         $email,
		 $reason) = pnVarCleanFromInput('uid',
                                       	'uname',
                                       	'passverif',
									   	'pass',
                                       	'uname',
                                       	'email',
									   	'reason');
	$name = pnUserGetVar('name');

	include 'header.php';
	OpenTable();

	echo "<center>";
	echo "<font class=\"pn-title\">"._UAREQSAVING."</font><br><br>";
	echo _UAYOURID;
	if (!$uid) { //Totalement inutile mais bon, qui s'en plaindrait ?
		echo ""._UANO."<br>";
		$stop = "<b>"._UAIDNOTREG."</b>";
	} else {
		echo "".pnVarPrepForDisplay($uid)."<br>";
	}
	echo _UAYOURUNAME;
	if (!$uname) {
		echo ""._UANO."<br>";
		$stop = "<b>"._UAUNAMENOTREG."</b>";
	} else {
		echo "".pnVarPrepForDisplay($uname)."<br>";
	}
	echo _UAYOUREMAIL;
	if (!$email) {
		echo ""._UANO."<br>";
		$stop = "<b>"._UAMAILNOTREG."</b>";
	} else {
		echo "".pnVarPrepForDisplay($email)."<br>";
	}
	echo _UAPASSVERIF;
	if (!$passverif) {
		echo "<b>"._UAEMPTY."</b><br>";
		$stop = "<b>"._UAMUSTPASS."</b>";
	} else if (comparePasswords($passverif, $upass, $uname, substr($upass, 0, 2))) {
		echo " "._UAYES."<br>";
	} else {
		echo "<b>"._UAPASSDIFF."</b><br>";
		$stop = ""._UANGOODPASS."";
	}
	echo "</center>";
	CloseTable();

	$column = &$pntable['users_modrequest_column'];	
	if (!$stop) {
		
		$dbconn->Execute("INSERT INTO $pntable[users_modrequest] (
								$column[uid],
								$column[name],
                                $column[uname],
								$column[email],
								$column[pass],
								$column[udel],
								$column[reason])
							VALUES ('".pnVarPrepForStore($uid)."',
								'".pnVarPrepForStore($name)."',
								'".pnVarPrepForStore($uname)."',
								'".pnVarPrepForStore($email)."',
								'".pnVarPrepForStore($upass)."',
								'1',
								'".pnVarPrepForStore($reason)."')");

	}
    if(($dbconn->ErrorNo()<>0) and (!$stop)) {
        $stop=""._UAREQSAVEOK." <b>"._UANO."</b>";
		OpenTable();
		echo "<center><font class=\"pn-title\">"._UAREQWRITE."</font></center><br>";
		echo "<center>".$dbconn->ErrorNo(). ": ".$dbconn->ErrorMsg(). "</center><br>";
		echo "<center>$stop</center>";
		CloseTable();
    } else {
		OpenTable();
		echo "<center><font class=\"pn-title\">"._UAREQWRITE."</font></center><br>";
		echo "<center>"._UAREQSUCCESSFUL."<b>"._UAYES."</b></center>";
		CloseTable();
	}
			
	if (!$stop) {
		OpenTable();
		echo _UAREQEND;
		if (pnConfigGetVar('pnc_mail_modusrwning') == "1") {
			echo _UAREQEND1;
		}
		echo _UAREQEND1B;
		echo _UAREQEND2;
		CloseTable();
		
		if (pnConfigGetVar('senddeletemail')=="1") {
			$adminmail = pnConfigGetVar('adminmail');
			$sitename = pnConfigGetVar('sitename');
			$message = ""._UAUSRMAILOBJ." $sitename !\nReason : $reason";
			$subject = "$uname "._UAUSRMAILSBJ." $sitename !\n\n";
			$from = "$adminmail";
			pnMail($adminmail, $subject, $message, "From: $from\nX-Mailer: PHP/" . phpversion());
		}	
	} else {
		OpenTable();
		echo "<center>";
		echo ""._UAINFOWRONG."<br>";
		echo "</center>";
		CloseTable();
	}
	
	include 'footer.php';
}

switch ($op) {
        case "selfdeleteuser":
                user_selfdeleteuser();
                break;
        case "SelfDeleteUser_Confirm":
				user_selfdeleteuser_Confirm();
                break;
}

?>