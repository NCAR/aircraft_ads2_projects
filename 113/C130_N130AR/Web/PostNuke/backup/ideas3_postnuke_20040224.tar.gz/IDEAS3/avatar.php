<?
/******************************************************************** 
 Avatar list by Chestnut !
*********************************************************************/ 

//Change this to see more or less avatars on each line
$perline = 2;

echo "<div align=center><table width=400>\n";
echo "<tr>\n";
$path = "images/avatar/";
$handle=opendir("$path"); 
$count=0;
//sort($handle);
while ($file = readdir($handle)) {
    if ($file != "." and $file !=".." and $file != "blank.gif" and $file != "index.html") {
        if ($count>=$perline) {
            echo "</tr><tr>\n";
            $count=0;
        }
        echo "<td align=center><img src=\"images/avatar/".$file."\"><br>".$file."</td>\n";
        $count++;
    }
}
closedir($handle);
if ($count!=$perline) {
    echo "<td colspan=\"".$count."\">&nbsp;</td>\n";
}
echo "</tr></table>\n</div>\n";

// REMOVE // IN FRONT OF THE FOLLOWING TO INSERT THIS PART WHERE YOU WANT IT

//    echo "<script language=\"JavaScript\">
//    <!--
//    function OpenAvatarWindow(theURL,winName,features) { //v2.0
//        window.open(theURL,winName,features);
//    }
//    //-->
//    </script>[ <a onClick=\"OpenAvatarWindow('avatar.php','Avatars','scrollbars=yes,width=450,height=400')\">avatar list</a> ]

?>